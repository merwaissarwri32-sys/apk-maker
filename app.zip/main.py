import threading
import traceback

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView

import runner


class MerwisTest(App):
    title = "MERWIS AI Test"

    def build(self):
        root = BoxLayout(orientation="vertical", padding=16, spacing=12)
        root.add_widget(Label(
            text="MERWIS AI Phase 12 - TEST BUILD\n(backend only, offline)",
            size_hint_y=None, height=90, halign="center"))
        self.b1 = Button(text="Quick check (import modules)", size_hint_y=None, height=120)
        self.b2 = Button(text="Run all tests (1227) - keep app open", size_hint_y=None, height=120)
        self.b1.bind(on_release=lambda *_: self.go(runner.quick_check))
        self.b2.bind(on_release=lambda *_: self.go(lambda: runner.run_tests(self.prog)))
        root.add_widget(self.b1)
        root.add_widget(self.b2)
        self.bar = ProgressBar(max=1, value=0, size_hint_y=None, height=24)
        root.add_widget(self.bar)
        self.out = Label(text="Ready.", size_hint_y=None, halign="left", valign="top")
        self.out.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
        self.out.bind(texture_size=lambda w, s: setattr(w, "height", s[1]))
        sv = ScrollView()
        sv.add_widget(self.out)
        root.add_widget(sv)
        return root

    def prog(self, n, total):
        Clock.schedule_once(lambda dt: self._prog(n, total))

    def _prog(self, n, total):
        self.bar.max = max(total, 1)
        self.bar.value = n
        self.out.text = "Running... %d / %d" % (n, total)

    def go(self, fn):
        self.b1.disabled = self.b2.disabled = True
        self.out.text = "Running..."

        def work():
            try:
                r = fn()
            except Exception:
                r = "CRASH:\n" + traceback.format_exc()
            Clock.schedule_once(lambda dt: self.done(r))

        threading.Thread(target=work, daemon=True).start()

    def done(self, r):
        self.out.text = r
        self.b1.disabled = self.b2.disabled = False


MerwisTest().run()
