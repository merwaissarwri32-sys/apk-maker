[app]
title = MERWIS AI Test
package.name = merwistest
package.domain = org.merwis
source.dir = .
source.include_exts = py,md,txt,json
source.exclude_dirs = bin,.buildozer,__pycache__
version = 0.12.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.archs = arm64-v8a
android.api = 33
android.minapi = 24
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
