"""
Intraday Candidate schema - MERWIS AI, Phase 4 completion.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.intelligence.scalp_schema import PriceZone
from omnisystem_v5.quant.risk_reward import RiskRewardResult
from omnisystem_v5.schemas.enums import Timeframe


class IntradaySchemaError(ValueError):
    pass


class IntradayScenarioType(str, Enum):
    """The distinct scenario classification that separates Intraday
    logic from Scalp — Scalp has no equivalent classification."""

    TREND_CONTINUATION = "TREND_CONTINUATION"
    REVERSAL = "REVERSAL"
    BREAKOUT_RETEST = "BREAKOUT_RETEST"
    MEAN_REVERSION = "MEAN_REVERSION"


@dataclass(frozen=True)
class IntradayCandidateEvidence:
    structure_alignment: AlignmentLevel
    liquidity_alignment: AlignmentLevel
    momentum_alignment: AlignmentLevel
    volatility_alignment: AlignmentLevel
    vwap_alignment: AlignmentLevel
    fvg_alignment: AlignmentLevel
    higher_timeframe_alignment: AlignmentLevel      # distinct from scalp's generic mtf_alignment:
    execution_timeframe_alignment: AlignmentLevel   # intraday explicitly separates HTF bias from execution-TF structure

    def as_dict(self) -> dict:
        return {
            "structure_alignment": self.structure_alignment,
            "liquidity_alignment": self.liquidity_alignment,
            "momentum_alignment": self.momentum_alignment,
            "volatility_alignment": self.volatility_alignment,
            "vwap_alignment": self.vwap_alignment,
            "fvg_alignment": self.fvg_alignment,
            "higher_timeframe_alignment": self.higher_timeframe_alignment,
            "execution_timeframe_alignment": self.execution_timeframe_alignment,
        }


@dataclass(frozen=True)
class IntradayCandidate:
    symbol: str
    horizon: Horizon
    scenario_type: IntradayScenarioType
    direction: DirectionBias
    timeframe: Timeframe                     # execution timeframe (e.g. 15M)
    higher_timeframe: Timeframe              # e.g. 1H or 4H
    calculated_at: datetime

    expected_holding_period: ExpectedHoldingPeriod
    preferred_entry_zone: PriceZone
    invalidation_zone: PriceZone
    target_zones: tuple[PriceZone, ...]
    risk_reward: RiskRewardResult | None

    evidence: IntradayCandidateEvidence
    supporting_evidence: tuple[EvidenceItem, ...]
    contradicting_evidence: tuple[EvidenceItem, ...]

    market_regime: MarketRegime
    data_quality: str
    confirmation_required: bool
    status: ScalpStatus                      # reuses the same lifecycle vocabulary as Scalp
    reasons: tuple[str, ...] = field(default_factory=tuple)
    entry_zone_quality: AlignmentLevel = AlignmentLevel.NONE
    entry_zone_source: str = "unspecified"
    current_price: float = None

    def __post_init__(self):
        if self.horizon != Horizon.INTRADAY:
            raise IntradaySchemaError("IntradayCandidate.horizon must be INTRADAY")
        if self.direction == DirectionBias.NEUTRAL:
            raise IntradaySchemaError("IntradayCandidate.direction must be BULLISH or BEARISH")
        if self.calculated_at.tzinfo is None:
            raise IntradaySchemaError("calculated_at must be timezone-aware (UTC)")


@dataclass(frozen=True)
class IntradayDetectionResult:
    symbol: str
    timeframe: Timeframe
    calculated_at: datetime
    status: ScalpStatus
    candidates: tuple[IntradayCandidate, ...] = field(default_factory=tuple)
    rejection_reasons: tuple = field(default_factory=tuple)
    notes: tuple[str, ...] = field(default_factory=tuple)
