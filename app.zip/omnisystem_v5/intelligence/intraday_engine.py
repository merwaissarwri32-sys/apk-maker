"""
Intraday Intelligence Engine - MERWIS AI, Phase 4 completion.

Genuinely distinct from the Scalp Engine in four ways:

  1. REQUIRES a higher-timeframe read (default 1H, configurable) in
     addition to the execution timeframe (default 15M) - a scalp
     candidate never requires this; Intraday rejects outright on
     ConflictStatus.CONFLICTING between them (Scalp has no such gate).
  2. Classifies a scenario_type (TREND_CONTINUATION / REVERSAL /
     BREAKOUT_RETEST / MEAN_REVERSION) - Scalp has no scenario
     classification at all.
  3. MEAN_REVERSION is a scenario Scalp can never produce: it triggers
     specifically on RANGE regime + VWAP extension + RSI extreme, and
     its direction is the OPPOSITE of the prevailing execution-timeframe
     bias (fading an overextension).
  4. Its evidence set has no volume_alignment/risk_reward_quality
     components; instead it splits multi-timeframe evidence into
     higher_timeframe_alignment and execution_timeframe_alignment.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, StructureEventType
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.entry_zone import EntryZoneConfig, build_structural_entry_zone
from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    ConflictStatus,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    NoTradeReason,
    ScalpStatus,
    alignment_rank,
)
from omnisystem_v5.intelligence.event_risk import EventRiskContext
from omnisystem_v5.intelligence.intraday_schema import (
    IntradayCandidate,
    IntradayCandidateEvidence,
    IntradayDetectionResult,
    IntradayScenarioType,
)
from omnisystem_v5.intelligence.mtf_bias import aggregate_multi_timeframe_bias
from omnisystem_v5.intelligence.regime import classify_market_regime
from omnisystem_v5.intelligence.scalp_schema import PriceZone
from omnisystem_v5.quant.enums import InvalidationDirection, QuantStatus
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.schemas.enums import Timeframe

_BULLISH_BREAKS = {StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH}
_BEARISH_BREAKS = {StructureEventType.BOS_BEARISH, StructureEventType.CHOCH_BEARISH}


@dataclass(frozen=True)
class IntradayEngineConfig:
    execution_timeframe: Timeframe = Timeframe.M15
    higher_timeframe: Timeframe = Timeframe.H1
    min_reward_risk_ratio: float = 1.3
    min_confluence_count: int = 3
    breakout_retest_atr_multiple: float = 0.5
    mean_reversion_rsi_overbought: float = 70.0
    mean_reversion_rsi_oversold: float = 30.0
    mean_reversion_vwap_distance_pct: float = 1.5
    entry_zone: EntryZoneConfig = None

    def __post_init__(self):
        if self.entry_zone is None:
            object.__setattr__(self, "entry_zone", EntryZoneConfig())


def _point_zone(price: float) -> PriceZone:
    return PriceZone(bottom=price, top=price)


def _classify_scenario(direction, mtf_bias, exec_regime, exec_market_ctx, exec_quant_ctx, config):
    breaks = {DirectionBias.BULLISH: _BULLISH_BREAKS, DirectionBias.BEARISH: _BEARISH_BREAKS}[direction]
    recent_events = exec_market_ctx.structure_events[-3:]
    recent_break = next((e for e in reversed(recent_events) if e.event_type in breaks), None)

    if exec_regime == MarketRegime.REVERSAL and recent_break is not None:
        choch_types = {StructureEventType.CHOCH_BULLISH, StructureEventType.CHOCH_BEARISH}
        if recent_break.event_type in choch_types:
            opposing_bias = {DirectionBias.BULLISH: "DOWNTREND", DirectionBias.BEARISH: "UPTREND"}[direction]
            if mtf_bias is not None and mtf_bias.higher_timeframe_bias.value == opposing_bias:
                return IntradayScenarioType.REVERSAL, f"{recent_break.event_type.value} against higher-timeframe {opposing_bias}"

    if recent_break is not None:
        atr = exec_market_ctx.volatility.atr if exec_market_ctx.volatility else None
        wanted_side = InvalidationDirection.BELOW_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.ABOVE_PRICE
        nearby_swing_levels = [
            c for c in exec_quant_ctx.invalidation_candidates
            if c.source.value == "SWING_STRUCTURE" and c.direction == wanted_side
        ]
        if atr and nearby_swing_levels:
            nearest = min(nearby_swing_levels, key=lambda c: c.distance_abs)
            if nearest.distance_abs <= config.breakout_retest_atr_multiple * atr:
                return IntradayScenarioType.BREAKOUT_RETEST, f"price retesting broken level within {config.breakout_retest_atr_multiple}x ATR"

    if exec_regime == MarketRegime.RANGE:
        vwap = exec_quant_ctx.vwap_session
        rsi = exec_quant_ctx.momentum.rsi if exec_quant_ctx.momentum else None
        if vwap and vwap.distance_pct is not None and rsi is not None:
            if direction == DirectionBias.BULLISH and vwap.distance_pct <= -config.mean_reversion_vwap_distance_pct and rsi <= config.mean_reversion_rsi_oversold:
                return IntradayScenarioType.MEAN_REVERSION, f"price {vwap.distance_pct:.2f}% below VWAP, RSI={rsi:.1f} oversold"
            if direction == DirectionBias.BEARISH and vwap.distance_pct >= config.mean_reversion_vwap_distance_pct and rsi >= config.mean_reversion_rsi_overbought:
                return IntradayScenarioType.MEAN_REVERSION, f"price {vwap.distance_pct:.2f}% above VWAP, RSI={rsi:.1f} overbought"

    if mtf_bias is not None and mtf_bias.conflict_status == ConflictStatus.ALIGNED:
        wanted_bias = "UPTREND" if direction == DirectionBias.BULLISH else "DOWNTREND"
        if mtf_bias.higher_timeframe_bias.value == wanted_bias:
            return IntradayScenarioType.TREND_CONTINUATION, f"higher-timeframe and execution-timeframe both {wanted_bias}"

    return None, "no intraday scenario pattern matched"


def detect_intraday_candidate(
    symbol: str,
    mtf: MultiTimeframeMarketContext,
    quant_by_timeframe: dict,
    config: IntradayEngineConfig | None = None,
    event_risk: EventRiskContext | None = None,
) -> IntradayDetectionResult:
    config = config or IntradayEngineConfig()
    now = datetime.now(timezone.utc)
    exec_tf, higher_tf = config.execution_timeframe, config.higher_timeframe

    def _reject(reason, note):
        return IntradayDetectionResult(
            symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
            rejection_reasons=(reason,), notes=(note,),
        )

    exec_market_ctx = mtf.get(exec_tf)
    higher_market_ctx = mtf.get(higher_tf)
    if exec_market_ctx is None or higher_market_ctx is None:
        return _reject(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, f"missing MarketContext for {exec_tf.value} and/or {higher_tf.value}")

    exec_quant_ctx = quant_by_timeframe.get(exec_tf)
    higher_quant_ctx = quant_by_timeframe.get(higher_tf)
    if exec_quant_ctx is None or higher_quant_ctx is None:
        return _reject(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, f"missing QuantContext for {exec_tf.value} and/or {higher_tf.value}")

    if exec_market_ctx.status != ContextStatus.OK or exec_quant_ctx.status != QuantStatus.OK:
        return _reject(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, f"execution timeframe status not OK: market={exec_market_ctx.status.value}, quant={exec_quant_ctx.status.value}")
    if higher_market_ctx.status != ContextStatus.OK or higher_quant_ctx.status != QuantStatus.OK:
        return _reject(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, f"higher timeframe status not OK: market={higher_market_ctx.status.value}, quant={higher_quant_ctx.status.value}")

    mtf_bias = aggregate_multi_timeframe_bias(mtf, higher_tf, exec_tf)
    if mtf_bias.conflict_status == ConflictStatus.CONFLICTING:
        return _reject(NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE, mtf_bias.basis)

    exec_regime, regime_basis = classify_market_regime(exec_market_ctx, exec_quant_ctx)
    if exec_regime == MarketRegime.UNSTABLE_UNKNOWN:
        return _reject(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, regime_basis)

    exec_bull = build_bull_case(symbol, exec_market_ctx, exec_quant_ctx, mtf_bias)
    exec_bear = build_bear_case(symbol, exec_market_ctx, exec_quant_ctx, mtf_bias)

    candidates = []
    failure_reasons, failure_notes = [], []

    for direction, exec_case in ((DirectionBias.BULLISH, exec_bull), (DirectionBias.BEARISH, exec_bear)):
        scenario_type, scenario_basis = _classify_scenario(direction, mtf_bias, exec_regime, exec_market_ctx, exec_quant_ctx, config)

        if scenario_type is None:
            failure_notes.append(f"[{direction.value}] {scenario_basis}")
            continue
        if scenario_type != IntradayScenarioType.MEAN_REVERSION and not exec_case.has_scenario:
            failure_notes.append(f"[{direction.value}] scenario={scenario_type.value} but execution-timeframe structure does not support it")
            continue

        price = exec_quant_ctx.current_price
        if price is None:
            failure_reasons.append(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA)
            continue

        wanted_side = InvalidationDirection.BELOW_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.ABOVE_PRICE
        opposite_side = InvalidationDirection.ABOVE_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.BELOW_PRICE
        invalidation_candidates = [c for c in exec_quant_ctx.invalidation_candidates if c.direction == wanted_side and c.valid]
        target_candidates = [c for c in exec_quant_ctx.invalidation_candidates if c.direction == opposite_side and c.valid]

        if not invalidation_candidates:
            failure_reasons.append(NoTradeReason.NO_TRADE_NO_CONFIRMATION)
            failure_notes.append(f"[{direction.value}] no invalidation level available")
            continue
        if not target_candidates:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] no target level available")
            continue

        invalidation_level = min(invalidation_candidates, key=lambda c: c.distance_abs)
        target_level = min(target_candidates, key=lambda c: c.distance_abs)

        try:
            rr = calculate_risk_reward(entry=price, invalidation=invalidation_level.price, target=target_level.price)
        except ValueError as e:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] {e}")
            continue

        if rr.reward_risk_ratio is None or rr.reward_risk_ratio < config.min_reward_risk_ratio:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] reward:risk={rr.reward_risk_ratio} below minimum {config.min_reward_risk_ratio}")
            continue

        if event_risk is not None and event_risk.blocks_trading():
            failure_reasons.append(NoTradeReason.NO_TRADE_HIGH_EVENT_RISK)
            failure_notes.append(f"[{direction.value}] confirmed high-impact event risk")
            continue

        if direction == DirectionBias.BULLISH:
            higher_alignment = {"UPTREND": AlignmentLevel.STRONG, "DOWNTREND": AlignmentLevel.NONE}.get(
                mtf_bias.higher_timeframe_bias.value,
                AlignmentLevel.MODERATE if mtf_bias.conflict_status == ConflictStatus.PARTIAL else AlignmentLevel.WEAK,
            )
        else:
            higher_alignment = {"DOWNTREND": AlignmentLevel.STRONG, "UPTREND": AlignmentLevel.NONE}.get(
                mtf_bias.higher_timeframe_bias.value,
                AlignmentLevel.MODERATE if mtf_bias.conflict_status == ConflictStatus.PARTIAL else AlignmentLevel.WEAK,
            )

        evidence = IntradayCandidateEvidence(
            structure_alignment=exec_case.structure_alignment,
            liquidity_alignment=exec_case.liquidity_alignment,
            momentum_alignment=exec_case.momentum_alignment,
            volatility_alignment=exec_case.volatility_alignment,
            vwap_alignment=exec_case.vwap_alignment,
            fvg_alignment=exec_case.fvg_alignment,
            higher_timeframe_alignment=higher_alignment,
            execution_timeframe_alignment=exec_case.structure_alignment,
        )
        confluence = sum(1 for lv in evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE))
        if confluence < config.min_confluence_count:
            failure_reasons.append(NoTradeReason.NO_TRADE_NOISY_MARKET)
            failure_notes.append(f"[{direction.value}] only {confluence}/8 components reached MODERATE+")
            continue

        entry_zone, entry_quality, entry_source = build_structural_entry_zone(direction, exec_market_ctx, exec_quant_ctx, config.entry_zone)
        holding_period = ExpectedHoldingPeriod.HOURS_TO_DAYS if scenario_type == IntradayScenarioType.TREND_CONTINUATION else ExpectedHoldingPeriod.HOURS

        candidates.append(IntradayCandidate(
            symbol=symbol, horizon=Horizon.INTRADAY, scenario_type=scenario_type, direction=direction,
            timeframe=exec_tf, higher_timeframe=higher_tf, calculated_at=now,
            expected_holding_period=holding_period,
            preferred_entry_zone=entry_zone, invalidation_zone=_point_zone(invalidation_level.price),
            target_zones=(_point_zone(target_level.price),), risk_reward=rr, evidence=evidence,
            supporting_evidence=exec_case.supporting_evidence, contradicting_evidence=exec_case.contradicting_evidence,
            market_regime=exec_regime, data_quality=exec_quant_ctx.status.value, confirmation_required=True,
            status=ScalpStatus.ZONE_IDENTIFIED,
            reasons=(f"scenario={scenario_type.value}: {scenario_basis}", f"confluence={confluence}/8"),
            entry_zone_quality=entry_quality, entry_zone_source=entry_source, current_price=price,
        ))

    if not candidates:
        reasons = tuple(dict.fromkeys(failure_reasons)) or (NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE,)
        return IntradayDetectionResult(symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
                                        rejection_reasons=reasons, notes=tuple(failure_notes))

    ranked = sorted(candidates, key=lambda c: (
        sum(1 for lv in c.evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE)),
        c.risk_reward.reward_risk_ratio or 0.0,
    ), reverse=True)

    return IntradayDetectionResult(symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.ZONE_IDENTIFIED, candidates=tuple(ranked))
