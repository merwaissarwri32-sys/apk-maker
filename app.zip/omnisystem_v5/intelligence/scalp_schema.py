"""
Scalp Candidate schemas - MERWIS AI, Phase 4.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.quant.risk_reward import RiskRewardResult
from omnisystem_v5.schemas.enums import Timeframe


class ScalpSchemaError(ValueError):
    pass


@dataclass(frozen=True)
class PriceZone:
    bottom: float
    top: float

    def __post_init__(self):
        if self.top < self.bottom:
            raise ScalpSchemaError("PriceZone.top cannot be less than bottom")

    def contains(self, price: float) -> bool:
        return self.bottom <= price <= self.top

    def overlaps(self, low: float, high: float) -> bool:
        return low <= self.top and high >= self.bottom


@dataclass(frozen=True)
class ScalpCandidateEvidence:
    structure_alignment: AlignmentLevel
    liquidity_alignment: AlignmentLevel
    momentum_alignment: AlignmentLevel
    volume_alignment: AlignmentLevel
    volatility_alignment: AlignmentLevel
    vwap_alignment: AlignmentLevel
    fvg_alignment: AlignmentLevel
    risk_reward_quality: AlignmentLevel
    multi_timeframe_alignment: AlignmentLevel

    def as_dict(self) -> dict:
        return {
            "structure_alignment": self.structure_alignment,
            "liquidity_alignment": self.liquidity_alignment,
            "momentum_alignment": self.momentum_alignment,
            "volume_alignment": self.volume_alignment,
            "volatility_alignment": self.volatility_alignment,
            "vwap_alignment": self.vwap_alignment,
            "fvg_alignment": self.fvg_alignment,
            "risk_reward_quality": self.risk_reward_quality,
            "multi_timeframe_alignment": self.multi_timeframe_alignment,
        }


@dataclass(frozen=True)
class ScalpCandidate:
    symbol: str
    horizon: Horizon
    direction: DirectionBias
    timeframe: Timeframe
    calculated_at: datetime

    expected_holding_period: ExpectedHoldingPeriod
    preferred_entry_zone: PriceZone
    invalidation_zone: PriceZone
    target_zones: tuple[PriceZone, ...]
    risk_reward: RiskRewardResult | None

    evidence: ScalpCandidateEvidence
    supporting_evidence: tuple[EvidenceItem, ...]
    contradicting_evidence: tuple[EvidenceItem, ...]

    market_regime: MarketRegime
    data_quality: str
    confirmation_required: bool
    status: ScalpStatus
    reasons: tuple[str, ...] = field(default_factory=tuple)
    # Added in Phase 4 completion: reports HOW the entry zone was built
    # (structural confluence/FVG/SR/liquidity/VWAP vs. a weak fallback
    # band) so consumers never mistake a fallback band for real
    # structural evidence. Defaulted for backward compatibility with
    # existing construction call sites.
    entry_zone_quality: AlignmentLevel = AlignmentLevel.NONE
    entry_zone_source: str = "unspecified"
    # Added in Phase 7: the exact reference price the engine used
    # internally to select invalidation/target candidates and compute
    # R:R (quant_context.current_price at calculation time). Bridges
    # MUST use this as "entry" rather than the entry-zone midpoint -
    # using the zone midpoint independently can put entry on the wrong
    # side of invalidation/target relative to what was actually
    # validated, causing spurious SL_WRONG_SIDE rejections downstream.
    # Defaulted to None only for backward compatibility with
    # pre-existing manual test construction; always populated by
    # detect_scalp_candidate/detect_scalp_candidates.
    current_price: float = None

    def __post_init__(self):
        if self.horizon != Horizon.SCALP:
            raise ScalpSchemaError("ScalpCandidate.horizon must be SCALP")
        if self.direction == DirectionBias.NEUTRAL:
            raise ScalpSchemaError("ScalpCandidate.direction must be BULLISH or BEARISH")
        if self.calculated_at.tzinfo is None:
            raise ScalpSchemaError("calculated_at must be timezone-aware (UTC)")


@dataclass(frozen=True)
class ScalpDetectionResult:
    symbol: str
    timeframe: Timeframe
    calculated_at: datetime
    status: ScalpStatus
    candidates: tuple[ScalpCandidate, ...] = field(default_factory=tuple)
    rejection_reasons: tuple = field(default_factory=tuple)
    notes: tuple[str, ...] = field(default_factory=tuple)
