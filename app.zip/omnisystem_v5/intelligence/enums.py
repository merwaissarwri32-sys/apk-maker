"""
Enumerations for MERWIS AI — Phase 4 (Multi-Horizon Intelligence,
Bull/Bear Engines, Scalp Zone Detection).
"""

from enum import Enum


class Horizon(str, Enum):
    SCALP = "SCALP"
    INTRADAY = "INTRADAY"
    SHORT_SWING = "SHORT_SWING"


class DirectionBias(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class AlignmentLevel(str, Enum):
    """A qualitative, explainable alignment rating. Deliberately NOT a
    numeric score — every value must be traceable to an explicit rule,
    documented at its point of computation. Ordered STRONG > MODERATE >
    WEAK > NONE only for convenience comparisons; no arithmetic is ever
    performed on these values."""

    STRONG = "STRONG"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    NONE = "NONE"


_ALIGNMENT_RANK = {AlignmentLevel.NONE: 0, AlignmentLevel.WEAK: 1, AlignmentLevel.MODERATE: 2, AlignmentLevel.STRONG: 3}


def alignment_rank(level: AlignmentLevel) -> int:
    """Ordinal helper for comparisons/thresholds ONLY (e.g. 'count how many
    components are >= MODERATE'). Never used as a score to sum/average."""
    return _ALIGNMENT_RANK[level]


class ConflictStatus(str, Enum):
    ALIGNED = "ALIGNED"
    PARTIAL = "PARTIAL"
    CONFLICTING = "CONFLICTING"
    INSUFFICIENT = "INSUFFICIENT"


class MarketRegime(str, Enum):
    TREND = "TREND"
    RANGE = "RANGE"
    EXPANSION = "EXPANSION"
    COMPRESSION = "COMPRESSION"
    REVERSAL = "REVERSAL"
    HIGH_VOLATILITY = "HIGH_VOLATILITY"
    LOW_VOLATILITY = "LOW_VOLATILITY"
    UNSTABLE_UNKNOWN = "UNSTABLE_UNKNOWN"


class ScalpStatus(str, Enum):
    ZONE_IDENTIFIED = "ZONE_IDENTIFIED"
    CONFIRMATION_PENDING = "CONFIRMATION_PENDING"
    CONFIRMED = "CONFIRMED"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"
    NO_VALID_SCALP = "NO_VALID_SCALP"


class ExpectedHoldingPeriod(str, Enum):
    MINUTES = "MINUTES"
    MINUTES_TO_HOURS = "MINUTES_TO_HOURS"
    HOURS = "HOURS"
    HOURS_TO_DAYS = "HOURS_TO_DAYS"
    ONE_TO_THREE_DAYS = "ONE_TO_THREE_DAYS"


class NoTradeReason(str, Enum):
    NO_TRADE_INSUFFICIENT_DATA = "NO_TRADE_INSUFFICIENT_DATA"
    NO_TRADE_CONFLICTING_STRUCTURE = "NO_TRADE_CONFLICTING_STRUCTURE"
    NO_TRADE_POOR_RR = "NO_TRADE_POOR_RR"
    NO_TRADE_HIGH_EVENT_RISK = "NO_TRADE_HIGH_EVENT_RISK"
    NO_TRADE_HIGH_VOLATILITY = "NO_TRADE_HIGH_VOLATILITY"
    NO_TRADE_LOW_LIQUIDITY = "NO_TRADE_LOW_LIQUIDITY"
    NO_TRADE_NO_CONFIRMATION = "NO_TRADE_NO_CONFIRMATION"
    NO_TRADE_STALE_DATA = "NO_TRADE_STALE_DATA"
    NO_TRADE_UNSTABLE_REGIME = "NO_TRADE_UNSTABLE_REGIME"
    NO_TRADE_BALANCED_BULL_BEAR = "NO_TRADE_BALANCED_BULL_BEAR"
    NO_TRADE_NOISY_MARKET = "NO_TRADE_NOISY_MARKET"
    NO_TRADE_MISSING_TIMEFRAME_CONTEXT = "NO_TRADE_MISSING_TIMEFRAME_CONTEXT"
