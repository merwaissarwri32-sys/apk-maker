"""
Event-Risk architecture - MERWIS AI, Phase 4 completion (requirement 5).

MERWIS AI has NO real news/event data source in this phase. This module
exists purely to define the CONTRACT a future provider must satisfy,
and to make the absence of that data an explicit, propagated fact
rather than a silent assumption of safety.

CRITICAL RULE: the absence of event data is NEVER treated as "no event
risk". EVENT_DATA_UNAVAILABLE must read, to every downstream consumer,
as "we don't know" - not as a green light.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class EventRiskStatus(str, Enum):
    EVENT_DATA_AVAILABLE = "EVENT_DATA_AVAILABLE"
    EVENT_DATA_UNAVAILABLE = "EVENT_DATA_UNAVAILABLE"
    EVENT_DATA_STALE = "EVENT_DATA_STALE"


@dataclass(frozen=True)
class EventRiskContext:
    symbol: str
    status: EventRiskStatus
    checked_at: datetime
    # Only meaningful when status == EVENT_DATA_AVAILABLE. None in every
    # other case — never defaulted to False, since False would silently
    # assert "no risk" from the absence of information.
    high_impact_event_near: bool | None = None
    window_minutes: int | None = None
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        if self.checked_at.tzinfo is None:
            raise ValueError("checked_at must be timezone-aware (UTC)")
        if self.status != EventRiskStatus.EVENT_DATA_AVAILABLE and self.high_impact_event_near is not None:
            raise ValueError(
                "high_impact_event_near must be None unless status == EVENT_DATA_AVAILABLE — "
                "never report a risk verdict from data that isn't actually available"
            )

    def blocks_trading(self) -> bool:
        """Conservative helper: returns True only when we KNOW a
        high-impact event is near. Unavailable/stale data does NOT
        return True here — callers must handle uncertainty explicitly
        rather than relying on this method to encode caution for them
        (see NoTradeReason.NO_TRADE_HIGH_EVENT_RISK usage in engines)."""
        return self.status == EventRiskStatus.EVENT_DATA_AVAILABLE and bool(self.high_impact_event_near)


class EventRiskProvider(ABC):
    """Future news/economic-calendar integrations implement this."""

    @abstractmethod
    def get_event_risk(self, symbol: str, window_minutes: int = 60) -> EventRiskContext:
        raise NotImplementedError


class NullEventRiskProvider(EventRiskProvider):
    """The only provider implementation in this phase. ALWAYS reports
    EVENT_DATA_UNAVAILABLE — it never fabricates a "no risk" verdict.
    Wiring in a real provider later is a drop-in replacement; nothing
    else in the codebase needs to change."""

    def get_event_risk(self, symbol: str, window_minutes: int = 60) -> EventRiskContext:
        return EventRiskContext(
            symbol=symbol,
            status=EventRiskStatus.EVENT_DATA_UNAVAILABLE,
            checked_at=datetime.now(timezone.utc),
            window_minutes=window_minutes,
            reasons=("no event/news data provider is configured in this phase",),
        )
