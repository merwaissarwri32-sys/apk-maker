"""
Scalp Zone Candidate Engine - MERWIS AI, Phase 4 (+ Phase 4 completion).

Two public entry points:

  detect_scalp_candidate(...)   - ORIGINAL, UNCHANGED behavior: picks the
      single strongest-aligned direction (rejecting on NO_TRADE_BALANCED
      _BULL_BEAR when Bull and Bear are too close). Kept for backward
      compatibility with existing callers/tests.

  detect_scalp_candidates(..., max_candidates=N) - NEW: evaluates BOTH
      directions independently (when both engines report a scenario),
      builds a fully independent candidate for each side that passes
      every quality gate on its own merits, and returns up to
      `max_candidates` of them ranked by explainable, non-arbitrary
      criteria (confluence count, then reward:risk) - never a summed
      "magic score".

Both share the same per-direction candidate-construction logic
(`_build_candidate_for_direction`) so there is exactly one implementation
of the RR/invalidation/target/evidence/entry-zone rules to maintain.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.intelligence.directional import DirectionalCase
from omnisystem_v5.intelligence.entry_zone import EntryZoneConfig, build_structural_entry_zone
from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    NoTradeReason,
    ScalpStatus,
    alignment_rank,
)
from omnisystem_v5.intelligence.event_risk import EventRiskContext
from omnisystem_v5.intelligence.regime import classify_market_regime
from omnisystem_v5.intelligence.scalp_schema import (
    PriceZone,
    ScalpCandidate,
    ScalpCandidateEvidence,
    ScalpDetectionResult,
)
from omnisystem_v5.quant.enums import InvalidationDirection, QuantStatus
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.quant.schema import QuantContext

_STRONG_OR_MODERATE = {AlignmentLevel.STRONG, AlignmentLevel.MODERATE}


@dataclass(frozen=True)
class ScalpEngineConfig:
    min_reward_risk_ratio: float = 1.5
    min_confluence_count: int = 4          # of 9 components, how many must be >= MODERATE
    balanced_threshold: int = 1            # bull/bear "strength" difference <= this => balanced/rejected (singular API only)
    volume_lookback: int = 20
    fvg_distance_atr_multiple: float = 2.0
    entry_zone: EntryZoneConfig = None

    def __post_init__(self):
        if self.entry_zone is None:
            object.__setattr__(self, "entry_zone", EntryZoneConfig(max_distance_atr=self.fvg_distance_atr_multiple))


def _strength_score(case: DirectionalCase) -> int:
    """Ordinal count of components >= MODERATE — used ONLY to compare
    Bull vs Bear relative conviction, never surfaced as a magic score."""
    levels = case.alignment_components().values()
    return sum(1 for lv in levels if lv in _STRONG_OR_MODERATE)


def _confluence_count(evidence: ScalpCandidateEvidence) -> int:
    return sum(1 for lv in evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE))


def _volume_alignment(bars, lookback: int) -> tuple[AlignmentLevel, str]:
    if len(bars) < lookback + 1:
        return AlignmentLevel.NONE, "insufficient bars for volume comparison"
    recent = bars[-lookback:]
    avg_volume = sum(b.volume for b in recent[:-1]) / (len(recent) - 1)
    last_volume = recent[-1].volume
    if avg_volume <= 0:
        return AlignmentLevel.NONE, "no volume data available"
    ratio = last_volume / avg_volume
    if ratio >= 1.5:
        return AlignmentLevel.STRONG, f"last bar volume {ratio:.2f}x the {lookback}-bar average"
    if ratio >= 1.1:
        return AlignmentLevel.MODERATE, f"last bar volume {ratio:.2f}x the {lookback}-bar average"
    if ratio >= 0.8:
        return AlignmentLevel.WEAK, f"last bar volume {ratio:.2f}x the {lookback}-bar average"
    return AlignmentLevel.NONE, f"last bar volume only {ratio:.2f}x the {lookback}-bar average"


def _rr_quality(reward_risk_ratio: float | None) -> AlignmentLevel:
    if reward_risk_ratio is None:
        return AlignmentLevel.NONE
    if reward_risk_ratio >= 3.0:
        return AlignmentLevel.STRONG
    if reward_risk_ratio >= 2.0:
        return AlignmentLevel.MODERATE
    if reward_risk_ratio >= 1.5:
        return AlignmentLevel.WEAK
    return AlignmentLevel.NONE


def _point_zone(price: float) -> PriceZone:
    return PriceZone(bottom=price, top=price)


@dataclass(frozen=True)
class _BuildFailure:
    reason: NoTradeReason
    note: str


def _build_candidate_for_direction(
    symbol: str,
    direction: DirectionBias,
    case: DirectionalCase,
    market_context: MarketContext,
    quant_context: QuantContext,
    regime: MarketRegime,
    config: ScalpEngineConfig,
    now: datetime,
    event_risk: EventRiskContext | None,
) -> ScalpCandidate | _BuildFailure:
    price = quant_context.current_price
    if price is None:
        return _BuildFailure(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, "current price unavailable")

    wanted_side = InvalidationDirection.BELOW_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.ABOVE_PRICE
    opposite_side = InvalidationDirection.ABOVE_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.BELOW_PRICE

    invalidation_candidates = [c for c in quant_context.invalidation_candidates if c.direction == wanted_side and c.valid]
    target_candidates = [c for c in quant_context.invalidation_candidates if c.direction == opposite_side and c.valid]

    if not invalidation_candidates:
        return _BuildFailure(NoTradeReason.NO_TRADE_NO_CONFIRMATION, f"[{direction.value}] no defensible invalidation level found on the correct side")
    if not target_candidates:
        return _BuildFailure(NoTradeReason.NO_TRADE_POOR_RR, f"[{direction.value}] no measurable target level found")

    invalidation_level = min(invalidation_candidates, key=lambda c: c.distance_abs)
    target_level = min(target_candidates, key=lambda c: c.distance_abs)

    try:
        rr = calculate_risk_reward(entry=price, invalidation=invalidation_level.price, target=target_level.price)
    except ValueError as e:
        return _BuildFailure(NoTradeReason.NO_TRADE_POOR_RR, f"[{direction.value}] {e}")

    if rr.reward_risk_ratio is None or rr.reward_risk_ratio < config.min_reward_risk_ratio:
        return _BuildFailure(
            NoTradeReason.NO_TRADE_POOR_RR,
            f"[{direction.value}] reward:risk={rr.reward_risk_ratio} below minimum {config.min_reward_risk_ratio}",
        )

    if event_risk is not None and event_risk.blocks_trading():
        return _BuildFailure(
            NoTradeReason.NO_TRADE_HIGH_EVENT_RISK,
            f"[{direction.value}] high-impact event risk confirmed near {event_risk.window_minutes}min window",
        )

    volume_level, _volume_basis = _volume_alignment(list(market_context.bars), config.volume_lookback)
    rr_quality = _rr_quality(rr.reward_risk_ratio)

    evidence = ScalpCandidateEvidence(
        structure_alignment=case.structure_alignment,
        liquidity_alignment=case.liquidity_alignment,
        momentum_alignment=case.momentum_alignment,
        volume_alignment=volume_level,
        volatility_alignment=case.volatility_alignment,
        vwap_alignment=case.vwap_alignment,
        fvg_alignment=case.fvg_alignment,
        risk_reward_quality=rr_quality,
        multi_timeframe_alignment=case.multi_timeframe_alignment,
    )

    confluence = _confluence_count(evidence)
    if confluence < config.min_confluence_count:
        return _BuildFailure(
            NoTradeReason.NO_TRADE_NOISY_MARKET,
            f"[{direction.value}] only {confluence} of 9 components reached MODERATE+, need {config.min_confluence_count}",
        )

    entry_zone, entry_quality, entry_source = build_structural_entry_zone(
        direction, market_context, quant_context, config.entry_zone
    )

    if event_risk is None:
        event_reasons = ("event risk was not evaluated (no EventRiskContext supplied)",)
    elif event_risk.status.value != "EVENT_DATA_AVAILABLE":
        event_reasons = (f"event risk data status={event_risk.status.value} — uncertainty not resolved, not treated as safe",)
    else:
        event_reasons = ()

    return ScalpCandidate(
        symbol=symbol, horizon=Horizon.SCALP, direction=direction, timeframe=market_context.timeframe,
        calculated_at=now,
        expected_holding_period=ExpectedHoldingPeriod.MINUTES_TO_HOURS,
        preferred_entry_zone=entry_zone,
        invalidation_zone=_point_zone(invalidation_level.price),
        target_zones=(_point_zone(target_level.price),),
        risk_reward=rr,
        evidence=evidence,
        supporting_evidence=case.supporting_evidence,
        contradicting_evidence=case.contradicting_evidence,
        market_regime=regime,
        data_quality=quant_context.status.value,
        confirmation_required=True,
        status=ScalpStatus.ZONE_IDENTIFIED,
        reasons=(f"direction={direction.value}, confluence={confluence}/9",) + event_reasons,
        entry_zone_quality=entry_quality,
        entry_zone_source=entry_source,
        current_price=price,
    )


def detect_scalp_candidate(
    symbol: str,
    market_context: MarketContext,
    quant_context: QuantContext,
    bull_case: DirectionalCase,
    bear_case: DirectionalCase,
    config: ScalpEngineConfig | None = None,
    event_risk: EventRiskContext | None = None,
) -> ScalpDetectionResult:
    """ORIGINAL single-best-direction API. Behavior preserved exactly
    from the initial Phase 4 implementation."""
    config = config or ScalpEngineConfig()
    now = datetime.now(timezone.utc)
    tf = market_context.timeframe

    def _reject(reason: NoTradeReason, note: str) -> ScalpDetectionResult:
        return ScalpDetectionResult(
            symbol=symbol, timeframe=tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
            rejection_reasons=(reason,), notes=(note,),
        )

    if market_context.status != ContextStatus.OK or quant_context.status != QuantStatus.OK:
        return _reject(
            NoTradeReason.NO_TRADE_INSUFFICIENT_DATA,
            f"MarketContext.status={market_context.status.value}, QuantContext.status={quant_context.status.value}",
        )

    regime, regime_basis = classify_market_regime(market_context, quant_context)
    if regime == MarketRegime.UNSTABLE_UNKNOWN:
        return _reject(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, regime_basis)

    bull_strength = _strength_score(bull_case) if bull_case.has_scenario else 0
    bear_strength = _strength_score(bear_case) if bear_case.has_scenario else 0

    if not bull_case.has_scenario and not bear_case.has_scenario:
        return _reject(NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE, "neither Bull nor Bear engine found a structural scenario")

    if bull_case.has_scenario and bear_case.has_scenario and abs(bull_strength - bear_strength) <= config.balanced_threshold:
        return _reject(
            NoTradeReason.NO_TRADE_BALANCED_BULL_BEAR,
            f"bull_strength={bull_strength}, bear_strength={bear_strength} — evidence too balanced",
        )

    if bull_strength > bear_strength:
        direction, case = DirectionBias.BULLISH, bull_case
    else:
        direction, case = DirectionBias.BEARISH, bear_case

    result = _build_candidate_for_direction(symbol, direction, case, market_context, quant_context, regime, config, now, event_risk)
    if isinstance(result, _BuildFailure):
        return _reject(result.reason, result.note)

    return ScalpDetectionResult(symbol=symbol, timeframe=tf, calculated_at=now, status=ScalpStatus.ZONE_IDENTIFIED, candidates=(result,))


def detect_scalp_candidates(
    symbol: str,
    market_context: MarketContext,
    quant_context: QuantContext,
    bull_case: DirectionalCase,
    bear_case: DirectionalCase,
    config: ScalpEngineConfig | None = None,
    event_risk: EventRiskContext | None = None,
    max_candidates: int = 1,
) -> ScalpDetectionResult:
    """NEW multi-candidate API. Evaluates BULLISH and BEARISH independently
    (no "balanced" cross-comparison — each side either earns a candidate
    on its own evidence or it doesn't) and returns up to `max_candidates`,
    ranked by (confluence_count desc, reward:risk desc) — both explainable,
    neither a summed score."""
    config = config or ScalpEngineConfig()
    now = datetime.now(timezone.utc)
    tf = market_context.timeframe

    def _reject(reasons: tuple, notes: tuple) -> ScalpDetectionResult:
        return ScalpDetectionResult(
            symbol=symbol, timeframe=tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
            rejection_reasons=tuple(dict.fromkeys(reasons)), notes=tuple(notes),
        )

    if market_context.status != ContextStatus.OK or quant_context.status != QuantStatus.OK:
        return _reject(
            (NoTradeReason.NO_TRADE_INSUFFICIENT_DATA,),
            (f"MarketContext.status={market_context.status.value}, QuantContext.status={quant_context.status.value}",),
        )

    regime, regime_basis = classify_market_regime(market_context, quant_context)
    if regime == MarketRegime.UNSTABLE_UNKNOWN:
        return _reject((NoTradeReason.NO_TRADE_UNSTABLE_REGIME,), (regime_basis,))

    if not bull_case.has_scenario and not bear_case.has_scenario:
        return _reject((NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE,), ("neither Bull nor Bear engine found a structural scenario",))

    candidates: list[ScalpCandidate] = []
    failure_reasons: list[NoTradeReason] = []
    failure_notes: list[str] = []

    for direction, case in ((DirectionBias.BULLISH, bull_case), (DirectionBias.BEARISH, bear_case)):
        if not case.has_scenario:
            continue
        result = _build_candidate_for_direction(symbol, direction, case, market_context, quant_context, regime, config, now, event_risk)
        if isinstance(result, _BuildFailure):
            failure_reasons.append(result.reason)
            failure_notes.append(result.note)
        else:
            candidates.append(result)

    if not candidates:
        return _reject(tuple(failure_reasons) or (NoTradeReason.NO_TRADE_NO_CONFIRMATION,), tuple(failure_notes))

    candidates_ranked = sorted(
        candidates,
        key=lambda c: (_confluence_count(c.evidence), c.risk_reward.reward_risk_ratio or 0.0),
        reverse=True,
    )
    selected = tuple(candidates_ranked[:max_candidates])

    return ScalpDetectionResult(symbol=symbol, timeframe=tf, calculated_at=now, status=ScalpStatus.ZONE_IDENTIFIED, candidates=selected)
