"""
Short-Swing Candidate schema - MERWIS AI, Phase 4 completion.

Distinct from both Scalp and Intraday: adds an explicit event_risk_status
field (a multi-day hold crosses far more calendar risk than a scalp or
single intraday session) and restricts invalidation/target sourcing to
"major" structural sources only (see short_swing_engine.py).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.event_risk import EventRiskStatus
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.intelligence.scalp_schema import PriceZone
from omnisystem_v5.quant.risk_reward import RiskRewardResult
from omnisystem_v5.schemas.enums import Timeframe


class ShortSwingSchemaError(ValueError):
    pass


class ShortSwingScenarioType(str, Enum):
    HTF_TREND_CONTINUATION = "HTF_TREND_CONTINUATION"
    MAJOR_REVERSAL = "MAJOR_REVERSAL"
    RANGE_EXPANSION_BREAKOUT = "RANGE_EXPANSION_BREAKOUT"


@dataclass(frozen=True)
class ShortSwingCandidateEvidence:
    higher_timeframe_structure_alignment: AlignmentLevel   # 1D
    execution_timeframe_structure_alignment: AlignmentLevel  # 4H
    liquidity_alignment: AlignmentLevel
    momentum_alignment: AlignmentLevel
    volatility_alignment: AlignmentLevel
    higher_timeframe_fvg_alignment: AlignmentLevel

    def as_dict(self) -> dict:
        return {
            "higher_timeframe_structure_alignment": self.higher_timeframe_structure_alignment,
            "execution_timeframe_structure_alignment": self.execution_timeframe_structure_alignment,
            "liquidity_alignment": self.liquidity_alignment,
            "momentum_alignment": self.momentum_alignment,
            "volatility_alignment": self.volatility_alignment,
            "higher_timeframe_fvg_alignment": self.higher_timeframe_fvg_alignment,
        }


@dataclass(frozen=True)
class ShortSwingCandidate:
    symbol: str
    horizon: Horizon
    scenario_type: ShortSwingScenarioType
    direction: DirectionBias
    timeframe: Timeframe                # execution timeframe (4H)
    higher_timeframe: Timeframe         # 1D
    calculated_at: datetime

    expected_holding_period: ExpectedHoldingPeriod
    preferred_entry_zone: PriceZone
    invalidation_zone: PriceZone
    target_zones: tuple[PriceZone, ...]
    risk_reward: RiskRewardResult | None

    evidence: ShortSwingCandidateEvidence
    supporting_evidence: tuple[EvidenceItem, ...]
    contradicting_evidence: tuple[EvidenceItem, ...]

    market_regime: MarketRegime
    event_risk_status: EventRiskStatus
    data_quality: str
    confirmation_required: bool
    status: ScalpStatus
    reasons: tuple[str, ...] = field(default_factory=tuple)
    entry_zone_quality: AlignmentLevel = AlignmentLevel.NONE
    entry_zone_source: str = "unspecified"
    current_price: float = None

    def __post_init__(self):
        if self.horizon != Horizon.SHORT_SWING:
            raise ShortSwingSchemaError("ShortSwingCandidate.horizon must be SHORT_SWING")
        if self.direction == DirectionBias.NEUTRAL:
            raise ShortSwingSchemaError("ShortSwingCandidate.direction must be BULLISH or BEARISH")
        if self.calculated_at.tzinfo is None:
            raise ShortSwingSchemaError("calculated_at must be timezone-aware (UTC)")


@dataclass(frozen=True)
class ShortSwingDetectionResult:
    symbol: str
    timeframe: Timeframe
    calculated_at: datetime
    status: ScalpStatus
    candidates: tuple[ShortSwingCandidate, ...] = field(default_factory=tuple)
    rejection_reasons: tuple = field(default_factory=tuple)
    notes: tuple[str, ...] = field(default_factory=tuple)
