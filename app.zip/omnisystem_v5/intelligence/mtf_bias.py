"""
Multi-timeframe hierarchy: 1D -> 4H -> 1H -> 15M -> 5M -> 1M.

This module exposes the raw ingredients (higher_timeframe_bias,
execution_timeframe_structure, microstructure_confirmation,
conflict_status) for a FUTURE Master Decision Engine to interpret —
it deliberately does NOT force agreement between timeframes or resolve
the conflict itself (per Phase 4 requirement 11: "Do not require every
timeframe to agree perfectly").
"""

from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.context.enums import ContextStatus, TrendState
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.enums import ConflictStatus
from omnisystem_v5.schemas.enums import Timeframe

_TRENDING = {TrendState.UPTREND, TrendState.DOWNTREND}


@dataclass(frozen=True)
class MultiTimeframeBias:
    higher_timeframe: Timeframe
    execution_timeframe: Timeframe
    microstructure_timeframe: Timeframe | None
    higher_timeframe_bias: TrendState
    execution_timeframe_structure: TrendState
    microstructure_confirmation: TrendState | None
    conflict_status: ConflictStatus
    basis: str


def _trend_of(mtf: MultiTimeframeMarketContext, tf: Timeframe | None) -> TrendState:
    if tf is None:
        return TrendState.UNDEFINED
    ctx = mtf.get(tf)
    if ctx is None or ctx.status != ContextStatus.OK or ctx.trend is None:
        return TrendState.UNDEFINED
    return ctx.trend.state


def aggregate_multi_timeframe_bias(
    mtf: MultiTimeframeMarketContext,
    higher_timeframe: Timeframe,
    execution_timeframe: Timeframe,
    microstructure_timeframe: Timeframe | None = None,
) -> MultiTimeframeBias:
    higher_bias = _trend_of(mtf, higher_timeframe)
    exec_structure = _trend_of(mtf, execution_timeframe)
    micro = _trend_of(mtf, microstructure_timeframe) if microstructure_timeframe else None

    if higher_bias == TrendState.UNDEFINED or exec_structure == TrendState.UNDEFINED:
        conflict = ConflictStatus.INSUFFICIENT
        basis = "one or both of the higher/execution timeframes have no confirmed trend yet"
    elif higher_bias == exec_structure:
        conflict = ConflictStatus.ALIGNED
        basis = f"{higher_timeframe.value} and {execution_timeframe.value} both read {higher_bias.value}"
    elif higher_bias in _TRENDING and exec_structure == TrendState.RANGE:
        conflict = ConflictStatus.PARTIAL
        basis = f"{higher_timeframe.value}={higher_bias.value} but {execution_timeframe.value} is RANGE (no contradiction, just no confirmation yet)"
    elif exec_structure in _TRENDING and higher_bias == TrendState.RANGE:
        conflict = ConflictStatus.PARTIAL
        basis = f"{higher_timeframe.value}=RANGE but {execution_timeframe.value}={exec_structure.value} (local move without higher-timeframe confirmation)"
    else:
        conflict = ConflictStatus.CONFLICTING
        basis = f"{higher_timeframe.value}={higher_bias.value} directly opposes {execution_timeframe.value}={exec_structure.value}"

    return MultiTimeframeBias(
        higher_timeframe=higher_timeframe,
        execution_timeframe=execution_timeframe,
        microstructure_timeframe=microstructure_timeframe,
        higher_timeframe_bias=higher_bias,
        execution_timeframe_structure=exec_structure,
        microstructure_confirmation=micro,
        conflict_status=conflict,
        basis=basis,
    )
