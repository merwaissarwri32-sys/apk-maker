"""
Structural entry-zone construction - MERWIS AI, Phase 4 completion.

Shared by the Scalp, Intraday, and Short-Swing engines. Priority order
(documented, deterministic, no arbitrary scoring):

  1. CONFLUENCE  - two or more structural zones (FVG, liquidity zone,
                   support/resistance) overlap near price on the correct
                   side -> STRONG entry_zone_quality.
  2. FVG         - a single unfilled FVG of the matching type sits near
                   price on the correct side -> MODERATE.
  3. SR/LIQUIDITY- a single support/resistance level or liquidity zone
                   sits near price on the correct side -> WEAK.
  4. VWAP        - price is currently near a VWAP value (session or
                   rolling), used as a reaction-area proxy -> WEAK.
  5. FALLBACK    - none of the above: a narrow band around current
                   price, explicitly reported as NONE quality (weak/
                   insufficient structural evidence - never silently
                   presented as equal to a structural zone).

"Near price on the correct side" means: for BULLISH, the zone sits at
or below current price within `max_distance_atr` ATRs; for BEARISH, at
or above current price within the same distance.
"""

from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.context.enums import FVGType
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias
from omnisystem_v5.intelligence.scalp_schema import PriceZone


@dataclass(frozen=True)
class EntryZoneConfig:
    max_distance_atr: float = 2.0
    vwap_reaction_band_atr: float = 0.3
    fallback_band_atr: float = 0.1


@dataclass(frozen=True)
class StructuralZone:
    bottom: float
    top: float
    kind: str          # "FVG", "SR", "LIQUIDITY"
    label: str          # human-readable description


def _candidate_zones(direction: DirectionBias, market_context: MarketContext) -> list[StructuralZone]:
    price = market_context.current_price
    fvg_type = FVGType.BULLISH if direction == DirectionBias.BULLISH else FVGType.BEARISH
    zones: list[StructuralZone] = []

    for g in market_context.fair_value_gaps:
        if g.fvg_type != fvg_type or g.filled:
            continue
        on_correct_side = g.top <= price if direction == DirectionBias.BULLISH else g.bottom >= price
        if on_correct_side:
            zones.append(StructuralZone(bottom=g.bottom, top=g.top, kind="FVG", label=f"unfilled {fvg_type.value} FVG"))

    wanted_sr = "SUPPORT" if direction == DirectionBias.BULLISH else "RESISTANCE"
    for lv in market_context.support_resistance:
        if lv.level_type.value != wanted_sr:
            continue
        on_correct_side = lv.price <= price if direction == DirectionBias.BULLISH else lv.price >= price
        if on_correct_side:
            half = max(price * 0.0005, 0.01)
            zones.append(StructuralZone(bottom=lv.price - half, top=lv.price + half, kind="SR",
                                         label=f"{wanted_sr} level ({lv.touch_count} touches)"))

    wanted_liq = "EQUAL_LOWS" if direction == DirectionBias.BULLISH else "EQUAL_HIGHS"
    for z in market_context.liquidity_zones:
        if z.liquidity_type.value != wanted_liq:
            continue
        on_correct_side = z.price_level <= price if direction == DirectionBias.BULLISH else z.price_level >= price
        if on_correct_side:
            half = max(price * 0.0005, 0.01)
            zones.append(StructuralZone(bottom=z.price_level - half, top=z.price_level + half, kind="LIQUIDITY",
                                         label=f"{wanted_liq} liquidity ({z.touch_count} touches)"))

    return zones


def _zones_overlap(a: StructuralZone, b: StructuralZone) -> bool:
    return a.bottom <= b.top and b.bottom <= a.top


def build_structural_entry_zone(
    direction: DirectionBias,
    market_context: MarketContext,
    quant_context=None,
    config: EntryZoneConfig | None = None,
) -> tuple[PriceZone, AlignmentLevel, str]:
    config = config or EntryZoneConfig()
    price = market_context.current_price
    atr = market_context.volatility.atr if market_context.volatility else None

    if price is None:
        return PriceZone(bottom=0.0, top=0.0), AlignmentLevel.NONE, "current price unavailable"

    zones = _candidate_zones(direction, market_context)
    if atr:
        zones = [z for z in zones if min(abs(price - z.bottom), abs(price - z.top)) <= config.max_distance_atr * atr]

    if zones:
        zones_sorted = sorted(zones, key=lambda z: min(abs(price - z.bottom), abs(price - z.top)))
        nearest = zones_sorted[0]
        overlapping = [z for z in zones_sorted[1:] if _zones_overlap(nearest, z)]
        if overlapping:
            all_bottoms = [nearest.bottom] + [z.bottom for z in overlapping]
            all_tops = [nearest.top] + [z.top for z in overlapping]
            kinds = {nearest.kind} | {z.kind for z in overlapping}
            zone = PriceZone(bottom=min(all_bottoms), top=max(all_tops))
            return zone, AlignmentLevel.STRONG, f"confluence of {', '.join(sorted(kinds))} near price"

        if nearest.kind == "FVG":
            return PriceZone(bottom=nearest.bottom, top=nearest.top), AlignmentLevel.MODERATE, nearest.label
        return PriceZone(bottom=nearest.bottom, top=nearest.top), AlignmentLevel.WEAK, nearest.label

    # VWAP reaction-area proxy (only available when a QuantContext is supplied)
    if atr and quant_context is not None:
        for vwap_price, vwap_name in _vwap_candidates(quant_context):
            if vwap_price is not None and abs(price - vwap_price) <= config.vwap_reaction_band_atr * atr:
                band = config.vwap_reaction_band_atr * atr
                return (
                    PriceZone(bottom=vwap_price - band, top=vwap_price + band),
                    AlignmentLevel.WEAK,
                    f"price reacting near {vwap_name}",
                )

    band = (atr * config.fallback_band_atr) if atr else (price * 0.001)
    return (
        PriceZone(bottom=price - band, top=price + band),
        AlignmentLevel.NONE,
        "no structural entry-zone evidence found (FVG/SR/liquidity/VWAP) — "
        "falling back to a narrow band around current price; entry zone is weak/insufficient",
    )


def _vwap_candidates(quant_context):
    if quant_context is None:
        return []
    out = []
    if quant_context.vwap_session and quant_context.vwap_session.value is not None:
        out.append((quant_context.vwap_session.value, "session VWAP"))
    if quant_context.vwap_rolling and quant_context.vwap_rolling.value is not None:
        out.append((quant_context.vwap_rolling.value, "rolling VWAP"))
    return out
