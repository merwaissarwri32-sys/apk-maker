"""
Market Regime classification — deterministic, rule-based, NOT an AI
judgment (per Phase 4 requirement 10).

This is explicitly a HEURISTIC precedence rule over already-computed
Phase 2/3 outputs (TrendState, VolatilityRegime, VolatilityPhase, and
recent CHoCH events) — not a statistically validated regime-detection
model. That limitation is intentional and documented here; refining
this into a more rigorous regime model is left for a future phase.

Precedence (first match wins), documented explicitly so the result is
always traceable to one specific rule:

  1. REVERSAL         — a CHoCH event (either direction) occurred among
                         the most recent `reversal_lookback` structure
                         events. A character change takes priority over
                         everything else because it invalidates the
                         relevance of the prior trend/volatility read.
  2. EXPANSION         — VolatilityPhase.EXPANSION
  3. COMPRESSION       — VolatilityPhase.CONTRACTION
  4. TREND             — TrendState.UPTREND or DOWNTREND
  5. RANGE             — TrendState.RANGE
  6. HIGH_VOLATILITY   — VolatilityRegime.HIGH (only reached if trend is
                         UNDEFINED and volatility phase is STABLE)
  7. LOW_VOLATILITY    — VolatilityRegime.LOW (same conditions)
  8. UNSTABLE_UNKNOWN  — anything else (including missing/invalid
                         MarketContext or QuantContext)
"""

from __future__ import annotations

from omnisystem_v5.context.enums import ContextStatus, StructureEventType, TrendState
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.intelligence.enums import MarketRegime
from omnisystem_v5.quant.enums import QuantStatus, VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.schema import QuantContext

_CHOCH_TYPES = {StructureEventType.CHOCH_BULLISH, StructureEventType.CHOCH_BEARISH}


def classify_market_regime(
    market_context: MarketContext,
    quant_context: QuantContext,
    reversal_lookback: int = 3,
) -> tuple[MarketRegime, str]:
    if market_context.status != ContextStatus.OK or quant_context.status != QuantStatus.OK:
        return (
            MarketRegime.UNSTABLE_UNKNOWN,
            f"MarketContext.status={market_context.status.value}, "
            f"QuantContext.status={quant_context.status.value} — cannot classify regime",
        )

    recent_events = market_context.structure_events[-reversal_lookback:]
    if any(e.event_type in _CHOCH_TYPES for e in recent_events):
        choch = next(e for e in reversed(recent_events) if e.event_type in _CHOCH_TYPES)
        return MarketRegime.REVERSAL, f"recent {choch.event_type.value} at {choch.timestamp.isoformat()}"

    phase = quant_context.volatility.phase if quant_context.volatility else None
    if phase == VolatilityPhase.EXPANSION:
        return MarketRegime.EXPANSION, "volatility phase = EXPANSION"
    if phase == VolatilityPhase.CONTRACTION:
        return MarketRegime.COMPRESSION, "volatility phase = CONTRACTION"

    trend = market_context.trend.state if market_context.trend else TrendState.UNDEFINED
    if trend in (TrendState.UPTREND, TrendState.DOWNTREND):
        return MarketRegime.TREND, f"trend state = {trend.value}"
    if trend == TrendState.RANGE:
        return MarketRegime.RANGE, "trend state = RANGE"

    regime = quant_context.volatility.regime if quant_context.volatility else None
    if regime == VolatilityRegime.HIGH:
        return MarketRegime.HIGH_VOLATILITY, "trend undefined, volatility regime = HIGH"
    if regime == VolatilityRegime.LOW:
        return MarketRegime.LOW_VOLATILITY, "trend undefined, volatility regime = LOW"

    return MarketRegime.UNSTABLE_UNKNOWN, "no regime rule matched (trend and volatility both inconclusive)"
