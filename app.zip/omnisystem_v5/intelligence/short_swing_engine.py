"""
Short-Swing Intelligence Engine - MERWIS AI, Phase 4 completion.

Distinct from Scalp and Intraday in five concrete ways:

  1. Timeframe hierarchy is 1D (higher) / 4H (execution) - one full
     level above Intraday's 1H/15M pairing.
  2. Invalidation/target candidates are restricted to "major" sources
     only (SWING_STRUCTURE, SUPPORT_RESISTANCE, LIQUIDITY_ZONE) -
     FVG boundaries are EXCLUDED as invalidation/target references,
     since a multi-day hold should not be stopped out by a small
     intraday imbalance. Neither Scalp nor Intraday apply this filter.
  3. Explicitly rejects on HIGH volatility regime
     (NoTradeReason.NO_TRADE_HIGH_VOLATILITY) - a regime a multi-day
     hold cannot safely ride out. Neither Scalp nor Intraday reject on
     this basis (they only downgrade the volatility_alignment score).
  4. Carries an explicit event_risk_status field on every candidate,
     surfaced regardless of outcome - a multi-day hold crosses far more
     calendar risk than a scalp or single session, so the uncertainty
     is always reported, not just used as a pass/fail gate.
  5. Its own scenario classification (HTF_TREND_CONTINUATION /
     MAJOR_REVERSAL / RANGE_EXPANSION_BREAKOUT) has no equivalent to
     Intraday's MEAN_REVERSION or BREAKOUT_RETEST - short swing does not
     fade ranges, and only treats a break as tradeable together with a
     volatility EXPANSION reading, never via retest proximity.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, StructureEventType
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.entry_zone import EntryZoneConfig, build_structural_entry_zone
from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    ConflictStatus,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    NoTradeReason,
    ScalpStatus,
    alignment_rank,
)
from omnisystem_v5.intelligence.event_risk import EventRiskContext, EventRiskStatus, NullEventRiskProvider
from omnisystem_v5.intelligence.mtf_bias import aggregate_multi_timeframe_bias
from omnisystem_v5.intelligence.regime import classify_market_regime
from omnisystem_v5.intelligence.scalp_schema import PriceZone
from omnisystem_v5.intelligence.short_swing_schema import (
    ShortSwingCandidate,
    ShortSwingCandidateEvidence,
    ShortSwingDetectionResult,
    ShortSwingScenarioType,
)
from omnisystem_v5.quant.enums import InvalidationDirection, InvalidationSource, QuantStatus, VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.schemas.enums import Timeframe

_BULLISH_BREAKS = {StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH}
_BEARISH_BREAKS = {StructureEventType.BOS_BEARISH, StructureEventType.CHOCH_BEARISH}
_CHOCH_TYPES = {StructureEventType.CHOCH_BULLISH, StructureEventType.CHOCH_BEARISH}
_MAJOR_SOURCES = {InvalidationSource.SWING_STRUCTURE, InvalidationSource.SUPPORT_RESISTANCE, InvalidationSource.LIQUIDITY_ZONE}


@dataclass(frozen=True)
class ShortSwingEngineConfig:
    higher_timeframe: Timeframe = Timeframe.D1
    execution_timeframe: Timeframe = Timeframe.H4
    min_reward_risk_ratio: float = 2.0
    min_confluence_count: int = 3
    entry_zone: EntryZoneConfig = None

    def __post_init__(self):
        if self.entry_zone is None:
            object.__setattr__(self, "entry_zone", EntryZoneConfig(max_distance_atr=3.0))


def _point_zone(price: float) -> PriceZone:
    return PriceZone(bottom=price, top=price)


def _classify_scenario(direction, mtf_bias, exec_regime, exec_market_ctx, exec_quant_ctx):
    breaks = {DirectionBias.BULLISH: _BULLISH_BREAKS, DirectionBias.BEARISH: _BEARISH_BREAKS}[direction]
    recent_events = exec_market_ctx.structure_events[-3:]
    recent_break = next((e for e in reversed(recent_events) if e.event_type in breaks), None)

    if recent_break is not None and recent_break.event_type in _CHOCH_TYPES:
        opposing_bias = {DirectionBias.BULLISH: "DOWNTREND", DirectionBias.BEARISH: "UPTREND"}[direction]
        if mtf_bias is not None and mtf_bias.higher_timeframe_bias.value == opposing_bias:
            return ShortSwingScenarioType.MAJOR_REVERSAL, f"{recent_break.event_type.value} on {exec_market_ctx.timeframe.value} against 1D {opposing_bias}"

    if recent_break is not None and exec_quant_ctx.volatility and exec_quant_ctx.volatility.phase == VolatilityPhase.EXPANSION:
        return ShortSwingScenarioType.RANGE_EXPANSION_BREAKOUT, f"{recent_break.event_type.value} coinciding with volatility EXPANSION"

    if mtf_bias is not None and mtf_bias.conflict_status == ConflictStatus.ALIGNED:
        wanted_bias = "UPTREND" if direction == DirectionBias.BULLISH else "DOWNTREND"
        if mtf_bias.higher_timeframe_bias.value == wanted_bias:
            return ShortSwingScenarioType.HTF_TREND_CONTINUATION, f"1D and {exec_market_ctx.timeframe.value} both {wanted_bias}"

    return None, "no short-swing scenario pattern matched"


def _htf_fvg_alignment(direction, higher_market_ctx):
    fvg_type_value = "BULLISH" if direction == DirectionBias.BULLISH else "BEARISH"
    price = higher_market_ctx.current_price
    atr = higher_market_ctx.volatility.atr if higher_market_ctx.volatility else None
    unfilled = [g for g in higher_market_ctx.fair_value_gaps if g.fvg_type.value == fvg_type_value and not g.filled]
    if not unfilled or price is None:
        return AlignmentLevel.NONE, "no unfilled 1D FVG in this direction"
    on_side = [g for g in unfilled if (g.top <= price if direction == DirectionBias.BULLISH else g.bottom >= price)]
    if not on_side:
        return AlignmentLevel.WEAK, "1D FVG exists but not positioned favorably"
    if atr:
        nearest = min(on_side, key=lambda g: abs(price - (g.top if direction == DirectionBias.BULLISH else g.bottom)))
        dist = abs(price - (nearest.top if direction == DirectionBias.BULLISH else nearest.bottom))
        if dist <= 3 * atr:
            return AlignmentLevel.STRONG, f"1D {fvg_type_value} FVG within 3x 1D-ATR"
    return AlignmentLevel.MODERATE, f"1D {fvg_type_value} FVG present on the favorable side"


def detect_short_swing_candidate(
    symbol: str,
    mtf: MultiTimeframeMarketContext,
    quant_by_timeframe: dict,
    config: ShortSwingEngineConfig | None = None,
    event_risk: EventRiskContext | None = None,
) -> ShortSwingDetectionResult:
    config = config or ShortSwingEngineConfig()
    now = datetime.now(timezone.utc)
    higher_tf, exec_tf = config.higher_timeframe, config.execution_timeframe

    if event_risk is None:
        event_risk = NullEventRiskProvider().get_event_risk(symbol)

    def _reject(reason, note):
        return ShortSwingDetectionResult(
            symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
            rejection_reasons=(reason,), notes=(note,),
        )

    exec_market_ctx = mtf.get(exec_tf)
    higher_market_ctx = mtf.get(higher_tf)
    if exec_market_ctx is None or higher_market_ctx is None:
        return _reject(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, f"missing MarketContext for {exec_tf.value} and/or {higher_tf.value}")

    exec_quant_ctx = quant_by_timeframe.get(exec_tf)
    higher_quant_ctx = quant_by_timeframe.get(higher_tf)
    if exec_quant_ctx is None or higher_quant_ctx is None:
        return _reject(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, f"missing QuantContext for {exec_tf.value} and/or {higher_tf.value}")

    if exec_market_ctx.status != ContextStatus.OK or exec_quant_ctx.status != QuantStatus.OK:
        return _reject(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, f"execution timeframe status not OK: market={exec_market_ctx.status.value}, quant={exec_quant_ctx.status.value}")
    if higher_market_ctx.status != ContextStatus.OK or higher_quant_ctx.status != QuantStatus.OK:
        return _reject(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, f"higher timeframe status not OK: market={higher_market_ctx.status.value}, quant={higher_quant_ctx.status.value}")

    if exec_quant_ctx.volatility and exec_quant_ctx.volatility.regime == VolatilityRegime.HIGH:
        return _reject(NoTradeReason.NO_TRADE_HIGH_VOLATILITY, f"{exec_tf.value} volatility regime=HIGH - unsuitable for a multi-day hold")

    mtf_bias = aggregate_multi_timeframe_bias(mtf, higher_tf, exec_tf)
    if mtf_bias.conflict_status == ConflictStatus.CONFLICTING:
        return _reject(NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE, mtf_bias.basis)

    exec_regime, regime_basis = classify_market_regime(exec_market_ctx, exec_quant_ctx)
    if exec_regime == MarketRegime.UNSTABLE_UNKNOWN:
        return _reject(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, regime_basis)

    exec_bull = build_bull_case(symbol, exec_market_ctx, exec_quant_ctx, mtf_bias)
    exec_bear = build_bear_case(symbol, exec_market_ctx, exec_quant_ctx, mtf_bias)
    higher_bull = build_bull_case(symbol, higher_market_ctx, higher_quant_ctx)
    higher_bear = build_bear_case(symbol, higher_market_ctx, higher_quant_ctx)

    candidates = []
    failure_reasons, failure_notes = [], []

    for direction, exec_case, higher_case in (
        (DirectionBias.BULLISH, exec_bull, higher_bull),
        (DirectionBias.BEARISH, exec_bear, higher_bear),
    ):
        scenario_type, scenario_basis = _classify_scenario(direction, mtf_bias, exec_regime, exec_market_ctx, exec_quant_ctx)
        if scenario_type is None:
            failure_notes.append(f"[{direction.value}] {scenario_basis}")
            continue
        if not exec_case.has_scenario:
            failure_notes.append(f"[{direction.value}] scenario={scenario_type.value} but 4H structure does not support it")
            continue

        price = exec_quant_ctx.current_price
        if price is None:
            failure_reasons.append(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA)
            continue

        wanted_side = InvalidationDirection.BELOW_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.ABOVE_PRICE
        opposite_side = InvalidationDirection.ABOVE_PRICE if direction == DirectionBias.BULLISH else InvalidationDirection.BELOW_PRICE

        invalidation_candidates = [
            c for c in exec_quant_ctx.invalidation_candidates
            if c.direction == wanted_side and c.valid and c.source in _MAJOR_SOURCES
        ]
        target_candidates = [
            c for c in exec_quant_ctx.invalidation_candidates
            if c.direction == opposite_side and c.valid and c.source in _MAJOR_SOURCES
        ]

        if not invalidation_candidates:
            failure_reasons.append(NoTradeReason.NO_TRADE_NO_CONFIRMATION)
            failure_notes.append(f"[{direction.value}] no MAJOR invalidation level available (FVG boundaries excluded for swing)")
            continue
        if not target_candidates:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] no MAJOR target level available")
            continue

        invalidation_level = min(invalidation_candidates, key=lambda c: c.distance_abs)
        target_level = min(target_candidates, key=lambda c: c.distance_abs)

        try:
            rr = calculate_risk_reward(entry=price, invalidation=invalidation_level.price, target=target_level.price)
        except ValueError as e:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] {e}")
            continue

        if rr.reward_risk_ratio is None or rr.reward_risk_ratio < config.min_reward_risk_ratio:
            failure_reasons.append(NoTradeReason.NO_TRADE_POOR_RR)
            failure_notes.append(f"[{direction.value}] reward:risk={rr.reward_risk_ratio} below minimum {config.min_reward_risk_ratio}")
            continue

        if event_risk.blocks_trading():
            failure_reasons.append(NoTradeReason.NO_TRADE_HIGH_EVENT_RISK)
            failure_notes.append(f"[{direction.value}] confirmed high-impact event risk within {event_risk.window_minutes}min window")
            continue

        htf_structure_alignment = higher_case.structure_alignment if higher_case.has_scenario else AlignmentLevel.NONE
        htf_fvg_alignment, _htf_fvg_basis = _htf_fvg_alignment(direction, higher_market_ctx)

        evidence = ShortSwingCandidateEvidence(
            higher_timeframe_structure_alignment=htf_structure_alignment,
            execution_timeframe_structure_alignment=exec_case.structure_alignment,
            liquidity_alignment=exec_case.liquidity_alignment,
            momentum_alignment=exec_case.momentum_alignment,
            volatility_alignment=exec_case.volatility_alignment,
            higher_timeframe_fvg_alignment=htf_fvg_alignment,
        )
        confluence = sum(1 for lv in evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE))
        if confluence < config.min_confluence_count:
            failure_reasons.append(NoTradeReason.NO_TRADE_NOISY_MARKET)
            failure_notes.append(f"[{direction.value}] only {confluence}/6 components reached MODERATE+")
            continue

        entry_zone, entry_quality, entry_source = build_structural_entry_zone(direction, exec_market_ctx, exec_quant_ctx, config.entry_zone)

        event_reason_note = f"event_risk_status={event_risk.status.value}"
        if event_risk.status != EventRiskStatus.EVENT_DATA_AVAILABLE:
            event_reason_note += " - uncertainty not resolved, not treated as safe for a multi-day hold"

        candidates.append(ShortSwingCandidate(
            symbol=symbol, horizon=Horizon.SHORT_SWING, scenario_type=scenario_type, direction=direction,
            timeframe=exec_tf, higher_timeframe=higher_tf, calculated_at=now,
            expected_holding_period=ExpectedHoldingPeriod.ONE_TO_THREE_DAYS,
            preferred_entry_zone=entry_zone, invalidation_zone=_point_zone(invalidation_level.price),
            target_zones=(_point_zone(target_level.price),), risk_reward=rr, evidence=evidence,
            supporting_evidence=exec_case.supporting_evidence, contradicting_evidence=exec_case.contradicting_evidence,
            market_regime=exec_regime, event_risk_status=event_risk.status,
            data_quality=exec_quant_ctx.status.value, confirmation_required=True, status=ScalpStatus.ZONE_IDENTIFIED,
            reasons=(f"scenario={scenario_type.value}: {scenario_basis}", f"confluence={confluence}/6", event_reason_note),
            entry_zone_quality=entry_quality, entry_zone_source=entry_source, current_price=price,
        ))

    if not candidates:
        reasons = tuple(dict.fromkeys(failure_reasons)) or (NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE,)
        return ShortSwingDetectionResult(symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.NO_VALID_SCALP,
                                          rejection_reasons=reasons, notes=tuple(failure_notes))

    ranked = sorted(candidates, key=lambda c: (
        sum(1 for lv in c.evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE)),
        c.risk_reward.reward_risk_ratio or 0.0,
    ), reverse=True)

    return ShortSwingDetectionResult(symbol=symbol, timeframe=exec_tf, calculated_at=now, status=ScalpStatus.ZONE_IDENTIFIED, candidates=tuple(ranked))
