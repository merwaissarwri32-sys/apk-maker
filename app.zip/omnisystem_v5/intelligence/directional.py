"""
DirectionalCase — the structured output of the Bull Engine and Bear
Engine. Each engine independently produces one of these; the two are
never required to agree, and either may report has_scenario=False.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.schemas.enums import Timeframe


@dataclass(frozen=True)
class DirectionalCase:
    symbol: str
    direction: DirectionBias      # BULLISH (Bull Engine) or BEARISH (Bear Engine) — never NEUTRAL
    timeframe: Timeframe
    calculated_at: datetime
    has_scenario: bool

    structure_alignment: AlignmentLevel
    liquidity_alignment: AlignmentLevel
    momentum_alignment: AlignmentLevel
    volatility_alignment: AlignmentLevel
    vwap_alignment: AlignmentLevel
    fvg_alignment: AlignmentLevel
    multi_timeframe_alignment: AlignmentLevel

    supporting_evidence: tuple[EvidenceItem, ...] = field(default_factory=tuple)
    contradicting_evidence: tuple[EvidenceItem, ...] = field(default_factory=tuple)
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        if self.direction == DirectionBias.NEUTRAL:
            raise ValueError("DirectionalCase.direction must be BULLISH or BEARISH, never NEUTRAL")
        if self.calculated_at.tzinfo is None:
            raise ValueError("calculated_at must be timezone-aware (UTC)")

    def alignment_components(self) -> dict:
        return {
            "structure_alignment": self.structure_alignment,
            "liquidity_alignment": self.liquidity_alignment,
            "momentum_alignment": self.momentum_alignment,
            "volatility_alignment": self.volatility_alignment,
            "vwap_alignment": self.vwap_alignment,
            "fvg_alignment": self.fvg_alignment,
            "multi_timeframe_alignment": self.multi_timeframe_alignment,
        }


def now_utc() -> datetime:
    return datetime.now(timezone.utc)
