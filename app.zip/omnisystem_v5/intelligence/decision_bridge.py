"""
Decision Bridge - MERWIS AI, Phase 6.

The ONLY module allowed to import both an intelligence/*.py candidate
type AND the decision/ package - mirrors risk_bridge.py's role exactly.
decision/ itself never imports intelligence/, quant/, or context/.

Maps each horizon candidate's own AlignmentLevel evidence into
decision.contracts.ScoreComponents using an explicit, documented
field-by-field correspondence - never a blanket copy-everything
mapping, so the correspondence stays auditable per horizon.
"""

from __future__ import annotations

from omnisystem_v5.decision.contracts import NormalizedCandidate, ScoreComponents
from omnisystem_v5.decision.enums import DataValidityState, QualityLevel
from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias
from omnisystem_v5.intelligence.intraday_schema import IntradayCandidate
from omnisystem_v5.intelligence.scalp_schema import ScalpCandidate
from omnisystem_v5.intelligence.short_swing_schema import ShortSwingCandidate
from omnisystem_v5.risk.enums import Direction

_DIRECTION_MAP = {DirectionBias.BULLISH: Direction.LONG, DirectionBias.BEARISH: Direction.SHORT}
_QUALITY_MAP = {
    AlignmentLevel.STRONG: QualityLevel.STRONG,
    AlignmentLevel.MODERATE: QualityLevel.MODERATE,
    AlignmentLevel.WEAK: QualityLevel.WEAK,
    AlignmentLevel.NONE: QualityLevel.NONE,
}


def _q(level):
    return _QUALITY_MAP[level]


def _entry_from_zone(zone):
    """Fallback ONLY - see _resolve_entry_price."""
    return (zone.bottom + zone.top) / 2.0


def _resolve_entry_price(candidate):
    """Root-cause fix (Phase 7) - see identical rationale in
    intelligence/risk_bridge.py. Kept as a separate copy (not a shared
    import) so decision_bridge.py and risk_bridge.py remain independent
    adapter files, matching the project's established one-way-bridge
    pattern."""
    if candidate.current_price is not None:
        return candidate.current_price
    return _entry_from_zone(candidate.preferred_entry_zone)


def from_scalp_candidate(candidate: ScalpCandidate) -> NormalizedCandidate:
    direction = _DIRECTION_MAP[candidate.direction]
    entry = _resolve_entry_price(candidate)
    sl = candidate.invalidation_zone.bottom
    tps = tuple(z.bottom for z in candidate.target_zones)

    quality = ScoreComponents(
        structural_quality=_q(candidate.evidence.structure_alignment),
        confirmation_quality=QualityLevel.MODERATE if candidate.status.value == "CONFIRMED" else QualityLevel.WEAK,
        risk_quality=_q(candidate.evidence.risk_reward_quality),
        reward_quality=_q(candidate.evidence.risk_reward_quality),
        timeframe_alignment=_q(candidate.evidence.multi_timeframe_alignment),
        data_quality=QualityLevel.STRONG if candidate.data_quality == "OK" else QualityLevel.WEAK,
        regime_compatibility=QualityLevel.NONE,
    )

    cid = NormalizedCandidate.make_id("ScalpEngine", candidate.symbol, direction, entry, sl, tps,
                                       candidate.horizon.value, candidate.calculated_at)
    return NormalizedCandidate(
        candidate_id=cid, source_engine="ScalpEngine", horizon=candidate.horizon.value,
        symbol=candidate.symbol, direction=direction, entry=entry, stop_loss=sl, take_profits=tps,
        generated_at=candidate.calculated_at, data_validity=DataValidityState.VALID, quality=quality,
        metadata={"entry_zone_quality": candidate.entry_zone_quality.value, "market_regime": candidate.market_regime.value},
    )


def from_intraday_candidate(candidate: IntradayCandidate) -> NormalizedCandidate:
    direction = _DIRECTION_MAP[candidate.direction]
    entry = _resolve_entry_price(candidate)
    sl = candidate.invalidation_zone.bottom
    tps = tuple(z.bottom for z in candidate.target_zones)

    quality = ScoreComponents(
        structural_quality=_q(candidate.evidence.structure_alignment),
        confirmation_quality=QualityLevel.WEAK,
        risk_quality=QualityLevel.MODERATE,
        reward_quality=QualityLevel.NONE,
        timeframe_alignment=_q(candidate.evidence.higher_timeframe_alignment),
        data_quality=QualityLevel.STRONG if candidate.data_quality == "OK" else QualityLevel.WEAK,
        regime_compatibility=QualityLevel.NONE,
    )

    cid = NormalizedCandidate.make_id("IntradayEngine", candidate.symbol, direction, entry, sl, tps,
                                       candidate.horizon.value, candidate.calculated_at)
    return NormalizedCandidate(
        candidate_id=cid, source_engine="IntradayEngine", horizon=candidate.horizon.value,
        symbol=candidate.symbol, direction=direction, entry=entry, stop_loss=sl, take_profits=tps,
        generated_at=candidate.calculated_at, data_validity=DataValidityState.VALID, quality=quality,
        metadata={"scenario_type": candidate.scenario_type.value, "market_regime": candidate.market_regime.value},
    )


def from_short_swing_candidate(candidate: ShortSwingCandidate) -> NormalizedCandidate:
    direction = _DIRECTION_MAP[candidate.direction]
    entry = _resolve_entry_price(candidate)
    sl = candidate.invalidation_zone.bottom
    tps = tuple(z.bottom for z in candidate.target_zones)

    quality = ScoreComponents(
        structural_quality=_q(candidate.evidence.higher_timeframe_structure_alignment),
        confirmation_quality=QualityLevel.WEAK,
        risk_quality=QualityLevel.MODERATE,
        reward_quality=QualityLevel.NONE,
        timeframe_alignment=_q(candidate.evidence.execution_timeframe_structure_alignment),
        data_quality=QualityLevel.STRONG if candidate.event_risk_status.value == "EVENT_DATA_AVAILABLE" else QualityLevel.WEAK,
        regime_compatibility=QualityLevel.NONE,
    )

    cid = NormalizedCandidate.make_id("ShortSwingEngine", candidate.symbol, direction, entry, sl, tps,
                                       candidate.horizon.value, candidate.calculated_at)
    return NormalizedCandidate(
        candidate_id=cid, source_engine="ShortSwingEngine", horizon=candidate.horizon.value,
        symbol=candidate.symbol, direction=direction, entry=entry, stop_loss=sl, take_profits=tps,
        generated_at=candidate.calculated_at, data_validity=DataValidityState.VALID, quality=quality,
        metadata={"scenario_type": candidate.scenario_type.value, "market_regime": candidate.market_regime.value,
                  "event_risk_status": candidate.event_risk_status.value},
    )
