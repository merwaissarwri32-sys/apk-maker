"""
Bear Intelligence Engine — MERWIS AI, Phase 4.

Independently evaluates MarketContext + QuantContext for BEARISH
evidence only, using its own bearish-specific rules (equal-highs
liquidity, supply/resistance, bearish FVGs, downside momentum). It does
not consult the Bull Engine's output and never derives its conclusion
by negating a bullish reading — see bull_engine.py module docstring for
the shared rationale.
"""

from __future__ import annotations

from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, FVGType, StructureEventType, TrendState
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.intelligence.directional import DirectionalCase
from omnisystem_v5.intelligence.enums import AlignmentLevel, ConflictStatus, DirectionBias
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.intelligence.mtf_bias import MultiTimeframeBias
from omnisystem_v5.quant.enums import QuantStatus, VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.schema import QuantContext

_BEARISH_BREAKS = {StructureEventType.BOS_BEARISH, StructureEventType.CHOCH_BEARISH}
_BEARISH_SWING_EVENTS = {StructureEventType.LOWER_HIGH, StructureEventType.LOWER_LOW}
_BULLISH_BREAKS = {StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH}


def _structure_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    events = market_context.structure_events
    recent_break = events[-1].event_type if events else None
    trend = market_context.trend.state if market_context.trend else TrendState.UNDEFINED

    if recent_break in _BEARISH_BREAKS and trend == TrendState.DOWNTREND:
        return AlignmentLevel.STRONG, f"most recent break={recent_break.value} and trend=DOWNTREND"
    if recent_break in _BEARISH_BREAKS or trend == TrendState.DOWNTREND:
        basis = f"most recent break={recent_break.value if recent_break else 'none'}, trend={trend.value}"
        return AlignmentLevel.MODERATE, basis
    if any(e.event_type in _BEARISH_SWING_EVENTS for e in events):
        return AlignmentLevel.WEAK, "some LOWER_HIGH/LOWER_LOW swings present, no confirmed break or downtrend"
    return AlignmentLevel.NONE, f"no bearish structural evidence (trend={trend.value})"


def _liquidity_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    equal_highs = [z for z in market_context.liquidity_zones if z.liquidity_type.value == "EQUAL_HIGHS"]
    bearish_breaks = [e for e in market_context.structure_events if e.event_type in _BEARISH_BREAKS]

    if equal_highs and bearish_breaks:
        for zone in equal_highs:
            confirming = [e for e in bearish_breaks if e.timestamp > zone.formed_at]
            if confirming:
                return (
                    AlignmentLevel.STRONG,
                    f"equal-highs liquidity at {zone.price_level} formed {zone.formed_at.isoformat()}, "
                    f"followed by {confirming[0].event_type.value} at {confirming[0].timestamp.isoformat()}",
                )
    if equal_highs:
        return AlignmentLevel.MODERATE, f"equal-highs liquidity resting above price at {equal_highs[0].price_level}, unconfirmed"
    resistances = [lv for lv in market_context.support_resistance if lv.level_type.value == "RESISTANCE"]
    if resistances:
        return AlignmentLevel.WEAK, f"resistance level at {resistances[0].price} with {resistances[0].touch_count} touches"
    return AlignmentLevel.NONE, "no bearish liquidity structure found"


def _momentum_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    m = quant_context.momentum
    if m is None:
        return AlignmentLevel.NONE, "momentum unavailable"
    checks = []
    if m.rsi is not None and m.rsi < 45:
        checks.append("RSI<45")
    if m.roc is not None and m.roc < 0:
        checks.append("ROC<0")
    if m.ema_relationship is not None and m.ema_relationship.value == "FAST_BELOW_SLOW":
        checks.append("EMA_fast<EMA_slow")

    if len(checks) >= 3:
        return AlignmentLevel.STRONG, " and ".join(checks)
    if len(checks) == 2:
        return AlignmentLevel.MODERATE, " and ".join(checks)
    if len(checks) == 1:
        return AlignmentLevel.WEAK, checks[0]
    return AlignmentLevel.NONE, "no bearish momentum signals"


def _volatility_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    v = quant_context.volatility
    if v is None or v.regime is None:
        return AlignmentLevel.NONE, "volatility unavailable"
    if v.phase == VolatilityPhase.EXPANSION and v.regime != VolatilityRegime.LOW:
        return AlignmentLevel.STRONG, f"volatility expanding, regime={v.regime.value}"
    if v.regime == VolatilityRegime.NORMAL:
        return AlignmentLevel.MODERATE, "volatility regime=NORMAL"
    if v.regime in (VolatilityRegime.LOW, VolatilityRegime.HIGH):
        return AlignmentLevel.WEAK, f"volatility regime={v.regime.value} (not clearly favorable)"
    return AlignmentLevel.NONE, "volatility inconclusive"


def _vwap_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    price = quant_context.current_price
    session = quant_context.vwap_session.value if quant_context.vwap_session else None
    rolling = quant_context.vwap_rolling.value if quant_context.vwap_rolling else None
    if price is None or (session is None and rolling is None):
        return AlignmentLevel.NONE, "VWAP unavailable"

    below_session = session is not None and price < session
    below_rolling = rolling is not None and price < rolling

    if below_session and below_rolling:
        return AlignmentLevel.STRONG, "price below both session and rolling VWAP"
    if below_session or below_rolling:
        return AlignmentLevel.MODERATE, "price below one of session/rolling VWAP"
    return AlignmentLevel.NONE, "price above both session and rolling VWAP"


def _fvg_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    price = market_context.current_price
    if price is None:
        return AlignmentLevel.NONE, "current price unavailable"
    atr = market_context.volatility.atr if market_context.volatility else None

    unfilled_bearish = [g for g in market_context.fair_value_gaps if g.fvg_type == FVGType.BEARISH and not g.filled]
    if not unfilled_bearish:
        return AlignmentLevel.NONE, "no unfilled bearish FVG"

    above_price = [g for g in unfilled_bearish if g.bottom >= price]
    if above_price and atr:
        nearest = min(above_price, key=lambda g: g.bottom - price)
        if (nearest.bottom - price) <= 2 * atr:
            return AlignmentLevel.STRONG, f"unfilled bearish FVG [{nearest.bottom},{nearest.top}] within 2x ATR above price"
        return AlignmentLevel.MODERATE, f"unfilled bearish FVG [{nearest.bottom},{nearest.top}] above price but beyond 2x ATR"
    if above_price:
        return AlignmentLevel.MODERATE, "unfilled bearish FVG above price (ATR unavailable for distance check)"
    return AlignmentLevel.WEAK, "unfilled bearish FVG exists but not positioned above current price"


def _mtf_alignment(mtf_bias: MultiTimeframeBias | None) -> tuple[AlignmentLevel, str]:
    if mtf_bias is None:
        return AlignmentLevel.NONE, "no multi-timeframe bias supplied"
    if mtf_bias.conflict_status == ConflictStatus.ALIGNED and mtf_bias.higher_timeframe_bias == TrendState.DOWNTREND:
        return AlignmentLevel.STRONG, mtf_bias.basis
    if mtf_bias.conflict_status == ConflictStatus.PARTIAL and TrendState.DOWNTREND in (
        mtf_bias.higher_timeframe_bias, mtf_bias.execution_timeframe_structure,
    ):
        return AlignmentLevel.MODERATE, mtf_bias.basis
    if mtf_bias.conflict_status == ConflictStatus.CONFLICTING and mtf_bias.execution_timeframe_structure == TrendState.DOWNTREND:
        return AlignmentLevel.WEAK, mtf_bias.basis
    return AlignmentLevel.NONE, mtf_bias.basis


def build_bear_case(
    symbol: str,
    market_context: MarketContext,
    quant_context: QuantContext,
    mtf_bias: MultiTimeframeBias | None = None,
) -> DirectionalCase:
    now = datetime.now(timezone.utc)

    if market_context.status != ContextStatus.OK or quant_context.status != QuantStatus.OK:
        return DirectionalCase(
            symbol=symbol, direction=DirectionBias.BEARISH, timeframe=market_context.timeframe,
            calculated_at=now, has_scenario=False,
            structure_alignment=AlignmentLevel.NONE, liquidity_alignment=AlignmentLevel.NONE,
            momentum_alignment=AlignmentLevel.NONE, volatility_alignment=AlignmentLevel.NONE,
            vwap_alignment=AlignmentLevel.NONE, fvg_alignment=AlignmentLevel.NONE,
            multi_timeframe_alignment=AlignmentLevel.NONE,
            reasons=(f"MarketContext.status={market_context.status.value} or QuantContext.status={quant_context.status.value}",),
        )

    structure, structure_basis = _structure_alignment(market_context)
    liquidity, liquidity_basis = _liquidity_alignment(market_context)
    momentum, momentum_basis = _momentum_alignment(quant_context)
    volatility, volatility_basis = _volatility_alignment(quant_context)
    vwap, vwap_basis = _vwap_alignment(quant_context)
    fvg, fvg_basis = _fvg_alignment(market_context)
    mtf, mtf_basis = _mtf_alignment(mtf_bias)

    tf = market_context.timeframe
    components = {
        "structure": (structure, structure_basis), "liquidity": (liquidity, liquidity_basis),
        "momentum": (momentum, momentum_basis), "volatility": (volatility, volatility_basis),
        "vwap": (vwap, vwap_basis), "fvg": (fvg, fvg_basis), "multi_timeframe": (mtf, mtf_basis),
    }
    supporting = tuple(
        EvidenceItem(factor=name, direction=DirectionBias.BEARISH, description=basis, timeframe=tf, source=name, timestamp=now)
        for name, (level, basis) in components.items() if level in (AlignmentLevel.STRONG, AlignmentLevel.MODERATE, AlignmentLevel.WEAK)
    )

    contradicting = []
    recent_bullish = [e for e in market_context.structure_events[-2:] if e.event_type in _BULLISH_BREAKS]
    for e in recent_bullish:
        contradicting.append(
            EvidenceItem(
                factor="structure", direction=DirectionBias.BULLISH,
                description=f"recent {e.event_type.value} at {e.timestamp.isoformat()} contradicts bearish case",
                timeframe=tf, source="structure_events", timestamp=e.timestamp,
            )
        )

    has_scenario = structure != AlignmentLevel.NONE
    reasons = () if has_scenario else ("no bearish structural alignment found — refusing to fabricate a scenario",)

    return DirectionalCase(
        symbol=symbol, direction=DirectionBias.BEARISH, timeframe=tf, calculated_at=now,
        has_scenario=has_scenario,
        structure_alignment=structure, liquidity_alignment=liquidity, momentum_alignment=momentum,
        volatility_alignment=volatility, vwap_alignment=vwap, fvg_alignment=fvg,
        multi_timeframe_alignment=mtf,
        supporting_evidence=supporting, contradicting_evidence=tuple(contradicting), reasons=reasons,
    )
