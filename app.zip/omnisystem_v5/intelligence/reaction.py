"""
Reaction-based confirmation - MERWIS AI, Phase 4 (requirement 9).

Distinguishes ZONE IDENTIFIED from TRADE CONFIRMED. A freshly detected
ScalpCandidate starts at ScalpStatus.ZONE_IDENTIFIED and is never
treated as tradeable until subsequent bars demonstrate:

  1. price actually entered the preferred_entry_zone, AND
  2. price closed back through the zone in the candidate's direction
     (a "reaction" — the deterministic proxy for structural
     confirmation used in this phase), AND
  3. the invalidation_zone was never breached along the way.

This is a simplified, fully deterministic proxy for what a discretionary
trader would call "confirmation" — it does not re-run swing/BOS
detection on the incoming bars. A more complete version (re-evaluating
CHoCH/BOS on the reaction leg itself) is left for a future phase; see
Known Limitations.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Sequence

from omnisystem_v5.intelligence.enums import DirectionBias, ScalpStatus
from omnisystem_v5.intelligence.scalp_schema import ScalpCandidate
from omnisystem_v5.schemas.market_data import OHLCVBar

_TERMINAL_STATUSES = {ScalpStatus.CONFIRMED, ScalpStatus.INVALIDATED, ScalpStatus.EXPIRED, ScalpStatus.NO_VALID_SCALP}


def _invalidation_breached(candidate: ScalpCandidate, bars: Sequence[OHLCVBar]) -> bool:
    if candidate.direction == DirectionBias.BULLISH:
        return any(b.close < candidate.invalidation_zone.bottom for b in bars)
    return any(b.close > candidate.invalidation_zone.top for b in bars)


def _entered_zone(candidate: ScalpCandidate, bars: Sequence[OHLCVBar]) -> bool:
    zone = candidate.preferred_entry_zone
    return any(zone.overlaps(b.low, b.high) for b in bars)


def _reaction_confirmed(candidate: ScalpCandidate, bars: Sequence[OHLCVBar]) -> bool:
    zone = candidate.preferred_entry_zone
    if candidate.direction == DirectionBias.BULLISH:
        return any(b.close > zone.top for b in bars)
    return any(b.close < zone.bottom for b in bars)


def evaluate_confirmation(candidate: ScalpCandidate, bars_after: Sequence[OHLCVBar]) -> ScalpCandidate:
    """Pure function: returns a NEW ScalpCandidate with an updated status.
    Never mutates the input. Bars must be in chronological order and
    dated after candidate.calculated_at (not enforced here — the caller
    owns data integrity, consistent with earlier phases)."""
    if candidate.status in _TERMINAL_STATUSES:
        return candidate
    if not bars_after:
        return candidate

    if _invalidation_breached(candidate, bars_after):
        return replace(candidate, status=ScalpStatus.INVALIDATED, confirmation_required=False)

    if not _entered_zone(candidate, bars_after):
        return replace(candidate, status=ScalpStatus.ZONE_IDENTIFIED)

    if _reaction_confirmed(candidate, bars_after):
        return replace(candidate, status=ScalpStatus.CONFIRMED, confirmation_required=False)

    return replace(candidate, status=ScalpStatus.CONFIRMATION_PENDING)
