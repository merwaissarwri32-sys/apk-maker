"""
Risk Bridge - MERWIS AI, Phase 5.

The ONLY module allowed to import both an intelligence/*.py candidate
type AND the risk/ package. The Risk Engine itself never imports
intelligence/, quant/, or context/ - this file is the one-way adapter
that keeps that boundary real instead of theoretical.

Current horizon engines produce a single point invalidation and a
single point target per candidate (see Known Limitations in the Phase
4 report) - so today TP2/TP3 are always None here. When a horizon
engine gains multi-target output, only this bridge needs to change.
"""

from __future__ import annotations

from omnisystem_v5.intelligence.enums import DirectionBias
from omnisystem_v5.intelligence.intraday_schema import IntradayCandidate
from omnisystem_v5.intelligence.scalp_schema import ScalpCandidate
from omnisystem_v5.intelligence.short_swing_schema import ShortSwingCandidate
from omnisystem_v5.risk.contracts import TradeCandidateInput
from omnisystem_v5.risk.enums import Direction

_DIRECTION_MAP = {
    DirectionBias.BULLISH: Direction.LONG,
    DirectionBias.BEARISH: Direction.SHORT,
}


def _entry_from_zone(zone) -> float:
    """Fallback ONLY - midpoint of the preferred entry zone. Used only
    when candidate.current_price is unavailable (e.g. a manually
    constructed candidate that predates the Phase 7 current_price
    field). Not used for real engine output - see resolve_entry_price."""
    return (zone.bottom + zone.top) / 2.0


def _resolve_entry_price(candidate) -> float:
    """Root-cause fix (Phase 7): the engine's invalidation/target/R:R
    selection is computed relative to quant_context.current_price, NOT
    the entry zone's midpoint. Using the zone midpoint as "entry" here
    could place entry on the wrong side of invalidation/target relative
    to what was actually validated internally (observed as spurious
    SL_WRONG_SIDE rejections downstream in the Risk Engine). Always
    prefer the engine's own current_price; fall back to the zone
    midpoint only for legacy/manually-built candidates that don't carry
    it."""
    if candidate.current_price is not None:
        return candidate.current_price
    return _entry_from_zone(candidate.preferred_entry_zone)


def from_scalp_candidate(candidate: ScalpCandidate, requested_risk_pct: float | None = None) -> TradeCandidateInput:
    return TradeCandidateInput(
        symbol=candidate.symbol,
        direction=_DIRECTION_MAP[candidate.direction],
        entry=_resolve_entry_price(candidate),
        stop_loss=candidate.invalidation_zone.bottom,
        take_profits=tuple(z.bottom for z in candidate.target_zones),
        horizon=candidate.horizon.value,
        source="ScalpEngine",
        requested_risk_pct=requested_risk_pct,
    )


def from_intraday_candidate(candidate: IntradayCandidate, requested_risk_pct: float | None = None) -> TradeCandidateInput:
    return TradeCandidateInput(
        symbol=candidate.symbol,
        direction=_DIRECTION_MAP[candidate.direction],
        entry=_resolve_entry_price(candidate),
        stop_loss=candidate.invalidation_zone.bottom,
        take_profits=tuple(z.bottom for z in candidate.target_zones),
        horizon=candidate.horizon.value,
        source=f"IntradayEngine:{candidate.scenario_type.value}",
        requested_risk_pct=requested_risk_pct,
    )


def from_short_swing_candidate(candidate: ShortSwingCandidate, requested_risk_pct: float | None = None) -> TradeCandidateInput:
    return TradeCandidateInput(
        symbol=candidate.symbol,
        direction=_DIRECTION_MAP[candidate.direction],
        entry=_resolve_entry_price(candidate),
        stop_loss=candidate.invalidation_zone.bottom,
        take_profits=tuple(z.bottom for z in candidate.target_zones),
        horizon=candidate.horizon.value,
        source=f"ShortSwingEngine:{candidate.scenario_type.value}",
        requested_risk_pct=requested_risk_pct,
    )
