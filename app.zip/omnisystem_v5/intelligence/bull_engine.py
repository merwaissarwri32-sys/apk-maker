"""
Bull Intelligence Engine — MERWIS AI, Phase 4.

Independently evaluates MarketContext + QuantContext for BULLISH
evidence only. It does not know what the Bear Engine concluded and
never negates a bearish reading to produce a bullish one — every
alignment component below is computed from its own bullish-specific
rule, so this engine can (and often should) report has_scenario=False
even when the Bear Engine reports a strong bearish case, and vice versa.

Each alignment rule is documented at its point of computation. These
are explicit, auditable heuristics over Phase 2/3 outputs — NOT a
statistically validated trading model. See Phase 4 report for the
consolidated list of limitations.
"""

from __future__ import annotations

from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, FVGType, StructureEventType, TrendState
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.intelligence.directional import DirectionalCase
from omnisystem_v5.intelligence.enums import AlignmentLevel, ConflictStatus, DirectionBias
from omnisystem_v5.intelligence.evidence import EvidenceItem
from omnisystem_v5.intelligence.mtf_bias import MultiTimeframeBias
from omnisystem_v5.quant.enums import QuantStatus, VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.schema import QuantContext

_BULLISH_BREAKS = {StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH}
_BULLISH_SWING_EVENTS = {StructureEventType.HIGHER_HIGH, StructureEventType.HIGHER_LOW}
_BEARISH_BREAKS = {StructureEventType.BOS_BEARISH, StructureEventType.CHOCH_BEARISH}


def _structure_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    events = market_context.structure_events
    recent_break = events[-1].event_type if events else None
    trend = market_context.trend.state if market_context.trend else TrendState.UNDEFINED

    if recent_break in _BULLISH_BREAKS and trend == TrendState.UPTREND:
        return AlignmentLevel.STRONG, f"most recent break={recent_break.value} and trend=UPTREND"
    if recent_break in _BULLISH_BREAKS or trend == TrendState.UPTREND:
        basis = f"most recent break={recent_break.value if recent_break else 'none'}, trend={trend.value}"
        return AlignmentLevel.MODERATE, basis
    if any(e.event_type in _BULLISH_SWING_EVENTS for e in events):
        return AlignmentLevel.WEAK, "some HIGHER_HIGH/HIGHER_LOW swings present, no confirmed break or uptrend"
    return AlignmentLevel.NONE, f"no bullish structural evidence (trend={trend.value})"


def _liquidity_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    equal_lows = [z for z in market_context.liquidity_zones if z.liquidity_type.value == "EQUAL_LOWS"]
    bullish_breaks = [e for e in market_context.structure_events if e.event_type in _BULLISH_BREAKS]

    if equal_lows and bullish_breaks:
        for zone in equal_lows:
            confirming = [e for e in bullish_breaks if e.timestamp > zone.formed_at]
            if confirming:
                return (
                    AlignmentLevel.STRONG,
                    f"equal-lows liquidity at {zone.price_level} formed {zone.formed_at.isoformat()}, "
                    f"followed by {confirming[0].event_type.value} at {confirming[0].timestamp.isoformat()}",
                )
    if equal_lows:
        return AlignmentLevel.MODERATE, f"equal-lows liquidity resting below price at {equal_lows[0].price_level}, unconfirmed"
    supports = [lv for lv in market_context.support_resistance if lv.level_type.value == "SUPPORT"]
    if supports:
        return AlignmentLevel.WEAK, f"support level at {supports[0].price} with {supports[0].touch_count} touches"
    return AlignmentLevel.NONE, "no bullish liquidity structure found"


def _momentum_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    m = quant_context.momentum
    if m is None:
        return AlignmentLevel.NONE, "momentum unavailable"
    checks = []
    if m.rsi is not None and m.rsi > 55:
        checks.append("RSI>55")
    if m.roc is not None and m.roc > 0:
        checks.append("ROC>0")
    if m.ema_relationship is not None and m.ema_relationship.value == "FAST_ABOVE_SLOW":
        checks.append("EMA_fast>EMA_slow")

    if len(checks) >= 3:
        return AlignmentLevel.STRONG, " and ".join(checks)
    if len(checks) == 2:
        return AlignmentLevel.MODERATE, " and ".join(checks)
    if len(checks) == 1:
        return AlignmentLevel.WEAK, checks[0]
    return AlignmentLevel.NONE, "no bullish momentum signals"


def _volatility_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    v = quant_context.volatility
    if v is None or v.regime is None:
        return AlignmentLevel.NONE, "volatility unavailable"
    if v.phase == VolatilityPhase.EXPANSION and v.regime != VolatilityRegime.LOW:
        return AlignmentLevel.STRONG, f"volatility expanding, regime={v.regime.value}"
    if v.regime == VolatilityRegime.NORMAL:
        return AlignmentLevel.MODERATE, "volatility regime=NORMAL"
    if v.regime in (VolatilityRegime.LOW, VolatilityRegime.HIGH):
        return AlignmentLevel.WEAK, f"volatility regime={v.regime.value} (not clearly favorable)"
    return AlignmentLevel.NONE, "volatility inconclusive"


def _vwap_alignment(quant_context: QuantContext) -> tuple[AlignmentLevel, str]:
    price = quant_context.current_price
    session = quant_context.vwap_session.value if quant_context.vwap_session else None
    rolling = quant_context.vwap_rolling.value if quant_context.vwap_rolling else None
    if price is None or (session is None and rolling is None):
        return AlignmentLevel.NONE, "VWAP unavailable"

    above_session = session is not None and price > session
    above_rolling = rolling is not None and price > rolling

    if above_session and above_rolling:
        return AlignmentLevel.STRONG, "price above both session and rolling VWAP"
    if above_session or above_rolling:
        return AlignmentLevel.MODERATE, "price above one of session/rolling VWAP"
    return AlignmentLevel.NONE, "price below both session and rolling VWAP"


def _fvg_alignment(market_context: MarketContext) -> tuple[AlignmentLevel, str]:
    price = market_context.current_price
    if price is None:
        return AlignmentLevel.NONE, "current price unavailable"
    atr = market_context.volatility.atr if market_context.volatility else None

    unfilled_bullish = [g for g in market_context.fair_value_gaps if g.fvg_type == FVGType.BULLISH and not g.filled]
    if not unfilled_bullish:
        return AlignmentLevel.NONE, "no unfilled bullish FVG"

    below_price = [g for g in unfilled_bullish if g.top <= price]
    if below_price and atr:
        nearest = min(below_price, key=lambda g: price - g.top)
        if (price - nearest.top) <= 2 * atr:
            return AlignmentLevel.STRONG, f"unfilled bullish FVG [{nearest.bottom},{nearest.top}] within 2x ATR below price"
        return AlignmentLevel.MODERATE, f"unfilled bullish FVG [{nearest.bottom},{nearest.top}] below price but beyond 2x ATR"
    if below_price:
        return AlignmentLevel.MODERATE, "unfilled bullish FVG below price (ATR unavailable for distance check)"
    return AlignmentLevel.WEAK, "unfilled bullish FVG exists but not positioned below current price"


def _mtf_alignment(mtf_bias: MultiTimeframeBias | None) -> tuple[AlignmentLevel, str]:
    if mtf_bias is None:
        return AlignmentLevel.NONE, "no multi-timeframe bias supplied"
    if mtf_bias.conflict_status == ConflictStatus.ALIGNED and mtf_bias.higher_timeframe_bias == TrendState.UPTREND:
        return AlignmentLevel.STRONG, mtf_bias.basis
    if mtf_bias.conflict_status == ConflictStatus.PARTIAL and TrendState.UPTREND in (
        mtf_bias.higher_timeframe_bias, mtf_bias.execution_timeframe_structure,
    ):
        return AlignmentLevel.MODERATE, mtf_bias.basis
    if mtf_bias.conflict_status == ConflictStatus.CONFLICTING and mtf_bias.execution_timeframe_structure == TrendState.UPTREND:
        return AlignmentLevel.WEAK, mtf_bias.basis
    return AlignmentLevel.NONE, mtf_bias.basis


def build_bull_case(
    symbol: str,
    market_context: MarketContext,
    quant_context: QuantContext,
    mtf_bias: MultiTimeframeBias | None = None,
) -> DirectionalCase:
    now = datetime.now(timezone.utc)

    if market_context.status != ContextStatus.OK or quant_context.status != QuantStatus.OK:
        return DirectionalCase(
            symbol=symbol, direction=DirectionBias.BULLISH, timeframe=market_context.timeframe,
            calculated_at=now, has_scenario=False,
            structure_alignment=AlignmentLevel.NONE, liquidity_alignment=AlignmentLevel.NONE,
            momentum_alignment=AlignmentLevel.NONE, volatility_alignment=AlignmentLevel.NONE,
            vwap_alignment=AlignmentLevel.NONE, fvg_alignment=AlignmentLevel.NONE,
            multi_timeframe_alignment=AlignmentLevel.NONE,
            reasons=(f"MarketContext.status={market_context.status.value} or QuantContext.status={quant_context.status.value}",),
        )

    structure, structure_basis = _structure_alignment(market_context)
    liquidity, liquidity_basis = _liquidity_alignment(market_context)
    momentum, momentum_basis = _momentum_alignment(quant_context)
    volatility, volatility_basis = _volatility_alignment(quant_context)
    vwap, vwap_basis = _vwap_alignment(quant_context)
    fvg, fvg_basis = _fvg_alignment(market_context)
    mtf, mtf_basis = _mtf_alignment(mtf_bias)

    tf = market_context.timeframe
    components = {
        "structure": (structure, structure_basis), "liquidity": (liquidity, liquidity_basis),
        "momentum": (momentum, momentum_basis), "volatility": (volatility, volatility_basis),
        "vwap": (vwap, vwap_basis), "fvg": (fvg, fvg_basis), "multi_timeframe": (mtf, mtf_basis),
    }
    supporting = tuple(
        EvidenceItem(factor=name, direction=DirectionBias.BULLISH, description=basis, timeframe=tf, source=name, timestamp=now)
        for name, (level, basis) in components.items() if level in (AlignmentLevel.STRONG, AlignmentLevel.MODERATE, AlignmentLevel.WEAK)
    )

    contradicting = []
    recent_bearish = [e for e in market_context.structure_events[-2:] if e.event_type in _BEARISH_BREAKS]
    for e in recent_bearish:
        contradicting.append(
            EvidenceItem(
                factor="structure", direction=DirectionBias.BEARISH,
                description=f"recent {e.event_type.value} at {e.timestamp.isoformat()} contradicts bullish case",
                timeframe=tf, source="structure_events", timestamp=e.timestamp,
            )
        )

    has_scenario = structure != AlignmentLevel.NONE
    reasons = () if has_scenario else ("no bullish structural alignment found — refusing to fabricate a scenario",)

    return DirectionalCase(
        symbol=symbol, direction=DirectionBias.BULLISH, timeframe=tf, calculated_at=now,
        has_scenario=has_scenario,
        structure_alignment=structure, liquidity_alignment=liquidity, momentum_alignment=momentum,
        volatility_alignment=volatility, vwap_alignment=vwap, fvg_alignment=fvg,
        multi_timeframe_alignment=mtf,
        supporting_evidence=supporting, contradicting_evidence=tuple(contradicting), reasons=reasons,
    )
