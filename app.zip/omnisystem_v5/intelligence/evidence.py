"""
A single structured piece of evidence — the atomic unit every engine in
Phase 4 uses to justify a conclusion. No engine emits free-form prose as
its reasoning; everything traceable is an EvidenceItem.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from omnisystem_v5.intelligence.enums import DirectionBias
from omnisystem_v5.schemas.enums import Timeframe


@dataclass(frozen=True)
class EvidenceItem:
    factor: str                 # e.g. "structure", "liquidity", "momentum", "vwap"
    direction: DirectionBias    # which side this evidence supports
    description: str            # human-readable, derived from actual computed values
    timeframe: Timeframe
    source: str                 # which underlying object/calculation produced this
    timestamp: datetime | None = None
