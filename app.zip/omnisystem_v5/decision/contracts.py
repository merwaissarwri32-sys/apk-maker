"""
Master Decision Contracts - MERWIS AI, Phase 6.

Forward-compatible by construction: every dataclass has a metadata
dict[str, str] escape hatch for future, non-breaking additions instead
of growing the schema itself for every small addition. Structural
fields already known to matter (direction, entry, SL/TP, risk result,
trace) are explicit, typed fields - metadata is for genuinely optional
extras only.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.decision.enums import (
    CandidateStatus,
    ConflictResolution,
    ConflictType,
    DataValidityState,
    DecisionOutcome,
    DecisionReasonCode,
    QualityLevel,
)
from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.risk.result import RiskAssessmentResult

DECISION_CONTRACT_VERSION = "1.0"


def _require_tz(value: datetime, name: str) -> None:
    if value.tzinfo is None:
        raise ValueError(f"{name} must be timezone-aware (UTC)")


@dataclass(frozen=True)
class ScoreComponents:
    structural_quality: QualityLevel = QualityLevel.NONE
    confirmation_quality: QualityLevel = QualityLevel.NONE
    risk_quality: QualityLevel = QualityLevel.NONE
    reward_quality: QualityLevel = QualityLevel.NONE
    timeframe_alignment: QualityLevel = QualityLevel.NONE
    conflict_penalty: QualityLevel = QualityLevel.NONE
    data_quality: QualityLevel = QualityLevel.NONE
    regime_compatibility: QualityLevel = QualityLevel.NONE

    def as_dict(self) -> dict:
        return {
            "structural_quality": self.structural_quality,
            "confirmation_quality": self.confirmation_quality,
            "risk_quality": self.risk_quality,
            "reward_quality": self.reward_quality,
            "timeframe_alignment": self.timeframe_alignment,
            "conflict_penalty": self.conflict_penalty,
            "data_quality": self.data_quality,
            "regime_compatibility": self.regime_compatibility,
        }


@dataclass(frozen=True)
class NormalizedCandidate:
    candidate_id: str
    source_engine: str
    horizon: str
    symbol: str
    direction: Direction
    entry: float
    stop_loss: float
    take_profits: tuple
    generated_at: datetime
    data_validity: DataValidityState = DataValidityState.VALID
    quality: ScoreComponents = field(default_factory=ScoreComponents)
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        _require_tz(self.generated_at, "generated_at")

    @staticmethod
    def make_id(source_engine, symbol, direction, entry, stop_loss, take_profits, horizon, generated_at) -> str:
        raw = f"{source_engine}|{symbol}|{direction.value}|{entry}|{stop_loss}|{take_profits}|{horizon}|{generated_at.isoformat()}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


@dataclass(frozen=True)
class ConflictRecord:
    conflict_type: ConflictType
    candidate_ids: tuple
    resolution: ConflictResolution
    surviving_candidate_id: object
    details: str


@dataclass(frozen=True)
class DecisionRecord:
    candidate_id: str
    source_engine: str
    direction: Direction
    status: CandidateStatus
    reasons: tuple = field(default_factory=tuple)


@dataclass(frozen=True)
class FinalDecision:
    decision_id: str
    decision_version: str
    policy_version: str
    generated_at: datetime

    outcome: DecisionOutcome
    symbol: object
    selected_candidate: object
    risk_result: object

    candidate_trace: tuple = field(default_factory=tuple)
    conflict_records: tuple = field(default_factory=tuple)
    data_validity_summary: DataValidityState = DataValidityState.VALID
    reason_code: DecisionReasonCode = DecisionReasonCode.NO_CANDIDATES_PROVIDED
    reasons: tuple = field(default_factory=tuple)
    audit_metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        _require_tz(self.generated_at, "generated_at")
        if self.outcome == DecisionOutcome.NO_TRADE and self.selected_candidate is not None:
            raise ValueError("NO_TRADE decisions cannot carry a selected_candidate")
        if self.outcome != DecisionOutcome.NO_TRADE and self.selected_candidate is None:
            raise ValueError(f"outcome={self.outcome.value} requires a selected_candidate")
        if self.outcome != DecisionOutcome.NO_TRADE and (self.risk_result is None or not self.risk_result.is_actionable):
            raise ValueError("a non-NO_TRADE decision requires an actionable RiskAssessmentResult - the risk gate cannot be bypassed")

    @staticmethod
    def make_id(symbol, outcome, generated_at, selected_candidate_id) -> str:
        raw = f"{symbol}|{outcome.value}|{generated_at.isoformat()}|{selected_candidate_id}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
