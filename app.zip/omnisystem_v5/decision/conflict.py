"""
Conflict detection and resolution - MERWIS AI, Phase 6.

Two independent stages, always run in this order:

  1. Same-engine duplicates: candidates from the SAME source_engine,
     SAME direction, with entries within duplicate_price_tolerance_pct
     of each other. Only the higher-ranked one survives.
  2. Directional conflicts: any two surviving candidates (regardless of
     engine) with OPPOSITE directions on the same symbol. Resolved by
     comparing rank keys - the winner must beat the loser on at least
     min_decisive_component_margin components (out of the 8 total) to
     be considered decisive; otherwise BOTH are dropped and the
     decision engine treats this as an unresolved conflict feeding
     toward NO_TRADE, per the requirement not to force a pick between
     genuinely close, opposing candidates.

Both stages are pure functions: same input candidates + policy always
produce the same surviving set and the same ConflictRecord trace.
"""

from __future__ import annotations

from itertools import combinations

from omnisystem_v5.decision.contracts import ConflictRecord
from omnisystem_v5.decision.enums import ConflictResolution, ConflictType
from omnisystem_v5.decision.policy import ConflictPolicy, ScoringPolicy
from omnisystem_v5.decision.scoring import rank_key


def _price_close(a: float, b: float, tolerance_pct: float) -> bool:
    if a == 0:
        return b == 0
    return abs(a - b) / abs(a) * 100.0 <= tolerance_pct


def resolve_duplicates(candidates, conflict_policy: ConflictPolicy, scoring_policy: ScoringPolicy):
    remaining = list(candidates)
    records = []
    survivors = []

    while remaining:
        current = remaining.pop(0)
        duplicate_group = [current]
        still_remaining = []
        for other in remaining:
            if (
                other.source_engine == current.source_engine
                and other.direction == current.direction
                and _price_close(current.entry, other.entry, conflict_policy.duplicate_price_tolerance_pct)
            ):
                duplicate_group.append(other)
            else:
                still_remaining.append(other)
        remaining = still_remaining

        if len(duplicate_group) == 1:
            survivors.append(current)
            continue

        ranked = sorted(duplicate_group, key=lambda c: rank_key(c.quality, scoring_policy), reverse=True)
        winner = ranked[0]
        survivors.append(winner)
        records.append(
            ConflictRecord(
                conflict_type=ConflictType.SAME_ENGINE_DUPLICATE,
                candidate_ids=tuple(c.candidate_id for c in duplicate_group),
                resolution=ConflictResolution.KEPT_HIGHER_RANKED,
                surviving_candidate_id=winner.candidate_id,
                details=(
                    f"{len(duplicate_group)} candidates from {current.source_engine} "
                    f"({current.direction.value}) within {conflict_policy.duplicate_price_tolerance_pct}% "
                    f"entry tolerance - kept {winner.candidate_id}"
                ),
            )
        )

    return survivors, records


def resolve_directional_conflicts(candidates, conflict_policy: ConflictPolicy, scoring_policy: ScoringPolicy):
    dropped_ids = set()
    records = []
    has_unresolved = False

    for a, b in combinations(candidates, 2):
        if a.candidate_id in dropped_ids or b.candidate_id in dropped_ids:
            continue
        if a.symbol != b.symbol or a.direction == b.direction:
            continue

        key_a = rank_key(a.quality, scoring_policy)
        key_b = rank_key(b.quality, scoring_policy)
        margin = sum(1 for x, y in zip(key_a, key_b) if x != y)
        decisive = margin >= conflict_policy.min_decisive_component_margin and key_a != key_b

        if decisive:
            winner, loser = (a, b) if key_a > key_b else (b, a)
            dropped_ids.add(loser.candidate_id)
            records.append(
                ConflictRecord(
                    conflict_type=ConflictType.DIRECTIONAL_CONFLICT,
                    candidate_ids=(a.candidate_id, b.candidate_id),
                    resolution=ConflictResolution.KEPT_HIGHER_RANKED,
                    surviving_candidate_id=winner.candidate_id,
                    details=(
                        f"{a.direction.value} vs {b.direction.value} on {a.symbol}: "
                        f"decisive margin ({margin} components) - kept {winner.candidate_id}"
                    ),
                )
            )
        else:
            dropped_ids.add(a.candidate_id)
            dropped_ids.add(b.candidate_id)
            has_unresolved = True
            records.append(
                ConflictRecord(
                    conflict_type=ConflictType.DIRECTIONAL_CONFLICT,
                    candidate_ids=(a.candidate_id, b.candidate_id),
                    resolution=ConflictResolution.DROPPED_UNRESOLVED,
                    surviving_candidate_id=None,
                    details=(
                        f"{a.direction.value} vs {b.direction.value} on {a.symbol}: "
                        f"margin ({margin} components) below decisive threshold "
                        f"({conflict_policy.min_decisive_component_margin}) - both dropped"
                    ),
                )
            )

    survivors = [c for c in candidates if c.candidate_id not in dropped_ids]
    return survivors, records, has_unresolved
