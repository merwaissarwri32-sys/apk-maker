"""
Candidate ranking - MERWIS AI, Phase 6.

There is NO single aggregate score anywhere in this module. Ranking is
a lexicographic comparison over named, independently-inspectable
components, in an order defined entirely by ScoringPolicy. This is the
literal implementation of "explainable and decomposable, not a magic
number": rank_key() returns a tuple of integers, each one traceable
back to exactly one named ScoreComponents field.
"""

from __future__ import annotations

from omnisystem_v5.decision.contracts import ScoreComponents
from omnisystem_v5.decision.enums import quality_rank
from omnisystem_v5.decision.policy import ScoringPolicy


def rank_key(components: ScoreComponents, policy: ScoringPolicy) -> tuple:
    values = components.as_dict()
    return tuple(quality_rank(values[name]) for name in policy.component_priority_order)


def explain_rank_key(components: ScoreComponents, policy: ScoringPolicy) -> tuple:
    values = components.as_dict()
    return tuple((name, values[name].value) for name in policy.component_priority_order)


def rank_candidates(candidates, policy: ScoringPolicy):
    return sorted(candidates, key=lambda c: rank_key(c.quality, policy), reverse=True)
