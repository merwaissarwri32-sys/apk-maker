"""
Decision policies - MERWIS AI, Phase 6.

Every threshold, priority order, and rule lives here as data, not as a
branch inside engine.py/scoring.py/conflict.py. Swapping in a smarter
policy later (regime-aware, engine-reliability-aware, user-specific)
means constructing a different DecisionPolicy instance - the core
engine code does not change.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ScoringPolicy:
    component_priority_order: tuple = (
        "risk_quality",
        "structural_quality",
        "confirmation_quality",
        "reward_quality",
        "data_quality",
        "timeframe_alignment",
        "regime_compatibility",
        "conflict_penalty",
    )


@dataclass(frozen=True)
class ConflictPolicy:
    duplicate_price_tolerance_pct: float = 0.05
    min_decisive_component_margin: int = 2


@dataclass(frozen=True)
class QualityGatePolicy:
    min_moderate_plus_components: int = 3


@dataclass(frozen=True)
class DecisionPolicy:
    policy_version: str = "1.0"
    scoring: ScoringPolicy = field(default_factory=ScoringPolicy)
    conflict: ConflictPolicy = field(default_factory=ConflictPolicy)
    quality_gate: QualityGatePolicy = field(default_factory=QualityGatePolicy)
    max_risk_attempts: int = 3
