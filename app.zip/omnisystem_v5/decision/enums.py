"""
Master Decision Layer enumerations - MERWIS AI, Phase 6.

This package imports risk.enums.Direction (the hard gate dependency is
intentional and unavoidable - the Decision Layer must talk to the Risk
Engine). It has ZERO imports from intelligence/, quant/, or context/ -
exactly the same independence discipline as risk/ itself. The one file
allowed to bridge intelligence candidate types into this layer is
intelligence/decision_bridge.py.
"""

from enum import Enum


class DecisionOutcome(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    NO_TRADE = "NO_TRADE"


class CandidateStatus(str, Enum):
    """Per-candidate trace status - every candidate considered gets
    exactly one of these, never a bare string."""

    ACCEPTED = "ACCEPTED"
    REJECTED_DATA_INVALID = "REJECTED_DATA_INVALID"
    REJECTED_DUPLICATE = "REJECTED_DUPLICATE"
    REJECTED_CONFLICT = "REJECTED_CONFLICT"
    REJECTED_QUALITY = "REJECTED_QUALITY"
    REJECTED_RANKED_LOWER = "REJECTED_RANKED_LOWER"
    REJECTED_RISK = "REJECTED_RISK"


class ConflictType(str, Enum):
    SAME_ENGINE_DUPLICATE = "SAME_ENGINE_DUPLICATE"
    NEAR_DUPLICATE = "NEAR_DUPLICATE"
    DIRECTIONAL_CONFLICT = "DIRECTIONAL_CONFLICT"


class ConflictResolution(str, Enum):
    KEPT_HIGHER_RANKED = "KEPT_HIGHER_RANKED"
    DROPPED_UNRESOLVED = "DROPPED_UNRESOLVED"   # margin too small to decide - both sides removed


class DataValidityState(str, Enum):
    VALID = "VALID"
    MISSING = "MISSING"
    STALE = "STALE"
    CONTRADICTORY = "CONTRADICTORY"
    INVALID = "INVALID"


class QualityLevel(str, Enum):
    """Deliberately mirrors intelligence.enums.AlignmentLevel's four
    values in spirit - but is its OWN enum so this package stays import-
    free of intelligence/. See decision/scoring.py for how these are
    used in a decomposable, non-magic-number ranking key."""

    STRONG = "STRONG"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    NONE = "NONE"


_QUALITY_RANK = {QualityLevel.NONE: 0, QualityLevel.WEAK: 1, QualityLevel.MODERATE: 2, QualityLevel.STRONG: 3}


def quality_rank(level: QualityLevel) -> int:
    return _QUALITY_RANK[level]


class DecisionReasonCode(str, Enum):
    """Top-level, structured reasons for the FINAL decision - distinct
    namespace from risk.enums.RejectionReasonCode (which explains why a
    single candidate failed risk) and from CandidateStatus (which
    explains why a single candidate was dropped in the trace)."""

    NO_CANDIDATES_PROVIDED = "NO_CANDIDATES_PROVIDED"
    ALL_CANDIDATES_DATA_INVALID = "ALL_CANDIDATES_DATA_INVALID"
    MULTI_SYMBOL_INPUT_NOT_SUPPORTED = "MULTI_SYMBOL_INPUT_NOT_SUPPORTED"
    UNRESOLVED_DIRECTIONAL_CONFLICT = "UNRESOLVED_DIRECTIONAL_CONFLICT"
    NO_CANDIDATE_PASSED_QUALITY_GATE = "NO_CANDIDATE_PASSED_QUALITY_GATE"
    NO_CANDIDATE_PASSED_RISK_GATE = "NO_CANDIDATE_PASSED_RISK_GATE"
    DECISION_MADE = "DECISION_MADE"
