"""
Master Decision Engine - MERWIS AI, Phase 6.

    NormalizedCandidate[] -> data integrity -> duplicate resolution ->
    directional conflict resolution -> quality gate -> ranking ->
    Risk Engine (hard gate, cannot be bypassed) -> FinalDecision

Every candidate provided gets exactly one CandidateStatus in the trace.
NO_TRADE is returned whenever the pipeline cannot produce a candidate
that is both quality-gated AND risk-actionable - it is never a
fallback bug path, it is a first-class, explicitly-reasoned outcome.

This module has ZERO imports from intelligence/, quant/, or context/.
It imports risk/ deliberately and unconditionally - the Risk Engine is
a hard gate with no bypass mechanism anywhere in this file.
"""

from __future__ import annotations

import math
from datetime import datetime, timezone

from omnisystem_v5.decision.conflict import resolve_directional_conflicts, resolve_duplicates
from omnisystem_v5.decision.contracts import DecisionRecord, FinalDecision, NormalizedCandidate
from omnisystem_v5.decision.enums import CandidateStatus, DataValidityState, DecisionOutcome, DecisionReasonCode
from omnisystem_v5.decision.policy import DecisionPolicy
from omnisystem_v5.decision.quality_gate import apply_quality_gate
from omnisystem_v5.decision.scoring import rank_candidates
from omnisystem_v5.risk.contracts import AccountState, RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.engine import assess_risk
from omnisystem_v5.risk.enums import Direction

DECISION_ENGINE_VERSION = "1.0"


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _candidate_data_ok(c):
    if c.data_validity != DataValidityState.VALID:
        return False, f"data_validity={c.data_validity.value}"
    if c.direction not in (Direction.LONG, Direction.SHORT):
        return False, "invalid direction"
    if not _finite(c.entry) or c.entry <= 0:
        return False, f"invalid entry={c.entry!r}"
    if not _finite(c.stop_loss) or c.stop_loss <= 0:
        return False, f"invalid stop_loss={c.stop_loss!r}"
    if not c.take_profits or any(not _finite(tp) for tp in c.take_profits):
        return False, "missing or non-finite take_profits"
    return True, ""


def _no_trade(now, reason_code, reasons, trace, conflict_records=(), data_validity=DataValidityState.VALID):
    decision_id = FinalDecision.make_id(None, DecisionOutcome.NO_TRADE, now, None)
    return FinalDecision(
        decision_id=decision_id, decision_version=DECISION_ENGINE_VERSION, policy_version="",
        generated_at=now, outcome=DecisionOutcome.NO_TRADE, symbol=None,
        selected_candidate=None, risk_result=None,
        candidate_trace=tuple(trace), conflict_records=tuple(conflict_records),
        data_validity_summary=data_validity, reason_code=reason_code, reasons=tuple(reasons),
    )


def decide(candidates, account, risk_policy=None, decision_policy=None, now=None):
    risk_policy = risk_policy or RiskPolicy()
    decision_policy = decision_policy or DecisionPolicy()
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware (UTC) if provided")

    trace = {}

    if not candidates:
        return _no_trade(now, DecisionReasonCode.NO_CANDIDATES_PROVIDED,
                          ("no candidates were provided to the decision engine",), [])

    symbols = {c.symbol for c in candidates}
    if len(symbols) > 1:
        for c in candidates:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_DATA_INVALID,
                                                     ("multi-symbol input is not supported in a single decide() call",))
        return _no_trade(now, DecisionReasonCode.MULTI_SYMBOL_INPUT_NOT_SUPPORTED,
                          (f"received candidates for {len(symbols)} distinct symbols: {sorted(symbols)}",),
                          list(trace.values()))

    symbol = next(iter(symbols))

    valid_candidates = []
    for c in candidates:
        ok, reason = _candidate_data_ok(c)
        if ok:
            valid_candidates.append(c)
        else:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_DATA_INVALID, (reason,))

    if not valid_candidates:
        return _no_trade(now, DecisionReasonCode.ALL_CANDIDATES_DATA_INVALID,
                          ("every candidate failed data integrity checks",), list(trace.values()),
                          data_validity=DataValidityState.INVALID)

    dedup_survivors, dup_records = resolve_duplicates(valid_candidates, decision_policy.conflict, decision_policy.scoring)
    dedup_ids = {c.candidate_id for c in dedup_survivors}
    for c in valid_candidates:
        if c.candidate_id not in dedup_ids:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_DUPLICATE,
                                                     ("dropped as a same-engine duplicate of a higher-ranked candidate",))

    conflict_survivors, conflict_records, has_unresolved = resolve_directional_conflicts(
        dedup_survivors, decision_policy.conflict, decision_policy.scoring
    )
    conflict_ids = {c.candidate_id for c in conflict_survivors}
    for c in dedup_survivors:
        if c.candidate_id not in conflict_ids:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_CONFLICT,
                                                     ("dropped due to an unresolved or lost directional conflict",))

    if not conflict_survivors:
        reason_code = DecisionReasonCode.UNRESOLVED_DIRECTIONAL_CONFLICT if has_unresolved else DecisionReasonCode.NO_CANDIDATE_PASSED_QUALITY_GATE
        return _no_trade(now, reason_code,
                          ("no candidate survived directional conflict resolution",),
                          list(trace.values()), conflict_records=dup_records + conflict_records)

    quality_passed, quality_failures = apply_quality_gate(conflict_survivors, decision_policy.quality_gate)
    for c in conflict_survivors:
        if c.candidate_id in quality_failures:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_QUALITY, (quality_failures[c.candidate_id],))

    if not quality_passed:
        return _no_trade(now, DecisionReasonCode.NO_CANDIDATE_PASSED_QUALITY_GATE,
                          ("no candidate met the minimum quality gate",),
                          list(trace.values()), conflict_records=dup_records + conflict_records)

    ranked = rank_candidates(quality_passed, decision_policy.scoring)

    winner = None
    winner_risk = None
    attempted = ranked[: decision_policy.max_risk_attempts]
    not_attempted = ranked[decision_policy.max_risk_attempts:]
    unreached_after_winner = []

    for idx, c in enumerate(attempted):
        trade_input = TradeCandidateInput(
            symbol=c.symbol, direction=c.direction, entry=c.entry, stop_loss=c.stop_loss,
            take_profits=c.take_profits, horizon=c.horizon, source=c.source_engine,
        )
        risk_result = assess_risk(trade_input, account, risk_policy, now)
        if risk_result.is_actionable:
            winner, winner_risk = c, risk_result
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.ACCEPTED,
                                                     (f"risk_decision={risk_result.decision.value}",))
            unreached_after_winner = attempted[idx + 1:]
            break
        else:
            trace[c.candidate_id] = DecisionRecord(
                c.candidate_id, c.source_engine, c.direction, CandidateStatus.REJECTED_RISK,
                tuple(r.value for r in risk_result.rejection_reasons) or (f"risk_decision={risk_result.decision.value}",),
            )

    for c in unreached_after_winner:
        trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                 CandidateStatus.REJECTED_RANKED_LOWER,
                                                 ("not attempted - a higher-ranked candidate already won",))

    for c in not_attempted:
        if winner is not None:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_RANKED_LOWER,
                                                     ("not attempted - a higher-ranked candidate already won",))
        else:
            trace[c.candidate_id] = DecisionRecord(c.candidate_id, c.source_engine, c.direction,
                                                     CandidateStatus.REJECTED_RANKED_LOWER,
                                                     (f"ranked beyond max_risk_attempts={decision_policy.max_risk_attempts}",))

    if winner is None:
        return _no_trade(now, DecisionReasonCode.NO_CANDIDATE_PASSED_RISK_GATE,
                          ("no candidate passed the Risk Engine's actionability gate",),
                          list(trace.values()), conflict_records=dup_records + conflict_records)

    outcome = DecisionOutcome.LONG if winner.direction == Direction.LONG else DecisionOutcome.SHORT
    decision_id = FinalDecision.make_id(symbol, outcome, now, winner.candidate_id)

    return FinalDecision(
        decision_id=decision_id, decision_version=DECISION_ENGINE_VERSION,
        policy_version=decision_policy.policy_version, generated_at=now,
        outcome=outcome, symbol=symbol, selected_candidate=winner, risk_result=winner_risk,
        candidate_trace=tuple(trace.values()), conflict_records=tuple(dup_records + conflict_records),
        data_validity_summary=DataValidityState.VALID, reason_code=DecisionReasonCode.DECISION_MADE,
        reasons=(f"selected {winner.candidate_id} from {winner.source_engine}",),
    )
