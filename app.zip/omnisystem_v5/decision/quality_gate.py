"""
Quality Gate - MERWIS AI, Phase 6.

The last filter before candidates reach the Risk Engine. A candidate
needs at least min_moderate_plus_components of its 8 ScoreComponents
fields at MODERATE or better to be considered actionable-quality -
this is a coarse, deliberately simple gate (a genuinely sophisticated
quality model belongs in the Intelligence layer that PRODUCES the
ScoreComponents in the first place, not here).
"""

from __future__ import annotations

from omnisystem_v5.decision.enums import QualityLevel, quality_rank
from omnisystem_v5.decision.policy import QualityGatePolicy


def passes_quality_gate(candidate, policy: QualityGatePolicy):
    values = candidate.quality.as_dict()
    moderate_or_better = sum(1 for v in values.values() if quality_rank(v) >= quality_rank(QualityLevel.MODERATE))
    passed = moderate_or_better >= policy.min_moderate_plus_components
    detail = f"{moderate_or_better}/{len(values)} components >= MODERATE (need {policy.min_moderate_plus_components})"
    return passed, detail


def apply_quality_gate(candidates, policy: QualityGatePolicy):
    passed = []
    failures = {}
    for c in candidates:
        ok, detail = passes_quality_gate(c, policy)
        if ok:
            passed.append(c)
        else:
            failures[c.candidate_id] = detail
    return passed, failures
