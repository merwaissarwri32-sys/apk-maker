"""
Basic trend classification.

Rule (deterministic, explainable):
  - UPTREND   if the most recent high-comparison event is HIGHER_HIGH
              AND the most recent low-comparison event is HIGHER_LOW.
  - DOWNTREND if the most recent high-comparison event is LOWER_HIGH
              AND the most recent low-comparison event is LOWER_LOW.
  - RANGE     if both exist but disagree (e.g. HIGHER_HIGH + LOWER_LOW,
              or EQUAL_* involved) — i.e. structure is not confirming a
              single direction.
  - UNDEFINED if there is no most-recent high event and/or no most-recent
              low event yet (not enough swing history).

This is intentionally the simplest classification that is still fully
explainable from the structure events already computed — no additional
free parameters.
"""

from __future__ import annotations

from datetime import datetime
from typing import Sequence

from omnisystem_v5.context.enums import StructureEventType, TrendState
from omnisystem_v5.context.schema import StructureEvent, TrendClassification
from omnisystem_v5.schemas.enums import Timeframe

_HIGH_EVENTS = {
    StructureEventType.HIGHER_HIGH,
    StructureEventType.LOWER_HIGH,
    StructureEventType.EQUAL_HIGH,
}
_LOW_EVENTS = {
    StructureEventType.HIGHER_LOW,
    StructureEventType.LOWER_LOW,
    StructureEventType.EQUAL_LOW,
}


def classify_trend(
    events: Sequence[StructureEvent], timeframe: Timeframe, as_of: datetime
) -> TrendClassification:
    last_high = next((e for e in reversed(events) if e.event_type in _HIGH_EVENTS), None)
    last_low = next((e for e in reversed(events) if e.event_type in _LOW_EVENTS), None)

    if last_high is None or last_low is None:
        return TrendClassification(
            state=TrendState.UNDEFINED,
            timeframe=timeframe,
            as_of=as_of,
            basis="insufficient swing history: fewer than 2 confirmed swing highs and/or lows",
        )

    if (
        last_high.event_type == StructureEventType.HIGHER_HIGH
        and last_low.event_type == StructureEventType.HIGHER_LOW
    ):
        state = TrendState.UPTREND
    elif (
        last_high.event_type == StructureEventType.LOWER_HIGH
        and last_low.event_type == StructureEventType.LOWER_LOW
    ):
        state = TrendState.DOWNTREND
    else:
        state = TrendState.RANGE

    basis = (
        f"last high event={last_high.event_type.value} at {last_high.timestamp.isoformat()}; "
        f"last low event={last_low.event_type.value} at {last_low.timestamp.isoformat()}"
    )
    return TrendClassification(state=state, timeframe=timeframe, as_of=as_of, basis=basis)
