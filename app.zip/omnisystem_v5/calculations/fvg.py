"""
Fair Value Gap (FVG) detection — standard 3-candle imbalance definition.

For three consecutive bars (A, B, C) at indices (i-2, i-1, i):
  - BULLISH FVG when A.high < C.low.  Gap zone = [A.high, C.low].
  - BEARISH FVG when A.low  > C.high. Gap zone = [C.high, A.low].

`filled` is determined ONLY from bars provided at calculation time —
by scanning bars after C for any bar whose range re-enters the gap
zone. If no bars exist after C yet, filled=False with the honest
caveat that it simply hasn't been evaluated against future data (not a
claim that it will never fill).
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.context.enums import FVGType
from omnisystem_v5.context.schema import FairValueGap
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar


def _check_filled(bars: Sequence[OHLCVBar], start_index: int, top: float, bottom: float):
    for b in bars[start_index:]:
        if b.low <= top and b.high >= bottom:
            return True, b.close_time
    return False, None


def detect_fair_value_gaps(bars: Sequence[OHLCVBar], timeframe: Timeframe) -> list[FairValueGap]:
    if len(bars) < 3:
        raise InsufficientDataError("detect_fair_value_gaps", required=3, available=len(bars))

    gaps: list[FairValueGap] = []
    for i in range(2, len(bars)):
        a, c = bars[i - 2], bars[i]
        middle = bars[i - 1]

        if a.high < c.low:
            filled, filled_at = _check_filled(bars, i + 1, top=c.low, bottom=a.high)
            gaps.append(
                FairValueGap(
                    fvg_type=FVGType.BULLISH,
                    top=c.low,
                    bottom=a.high,
                    timeframe=timeframe,
                    formed_at=middle.open_time,
                    filled=filled,
                    filled_at=filled_at,
                )
            )
        elif a.low > c.high:
            filled, filled_at = _check_filled(bars, i + 1, top=a.low, bottom=c.high)
            gaps.append(
                FairValueGap(
                    fvg_type=FVGType.BEARISH,
                    top=a.low,
                    bottom=c.high,
                    timeframe=timeframe,
                    formed_at=middle.open_time,
                    filled=filled,
                    filled_at=filled_at,
                )
            )

    return gaps
