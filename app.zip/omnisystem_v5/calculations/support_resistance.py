"""
Support/Resistance level detection via simple 1D price clustering of
confirmed swing points.

Algorithm (deterministic greedy clustering):
  1. Sort swings of a given type (HIGH -> resistance, LOW -> support) by price.
  2. Walk the sorted list, growing a cluster while each next price is
     within `tolerance_pct` of the CURRENT CLUSTER AVERAGE.
  3. A cluster becomes a reported level once it has >= min_touches swings.
     A single untouched swing is not reported as a level (there is no
     statistical basis for calling a single pivot a "level").

This is a simple, fully explainable clustering approach — not a
statistical/ML clustering method — chosen so results are reproducible
by hand.
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.context.enums import SRLevelType, SwingType
from omnisystem_v5.context.schema import SupportResistanceLevel, SwingPoint
from omnisystem_v5.schemas.enums import Timeframe


def _cluster(swings_sorted: list[SwingPoint], tolerance_pct: float) -> list[list[SwingPoint]]:
    clusters: list[list[SwingPoint]] = []
    for s in swings_sorted:
        if clusters:
            current = clusters[-1]
            avg_price = sum(x.price for x in current) / len(current)
            if avg_price != 0 and abs(s.price - avg_price) / avg_price <= tolerance_pct:
                current.append(s)
                continue
        clusters.append([s])
    return clusters


def detect_support_resistance(
    swings: Sequence[SwingPoint],
    timeframe: Timeframe,
    tolerance_pct: float = 0.0015,
    min_touches: int = 2,
) -> list[SupportResistanceLevel]:
    highs = sorted([s for s in swings if s.swing_type == SwingType.HIGH], key=lambda s: s.price)
    lows = sorted([s for s in swings if s.swing_type == SwingType.LOW], key=lambda s: s.price)

    levels: list[SupportResistanceLevel] = []

    for cluster in _cluster(highs, tolerance_pct):
        if len(cluster) >= min_touches:
            avg_price = sum(x.price for x in cluster) / len(cluster)
            times = sorted(x.timestamp for x in cluster)
            levels.append(
                SupportResistanceLevel(
                    level_type=SRLevelType.RESISTANCE,
                    price=avg_price,
                    timeframe=timeframe,
                    touch_count=len(cluster),
                    first_formed_at=times[0],
                    last_touched_at=times[-1],
                )
            )

    for cluster in _cluster(lows, tolerance_pct):
        if len(cluster) >= min_touches:
            avg_price = sum(x.price for x in cluster) / len(cluster)
            times = sorted(x.timestamp for x in cluster)
            levels.append(
                SupportResistanceLevel(
                    level_type=SRLevelType.SUPPORT,
                    price=avg_price,
                    timeframe=timeframe,
                    touch_count=len(cluster),
                    first_formed_at=times[0],
                    last_touched_at=times[-1],
                )
            )

    return levels
