"""
Break of Structure (BOS) and Change of Character (CHoCH) detection.

Algorithm (deterministic, single forward pass, no lookahead):

  1. Swings are pre-computed (find_swing_points) and each carries the
     bar index at which it becomes CONFIRMED (bar_index + window).
  2. Walk bars in chronological order. At each bar:
       a. Activate any swing that becomes confirmed at this index.
          The "active" swing high/low is always the MOST RECENTLY
          confirmed one — it represents the last pivot price has not
          yet closed beyond.
       b. Track the current trend using the same HH/HL/LH/LL logic as
          calculations.trend, evaluated only on swings confirmed up to
          (and not including) the current bar — no future information.
       c. If the bar's close breaks beyond the active high (close >
          active_high.price) or active low (close < active_low.price),
          emit exactly one break event, classified as:
            - BOS_BULLISH   if trend-so-far == UPTREND
            - CHOCH_BULLISH if trend-so-far == DOWNTREND, RANGE, or UNDEFINED
              (a bullish break against/absent an established uptrend is
              treated conservatively as a character change, not a
              trend continuation)
          and symmetrically for the downside break.
          Once a swing is broken it is retired — it will not be
          re-broken; the next confirmed swing of that type becomes the
          new active one.

This is a "basic" structure-break implementation as scoped for Phase 2:
it does not attempt multi-leg liquidity sweeps, internal vs external
structure, or timeframe confluence — those are explicitly left for a
later phase.
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.trend import classify_trend
from omnisystem_v5.context.enums import StructureEventType, SwingType, TrendState
from omnisystem_v5.context.schema import StructureEvent, SwingPoint
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar


def _label_events_up_to(swings: list[SwingPoint], count_high: int, count_low: int, timeframe: Timeframe):
    """Re-usable thin wrapper so trend classification only sees swings
    confirmed so far, preserving the no-lookahead guarantee."""
    from omnisystem_v5.calculations.swings import label_hh_hl_lh_ll

    highs = [s for s in swings if s.swing_type == SwingType.HIGH][:count_high]
    lows = [s for s in swings if s.swing_type == SwingType.LOW][:count_low]
    return label_hh_hl_lh_ll(highs + lows, timeframe)


def detect_structure_breaks(
    bars: Sequence[OHLCVBar], swings: Sequence[SwingPoint], timeframe: Timeframe
) -> list[StructureEvent]:
    events: list[StructureEvent] = []

    swings_sorted = sorted(swings, key=lambda s: s.confirmed_at_index)
    confirmed_highs: list[SwingPoint] = []
    confirmed_lows: list[SwingPoint] = []

    active_high: SwingPoint | None = None
    active_low: SwingPoint | None = None

    swing_cursor = 0

    for i, bar in enumerate(bars):
        # 1. Activate any swings confirmed at this bar index.
        while swing_cursor < len(swings_sorted) and swings_sorted[swing_cursor].confirmed_at_index == i:
            s = swings_sorted[swing_cursor]
            if s.swing_type == SwingType.HIGH:
                confirmed_highs.append(s)
                active_high = s
            else:
                confirmed_lows.append(s)
                active_low = s
            swing_cursor += 1

        # 2. Determine trend using only swings confirmed strictly before this bar's close is evaluated.
        #    (confirmed_highs/confirmed_lows already reflect "up to and including this bar".)
        trend_events = _label_events_up_to(
            confirmed_highs + confirmed_lows, len(confirmed_highs), len(confirmed_lows), timeframe
        )
        current_trend = classify_trend(trend_events, timeframe, as_of=bar.close_time).state

        # 3. Check bullish break.
        if active_high is not None and bar.close > active_high.price:
            etype = (
                StructureEventType.BOS_BULLISH
                if current_trend == TrendState.UPTREND
                else StructureEventType.CHOCH_BULLISH
            )
            events.append(
                StructureEvent(
                    event_type=etype,
                    timestamp=bar.close_time,
                    price=bar.close,
                    timeframe=timeframe,
                    calculation_source=(
                        f"close {bar.close} broke above active swing high "
                        f"{active_high.price} (formed at {active_high.timestamp.isoformat()}); "
                        f"trend-so-far={current_trend.value}"
                    ),
                )
            )
            active_high = None  # retire — wait for the next confirmed swing high

        # 4. Check bearish break.
        if active_low is not None and bar.close < active_low.price:
            etype = (
                StructureEventType.BOS_BEARISH
                if current_trend == TrendState.DOWNTREND
                else StructureEventType.CHOCH_BEARISH
            )
            events.append(
                StructureEvent(
                    event_type=etype,
                    timestamp=bar.close_time,
                    price=bar.close,
                    timeframe=timeframe,
                    calculation_source=(
                        f"close {bar.close} broke below active swing low "
                        f"{active_low.price} (formed at {active_low.timestamp.isoformat()}); "
                        f"trend-so-far={current_trend.value}"
                    ),
                )
            )
            active_low = None

    return events
