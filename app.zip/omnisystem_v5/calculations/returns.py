"""
Simple returns and volatility (sample standard deviation of returns).

Returns:
    r[i] = (close[i] - close[i-1]) / close[i-1]    for i in 1..N-1

Volatility:
    sample standard deviation of the returns series (statistics.stdev),
    which requires at least 2 return values (i.e. at least 3 bars).

No annualization, no smoothing, no assumptions about distribution —
this is deliberately the simplest defensible statistic so it stays
fully reproducible by hand.
"""

from __future__ import annotations

import statistics
from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.schemas.market_data import OHLCVBar


def calculate_returns(bars: Sequence[OHLCVBar]) -> list[float]:
    if len(bars) < 2:
        raise InsufficientDataError("calculate_returns", required=2, available=len(bars))

    returns = []
    for i in range(1, len(bars)):
        prev_close = bars[i - 1].close
        if prev_close == 0:
            raise ValueError(f"cannot compute return: prior close is zero at index {i - 1}")
        returns.append((bars[i].close - prev_close) / prev_close)
    return returns


def calculate_volatility(bars: Sequence[OHLCVBar]) -> float:
    """Sample standard deviation of simple returns. Requires >= 3 bars
    (>= 2 returns) since statistics.stdev is undefined for n < 2."""
    returns = calculate_returns(bars)
    if len(returns) < 2:
        raise InsufficientDataError("calculate_volatility", required=3, available=len(bars))
    return statistics.stdev(returns)
