"""
Basic liquidity zone detection: equal highs / equal lows.

Uses the same greedy clustering approach as support/resistance but with
a TIGHTER tolerance (liquidity "equal" levels are meant to represent
near-identical price rejection points, not a general S/R band) and a
strict minimum of 2 touches, since a liquidity zone is definitionally a
pool formed by 2+ coinciding swings.
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.support_resistance import _cluster
from omnisystem_v5.context.enums import LiquidityType, SwingType
from omnisystem_v5.context.schema import LiquidityZone, SwingPoint
from omnisystem_v5.schemas.enums import Timeframe


def detect_liquidity_zones(
    swings: Sequence[SwingPoint],
    timeframe: Timeframe,
    tolerance_pct: float = 0.0005,
) -> list[LiquidityZone]:
    highs = sorted([s for s in swings if s.swing_type == SwingType.HIGH], key=lambda s: s.price)
    lows = sorted([s for s in swings if s.swing_type == SwingType.LOW], key=lambda s: s.price)

    zones: list[LiquidityZone] = []

    for cluster in _cluster(highs, tolerance_pct):
        if len(cluster) >= 2:
            avg_price = sum(x.price for x in cluster) / len(cluster)
            latest = max(x.timestamp for x in cluster)
            zones.append(
                LiquidityZone(
                    liquidity_type=LiquidityType.EQUAL_HIGHS,
                    price_level=avg_price,
                    timeframe=timeframe,
                    touch_count=len(cluster),
                    formed_at=latest,
                )
            )

    for cluster in _cluster(lows, tolerance_pct):
        if len(cluster) >= 2:
            avg_price = sum(x.price for x in cluster) / len(cluster)
            latest = max(x.timestamp for x in cluster)
            zones.append(
                LiquidityZone(
                    liquidity_type=LiquidityType.EQUAL_LOWS,
                    price_level=avg_price,
                    timeframe=timeframe,
                    touch_count=len(cluster),
                    formed_at=latest,
                )
            )

    return zones
