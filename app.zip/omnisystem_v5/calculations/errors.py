"""
Shared error types for the calculations layer.

Every calculation function in this package raises InsufficientDataError
rather than guessing, padding, or extrapolating when it doesn't have
enough bars to produce a mathematically justified result. This is the
enforcement point for the "no AI guessing / never infer missing data"
rule at the deterministic-calculation level.
"""


class InsufficientDataError(Exception):
    """Raised when a calculation does not have enough bars to produce
    a valid, mathematically justified result."""

    def __init__(self, calculation: str, required: int, available: int):
        self.calculation = calculation
        self.required = required
        self.available = available
        super().__init__(
            f"{calculation}: requires at least {required} bars, got {available}"
        )
