"""
Swing point detection and higher-high/lower-low labeling.

Definition used (fractal-style swing, a common, fully deterministic
definition): given a symmetric window W, bar i is a:

  - SWING HIGH if bars[i].high is strictly greater than the high of
    every bar in [i-W, i-1] and every bar in [i+1, i+W].
  - SWING LOW  if bars[i].low is strictly less than the low of every
    bar in [i-W, i-1] and every bar in [i+1, i+W].

A swing at index i is only "confirmed" once bar i+W exists, i.e. no
lookahead is required beyond bars actually present in the input.
Strict inequality is used deliberately: ties are not swings (they are
instead surfaced later as EQUAL_HIGH/EQUAL_LOW comparisons and can feed
liquidity-zone detection).
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.context.enums import StructureEventType, SwingType
from omnisystem_v5.context.schema import StructureEvent, SwingPoint
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar


def find_swing_points(
    bars: Sequence[OHLCVBar], timeframe: Timeframe, window: int = 2
) -> list[SwingPoint]:
    if window < 1:
        raise ValueError("window must be >= 1")

    required = 2 * window + 1
    if len(bars) < required:
        raise InsufficientDataError("find_swing_points", required=required, available=len(bars))

    swings: list[SwingPoint] = []
    for i in range(window, len(bars) - window):
        left = bars[i - window : i]
        right = bars[i + 1 : i + 1 + window]

        is_high = all(bars[i].high > b.high for b in left) and all(bars[i].high > b.high for b in right)
        is_low = all(bars[i].low < b.low for b in left) and all(bars[i].low < b.low for b in right)

        if is_high:
            swings.append(
                SwingPoint(
                    swing_type=SwingType.HIGH,
                    price=bars[i].high,
                    timestamp=bars[i].open_time,
                    bar_index=i,
                    confirmed_at_index=i + window,
                    timeframe=timeframe,
                )
            )
        if is_low:
            swings.append(
                SwingPoint(
                    swing_type=SwingType.LOW,
                    price=bars[i].low,
                    timestamp=bars[i].open_time,
                    bar_index=i,
                    confirmed_at_index=i + window,
                    timeframe=timeframe,
                )
            )

    return swings


def label_hh_hl_lh_ll(
    swings: Sequence[SwingPoint], timeframe: Timeframe
) -> list[StructureEvent]:
    """Compares each swing high to the PREVIOUS swing high (chronologically),
    and each swing low to the previous swing low. The first swing of each
    type has nothing to compare against, so no event is emitted for it."""

    events: list[StructureEvent] = []
    highs = [s for s in swings if s.swing_type == SwingType.HIGH]
    lows = [s for s in swings if s.swing_type == SwingType.LOW]

    for prev, curr in zip(highs, highs[1:]):
        if curr.price > prev.price:
            etype = StructureEventType.HIGHER_HIGH
        elif curr.price < prev.price:
            etype = StructureEventType.LOWER_HIGH
        else:
            etype = StructureEventType.EQUAL_HIGH
        events.append(
            StructureEvent(
                event_type=etype,
                timestamp=curr.timestamp,
                price=curr.price,
                timeframe=timeframe,
                calculation_source=(
                    f"compared swing high at {curr.timestamp.isoformat()} "
                    f"(price={curr.price}) to previous swing high at "
                    f"{prev.timestamp.isoformat()} (price={prev.price})"
                ),
            )
        )

    for prev, curr in zip(lows, lows[1:]):
        if curr.price > prev.price:
            etype = StructureEventType.HIGHER_LOW
        elif curr.price < prev.price:
            etype = StructureEventType.LOWER_LOW
        else:
            etype = StructureEventType.EQUAL_LOW
        events.append(
            StructureEvent(
                event_type=etype,
                timestamp=curr.timestamp,
                price=curr.price,
                timeframe=timeframe,
                calculation_source=(
                    f"compared swing low at {curr.timestamp.isoformat()} "
                    f"(price={curr.price}) to previous swing low at "
                    f"{prev.timestamp.isoformat()} (price={prev.price})"
                ),
            )
        )

    events.sort(key=lambda e: e.timestamp)
    return events
