"""
Average True Range (ATR) — Wilder's smoothing method.

Formula (per bar i, i >= 1):
    TR[i] = max(
        high[i] - low[i],
        abs(high[i] - close[i-1]),
        abs(low[i] - close[i-1]),
    )

Wilder's ATR:
    ATR[period]     = mean(TR[1 .. period])                 (simple average, seed value)
    ATR[i > period] = (ATR[i-1] * (period - 1) + TR[i]) / period

This is the standard, widely-documented definition (J. Welles Wilder,
"New Concepts in Technical Trading Systems", 1978) — chosen specifically
because it is fully deterministic and reproducible from raw OHLC data,
with no free parameters beyond `period`.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.schemas.market_data import OHLCVBar


@dataclass(frozen=True)
class AtrSeriesPoint:
    timestamp: datetime  # close_time of the bar this ATR value corresponds to
    value: float


def calculate_true_range(bars: Sequence[OHLCVBar]) -> list[float]:
    """Returns TR values for bars[1:] (TR is undefined for the first bar,
    since it needs a previous close)."""
    if len(bars) < 2:
        raise InsufficientDataError("true_range", required=2, available=len(bars))

    tr_values = []
    for i in range(1, len(bars)):
        prev_close = bars[i - 1].close
        high, low = bars[i].high, bars[i].low
        tr = max(
            high - low,
            abs(high - prev_close),
            abs(low - prev_close),
        )
        tr_values.append(tr)
    return tr_values


def calculate_atr(bars: Sequence[OHLCVBar], period: int = 14) -> list[AtrSeriesPoint]:
    """Returns the full Wilder ATR series aligned to bar close_times.
    The first ATR value appears at bars[period] (needs `period` TR values,
    which needs `period + 1` bars)."""
    required = period + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_atr", required=required, available=len(bars))

    tr_values = calculate_true_range(bars)  # length = len(bars) - 1, aligned to bars[1:]

    series: list[AtrSeriesPoint] = []
    seed = sum(tr_values[:period]) / period
    series.append(AtrSeriesPoint(timestamp=bars[period].close_time, value=seed))

    prev_atr = seed
    for i in range(period, len(tr_values)):
        tr = tr_values[i]
        atr = (prev_atr * (period - 1) + tr) / period
        series.append(AtrSeriesPoint(timestamp=bars[i + 1].close_time, value=atr))
        prev_atr = atr

    return series


def latest_atr(bars: Sequence[OHLCVBar], period: int = 14) -> AtrSeriesPoint:
    """Convenience: returns only the most recent ATR value."""
    series = calculate_atr(bars, period)
    return series[-1]
