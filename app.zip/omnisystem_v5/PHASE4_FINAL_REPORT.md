# MERWIS AI — Phase 4 (Completion) — Final Report

**Status: DOCUMENTATION + VALIDATION + PACKAGING ONLY. Phase 5 NOT started.**

---

## 1. Final Project Architecture

```
MarketDataEnvelope  (Phase 1 — raw, quality-gated OHLCV per timeframe)
        │
        ▼
MarketContext        (Phase 2 — deterministic structure: swings, BOS/CHoCH,
        │              trend, S/R, liquidity zones, FVGs, ATR/volatility)
        ▼
QuantContext          (Phase 3 — VWAP, momentum/RSI/ROC/EMA, volatility
        │              regime/phase, normalization, invalidation candidates)
        ▼
   ┌────┴──────────────────────────────────────────────┐
   ▼                                                     ▼
BullEngine (independent)                          BearEngine (independent)
   └────────────────────┬──────────────────────────────┘
                         ▼
        classify_market_regime + aggregate_multi_timeframe_bias
                         │
     ┌───────────────────┼────────────────────────┐
     ▼                   ▼                        ▼
ScalpEngine         IntradayEngine          ShortSwingEngine
(5m/15m exec)       (15m exec / 1H HTF)      (4H exec / 1D HTF)
     │                   │                        │
     └─────────── EventRiskContext (shared interface, all 3 engines) ──┘
                         │
                         ▼
        ScalpCandidate / IntradayCandidate / ShortSwingCandidate
        (status = ZONE_IDENTIFIED)  +  NO_VALID_SCALP with explicit reason
                         │
                         ▼
        evaluate_confirmation()  →  CONFIRMATION_PENDING / CONFIRMED / INVALIDATED
                         │
                         ▼
        (Future: Risk Engine → Master Decision Engine → execution interface)
```

Each horizon engine (Scalp / Intraday / Short-Swing) is independently invocable, consumes only `MarketContext`/`QuantContext` (never raw provider data), and shares exactly three cross-cutting utilities: `entry_zone.py` (structural entry-zone construction), `event_risk.py` (event-risk interface), and the Bull/Bear engines (for directional evidence). No engine wraps or renames another — each has its own scenario classification, evidence shape, and rejection logic (detailed in §3).

---

## 2. All 16 `intelligence/` Modules

| # | Module | Role |
|---|---|---|
| 1 | `enums.py` | Shared vocabulary: `Horizon`, `DirectionBias`, `AlignmentLevel` (+ `alignment_rank` ordinal helper), `ConflictStatus`, `MarketRegime`, `ScalpStatus`, `ExpectedHoldingPeriod`, `NoTradeReason`. |
| 2 | `evidence.py` | `EvidenceItem` — the one atomic, auditable unit every engine uses to justify a conclusion (factor, direction, description, timeframe, source). |
| 3 | `regime.py` | `classify_market_regime()` — deterministic precedence rule (REVERSAL > EXPANSION > COMPRESSION > TREND > RANGE > HIGH/LOW_VOLATILITY > UNSTABLE_UNKNOWN) over Phase 2/3 outputs only. |
| 4 | `mtf_bias.py` | `aggregate_multi_timeframe_bias()` — exposes `higher_timeframe_bias`, `execution_timeframe_structure`, `microstructure_confirmation`, `conflict_status` (ALIGNED/PARTIAL/CONFLICTING/INSUFFICIENT) without forcing agreement. |
| 5 | `directional.py` | `DirectionalCase` schema — the structured output shape shared by Bull/Bear engines. |
| 6 | `bull_engine.py` | Independent bullish-only evaluator: structure, liquidity (equal-lows + confirming break), momentum (RSI/ROC/EMA), volatility, VWAP, FVG, multi-timeframe alignment. |
| 7 | `bear_engine.py` | Independent bearish-only evaluator — its own rules (equal-highs, resistance, bearish FVG, downside momentum), not a negation of Bull. |
| 8 | `entry_zone.py` | `build_structural_entry_zone()` — shared by all 3 horizon engines. Priority: confluence (2+ overlapping zones) → single FVG → single SR/liquidity → VWAP reaction band → fallback narrow band (explicitly flagged `NONE` quality). |
| 9 | `event_risk.py` | `EventRiskStatus` (AVAILABLE/UNAVAILABLE/STALE), `EventRiskContext` (schema-enforced: cannot report a risk verdict unless status=AVAILABLE), `EventRiskProvider` interface, `NullEventRiskProvider` (only implementation — always UNAVAILABLE, never fabricates "no risk"). |
| 10 | `scalp_schema.py` | `PriceZone`, `ScalpCandidateEvidence` (9 components), `ScalpCandidate` (+ `entry_zone_quality`/`entry_zone_source`, additive), `ScalpDetectionResult`. |
| 11 | `scalp_engine.py` | `detect_scalp_candidate()` (original single-best API, unchanged) + `detect_scalp_candidates()` (new: evaluates BULLISH and BEARISH independently, ranks by confluence-count then R:R, returns up to `max_candidates`). |
| 12 | `intraday_schema.py` | `IntradayScenarioType` (TREND_CONTINUATION/REVERSAL/BREAKOUT_RETEST/MEAN_REVERSION), `IntradayCandidateEvidence` (8 components, splits `higher_timeframe_alignment` from `execution_timeframe_alignment` — no volume/RR-quality fields), `IntradayCandidate`. |
| 13 | `intraday_engine.py` | `detect_intraday_candidate()` — requires 1H+15M non-conflicting bias, classifies scenario type, MEAN_REVERSION uniquely fades RANGE+VWAP-extension+RSI-extreme. |
| 14 | `short_swing_schema.py` | `ShortSwingScenarioType` (HTF_TREND_CONTINUATION/MAJOR_REVERSAL/RANGE_EXPANSION_BREAKOUT), `ShortSwingCandidateEvidence` (6 components incl. `higher_timeframe_fvg_alignment`), `ShortSwingCandidate` (+ explicit `event_risk_status` field). |
| 15 | `short_swing_engine.py` | `detect_short_swing_candidate()` — 1D/4H hierarchy, invalidation/target restricted to MAJOR sources only (FVG boundaries excluded), outright rejects HIGH volatility regime. |
| 16 | `reaction.py` | `evaluate_confirmation()` — pure state-machine function: ZONE_IDENTIFIED → (breach→INVALIDATED) / (no entry→unchanged) / (entry+reaction→CONFIRMED) / (entry, no reaction yet→CONFIRMATION_PENDING). Never mutates input. |

---

## 3. How Scalp / Intraday / Short-Swing Genuinely Differ

| Aspect | Scalp | Intraday | Short-Swing |
|---|---|---|---|
| Timeframes | single execution TF | 15M exec + 1H HTF (required, hard conflict gate) | 4H exec + 1D HTF (required, hard conflict gate) |
| Scenario classification | none | 4 types (incl. MEAN_REVERSION, which *fades* structure) | 3 types (no mean-reversion; only trend/reversal/expansion-breakout) |
| Evidence shape | 9 components (incl. volume, RR-quality) | 8 components (no volume/RR-quality; splits HTF vs exec alignment) | 6 components (adds HTF FVG alignment; no volume, no VWAP) |
| Invalidation/target sources | any (incl. FVG boundaries) | any (incl. FVG boundaries) | **MAJOR sources only** — FVG boundaries excluded |
| Volatility handling | downgrades alignment score only | downgrades alignment score only | **outright rejects HIGH regime** (`NO_TRADE_HIGH_VOLATILITY`) |
| Event risk | optional, gates on confirmed risk only | optional, gates on confirmed risk only | **always evaluated + surfaced on every candidate** via `event_risk_status` |
| Candidates per call | 1 (original) or N (new `detect_scalp_candidates`) | up to 2 (one per direction) | up to 2 (one per direction) |
| Default min R:R | 1.5 | 1.3 | 2.0 |

---

## 4. All 27 Test Files

| File | Tests | Covers |
|---|---|---|
| `test_phase1.py` | 23 | Ingestion, normalization, quality gate, staleness, missing data |
| `test_phase2_atr_returns.py` | 11 | ATR (Wilder), returns, volatility |
| `test_phase2_context_builder.py` | 10 | MarketContext status mapping, multi-timeframe independence |
| `test_phase2_fvg.py` | 7 | Fair Value Gap detection + fill logic |
| `test_phase2_sr_liquidity.py` | 5 | Support/resistance & liquidity clustering |
| `test_phase2_structure_breaks.py` | 5 | BOS/CHoCH sequential detection |
| `test_phase2_swings_trend.py` | 11 | Swing points, HH/HL/LH/LL, trend classification |
| `test_phase3_edge_cases.py` | 3 | Extreme volatility, zero-ATR, near-zero denominators |
| `test_phase3_engine.py` | 9 | QuantContext status mapping, happy path |
| `test_phase3_invalidation.py` | 11 | Invalidation candidate generation & validity |
| `test_phase3_momentum.py` | 15 | ROC, momentum, RSI, EMA |
| `test_phase3_normalization.py` | 6 | Return z-score, ATR-normalized momentum |
| `test_phase3_risk_reward.py` | 11 | R:R and R-multiple calculations |
| `test_phase3_volatility.py` | 12 | ATR%, rolling volatility, regime/phase classification |
| `test_phase3_vwap.py` | 8 | Session/rolling VWAP, zero-volume handling |
| `test_phase4_adversarial.py` | 9 | Original Phase 4 adversarial set (HTF conflict, liquidity-without-MSS, FVG-without-structure, poor R:R, stale data, high volatility, missing volume, missing LTF, balanced evidence) |
| `test_phase4_bull_bear.py` | 7 | Bull/Bear independence on trending/flat markets |
| `test_phase4_mtf_bias.py` | 6 | Multi-timeframe conflict classification |
| `test_phase4_reaction.py` | 9 | Reaction confirmation state machine |
| `test_phase4_regime.py` | 9 | Market regime precedence rules |
| `test_phase4_scalp_engine.py` | 6 | Original single-candidate Scalp API (hand-verified positive case) |
| `test_phase4c_adversarial.py` | 5 | Stale-data-blocks-intraday, event-risk-never-fabricates-safety, invalid-structure-rejected, zero-volume-survival |
| `test_phase4c_entry_zone.py` | 12 | Fallback, single-source, confluence, wrong-side exclusion, distance cutoff, VWAP reaction area |
| `test_phase4c_event_risk.py` | 7 | AVAILABLE/UNAVAILABLE/STALE states, schema-enforced anti-fabrication, `blocks_trading()` |
| `test_phase4c_intraday.py` | 8 | Positive (hand-verified TREND_CONTINUATION), rejections (missing TF, conflict, unstable regime, poor R:R, event risk), schema distinctness |
| `test_phase4c_multi_candidate_scalp.py` | 9 | Backward compatibility, multi-candidate ranking, no-balanced-rejection in plural API, event-risk integration |
| `test_phase4c_short_swing.py` | 9 | Positive (hand-verified HTF_TREND_CONTINUATION), HIGH-volatility rejection, stale/confirmed event risk, MAJOR-source restriction |

**Total: 243 tests across 27 files.**

---

## 5. Final Test Results

```
Adversarial suite (test_phase4c_adversarial.py):  5/5 PASS
Full project suite (all 27 files):              243/243 PASS
```
Re-run immediately before packaging (this session) — confirmed identical result, no code touched in between.

---

## 6. Entry / SL / TP / Risk Control / Fail-Safe — Honest Assessment

**What exists today:**
- **Invalidation (SL)** is never invented: it is always the nearest *valid* (unbroken) structural level from `QuantContext.invalidation_candidates` (swing/S-R/liquidity/FVG, or MAJOR-only for Short-Swing). If none exists, the engine returns `NO_VALID_SCALP`/rejects rather than placing a stop.
- **Target (TP)** is likewise always a real structural level, never a fixed R-multiple guess. If none exists, the engine rejects.
- **R:R gating** happens before a candidate is ever constructed (`min_reward_risk_ratio`, per-horizon).
- **Fail-safe defaults**: every engine's default path is `NO_VALID_SCALP` / `NO_TRADE_*` — a candidate is the exception, not the default.
- **Event risk** can never silently read as "safe" (schema-enforced).

**What does NOT exist yet (honest gaps):**
- **There is no Risk Engine.** Nothing in the codebase currently enforces position sizing, max-risk-per-trade, portfolio-level exposure, or a hard veto layer independent of the horizon engines. Each engine's R:R/volatility checks are *self-imposed*, not externally validated by a separate authority.
- **No multi-stage validation pipeline.** The spec's requirement ("Entry/SL/TP must be under Risk Engine and multi-stage validation") is **not implemented** — this is the single largest architectural gap relative to where the project is heading.
- **SL/TP "reasonableness" is only as good as the underlying structural levels.** There is no explicit floor/ceiling check (e.g., "reject if SL distance > X% of price regardless of structure") — an unusually distant swing level could still pass R:R math while being impractical to size a position around.
- **No portfolio or cross-symbol awareness** — every candidate is evaluated in isolation.

This gap is flagged, not fixed, per your instruction to document rather than implement in this pass.

---

## 7. Known Limitations & Technical Debt

1. **No Risk Engine / no position sizing / no portfolio-level veto** (see §6) — the most significant open item.
2. **No true Order Block detection.** Entry-zone construction uses FVG/S-R/liquidity/VWAP only; "Order Block boundaries" from the original spec are not implemented as a distinct concept (no dedicated OB detector exists in Phase 2). Documented as a gap, not silently faked.
3. **`ScalpCandidate`, `IntradayCandidate`, `ShortSwingCandidate` are structurally similar but NOT unified under a shared base class** — each is a separate frozen dataclass with duplicated field patterns. This was a deliberate low-risk choice (avoiding inheritance surgery on a tested schema) but is real duplication a future refactor should address.
4. **No real event/news provider** — `NullEventRiskProvider` is the only implementation; the interface is ready but unused in practice until a real provider is wired in.
5. **Multi-candidate ranking is confluence-count + R:R only** — reasonable and explainable, but coarse; it does not account for zone quality (`entry_zone_quality`) in the ranking itself.
6. **Regime classification (`classify_market_regime`) is a documented heuristic precedence rule**, not a statistically validated model.
7. **No caching, observability, or audit-log persistence layer** — every call recomputes from scratch; nothing is persisted for backtesting yet (explicitly out of scope per Phase 4 spec, but still a real gap toward "production-grade").
8. **No live/streaming data path** — everything operates on a fixed historical bar array passed in per call.

## 8. Architectural Concerns Worth Flagging Now

- The **Autonomous Market Scanner** referenced in your priorities does not exist as a standalone component — today, each horizon engine must be invoked explicitly per symbol/timeframe combination by a caller. There is no scheduler/orchestrator scanning multiple symbols autonomously.
- The three horizon engines duplicate a fair amount of control flow (status checks → regime check → per-direction loop → evidence → confluence gate → entry zone). This is intentional (genuine per-horizon distinctness, per your explicit requirement not to merely wrap/rename), but a future Master Decision layer should be the one place that reconciles this, not a reason to prematurely unify the three now.

---

## 9. Files in This Session

**No files created or modified this session** — this was documentation, validation, and packaging only, exactly as scoped. All 16 `intelligence/` modules and 27 test files were produced in prior turns and are being packaged as-is.

---

## 10. Recommended First Step for Phase 5 (NOT executed)

Build the **Risk Engine** as the first Phase 5 component: a deterministic, independent authority that (a) validates every candidate's SL distance against an explicit account-level max-risk-per-trade parameter, (b) enforces a hard floor/ceiling on SL distance regardless of which structural source produced it, (c) can veto any candidate from any horizon engine, and (d) is the only component permitted to convert a `ZONE_IDENTIFIED`/`CONFIRMED` candidate into something a future Master Decision Engine may act on. This directly closes the largest gap identified in §6 before any Master Decision or execution-adjacent work begins.
