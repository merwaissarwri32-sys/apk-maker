"""
Structured schemas for raw and normalized market data.

Design rule: every object that leaves this layer and enters the rest of
Omnisystem must be a validated dataclass, never a raw dict. This is the
"input/output contract" boundary referenced in the architecture doc.

Note: built on stdlib `dataclasses` with explicit __post_init__
validation (no pydantic available in this environment) — the contract
guarantees are the same: invalid construction raises immediately.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe

SCHEMA_VERSION = "1.0"


class SchemaValidationError(ValueError):
    """Raised when a schema object fails its own validation rules."""


def _require_timezone_aware(value: datetime, field_name: str) -> None:
    if value.tzinfo is None:
        raise SchemaValidationError(f"{field_name} must be timezone-aware (UTC)")


@dataclass(frozen=True)
class OHLCVBar:
    """A single normalized OHLCV candle. Purely a data record — no
    interpretation, no signals."""

    open: float
    high: float
    low: float
    close: float
    volume: float
    open_time: datetime
    close_time: datetime

    def __post_init__(self):
        if self.volume < 0:
            raise SchemaValidationError("volume cannot be negative")
        if self.high < self.low:
            raise SchemaValidationError("high cannot be less than low")
        if self.high < self.open or self.high < self.close:
            raise SchemaValidationError("high must be >= open and close")
        if self.low > self.open or self.low > self.close:
            raise SchemaValidationError("low must be <= open and close")
        _require_timezone_aware(self.open_time, "open_time")
        _require_timezone_aware(self.close_time, "close_time")
        if self.close_time < self.open_time:
            raise SchemaValidationError("close_time cannot precede open_time")


@dataclass(frozen=True)
class DataProvenance:
    """Where this data came from and how old it is. Mandatory on every
    envelope — this is what lets the formatter truthfully say 'live' or not."""

    source: str                # e.g. "binance_spot", "mock_provider"
    origin: DataOrigin
    fetched_at: datetime       # when the ingestion layer retrieved it
    data_timestamp: datetime   # the timestamp the data itself represents (e.g. bar close)

    def __post_init__(self):
        _require_timezone_aware(self.fetched_at, "fetched_at")
        _require_timezone_aware(self.data_timestamp, "data_timestamp")

    @property
    def freshness_seconds(self) -> float:
        now = datetime.now(timezone.utc)
        return (now - self.data_timestamp).total_seconds()


@dataclass(frozen=True)
class MarketDataEnvelope:
    """The single object type that leaves the ingestion layer.

    This is intentionally the ONLY shape downstream engines are allowed
    to consume. quality_status is set by the Data Quality Gate, never by
    the provider itself — a provider reports what it saw, the gate
    decides whether it's usable.
    """

    market: str
    timeframe: Timeframe
    provenance: DataProvenance
    quality_status: QualityStatus
    bars: tuple[OHLCVBar, ...] = field(default_factory=tuple)
    reasons: tuple[str, ...] = field(default_factory=tuple)
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self):
        if self.provenance.origin == DataOrigin.UNAVAILABLE and self.bars:
            raise SchemaValidationError("origin=UNAVAILABLE cannot carry bar data")
        if self.provenance.origin == DataOrigin.UNAVAILABLE and self.quality_status != QualityStatus.DATA_UNAVAILABLE:
            raise SchemaValidationError("origin=UNAVAILABLE must have quality_status=DATA_UNAVAILABLE")

    def is_usable(self) -> bool:
        """Convenience check downstream engines should call before using bars."""
        return self.quality_status == QualityStatus.OK and self.provenance.origin in (
            DataOrigin.LIVE,
            DataOrigin.HISTORICAL,
        )
