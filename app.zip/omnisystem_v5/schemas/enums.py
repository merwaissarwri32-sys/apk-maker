"""
Enumerations shared across the ingestion layer.

These exist specifically to enforce the Phase 1 strict rule:
the system must always be able to say WHAT KIND of data it is
looking at (live vs historical vs simulated vs unavailable) and
WHAT STATE that data is in (ok vs stale vs insufficient vs error).
Nothing downstream is allowed to treat these as interchangeable.
"""

from enum import Enum


class DataOrigin(str, Enum):
    """Where a data point actually came from. Never inferred — always
    set explicitly by the provider that produced it."""

    LIVE = "LIVE"                # streamed/pulled from a live market feed just now
    HISTORICAL = "HISTORICAL"    # pulled from a historical/archival dataset
    SIMULATED = "SIMULATED"      # synthetic data, e.g. for tests/dev — NEVER usable by engines
    UNAVAILABLE = "UNAVAILABLE"  # no data could be obtained at all


class QualityStatus(str, Enum):
    """Result of running a data envelope through the Data Quality Gate."""

    OK = "OK"
    STALE = "STALE"                          # data exists but is older than freshness threshold
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"  # data exists but fails completeness checks
    INVALID = "INVALID"                      # data exists but fails validation rules
    ERROR = "ERROR"                          # ingestion/provider error occurred
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"    # explicit terminal state — no usable data, do not guess


class Timeframe(str, Enum):
    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    H1 = "1h"
    H4 = "4h"
    D1 = "1d"
