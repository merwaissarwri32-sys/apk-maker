# MERWIS AI - Phase 6: Master Decision Intelligence - Final Report

Boundaries respected: No Execution Engine, no Auto Trading, no Broker/Exchange
integration, no Autonomous Scanner, no Live Data Provider, no Order Placement, no
Market Prediction Engine were built. Phase 7 was NOT started.

---

## 1. Final Architecture

```
Intelligence candidates (Scalp / Intraday / Short-Swing / future engines)
                              |
        intelligence/decision_bridge.py   <- the ONLY file importing
                              |              both intelligence/ and decision/
                              v
                decision.contracts.NormalizedCandidate
                (+ ScoreComponents, decomposed evidence)
                              |
                    decision.engine.decide()
                              |
   Stage 1: data integrity        (fail-closed, per-candidate)
   Stage 2: same-engine duplicate resolution   (decision/conflict.py)
   Stage 3: directional conflict resolution    (decision/conflict.py)
   Stage 4: quality gate                       (decision/quality_gate.py)
   Stage 5: deterministic ranking              (decision/scoring.py)
   Stage 6: Risk Engine - HARD GATE, no bypass (risk/engine.py, unmodified)
   Stage 7: FinalDecision assembly
                              |
                              v
                decision.contracts.FinalDecision
        (decision_id, outcome, selected_candidate, risk_result,
         full candidate_trace, conflict_records, policy_version)
```

Independence guarantee (verified, not just claimed):
```
$ grep -rn "from omnisystem_v5\.(intelligence|quant|context)" omnisystem_v5/decision/
(no output)
```
`decision/` imports only `risk/` (the mandatory hard gate) - zero coupling to the
Intelligence layer's internals, exactly mirroring how `risk/` itself has zero
coupling to `decision/`, `intelligence/`, `quant/`, or `context/`. Each layer only
knows the layer directly below it through one bridge file.

---

## 2. Decision Flow (step by step)

1. Empty input -> `NO_TRADE` / `NO_CANDIDATES_PROVIDED`.
2. Multi-symbol input -> `NO_TRADE` / `MULTI_SYMBOL_INPUT_NOT_SUPPORTED` (documented current-scope limitation, not silently mishandled).
3. Data integrity: each candidate checked for finite/positive entry, finite/positive stop_loss, non-empty finite take_profits, valid direction. Failures marked `REJECTED_DATA_INVALID` individually - one bad candidate never blocks the others.
4. Same-engine duplicates: candidates from the same `source_engine`, same direction, within `duplicate_price_tolerance_pct` of each other's entry - only the highest-ranked survives.
5. Directional conflicts: any two candidates (any engines) with opposite directions on the same symbol. Resolved by comparing rank keys; a win requires beating the loser on at least `min_decisive_component_margin` components - otherwise both are dropped (never forced to pick a side on a close call).
6. Quality gate: requires `min_moderate_plus_components` of the 8 `ScoreComponents` fields at MODERATE+.
7. Ranking: lexicographic tuple comparison over `ScoringPolicy.component_priority_order` - no summed score anywhere.
8. Risk Engine: the top `max_risk_attempts` ranked candidates are tried, in order, against `risk.engine.assess_risk()`. The first one that comes back `is_actionable=True` wins. If none do, `NO_TRADE` / `NO_CANDIDATE_PASSED_RISK_GATE`.
9. Final decision: `LONG`/`SHORT` with the winning candidate and its `RiskAssessmentResult` attached, or `NO_TRADE` with a structured reason code at every stage.

---

## 3. Contracts / Schemas Created

| Contract | Purpose |
|---|---|
| `NormalizedCandidate` | Horizon-agnostic candidate shape; deterministic `candidate_id` via SHA-256 of its own defining fields (no randomness) |
| `ScoreComponents` | 8 named `QualityLevel` fields (structural, confirmation, risk, reward, timeframe, conflict_penalty, data, regime) - never summed |
| `DecisionRecord` | One per candidate considered: id, engine, direction, `CandidateStatus`, reasons |
| `ConflictRecord` | Type, involved candidate IDs, resolution, surviving ID, human detail |
| `FinalDecision` | decision_id, decision_version, policy_version, outcome, selected_candidate, risk_result, full candidate_trace, conflict_records, data_validity_summary, reason_code, reasons, audit_metadata |

Every dataclass carries a `metadata: dict` escape hatch for non-breaking future additions - no field was added "just in case" without a concrete current use.

`FinalDecision.__post_init__` enforces the hard invariants at the type level, not just by convention:
- `NO_TRADE` can never carry a `selected_candidate`.
- A non-`NO_TRADE` outcome can never exist without an actionable `RiskAssessmentResult` - this makes bypassing the Risk Engine a `ValueError`, not just a code-review concern.

---

## 4. Conflict-Resolution Policy

Two independent, pure-function stages (`decision/conflict.py`), both driven entirely by `ConflictPolicy`:

- Duplicates: `duplicate_price_tolerance_pct` (default 0.05%) - same engine, same direction, close entry price.
- Directional conflicts: `min_decisive_component_margin` (default 2 of 8 components) - the winner must clearly out-rank the loser; a near-tie drops both and surfaces as `UNRESOLVED_DIRECTIONAL_CONFLICT`.

Both thresholds are policy data, not code. Swapping in a future "engine reliability" or "regime compatibility" resolution rule means adding a new `ScoreComponents` field (already has slots: `regime_compatibility`, `conflict_penalty`) and/or reordering `component_priority_order` - no rewrite of `conflict.py`'s algorithm itself required for the common cases described in the spec (quality, risk-adjusted quality, timeframe hierarchy, engine reliability, regime compatibility all reduce to "add or reweight a component").

---

## 5. Ranking / Scoring Architecture

There is no aggregate score anywhere. `rank_key()` returns a tuple of ordinal ranks, one per `ScoringPolicy.component_priority_order` entry, compared lexicographically by Python's native tuple comparison. `explain_rank_key()` returns the same ordering paired with human-readable component names for audit output. Changing which factor dominates ranking (e.g., prioritizing timeframe hierarchy over reward quality) is a one-line policy change (`component_priority_order`), not a code change.

---

## 6. Risk Engine Integration (hard gate)

- `decide()` unconditionally builds a `risk.contracts.TradeCandidateInput` from the top-ranked survivor(s) and calls `risk.engine.assess_risk()` - no branch skips this call, and no file in `decision/` defines an alternate path around it.
- Only `RiskAssessmentResult.is_actionable == True` (i.e. `VALID` or `WARNING`) can produce a `LONG`/`SHORT` outcome - enforced twice: once by `decide()`'s own logic, and again structurally by `FinalDecision.__post_init__` raising if violated.
- If the top-ranked candidate fails risk, the next-ranked candidate (up to `DecisionPolicy.max_risk_attempts`, default 3) is tried - a more complete design than simply giving up after the single best candidate, while still bounded and deterministic.
- Zero modifications were made to `risk/*.py` - Phase 5's Risk Engine is consumed exactly as designed, unchanged.

---

## 7. Explainability / Decision Trace

Every `FinalDecision.candidate_trace` entry is a `DecisionRecord` with a structured `CandidateStatus` (`ACCEPTED`, `REJECTED_DATA_INVALID`, `REJECTED_DUPLICATE`, `REJECTED_CONFLICT`, `REJECTED_QUALITY`, `REJECTED_RANKED_LOWER`, `REJECTED_RISK`) plus machine-readable reason strings (risk rejection codes' `.value`, quality-gate detail counts, conflict margin explanations) - never bare prose alone. `conflict_records` separately document every duplicate/conflict decision with the exact candidates and margin involved. A dedicated test (`test_every_input_candidate_appears_exactly_once_in_trace`) enforces that every input candidate gets exactly one trace entry - this test caught a real bug (see Section 11).

---

## 8. Files Created

```
omnisystem_v5/decision/
    __init__.py
    enums.py            DecisionOutcome, CandidateStatus, ConflictType,
                         ConflictResolution, DataValidityState, QualityLevel
                         (+ quality_rank), DecisionReasonCode
    contracts.py         NormalizedCandidate, ScoreComponents, ConflictRecord,
                         DecisionRecord, FinalDecision
    policy.py             ScoringPolicy, ConflictPolicy, QualityGatePolicy,
                         DecisionPolicy
    scoring.py             rank_key, explain_rank_key, rank_candidates
    conflict.py            resolve_duplicates, resolve_directional_conflicts
    quality_gate.py        passes_quality_gate, apply_quality_gate
    engine.py              decide() - the orchestrator

omnisystem_v5/intelligence/
    decision_bridge.py    from_scalp_candidate / from_intraday_candidate /
                          from_short_swing_candidate -> NormalizedCandidate

omnisystem_v5/tests/
    test_phase6_scoring_conflict.py     (14 tests)
    test_phase6_quality_gate.py          (5 tests)
    test_phase6_engine_integration.py   (24 tests)
    test_phase6_adversarial.py          (10 tests)
```

## 9. Files Modified

None. No file under `risk/`, `intelligence/` (existing modules), `quant/`, `context/`, `calculations/`, `schemas/`, or `data/` was changed. `decision_bridge.py` is additive and imported by nothing in Phase 1-5.

---

## 10. New Tests: 53

| File | Count | Focus |
|---|---|---|
| `test_phase6_scoring_conflict.py` | 14 | Rank-key ordering, priority-order ties, duplicate detection (same/different engine, direction, distance), directional conflict decisiveness threshold |
| `test_phase6_quality_gate.py` | 5 | Threshold boundaries (exactly-at, too-few, all-none), pass/fail splitting |
| `test_phase6_engine_integration.py` | 24 | Full pipeline for every outcome type, multi-symbol rejection, data integrity isolation, duplicate/conflict/quality/risk stage interaction, policy-version recording, policy-change-changes-outcome, determinism, trace completeness, contract invariant violations |
| `test_phase6_adversarial.py` | 10 | Infinity/negative/zero numerics, huge numbers, 20-candidate mixed batch determinism, 10-way duplicate collapse, stale timestamps, never-forced NO_TRADE, full real-data stack test (raw bars -> MarketContext -> QuantContext -> Bull/Bear -> ScalpEngine -> decision_bridge -> Master Decision Engine) |

---

## 11. Bug Found and Fixed (this session)

`decide()`'s risk-attempt loop sliced `ranked[:max_risk_attempts]` into `attempted`, then iterated with a `break` on the first actionable candidate. Any candidate in `attempted` positioned after the winner but before the slice's end was never actually visited by the loop body and so never received a trace entry at all - silently vanishing from `candidate_trace` rather than being marked `REJECTED_RANKED_LOWER`. Caught immediately by `test_every_input_candidate_appears_exactly_once_in_trace`. Fixed by tracking the loop index and explicitly marking every `attempted` candidate positioned after the winner as `REJECTED_RANKED_LOWER`, alongside the pre-existing `not_attempted` (beyond `max_risk_attempts`) handling.

---

## 12. Test Results

```
Phase 6 new tests:         53/53  PASS
Full project suite:      392/392  PASS   (339 pre-existing + 53 new)
```

## 13. Regression Status

ZERO REGRESSION. All 339 tests from Phases 1-5 pass unchanged.

---

## 14. Architectural Trade-offs

- Scoring uses lexicographic tuple ranking instead of a weighted-sum score. More conservative and more literally "decomposable" than a weighted formula, at the cost of not being able to express "component A is twice as important as component B" - only "A is compared before B." This was a deliberate choice per the explicit "no magic number" instruction; a future weighted model can be introduced as an alternative `ScoringPolicy` implementation without touching `engine.py`.
- `decision/` duplicates a small vocabulary already defined in `intelligence/` (its own `QualityLevel` mirrors `AlignmentLevel`; its own reliance on `risk.enums.Direction` rather than `intelligence.enums.DirectionBias`). This is the same trade-off already made between `risk/` and `intelligence/` in Phase 5 - accepted again here for consistency and genuine layer independence, at the cost of a translation table in each bridge file.
- Single-symbol scope per `decide()` call. Multi-symbol portfolio-level decisioning was explicitly out of scope for this phase (and for Phase 5's `AccountState`, which already only tracks aggregate figures, not per-symbol breakdowns) - extending to multi-symbol is additive (a grouping wrapper around `decide()`), not a redesign.
- Directional-conflict resolution is pairwise over `itertools.combinations`, not a global optimization - for the realistic candidate counts this system produces (a handful per symbol per Intelligence Engine), this is the simplest correct algorithm; a chain of 3+ mutually conflicting candidates is still resolved correctly (a candidate dropped by any losing comparison is excluded from the final survivor set), just not via a single "find the global best" solver.

---

## 15. Remaining Limitations

1. No portfolio-level or cross-symbol reasoning (consistent with Phase 5's same limitation).
2. `regime_compatibility` and `conflict_penalty` `ScoreComponents` fields are always `NONE` today - the bridge doesn't populate them yet because no current Intelligence Engine output maps cleanly to a "regime compatibility" quality judgment beyond what's already captured elsewhere. The fields exist specifically so a future regime-aware policy can populate them without a schema change.
3. The `decision_bridge.py` quality mappings are coarse for Intraday/Short-Swing (`risk_quality`/`reward_quality` default to a flat `MODERATE`/`NONE` since those horizons' own `CandidateEvidence` shapes don't carry a dedicated risk-quality or reward-quality field - see Phase 4's report). This is an honest reflection of the underlying data, not a bridge shortcoming.
4. No persistence of `FinalDecision` objects - each `decide()` call is stateless; audit/compliance storage of decisions is a future layer's job.
5. `max_risk_attempts` is a flat integer, not adaptive (e.g., "keep trying until N minutes of evaluation time elapse") - deliberately simple and fully deterministic.

---

## 16. Future Extension Points (interfaces present, NOT implemented)

- `ScoreComponents.regime_compatibility` / `conflict_penalty` - ready for a regime-aware or engine-reliability-aware policy.
- `NormalizedCandidate.metadata` / `FinalDecision.audit_metadata` - open dict fields for anything a future layer (Portfolio Risk, Backtesting, Alerting) needs to attach without a schema migration.
- `DecisionPolicy` as a single injectable object - a future user-specific or asset-specific policy is just a different `DecisionPolicy` instance passed into the same `decide()` signature.
- The layered bridge pattern (`intelligence/decision_bridge.py`, `intelligence/risk_bridge.py`) is now established twice - a third Intelligence Engine or a completely new candidate source (e.g. an ML-assisted ranker) plugs in by writing one more bridge function, never by modifying `decision/` or `risk/`.

---

## 17. Recommended Phase 7 (NOT executed)

Two reasonable candidates, in order of how directly they build on what now exists:

1. A thin, read-only "Decision Explainer" / reporting view over `FinalDecision` - human-readable rendering of the structured trace for operators, with zero new decision logic. Low-risk, high value for trust-building before anything execution-adjacent is considered.
2. Backtesting harness: replay historical `MarketDataEnvelope` sequences through the full stack (Context -> Quant -> Intelligence -> Decision, Risk Engine included) to produce a sequence of `FinalDecision` objects and measure hypothetical outcomes - this is the natural way to gather the "evidence" the project's final principle demands before any performance claim is made, and it requires no new production code path, only a harness around what already exists.

Both stay entirely within the "no execution" boundary. Phase 7 has not been started; this is a recommendation only, pending explicit approval.
