"""Notification envelope - Phase 12. The core->transport contract: language-neutral data + rendered text for the target's locale.

An invalid envelope cannot be constructed (validation in __post_init__), so a malformed payload can never reach a transport.
Payloads are untrusted data: nothing is evaluated, templates are ours, params are only substituted as text, control characters
are refused, sizes are bounded. No vendor payload format exists here; real transports translate this contract behind the seam.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

from omnisystem_v5.alerts.enums import AlertDedupVerdict, AlertSeverity, NotificationChannel, NotificationUrgency
from omnisystem_v5.alerts.errors import PayloadValidationError
from omnisystem_v5.alerts.i18n import SEVERITY_KEY, AlertMessageKey as K
from omnisystem_v5.alerts.model import Alert
from omnisystem_v5.alerts.routing import NotificationTarget, NotificationRoute
from omnisystem_v5.marketdata.canonical import digest
from omnisystem_v5.marketdata.i18n import LocalizedMessage, MessageCatalog, StructuredMessage

MAX_LINES, MAX_LINE_CHARS, MAX_TOTAL_CHARS, MAX_PAYLOAD_CHARS = 12, 1000, 8000, 16000
_ID = re.compile(r"^[0-9a-f]{24}$")
_CTRL = re.compile(r"[\x00-\x1f\x7f]")
_NOTIFY_KEY = {AlertDedupVerdict.NEW: K.NOTIFY_NEW, AlertDedupVerdict.MATERIAL_CHANGE: K.NOTIFY_UPDATED,
               AlertDedupVerdict.RENOTIFY: K.NOTIFY_REMINDER, AlertDedupVerdict.REDELIVER: K.NOTIFY_REMINDER}


@dataclass(frozen=True)
class NotificationEnvelope:
    envelope_id: str
    alert_id: str
    target: NotificationTarget
    urgency: NotificationUrgency
    severity: AlertSeverity
    verdict: AlertDedupVerdict
    lines: tuple                     # LocalizedMessage, in display order
    payload_json: str                # canonical, language-neutral alert JSON
    degraded_localization: bool = False

    def __post_init__(self):
        def bad(why):
            raise PayloadValidationError(why)
        if not isinstance(self.envelope_id, str) or not _ID.match(self.envelope_id):
            bad("envelope_id must be 24 lowercase hex characters")
        if not isinstance(self.alert_id, str) or not self.alert_id or not isinstance(self.target, NotificationTarget):
            bad("alert_id/target invalid")
        if not isinstance(self.urgency, NotificationUrgency) or not isinstance(self.severity, AlertSeverity) or not isinstance(self.verdict, AlertDedupVerdict):
            bad("urgency/severity/verdict have the wrong types")
        if not self.verdict.notifies:
            bad("a suppressed verdict must never produce an envelope")
        if not self.lines or len(self.lines) > MAX_LINES or not all(isinstance(x, LocalizedMessage) for x in self.lines):
            bad("lines must be 1..MAX_LINES LocalizedMessage items")
        total = 0
        for x in self.lines:
            if not isinstance(x.text, str) or not x.text.strip() or len(x.text) > MAX_LINE_CHARS or _CTRL.search(x.text):
                bad("a rendered line is empty, too long or contains control characters")
            total += len(x.text)
        if total > MAX_TOTAL_CHARS:
            bad("rendered text is too long")
        if not isinstance(self.payload_json, str) or len(self.payload_json) > MAX_PAYLOAD_CHARS:
            bad("payload is missing or too large")
        try:
            if json.loads(self.payload_json).get("identity", {}).get("family") is None:
                bad("payload is not a canonical alert")
        except (ValueError, AttributeError):
            bad("payload is not valid JSON")

    @property
    def channel(self) -> NotificationChannel:
        return self.target.channel


def envelope_id_for(alert: Alert, target_id: str, verdict: AlertDedupVerdict) -> str:
    return digest({"alert": alert.alert_id, "observation": alert.observation_key, "target": target_id, "verdict": verdict})[:24]


def build_envelope(alert: Alert, verdict: AlertDedupVerdict, route: NotificationRoute, target: NotificationTarget, catalog: MessageCatalog) -> NotificationEnvelope:
    """Raises PayloadValidationError (never returns a malformed envelope)."""
    if not isinstance(verdict, AlertDedupVerdict) or not verdict.notifies:
        raise PayloadValidationError("a suppressed verdict must never produce an envelope")
    msgs = [StructuredMessage(SEVERITY_KEY[alert.severity.value]), StructuredMessage(_NOTIFY_KEY[verdict]), alert.headline, *alert.reasons]
    lines = tuple(catalog.render(m, target.locale) for m in msgs)
    return NotificationEnvelope(
        envelope_id=envelope_id_for(alert, target.target_id, verdict), alert_id=alert.alert_id, target=target, urgency=route.urgency,
        severity=alert.severity, verdict=verdict, lines=lines, payload_json=alert.to_json(),
        degraded_localization=any(x.fallback for x in lines))
