"""Deterministic alert identity - Phase 12.

family      = digest(version, alert type, family pairs)        -> "which ongoing condition"
fingerprint = digest(family, state pairs)                        -> "which materially distinct state of it"
Inputs are stable semantic fields only: no wall-clock, no random id, no pid/address, no Python hash(). The SOURCE is
deliberately NOT part of identity so the same provider outage seen via a snapshot and via an event is ONE condition.
"""
from __future__ import annotations

from omnisystem_v5.alerts.enums import AlertType
from omnisystem_v5.alerts.model import AlertIdentity, pairs
from omnisystem_v5.marketdata.canonical import digest

IDENTITY_VERSION = "alert-id/1"


def compute_identity(alert_type: AlertType, family, state) -> AlertIdentity:
    fam = pairs(family)
    fam_digest = digest({"v": IDENTITY_VERSION, "type": alert_type, "family": fam})[:20]
    fp_digest = digest({"v": IDENTITY_VERSION, "family": fam_digest, "state": pairs(state)})[:20]
    return AlertIdentity(fam_digest, fp_digest)
