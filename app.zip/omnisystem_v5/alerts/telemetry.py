"""Alert telemetry - Phase 12. Reuses the Phase 11 event plumbing (TelemetryEvent / sinks / safe `emit`); no second
observability system. The kind enum is alert-specific because DataEventKind is frozen; the emit helper only tags the
event with `kind.value`-carrying enum members, so any str-Enum kind is accepted (same nominal convention as Phase 11).
Emission NEVER raises: a failing sink returns False and is counted, never propagated."""
from __future__ import annotations

from enum import Enum

from omnisystem_v5.marketdata.events import CompositeSink, emit as _emit          # noqa: F401  (CompositeSink re-exported for wiring)


class AlertEventKind(str, Enum):
    ALERT_CREATED = "ALERT_CREATED"
    ALERT_REJECTED = "ALERT_REJECTED"            # qualification failure / unsupported / upstream-suppressed / below policy
    ALERT_DEDUPLICATED = "ALERT_DEDUPLICATED"    # EXACT_DUPLICATE or STILL_ACTIVE
    ALERT_SUPPRESSED = "ALERT_SUPPRESSED"        # COOLDOWN, or no eligible target after routing
    ALERT_EXPIRED = "ALERT_EXPIRED"
    ROUTING_DECIDED = "ROUTING_DECIDED"
    DELIVERY_STARTED = "DELIVERY_STARTED"
    DELIVERY_SUCCEEDED = "DELIVERY_SUCCEEDED"
    DELIVERY_FAILED = "DELIVERY_FAILED"
    RETRY_SCHEDULED = "RETRY_SCHEDULED"
    RETRY_EXHAUSTED = "RETRY_EXHAUSTED"
    PIPELINE_ERROR = "PIPELINE_ERROR"            # a stage failed for one candidate; processing of the rest continued


def emit_alert_event(sink, kind: AlertEventKind, at, subject=None, **detail) -> bool:
    return _emit(sink, kind, at, subject, **detail)
