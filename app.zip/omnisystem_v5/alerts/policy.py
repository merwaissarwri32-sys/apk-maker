"""Alert policy - Phase 12. Explicit, deterministic, validated at construction (fail closed).

Severity is POLICY-DRIVEN and explainable: a table lookup on a declared fact of the candidate (risk verdict, health state,
event kind). It is never a probability and never claims a signal is profitable. Unknown facts have NO severity and are
rejected as unsupported rather than guessed.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from omnisystem_v5.alerts.dedup import AlertDedupPolicy
from omnisystem_v5.alerts.enums import AlertSeverity as S
from omnisystem_v5.alerts.enums import AlertSourceKind, AlertType
from omnisystem_v5.alerts.errors import AlertConfigError


def _table(name: str, table: tuple) -> tuple:
    if not isinstance(table, tuple) or not all(isinstance(p, tuple) and len(p) == 2 and isinstance(p[0], str) and isinstance(p[1], S) for p in table):
        raise AlertConfigError(f"{name} must be a tuple of (str, AlertSeverity) pairs")
    if len({k for k, _ in table}) != len(table):
        raise AlertConfigError(f"{name} has duplicate keys")
    return table


@dataclass(frozen=True)
class SeverityPolicy:
    signal_by_risk: tuple = (("VALID", S.NOTICE), ("WARNING", S.WARNING))
    provider_by_state: tuple = (("HEALTHY", S.INFO), ("RECOVERING", S.INFO), ("THROTTLED", S.NOTICE), ("DEGRADED", S.WARNING), ("UNAVAILABLE", S.CRITICAL))
    instrument_by_state: tuple = (("AVAILABLE", S.INFO), ("DEGRADED", S.NOTICE), ("QUARANTINED", S.WARNING), ("UNAVAILABLE", S.WARNING), ("DISABLED", S.INFO))
    system_by_state: tuple = (("HEALTHY", S.INFO), ("NO_WORK", S.INFO), ("DEGRADED", S.WARNING), ("UNAVAILABLE", S.CRITICAL), ("SYSTEMIC_FAILURE", S.CRITICAL))
    event_by_kind: tuple = (("DATA_STALE", S.WARNING), ("DATA_REJECTED", S.NOTICE), ("PROVIDER_ERROR", S.WARNING), ("RATE_LIMITED", S.NOTICE))

    def __post_init__(self):
        for n in ("signal_by_risk", "provider_by_state", "instrument_by_state", "system_by_state", "event_by_kind"):
            _table(n, getattr(self, n))

    def severity_for(self, candidate):
        """AlertSeverity or None (no rule -> unsupported)."""
        t = candidate.alert_type
        if t == AlertType.SIGNAL:
            table, key = self.signal_by_risk, candidate.detail("risk_verdict")
        elif t == AlertType.PROVIDER_HEALTH:
            table, key = self.provider_by_state, candidate.detail("state")
        elif t == AlertType.INSTRUMENT_HEALTH:
            table, key = self.instrument_by_state, candidate.detail("state")
        elif t == AlertType.SYSTEM_HEALTH:
            table, key = self.system_by_state, candidate.detail("state")
        else:
            table, key = self.event_by_kind, candidate.detail("event_kind")
        return dict(table).get(key)


@dataclass(frozen=True)
class QualificationPolicy:
    enabled_sources: frozenset = frozenset(AlertSourceKind)
    min_severity: S = S.NOTICE

    def __post_init__(self):
        if not isinstance(self.min_severity, S) or not self.enabled_sources or not all(isinstance(s, AlertSourceKind) for s in self.enabled_sources):
            raise AlertConfigError("qualification policy is invalid")


@dataclass(frozen=True)
class AlertPolicy:
    qualification: QualificationPolicy = field(default_factory=QualificationPolicy)
    severity: SeverityPolicy = field(default_factory=SeverityPolicy)
    dedup: AlertDedupPolicy = field(default_factory=AlertDedupPolicy)
