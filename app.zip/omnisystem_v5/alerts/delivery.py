"""Delivery - Phase 12. One envelope, one transport, bounded deterministic retry, explicit state machine. Never raises.

REUSED from Phase 11: RetryPolicy (attempt cap, backoff, deterministic jitter, rate-limit wait budget, retry_on), compute_delay.
REUSED from Phase 10: FailureClass / classify_fetch_exception / ProviderRateLimitedError.
Time is injected: `clock` reads, `sleep` waits (this module imports no `time`). Retries happen ONLY inside deliver(), are capped
by max_attempts and an optional total deadline, and are never attempted for permanent / auth / config / rejected / internal
failures. A rate limit is waited on only when rate_limit_max_wait_seconds allows it, otherwise it is reported (FAILED, with
retry_after_seconds) - exactly the Phase 11 philosophy. A failing transport only affects its own envelope.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.alerts.enums import (DELIVERY_TRANSITIONS, AttemptOutcome, DeliveryFailureKind, DeliveryStatus, NotificationChannel)
from omnisystem_v5.alerts.errors import AlertConfigError, TransportAuthError, TransportConfigError, TransportRejectedError
from omnisystem_v5.alerts.telemetry import AlertEventKind as E
from omnisystem_v5.alerts.telemetry import emit_alert_event
from omnisystem_v5.marketdata.config import RetryPolicy
from omnisystem_v5.marketdata.retry import compute_delay
from omnisystem_v5.scanner.failures import FailureClass, classify_fetch_exception

# Why DeliveryFailureKind exists: FailureClass has no AUTH / CONFIG / REJECTED notion. Where they overlap it is REUSED via this map.
FAILURE_CLASS_OF = {DeliveryFailureKind.TIMEOUT: FailureClass.PROVIDER_TIMEOUT, DeliveryFailureKind.RATE_LIMITED: FailureClass.PROVIDER_RATE_LIMITED,
                    DeliveryFailureKind.UNAVAILABLE: FailureClass.PROVIDER_UNAVAILABLE, DeliveryFailureKind.REJECTED: FailureClass.MALFORMED_RESPONSE,
                    DeliveryFailureKind.INTERNAL: FailureClass.INTERNAL_ERROR}
_FROM_CLASS = {FailureClass.PROVIDER_TIMEOUT: DeliveryFailureKind.TIMEOUT, FailureClass.PROVIDER_RATE_LIMITED: DeliveryFailureKind.RATE_LIMITED,
               FailureClass.PROVIDER_UNAVAILABLE: DeliveryFailureKind.UNAVAILABLE}


def classify_transport_exception(exc: BaseException) -> DeliveryFailureKind:
    if isinstance(exc, TransportAuthError):
        return DeliveryFailureKind.AUTH
    if isinstance(exc, TransportConfigError):
        return DeliveryFailureKind.CONFIG
    if isinstance(exc, TransportRejectedError):
        return DeliveryFailureKind.REJECTED
    return _FROM_CLASS.get(classify_fetch_exception(exc), DeliveryFailureKind.INTERNAL)


@dataclass(frozen=True)
class DeliveryPolicy:
    retry: RetryPolicy = field(default_factory=lambda: RetryPolicy(max_attempts=3, base_delay_seconds=1.0,
                                                                   retry_on=frozenset({FailureClass.PROVIDER_TIMEOUT, FailureClass.PROVIDER_UNAVAILABLE})))
    timeout_seconds: float = 10.0
    deadline_seconds: float | None = 60.0          # total budget for one envelope (elapsed + next wait); None = attempts cap only

    def __post_init__(self):
        if not isinstance(self.retry, RetryPolicy):
            raise AlertConfigError("retry must be a RetryPolicy")
        if isinstance(self.timeout_seconds, bool) or not isinstance(self.timeout_seconds, (int, float)) or not self.timeout_seconds > 0:
            raise AlertConfigError("timeout_seconds must be > 0")
        if self.deadline_seconds is not None and (isinstance(self.deadline_seconds, bool) or not isinstance(self.deadline_seconds, (int, float)) or not self.deadline_seconds > 0):
            raise AlertConfigError("deadline_seconds must be > 0 or None")


@dataclass(frozen=True)
class DeliveryAttempt:
    number: int
    started_at: datetime
    outcome: AttemptOutcome
    failure_kind: DeliveryFailureKind | None = None
    retry_delay_seconds: float | None = None
    error_type: str | None = None               # exception CLASS NAME only - messages may carry secrets and are never stored


@dataclass(frozen=True)
class DeliveryResult:
    envelope_id: str
    alert_id: str
    target_id: str
    channel: NotificationChannel
    status: DeliveryStatus
    attempts: tuple = ()
    state_path: tuple = ()
    failure_kind: DeliveryFailureKind | None = None
    retry_after_seconds: float | None = None
    detail: str = ""
    telemetry_errors: int = 0


def rejected_result(envelope_id: str, alert_id: str, target_id: str, channel, detail: str = "payload_invalid") -> DeliveryResult:
    """A payload that failed validation and was therefore never sent."""
    return DeliveryResult(envelope_id, alert_id, target_id, channel, DeliveryStatus.REJECTED, (), (DeliveryStatus.PENDING, DeliveryStatus.REJECTED),
                          DeliveryFailureKind.REJECTED, None, detail)


class DeliveryExecutor:
    def __init__(self, policy: DeliveryPolicy, clock, sleep, sink=None):
        if not callable(sleep):
            raise AlertConfigError("sleep must be an injected callable (seconds) -> None")
        self._p, self._clock, self._sleep, self._sink = policy, clock, sleep, sink

    def _wait_for(self, kind: DeliveryFailureKind, exc, envelope_id: str, attempt: int):
        """Seconds to wait before the next attempt, or None if this failure is not retryable."""
        r = self._p.retry
        if kind in (DeliveryFailureKind.TIMEOUT, DeliveryFailureKind.UNAVAILABLE):
            return compute_delay(r, envelope_id, attempt) if FAILURE_CLASS_OF[kind] in r.retry_on else None
        if kind == DeliveryFailureKind.RATE_LIMITED:
            after = getattr(exc, "retry_after_seconds", None)
            if r.rate_limit_max_wait_seconds > 0 and after is not None and 0 <= after <= r.rate_limit_max_wait_seconds:
                return float(after)
        return None

    def deliver(self, envelope, transport) -> DeliveryResult:
        ids = (envelope.envelope_id, envelope.alert_id, envelope.target.target_id, envelope.channel)
        path, attempts, tel = [DeliveryStatus.PENDING], [], [0]

        def go(new: DeliveryStatus):
            if new not in DELIVERY_TRANSITIONS[path[-1]]:
                raise AssertionError(f"illegal delivery transition {path[-1].value} -> {new.value}")
            path.append(new)

        def ev(kind, **detail):
            if not emit_alert_event(self._sink, kind, self._clock.now(), envelope.alert_id, envelope_id=envelope.envelope_id,
                                    target=envelope.target.target_id, channel=envelope.channel, **detail):
                tel[0] += 1

        def done(status, kind=None, retry_after=None, detail=""):
            return DeliveryResult(*ids, status, tuple(attempts), tuple(path), kind, retry_after, detail, tel[0])

        if transport is None or getattr(transport, "channel", None) != envelope.channel:
            go(DeliveryStatus.FAILED)
            ev(E.DELIVERY_FAILED, failure_kind=DeliveryFailureKind.CONFIG, detail="no_transport_bound")
            return done(DeliveryStatus.FAILED, DeliveryFailureKind.CONFIG, detail="no_transport_bound")
        started = self._clock.now()
        ev(E.DELIVERY_STARTED, urgency=envelope.urgency)
        n = 0
        while True:
            n += 1
            go(DeliveryStatus.ATTEMPTING)
            at = self._clock.now()
            try:
                transport.send(envelope, self._p.timeout_seconds)
            except Exception as exc:                                   # isolation: a transport can never break the caller
                kind, err = classify_transport_exception(exc), type(exc).__name__
                wait = self._wait_for(kind, exc, envelope.envelope_id, n)
                after = getattr(exc, "retry_after_seconds", None) if kind == DeliveryFailureKind.RATE_LIMITED else None
                if wait is None:
                    status, detail = DeliveryStatus.FAILED, "not_retryable"
                elif n >= self._p.retry.max_attempts:
                    status, detail = DeliveryStatus.EXHAUSTED, "attempts"
                elif self._p.deadline_seconds is not None and (self._clock.now() - started).total_seconds() + wait > self._p.deadline_seconds:
                    status, detail = DeliveryStatus.EXHAUSTED, "deadline"
                else:
                    attempts.append(DeliveryAttempt(n, at, AttemptOutcome.FAILURE, kind, wait, err))
                    go(DeliveryStatus.RETRY_SCHEDULED)
                    ev(E.RETRY_SCHEDULED, attempt=n, delay_seconds=wait, failure_kind=kind)
                    try:
                        self._sleep(wait)
                    except Exception:
                        go(DeliveryStatus.FAILED)
                        ev(E.DELIVERY_FAILED, failure_kind=DeliveryFailureKind.INTERNAL, detail="sleep_error")
                        return done(DeliveryStatus.FAILED, DeliveryFailureKind.INTERNAL, detail="sleep_error")
                    continue
                attempts.append(DeliveryAttempt(n, at, AttemptOutcome.FAILURE, kind, None, err))
                go(status)
                ev(E.RETRY_EXHAUSTED if status == DeliveryStatus.EXHAUSTED else E.DELIVERY_FAILED, attempt=n, failure_kind=kind, detail=detail)
                return done(status, kind, after, detail)
            attempts.append(DeliveryAttempt(n, at, AttemptOutcome.SUCCESS))
            go(DeliveryStatus.DELIVERED)
            ev(E.DELIVERY_SUCCEEDED, attempts=n)
            return done(DeliveryStatus.DELIVERED)
