"""Alert & Notification Infrastructure - MERWIS AI, Phase 12.

Dependency direction (enforced by tests):  frozen Phase 1-11 layers  ->  alerts.   Never the reverse.
This package observes already-computed results and routes notifications. It has no execution capability,
no network access, no clock reads and no threads: time, sleep and transports are injected.
EVIDENCE CLASS: IMPLEMENTED + TESTED (synthetic/offline). Nothing here is live-connected.
"""
