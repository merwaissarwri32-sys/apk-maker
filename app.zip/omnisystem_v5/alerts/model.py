"""Alert domain contracts - Phase 12. Small, immutable, validated (fail closed), language-neutral.

An AlertCandidate is a SOURCE-NORMALISED observation (no severity, no identity, no clock). An Alert is what qualification +
construction make of it. Nothing here recomputes a decision or a risk result; values are carried exactly as exposed by the
frozen contracts. No probability / confidence is ever invented.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum

from omnisystem_v5.alerts.enums import AlertSeverity, AlertSourceKind, AlertState, AlertType
from omnisystem_v5.alerts.errors import AlertValidationError
from omnisystem_v5.alerts.i18n import AlertMessageKey
from omnisystem_v5.marketdata.canonical import canonical_dict, canonical_json
from omnisystem_v5.marketdata.i18n import MessageKey, StructuredMessage

SCHEMA_VERSION = "alert/1"
_CTRL = re.compile(r"[\x00-\x1f\x7f]")
_HEX20 = re.compile(r"^[0-9a-f]{20}$")


def clean_text(name: str, value, max_len: int = 200, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not value and not allow_empty):
        raise AlertValidationError(f"{name} must be a non-empty string")
    if len(value) > max_len or _CTRL.search(value):
        raise AlertValidationError(f"{name} is too long or contains control characters")
    return value


def _opt_text(name, value):
    return None if value is None else clean_text(name, value, 120)


def scalar(name: str, v, max_len: int = 500):
    """Normalise one detail/identity value to a plain scalar (str | int | float | bool | None)."""
    if isinstance(v, Enum):
        v = v.value
    if isinstance(v, datetime):
        if v.tzinfo is None:
            raise AlertValidationError(f"{name}: naive datetime")
        return v.astimezone(timezone.utc).isoformat()
    if isinstance(v, (tuple, list, frozenset, set)):
        v = ",".join(str(scalar(name, x, max_len)) for x in (sorted(v, key=str) if isinstance(v, (set, frozenset)) else v))
    if v is None or isinstance(v, (bool, int)):
        return v
    if isinstance(v, float):
        if not math.isfinite(v):
            raise AlertValidationError(f"{name}: non-finite number")
        return v                      # carried exactly as exposed; canonical JSON already writes floats deterministically
    if isinstance(v, str):
        return clean_text(name, v, max_len, allow_empty=True)
    raise AlertValidationError(f"{name}: unsupported value type {type(v).__name__}")


def pairs(mapping) -> tuple:
    """dict / iterable of pairs -> sorted tuple of (str, scalar); duplicate keys are refused."""
    items = list(mapping.items()) if isinstance(mapping, dict) else list(mapping)
    out = {}
    for k, v in items:
        k = clean_text("key", k, 64)
        if k in out:
            raise AlertValidationError(f"duplicate key {k!r}")
        out[k] = scalar(k, v)
    return tuple(sorted(out.items()))


def _aware(name, v):
    if not isinstance(v, datetime) or v.tzinfo is None:
        raise AlertValidationError(f"{name} must be a timezone-aware datetime")
    return v


@dataclass(frozen=True)
class AlertSource:
    kind: AlertSourceKind
    name: str

    def __post_init__(self):
        if not isinstance(self.kind, AlertSourceKind):
            raise AlertValidationError("source.kind must be an AlertSourceKind")
        clean_text("source.name", self.name, 64)


@dataclass(frozen=True)
class AlertContext:
    symbol: str | None = None
    instrument: str | None = None       # e.g. "CRYPTO:BTC/USDT" (asset class + canonical symbol)
    asset_class: str | None = None
    venue: str | None = None
    provider: str | None = None
    horizon: str | None = None
    direction: str | None = None
    timeframe: str | None = None

    def __post_init__(self):
        for f in ("symbol", "instrument", "asset_class", "venue", "provider", "horizon", "direction", "timeframe"):
            _opt_text(f"context.{f}", getattr(self, f))


@dataclass(frozen=True)
class AlertPriority:
    """The scanner's COMPUTATIONAL priority, carried unchanged. Not severity, not urgency, not a probability."""
    kind: str
    components: tuple            # ((name, ordinal), ...)

    def __post_init__(self):
        clean_text("priority.kind", self.kind, 80)
        if not all(isinstance(c, tuple) and len(c) == 2 and isinstance(c[0], str) and isinstance(c[1], int) and not isinstance(c[1], bool) for c in self.components):
            raise AlertValidationError("priority.components must be ((name, int), ...)")


def _check_message(m, where):
    if not isinstance(m, StructuredMessage) or not isinstance(m.key, (AlertMessageKey, MessageKey)):
        raise AlertValidationError(f"{where} must be a StructuredMessage with an AlertMessageKey or MessageKey")
    return m


@dataclass(frozen=True)
class AlertCandidate:
    alert_type: AlertType
    source: AlertSource
    context: AlertContext
    headline: StructuredMessage
    family: tuple                # identity pairs: which ongoing condition this belongs to
    state: tuple                 # identity pairs: which materially distinct state of that condition
    observation_key: str         # stable id of THIS observation (replay of the same observation -> same key)
    observed_at: datetime
    reasons: tuple = ()
    details: tuple = ()
    evidence: tuple = ()
    priority: AlertPriority | None = None

    def __post_init__(self):
        if not isinstance(self.alert_type, AlertType) or not isinstance(self.source, AlertSource) or not isinstance(self.context, AlertContext):
            raise AlertValidationError("candidate type/source/context have the wrong types")
        _check_message(self.headline, "headline")
        for r in self.reasons:
            _check_message(r, "reason")
        if not self.family:
            raise AlertValidationError("candidate.family must not be empty")
        for n in ("family", "state", "details", "evidence"):
            object.__setattr__(self, n, pairs(getattr(self, n)))
        clean_text("observation_key", self.observation_key, 300)
        _aware("observed_at", self.observed_at)
        if self.priority is not None and not isinstance(self.priority, AlertPriority):
            raise AlertValidationError("priority must be an AlertPriority or None")

    def detail(self, key: str, default=None):
        return dict(self.details).get(key, default)


@dataclass(frozen=True)
class AlertIdentity:
    family: str
    fingerprint: str

    def __post_init__(self):
        if not (isinstance(self.family, str) and _HEX20.match(self.family) and isinstance(self.fingerprint, str) and _HEX20.match(self.fingerprint)):
            raise AlertValidationError("identity parts must be 20 lowercase hex characters")

    @property
    def alert_id(self) -> str:
        return f"{self.family}.{self.fingerprint}"


@dataclass(frozen=True)
class Alert:
    identity: AlertIdentity
    alert_type: AlertType
    source: AlertSource
    severity: AlertSeverity
    context: AlertContext
    headline: StructuredMessage
    observation_key: str
    observed_at: datetime         # when the producer observed it (source time)
    created_at: datetime          # injected-clock time of construction (NOT part of identity)
    reasons: tuple = ()
    details: tuple = ()
    evidence: tuple = ()
    priority: AlertPriority | None = None
    state: AlertState = AlertState.ACTIVE
    schema_version: str = SCHEMA_VERSION

    def __post_init__(self):
        if not isinstance(self.identity, AlertIdentity) or not isinstance(self.alert_type, AlertType) or not isinstance(self.source, AlertSource):
            raise AlertValidationError("alert identity/type/source have the wrong types")
        if not isinstance(self.severity, AlertSeverity) or not isinstance(self.state, AlertState) or not isinstance(self.context, AlertContext):
            raise AlertValidationError("alert severity/state/context have the wrong types")
        _check_message(self.headline, "headline")
        for r in self.reasons:
            _check_message(r, "reason")
        clean_text("observation_key", self.observation_key, 300)
        _aware("observed_at", self.observed_at)
        _aware("created_at", self.created_at)
        for n in ("details", "evidence"):
            object.__setattr__(self, n, pairs(getattr(self, n)))
        if self.priority is not None and not isinstance(self.priority, AlertPriority):
            raise AlertValidationError("priority must be an AlertPriority or None")

    @property
    def alert_id(self) -> str:
        return self.identity.alert_id

    def detail(self, key: str, default=None):
        return dict(self.details).get(key, default)

    def to_dict(self) -> dict:
        return canonical_dict(self)

    def to_json(self) -> str:
        return canonical_json(self)
