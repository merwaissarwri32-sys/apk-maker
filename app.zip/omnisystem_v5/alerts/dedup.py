"""Alert deduplication / lifecycle - Phase 12. Pure functions over an immutable AlertDedupState; no clock reads, no globals.

It operates at the ALERT boundary (the Phase 10 scanner already dedups signals; this does not re-implement that - it makes
notification idempotent across replays, restarts of the consumer, non-scanner sources and failed deliveries).

  key:  family (which ongoing condition)  x  fingerprint (which materially distinct state)  x  observation_key (this sighting)
  NEW              no record for the family
  EXACT_DUPLICATE  observation_key already seen                      -> suppressed, nothing changes
  MATERIAL_CHANGE  same family, different fingerprint                -> notifies, bypasses cooldown (as in Phase 10)
  STILL_ACTIVE     same fingerprint, newer sighting, not expired     -> suppressed, last_seen refreshed
  COOLDOWN         same fingerprint re-appeared after expiry but inside cooldown since the last notification -> suppressed
  RENOTIFY         same fingerprint re-appeared after expiry and after the cooldown                           -> notifies
  REDELIVER        same fingerprint, newer sighting, previous notification reached nobody -> notifies, bounded by max_redeliveries
Boundaries are strict: expires when now-last_seen > expiry; cooldown holds while now-last_notified < cooldown;
expired records are forgotten (-> NEW) once now-last_notified >= retention_seconds.
Persistence seam: AlertStateStore (load/save) + to_dict/from_dict. The reference store is in-memory and NOT durable.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

from omnisystem_v5.alerts.enums import ALERT_TRANSITIONS, AlertDedupVerdict, AlertState
from omnisystem_v5.alerts.errors import AlertConfigError, AlertValidationError
from omnisystem_v5.alerts.model import Alert
from omnisystem_v5.marketdata.canonical import canonical_dict


@dataclass(frozen=True)
class AlertDedupPolicy:
    cooldown_seconds: float = 900.0
    expiry_seconds: float = 300.0
    max_redeliveries: int = 2
    observation_memory: int = 32
    retention_seconds: float = 86400.0      # expired records are remembered this long (bounded state), then forgotten -> NEW

    def __post_init__(self):
        for n in ("cooldown_seconds", "expiry_seconds", "retention_seconds"):
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or v in (float("inf"), float("-inf")):
                raise AlertConfigError(f"{n} must be a finite number")
        if self.cooldown_seconds < 0 or self.expiry_seconds <= 0:
            raise AlertConfigError("cooldown_seconds must be >= 0 and expiry_seconds > 0")
        if self.retention_seconds < self.cooldown_seconds:
            raise AlertConfigError("retention_seconds must be >= cooldown_seconds")
        for n in ("max_redeliveries", "observation_memory"):
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, int) or v < (0 if n == "max_redeliveries" else 1):
                raise AlertConfigError(f"{n} is out of range")


@dataclass(frozen=True)
class AlertRecord:
    family: str
    fingerprint: str
    state: AlertState
    first_seen_at: datetime
    last_seen_at: datetime
    last_notified_at: datetime
    seen_count: int = 1
    observations: tuple = ()
    pending_delivery: bool = False
    redeliveries: int = 0


@dataclass(frozen=True)
class AlertDedupState:
    records: tuple = field(default_factory=tuple)

    def get(self, family: str):
        return next((r for r in self.records if r.family == family), None)

    def to_dict(self) -> dict:
        return canonical_dict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "AlertDedupState":
        """Restore after a restart. Fail closed: anything malformed raises AlertValidationError."""
        try:
            recs = []
            for r in data["records"]:
                recs.append(AlertRecord(
                    family=str(r["family"]), fingerprint=str(r["fingerprint"]), state=AlertState(r["state"]),
                    first_seen_at=datetime.fromisoformat(r["first_seen_at"]), last_seen_at=datetime.fromisoformat(r["last_seen_at"]),
                    last_notified_at=datetime.fromisoformat(r["last_notified_at"]), seen_count=int(r["seen_count"]),
                    observations=tuple(str(o) for o in r["observations"]), pending_delivery=bool(r["pending_delivery"]),
                    redeliveries=int(r["redeliveries"])))
            for r in recs:
                for n in ("first_seen_at", "last_seen_at", "last_notified_at"):
                    if getattr(r, n).tzinfo is None:
                        raise AlertValidationError("naive datetime in stored state")
            return cls(_by_family(recs))
        except AlertValidationError:
            raise
        except (KeyError, TypeError, ValueError) as exc:
            raise AlertValidationError(f"stored alert state is malformed: {type(exc).__name__}") from exc


def _by_family(records) -> tuple:
    return tuple(sorted(records, key=lambda r: r.family))


def _move(rec: AlertRecord, new: AlertState, **changes) -> AlertRecord:
    if new != rec.state and new not in ALERT_TRANSITIONS[rec.state]:
        raise AlertValidationError(f"illegal alert transition {rec.state.value} -> {new.value}")
    return dataclasses.replace(rec, state=new, **changes)


def expire(state: AlertDedupState, now: datetime, policy: AlertDedupPolicy) -> tuple:
    """(new_state, newly_expired_records). Expired records are forgotten after retention_seconds (state stays bounded)."""
    kept, expired = [], []
    for r in state.records:
        if r.state == AlertState.ACTIVE and (now - r.last_seen_at).total_seconds() > policy.expiry_seconds:
            r = _move(r, AlertState.EXPIRED)
            expired.append(r)
        if r.state == AlertState.EXPIRED and (now - r.last_notified_at).total_seconds() >= policy.retention_seconds:
            continue
        kept.append(r)
    return AlertDedupState(_by_family(kept)), tuple(sorted(expired, key=lambda r: r.family))


def _remember(rec_obs: tuple, key: str, policy: AlertDedupPolicy) -> tuple:
    return (*rec_obs, key)[-policy.observation_memory:]


def _fresh(alert: Alert, now: datetime, policy: AlertDedupPolicy, **kw) -> AlertRecord:
    return AlertRecord(alert.identity.family, alert.identity.fingerprint, AlertState.ACTIVE, now, now, now, 1,
                       _remember((), alert.observation_key, policy), **kw)


def observe(state: AlertDedupState, alert: Alert, now: datetime, policy: AlertDedupPolicy) -> tuple:
    """(new_state, verdict)."""
    state, _ = expire(state, now, policy)
    fam = alert.identity.family
    rec = state.get(fam)
    others = [r for r in state.records if r.family != fam]

    def put(r, verdict):
        return AlertDedupState(_by_family([*others, r])), verdict

    if rec is None:
        return put(_fresh(alert, now, policy), AlertDedupVerdict.NEW)
    if alert.observation_key in rec.observations:
        return state, AlertDedupVerdict.EXACT_DUPLICATE
    obs = _remember(rec.observations, alert.observation_key, policy)
    if rec.fingerprint != alert.identity.fingerprint:
        return put(_fresh(alert, now, policy), AlertDedupVerdict.MATERIAL_CHANGE)
    if rec.state == AlertState.ACTIVE:
        if rec.pending_delivery and rec.redeliveries < policy.max_redeliveries:
            return put(dataclasses.replace(rec, last_seen_at=now, last_notified_at=now, seen_count=rec.seen_count + 1,
                                           observations=obs, redeliveries=rec.redeliveries + 1), AlertDedupVerdict.REDELIVER)
        return put(dataclasses.replace(rec, last_seen_at=now, seen_count=rec.seen_count + 1, observations=obs), AlertDedupVerdict.STILL_ACTIVE)
    # expired, same fingerprint
    if (now - rec.last_notified_at).total_seconds() < policy.cooldown_seconds:
        return put(dataclasses.replace(rec, observations=obs), AlertDedupVerdict.COOLDOWN)
    return put(_fresh(alert, now, policy), AlertDedupVerdict.RENOTIFY)


def record_delivery(state: AlertDedupState, family: str, *, deliverable: bool, delivered: bool) -> AlertDedupState:
    """After routing+delivery: if someone was supposed to be told (deliverable) and nobody was (not delivered), the record is
    marked pending so a later sighting may REDELIVER (bounded by max_redeliveries). Anything else clears the flag."""
    rec = state.get(family)
    if rec is None:
        return state
    pending = bool(deliverable and not delivered)
    others = [r for r in state.records if r.family != family]
    return AlertDedupState(_by_family([*others, dataclasses.replace(rec, pending_delivery=pending)]))


class AlertStateStore(Protocol):
    """Persistence seam. A durable implementation MUST: (1) load() the last saved state after a restart so EXACT_DUPLICATE /
    COOLDOWN survive it; (2) make save() atomic (all-or-nothing); (3) never invent state. Delivery is at-most-once at the
    dedup boundary unless the implementation adds an outbox - Phase 12 does NOT provide one (documented limitation)."""

    def load(self) -> AlertDedupState: ...

    def save(self, state: AlertDedupState) -> None: ...


class InMemoryAlertStateStore:
    """Transient reference store (NOT durable). Used by tests and offline runs."""

    def __init__(self, state: AlertDedupState | None = None):
        self._state = state or AlertDedupState()

    def load(self) -> AlertDedupState:
        return self._state

    def save(self, state: AlertDedupState) -> None:
        self._state = state
