"""Phase 12 failure model. Only failures with no semantic equivalent in the frozen taxonomy live here.

Reused, NOT redefined:  scanner.failures.FailureClass (+ classify_fetch_exception, ProviderRateLimitedError).
New (scoped, non-overlapping):
  AlertValidationError     - a candidate/alert violates the alert contract (qualification / construction stage)
  AlertConfigError         - an alerting policy / routing table is invalid (configuration stage, raised at build time)
  PayloadValidationError   - a notification envelope is malformed and must never be sent (payload stage)
  TransportRejectedError   - the transport refused the payload (PERMANENT delivery failure)
  TransportAuthError       - the transport's credentials are refused (PERMANENT, operator action)
  TransportConfigError     - the transport is mis-wired / unbound (PERMANENT, operator action)
Timeouts, rate limits and outages reuse TimeoutError / ProviderRateLimitedError / ConnectionError.
"""
from __future__ import annotations


class AlertValidationError(ValueError):
    pass


class AlertConfigError(ValueError):
    pass


class PayloadValidationError(ValueError):
    pass


class TransportRejectedError(ValueError):
    pass


class TransportAuthError(Exception):
    pass


class TransportConfigError(Exception):
    pass
