"""Transport boundary - Phase 12. The core only knows this Protocol. Real transports (push, email, webhook, messaging, SMS)
are future, injected implementations that translate NotificationEnvelope into a vendor payload BEHIND this seam; none exists
here, none is needed by tests, and no credential or endpoint is ever part of the core.

A transport signals failure by RAISING (TimeoutError, ConnectionError, ProviderRateLimitedError, TransportRejectedError,
TransportAuthError, TransportConfigError). `timeout_seconds` is passed down: enforcing it is the transport's job (the core starts
no threads and cannot interrupt a call).
"""
from __future__ import annotations

from typing import Protocol

from omnisystem_v5.alerts.enums import NotificationChannel
from omnisystem_v5.alerts.errors import AlertConfigError, TransportConfigError


class NotificationTransport(Protocol):
    channel: NotificationChannel

    def send(self, envelope, timeout_seconds: float) -> None: ...


class RecordingTransport:
    """Always succeeds; records every envelope it was given."""

    def __init__(self, channel: NotificationChannel = NotificationChannel.INTERNAL):
        self.channel = channel
        self.sent: list = []

    def send(self, envelope, timeout_seconds: float) -> None:
        self.sent.append(envelope)


class InMemoryTransport:
    """Per-target mailboxes; idempotent on envelope_id (a duplicate send is counted, not stored twice)."""

    def __init__(self, channel: NotificationChannel = NotificationChannel.INTERNAL):
        self.channel = channel
        self.mailboxes: dict = {}
        self.duplicates = 0
        self._seen: set = set()

    def send(self, envelope, timeout_seconds: float) -> None:
        if envelope.envelope_id in self._seen:
            self.duplicates += 1
            return
        self._seen.add(envelope.envelope_id)
        self.mailboxes.setdefault(envelope.target.target_id, []).append(envelope)


class ScriptedTransport:
    """Each send consumes the next scripted outcome: None = success, an Exception instance = raise it.
    An exhausted script fails loudly (TransportConfigError) instead of silently succeeding."""

    def __init__(self, script, channel: NotificationChannel = NotificationChannel.INTERNAL):
        self.channel = channel
        self._script = list(script)
        self.calls: list = []

    def send(self, envelope, timeout_seconds: float) -> None:
        self.calls.append((envelope.envelope_id, timeout_seconds))
        if not self._script:
            raise TransportConfigError("scripted transport exhausted")
        outcome = self._script.pop(0)
        if outcome is not None:
            raise outcome


class TransportRegistry:
    """Immutable channel -> transport binding. A channel without a transport fails closed at delivery time."""

    def __init__(self, transports=()):
        by = {}
        for t in transports:
            if t.channel in by:
                raise AlertConfigError(f"two transports bound to channel {t.channel.value}")
            by[t.channel] = t
        self._by = by

    def get(self, channel):
        return self._by.get(channel)
