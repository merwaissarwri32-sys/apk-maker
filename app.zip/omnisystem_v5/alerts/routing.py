"""Alert routing - Phase 12. Infrastructure-level and deterministic: Alert -> RoutingPolicy -> RoutingDecision.

No user accounts, plans or permissions: a NotificationTarget is an opaque, declared infrastructure endpoint
(`endpoint_ref` is a NAME that a transport adapter resolves; it can never be a URL or a secret - validated).
Rules are matched in declared order; DENY overrides ALLOW; quiet hours (UTC) and per-target rate limits (the Phase 11
Throttle, driven by the injected clock) can suppress a route transiently. Every unknown target fails closed at build time.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.alerts.enums import (AlertSeverity, AlertSourceKind, AlertType, NotificationChannel, NotificationUrgency,
                                        RouteSuppression, RoutingOutcome, RuleEffect)
from omnisystem_v5.alerts.errors import AlertConfigError
from omnisystem_v5.alerts.model import Alert
from omnisystem_v5.marketdata.config import ThrottlePolicy
from omnisystem_v5.marketdata.i18n import EN, Locale
from omnisystem_v5.marketdata.retry import Throttle

_NAME = re.compile(r"^[a-z0-9][a-z0-9_.\-]{0,63}$")


@dataclass(frozen=True)
class NotificationTarget:
    target_id: str
    channel: NotificationChannel
    locale: Locale = EN
    endpoint_ref: str = "default"
    rate_limit: ThrottlePolicy = field(default_factory=ThrottlePolicy)     # max_requests None = unlimited

    def __post_init__(self):
        if not isinstance(self.target_id, str) or not _NAME.match(self.target_id):
            raise AlertConfigError(f"invalid target_id {self.target_id!r}")
        if not isinstance(self.endpoint_ref, str) or not _NAME.match(self.endpoint_ref):
            raise AlertConfigError("endpoint_ref must be a plain name (no URLs, no secrets)")
        if not isinstance(self.channel, NotificationChannel) or not isinstance(self.locale, Locale) or not isinstance(self.rate_limit, ThrottlePolicy):
            raise AlertConfigError("target channel/locale/rate_limit have the wrong types")


@dataclass(frozen=True)
class QuietHours:
    """UTC minute-of-day window [start, end); wraps past midnight when start > end. Alerts up to `suppress_up_to` are held back
    (suppressed, not queued) while it is active. No time zones, no DST."""
    start_minute: int
    end_minute: int
    suppress_up_to: AlertSeverity = AlertSeverity.WARNING

    def __post_init__(self):
        for v in (self.start_minute, self.end_minute):
            if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v < 1440:
                raise AlertConfigError("quiet-hours minutes must be ints in [0, 1440)")
        if self.start_minute == self.end_minute or not isinstance(self.suppress_up_to, AlertSeverity):
            raise AlertConfigError("quiet hours need start != end and a severity")

    def active(self, now: datetime) -> bool:
        u = now.astimezone(timezone.utc)
        m = u.hour * 60 + u.minute
        return self.start_minute <= m < self.end_minute if self.start_minute < self.end_minute else (m >= self.start_minute or m < self.end_minute)


@dataclass(frozen=True)
class RoutingRule:
    name: str
    targets: tuple
    effect: RuleEffect = RuleEffect.ALLOW
    min_severity: AlertSeverity = AlertSeverity.INFO
    sources: frozenset = frozenset()          # empty = any (same for every filter below)
    types: frozenset = frozenset()
    asset_classes: frozenset = frozenset()
    symbols: frozenset = frozenset()
    providers: frozenset = frozenset()
    urgency: NotificationUrgency | None = None
    quiet_hours: QuietHours | None = None

    def __post_init__(self):
        if not isinstance(self.name, str) or not _NAME.match(self.name):
            raise AlertConfigError(f"invalid rule name {self.name!r}")
        if not self.targets or not all(isinstance(t, str) for t in self.targets):
            raise AlertConfigError(f"rule {self.name!r} needs at least one target id")
        if not isinstance(self.effect, RuleEffect) or not isinstance(self.min_severity, AlertSeverity):
            raise AlertConfigError("rule effect/min_severity have the wrong types")
        for n, cls in (("sources", AlertSourceKind), ("types", AlertType)):
            if not all(isinstance(x, cls) for x in getattr(self, n)):
                raise AlertConfigError(f"rule {self.name!r}: {n} must contain {cls.__name__} values")
        for n in ("asset_classes", "symbols", "providers"):
            if not all(isinstance(x, str) for x in getattr(self, n)):
                raise AlertConfigError(f"rule {self.name!r}: {n} must contain strings")
        if self.urgency is not None and not isinstance(self.urgency, NotificationUrgency):
            raise AlertConfigError("rule urgency must be a NotificationUrgency")

    def matches(self, a: Alert) -> bool:
        return (a.severity.at_least(self.min_severity)
                and (not self.sources or a.source.kind in self.sources)
                and (not self.types or a.alert_type in self.types)
                and (not self.asset_classes or a.context.asset_class in self.asset_classes)
                and (not self.symbols or a.context.symbol in self.symbols)
                and (not self.providers or a.context.provider in self.providers))


DEFAULT_URGENCY = ((AlertSeverity.INFO, NotificationUrgency.LOW), (AlertSeverity.NOTICE, NotificationUrgency.NORMAL),
                   (AlertSeverity.WARNING, NotificationUrgency.NORMAL), (AlertSeverity.CRITICAL, NotificationUrgency.HIGH))


@dataclass(frozen=True)
class RoutingPolicy:
    targets: tuple
    rules: tuple
    urgency_by_severity: tuple = DEFAULT_URGENCY

    def __post_init__(self):
        if not all(isinstance(t, NotificationTarget) for t in self.targets) or not all(isinstance(r, RoutingRule) for r in self.rules):
            raise AlertConfigError("routing policy needs NotificationTarget and RoutingRule entries")
        ids = [t.target_id for t in self.targets]
        if len(set(ids)) != len(ids) or len({r.name for r in self.rules}) != len(self.rules):
            raise AlertConfigError("duplicate target id or rule name")
        for r in self.rules:
            for t in r.targets:
                if t not in ids:
                    raise AlertConfigError(f"rule {r.name!r} references unknown target {t!r}")          # fail closed
        if {s for s, _ in self.urgency_by_severity} != set(AlertSeverity) or not all(isinstance(u, NotificationUrgency) for _, u in self.urgency_by_severity):
            raise AlertConfigError("urgency_by_severity must map every severity to a NotificationUrgency")

    def target(self, target_id: str) -> NotificationTarget:
        return next(t for t in self.targets if t.target_id == target_id)

    def urgency_for(self, severity: AlertSeverity) -> NotificationUrgency:
        return dict(self.urgency_by_severity)[severity]


@dataclass(frozen=True)
class NotificationRoute:
    target_id: str
    channel: NotificationChannel
    urgency: NotificationUrgency
    rule: str


@dataclass(frozen=True)
class SuppressedRoute:
    target_id: str
    reason: RouteSuppression
    rule: str


@dataclass(frozen=True)
class RoutingDecision:
    alert_id: str
    outcome: RoutingOutcome
    matched_rules: tuple = ()
    routes: tuple = ()
    suppressed: tuple = ()

    @property
    def transient_suppression(self) -> bool:
        return any(s.reason.transient for s in self.suppressed)


class AlertRouter:
    """Holds only explicit per-target rate-limit state (one Phase 11 Throttle per target); no globals, no clock reads."""

    def __init__(self, policy: RoutingPolicy):
        self._policy = policy
        self._throttles = {t.target_id: Throttle(t.rate_limit) for t in policy.targets}

    @property
    def policy(self) -> RoutingPolicy:
        return self._policy

    def decide(self, alert: Alert, now: datetime) -> RoutingDecision:
        p = self._policy
        matched = tuple(r for r in p.rules if r.matches(alert))
        denied, allowed, quiet = {}, {}, {}
        for r in matched:
            for tid in dict.fromkeys(r.targets):
                if r.effect == RuleEffect.DENY:
                    denied.setdefault(tid, r.name)
                elif r.quiet_hours is not None and r.quiet_hours.active(now) and alert.severity.rank <= r.quiet_hours.suppress_up_to.rank:
                    quiet.setdefault(tid, r.name)
                else:
                    urg = r.urgency or p.urgency_for(alert.severity)
                    if tid not in allowed or urg.rank > allowed[tid][0].rank:
                        allowed[tid] = (urg, r.name)          # the rule that supplied the winning urgency; a tie keeps the first
        suppressed = [SuppressedRoute(t, RouteSuppression.DENIED_BY_RULE, n) for t, n in denied.items()]
        suppressed += [SuppressedRoute(t, RouteSuppression.QUIET_HOURS, n) for t, n in quiet.items() if t not in allowed and t not in denied]
        routes = []
        order = sorted((t for t in allowed if t not in denied), key=lambda t: (p.target(t).channel.value, t))
        for tid in order:
            ok, _ = self._throttles[tid].try_acquire(now)
            if ok:
                routes.append(NotificationRoute(tid, p.target(tid).channel, allowed[tid][0], allowed[tid][1]))
            else:
                suppressed.append(SuppressedRoute(tid, RouteSuppression.RATE_LIMITED, allowed[tid][1]))
        suppressed.sort(key=lambda s: (s.target_id, s.reason.value))
        return RoutingDecision(alert.alert_id, RoutingOutcome.ROUTED if routes else RoutingOutcome.NO_ELIGIBLE_TARGET,
                               tuple(r.name for r in matched), tuple(routes), tuple(suppressed))
