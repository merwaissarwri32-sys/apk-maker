"""Phase 12 enumerations. SOURCE, TYPE, SEVERITY, PRIORITY, URGENCY and CHANNEL are separate concepts:
  source    - who produced the observation            (AlertSourceKind)
  type      - what kind of condition it describes      (AlertType)
  severity  - policy-driven importance of the alert    (AlertSeverity)   <- never a probability
  priority  - the scanner's COMPUTATIONAL ordering, carried unchanged (AlertPriority in model.py)
  urgency   - how insistently a target is notified      (NotificationUrgency)
  channel   - abstract delivery medium                  (NotificationChannel)
"""
from __future__ import annotations

from enum import Enum


class AlertSourceKind(str, Enum):
    SCANNER_SIGNAL = "SCANNER_SIGNAL"
    SCANNER_CYCLE = "SCANNER_CYCLE"
    DATA_SNAPSHOT = "DATA_SNAPSHOT"
    DATA_EVENT = "DATA_EVENT"


class AlertType(str, Enum):
    SIGNAL = "SIGNAL"
    PROVIDER_HEALTH = "PROVIDER_HEALTH"
    INSTRUMENT_HEALTH = "INSTRUMENT_HEALTH"
    SYSTEM_HEALTH = "SYSTEM_HEALTH"
    DATA_QUALITY = "DATA_QUALITY"
    PROVIDER_FAULT = "PROVIDER_FAULT"


_SEVERITY_ORDER = ("INFO", "NOTICE", "WARNING", "CRITICAL")


class AlertSeverity(str, Enum):
    INFO = "INFO"
    NOTICE = "NOTICE"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"

    @property
    def rank(self) -> int:
        return _SEVERITY_ORDER.index(self.value)

    def at_least(self, other: "AlertSeverity") -> bool:
        return self.rank >= other.rank


class AlertState(str, Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"


ALERT_TRANSITIONS = {AlertState.ACTIVE: frozenset({AlertState.EXPIRED}), AlertState.EXPIRED: frozenset({AlertState.ACTIVE})}


class QualificationOutcome(str, Enum):
    QUALIFIED = "QUALIFIED"
    REJECTED_MALFORMED = "REJECTED_MALFORMED"
    REJECTED_UNSUPPORTED = "REJECTED_UNSUPPORTED"
    REJECTED_UPSTREAM = "REJECTED_UPSTREAM"          # the producer itself did not release it (e.g. scanner-suppressed)
    SUPPRESSED_BY_POLICY = "SUPPRESSED_BY_POLICY"    # valid, but below min severity / source disabled


class AlertDedupVerdict(str, Enum):
    NEW = "NEW"
    EXACT_DUPLICATE = "EXACT_DUPLICATE"      # the very same observation seen again (replay)
    STILL_ACTIVE = "STILL_ACTIVE"            # same alert, newer observation, still inside its expiry window
    MATERIAL_CHANGE = "MATERIAL_CHANGE"      # same family, different fingerprint (bypasses cooldown, like Phase 10)
    COOLDOWN = "COOLDOWN"                    # expired alert re-appeared inside its cooldown window
    RENOTIFY = "RENOTIFY"                    # expired alert re-appeared after its cooldown window
    REDELIVER = "REDELIVER"                  # previous notification reached nobody; bounded re-attempt

    @property
    def notifies(self) -> bool:
        return self in (AlertDedupVerdict.NEW, AlertDedupVerdict.MATERIAL_CHANGE, AlertDedupVerdict.RENOTIFY, AlertDedupVerdict.REDELIVER)


class NotificationChannel(str, Enum):
    """Abstract channels. Only INTERNAL has a reference implementation; the rest are future extension points."""
    INTERNAL = "INTERNAL"
    PUSH = "PUSH"
    EMAIL = "EMAIL"
    WEBHOOK = "WEBHOOK"
    MESSAGING = "MESSAGING"
    SMS = "SMS"


_URGENCY_ORDER = ("LOW", "NORMAL", "HIGH")


class NotificationUrgency(str, Enum):
    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"

    @property
    def rank(self) -> int:
        return _URGENCY_ORDER.index(self.value)


class RuleEffect(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"


class RoutingOutcome(str, Enum):
    ROUTED = "ROUTED"
    NO_ELIGIBLE_TARGET = "NO_ELIGIBLE_TARGET"


class RouteSuppression(str, Enum):
    DENIED_BY_RULE = "DENIED_BY_RULE"
    QUIET_HOURS = "QUIET_HOURS"            # transient
    RATE_LIMITED = "RATE_LIMITED"          # transient

    @property
    def transient(self) -> bool:
        return self in (RouteSuppression.QUIET_HOURS, RouteSuppression.RATE_LIMITED)


class DeliveryStatus(str, Enum):
    """PENDING -> ATTEMPTING -> {DELIVERED | RETRY_SCHEDULED -> {ATTEMPTING | FAILED} | FAILED | EXHAUSTED};  PENDING -> {FAILED | REJECTED}.
    Terminal: DELIVERED, FAILED, EXHAUSTED, REJECTED.  Routing-level suppression is recorded on the RoutingDecision."""
    PENDING = "PENDING"
    ATTEMPTING = "ATTEMPTING"
    RETRY_SCHEDULED = "RETRY_SCHEDULED"
    DELIVERED = "DELIVERED"
    FAILED = "FAILED"            # not retried: permanent, auth, config, internal, or rate-limited beyond the wait budget
    EXHAUSTED = "EXHAUSTED"      # retryable, but attempts or the deadline ran out
    REJECTED = "REJECTED"        # payload invalid - never sent

    @property
    def terminal(self) -> bool:
        return self in (DeliveryStatus.DELIVERED, DeliveryStatus.FAILED, DeliveryStatus.EXHAUSTED, DeliveryStatus.REJECTED)


DELIVERY_TRANSITIONS = {
    DeliveryStatus.PENDING: frozenset({DeliveryStatus.ATTEMPTING, DeliveryStatus.FAILED, DeliveryStatus.REJECTED}),
    DeliveryStatus.ATTEMPTING: frozenset({DeliveryStatus.DELIVERED, DeliveryStatus.RETRY_SCHEDULED, DeliveryStatus.FAILED, DeliveryStatus.EXHAUSTED}),
    DeliveryStatus.RETRY_SCHEDULED: frozenset({DeliveryStatus.ATTEMPTING, DeliveryStatus.FAILED}),   # FAILED: the injected sleep itself failed
    DeliveryStatus.DELIVERED: frozenset(), DeliveryStatus.FAILED: frozenset(),
    DeliveryStatus.EXHAUSTED: frozenset(), DeliveryStatus.REJECTED: frozenset(),
}


class AttemptOutcome(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"


class DeliveryFailureKind(str, Enum):
    TIMEOUT = "TIMEOUT"
    RATE_LIMITED = "RATE_LIMITED"
    UNAVAILABLE = "UNAVAILABLE"
    REJECTED = "REJECTED"
    AUTH = "AUTH"
    CONFIG = "CONFIG"
    INTERNAL = "INTERNAL"
