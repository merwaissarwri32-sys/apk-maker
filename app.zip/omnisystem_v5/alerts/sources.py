"""Alert sources - Phase 12. Adapters from the REAL frozen Phase 10/11 contracts to source-neutral AlertCandidates.

They only READ: a ScanSignal (already-computed decision + risk verdict), a ScanReport, a DataSystemSnapshot, or a stream of
Phase 11 telemetry events. Nothing is recomputed, no probability/confidence is invented, and the alert layer never imports the
decision/risk layers: it reads the values the scanner contract exposes. Anything malformed / unsupported / not released by the
producer becomes a Rejection (audited), never an alert. Transport code never sees these types.
"""
from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.alerts.enums import AlertSourceKind, AlertType, QualificationOutcome
from omnisystem_v5.alerts.errors import AlertValidationError
from omnisystem_v5.alerts.i18n import AlertMessageKey as K
from omnisystem_v5.alerts.i18n import amsg
from omnisystem_v5.alerts.model import AlertCandidate, AlertContext, AlertPriority, AlertSource
from omnisystem_v5.alerts.qualification import Rejection, reject
from omnisystem_v5.marketdata.canonical import digest
from omnisystem_v5.marketdata.events import DataEventKind

_BAD_INPUT = (AttributeError, TypeError, ValueError, KeyError, IndexError, AlertValidationError)
SUPPORTED_EVENT_KINDS = frozenset({DataEventKind.PROVIDER_STATE_CHANGED.value, DataEventKind.INSTRUMENT_STATE_CHANGED.value,
                                   DataEventKind.DATA_STALE.value, DataEventKind.DATA_REJECTED.value,
                                   DataEventKind.PROVIDER_ERROR.value, DataEventKind.RATE_LIMITED.value})


@dataclass(frozen=True)
class MapResult:
    candidates: tuple = ()
    rejections: tuple = ()
    skipped: int = 0


class CatalogContextResolver:
    """Resolves a canonical symbol to (instrument, asset class, venue) through the real Phase 11 InstrumentCatalog.
    Read-only; unknown symbols resolve to nothing (the alert simply carries no instrument context)."""

    def __init__(self, catalog):
        self._catalog = catalog

    def resolve(self, symbol: str) -> dict:
        lst = self._catalog.primary(symbol) or self._catalog.any_listing(symbol)
        if lst is None:
            return {}
        return {"instrument": f"{lst.instrument.asset_class.value}:{lst.symbol}", "asset_class": lst.instrument.asset_class.value,
                "venue": lst.venue.code}


def _n(x) -> str:
    return repr(round(float(x), 6))


def _zone(z) -> str:
    return f"{_n(z[0])}-{_n(z[1])}"


def _iso(dt) -> str:
    return dt.isoformat()


def _context(resolver, symbol, **kw) -> AlertContext:
    extra = resolver.resolve(symbol) if (resolver is not None and symbol) else {}
    return AlertContext(symbol=symbol, **extra, **kw)


# ---------------------------------------------------------------- scanner signals
def map_signal(signal, resolver=None) -> AlertCandidate:
    """Raises a _BAD_INPUT error for anything that is not a well-formed, EMITTED, risk-gated signal (fail closed)."""
    if signal.state.value != "EMITTED":
        raise AlertValidationError("signal is not EMITTED")          # callers route this to REJECTED_UPSTREAM first
    d = signal.decision
    r = d.risk_result
    if d is None or r is None or r.is_actionable is not True or d.outcome.value == "NO_TRADE":
        raise AlertValidationError("an alert needs an actionable, risk-gated decision")
    desc = signal.descriptor
    verdict = r.decision.value
    rr = r.primary_reward_risk_ratio
    targets = ",".join(_n(t) for t in r.take_profits)
    headline = amsg(K.SIGNAL_HEADLINE, symbol=desc.symbol, direction=desc.direction, horizon=desc.horizon,
                    timeframe=desc.timeframe, engine=desc.source_engine)
    reasons = (amsg(K.SIGNAL_LEVELS, entry_zone=_zone(desc.entry_zone), invalidation_zone=_zone(desc.invalidation_zone), targets=targets or "n/a"),
               amsg(K.SIGNAL_RISK, verdict=verdict, reward_risk=_n(rr) if rr is not None else "n/a"),
               amsg(K.SIGNAL_DISCLAIMER))
    details = {"risk_verdict": verdict, "decision_outcome": d.outcome.value, "scenario": desc.scenario, "scanner_verdict": signal.verdict.value,
               "seen_count": signal.seen_count, "entry_low": desc.entry_zone[0], "entry_high": desc.entry_zone[1],
               "invalidation_low": desc.invalidation_zone[0], "invalidation_high": desc.invalidation_zone[1],
               "entry": r.entry, "stop_loss": r.stop_loss, "targets": targets, "reward_risk": rr}
    priority = None
    if signal.priority is not None:
        priority = AlertPriority(signal.priority.kind, tuple((str(a), int(b)) for a, b in signal.priority.components))
    return AlertCandidate(
        alert_type=AlertType.SIGNAL, source=AlertSource(AlertSourceKind.SCANNER_SIGNAL, "scanner"),
        context=_context(resolver, desc.symbol, horizon=desc.horizon, direction=desc.direction, timeframe=desc.timeframe),
        headline=headline, reasons=reasons,
        family=(("symbol", desc.symbol), ("direction", desc.direction), ("horizon", desc.horizon), ("engine", desc.source_engine)),
        state=(("fingerprint", signal.fingerprint),),
        observation_key=f"signal:{signal.fingerprint}:{_iso(signal.emitted_at)}", observed_at=signal.emitted_at,
        details=details, priority=priority,
        evidence=(("scanner.fingerprint", signal.fingerprint), ("scanner.first_seen_at", _iso(signal.first_seen_at)),
                  ("scanner.emitted_at", _iso(signal.emitted_at))))


def _cycle_candidate(report) -> AlertCandidate:
    health = report.health.value
    reasons = ",".join(str(x) for x in report.health_reasons)[:400]
    return AlertCandidate(
        alert_type=AlertType.SYSTEM_HEALTH, source=AlertSource(AlertSourceKind.SCANNER_CYCLE, "scanner"), context=AlertContext(),
        headline=amsg(K.CYCLE_HEALTH, health=health), family=(("scope", "scanner_cycle"),), state=(("state", health),),
        observation_key=f"cycle:{_iso(report.started_at)}:{health}", observed_at=report.started_at,
        details={"state": health, "universe_size": report.universe_size, "emitted_count": len(report.emitted), "health_reasons": reasons},
        evidence=(("scanner.cycle_started_at", _iso(report.started_at)),))


def map_report(report, resolver=None, include_healthy: bool = False) -> MapResult:
    cands, rejs = [], []
    try:
        emitted, upstream = tuple(report.emitted), tuple((*report.suppressed, *report.expired))
        cycle = _cycle_candidate(report) if (include_healthy or report.health.value not in ("HEALTHY", "NO_WORK")) else None
    except _BAD_INPUT:
        return MapResult((), (reject(QualificationOutcome.REJECTED_MALFORMED, "scan report"),), 0)
    for s in emitted:
        try:
            cands.append(map_signal(s, resolver))
        except _BAD_INPUT:
            rejs.append(reject(QualificationOutcome.REJECTED_MALFORMED, f"signal {getattr(s, 'fingerprint', '?')}"))
    for s in upstream:
        rejs.append(reject(QualificationOutcome.REJECTED_UPSTREAM, f"signal {getattr(s, 'fingerprint', '?')}"))
    if cycle is not None:
        cands.append(cycle)
    return MapResult(tuple(cands), tuple(rejs))


# ---------------------------------------------------------------- Phase 11 snapshot
def map_snapshot(snapshot, resolver=None, include_healthy: bool = False) -> MapResult:
    cands = []
    try:
        at = snapshot.at
        evidence = dict(snapshot.evidence)
        for ph in snapshot.providers:
            st = ph.state.value
            if st == "HEALTHY" and not include_healthy:
                continue
            ev = [("snapshot.at", _iso(at))] + ([("provider.evidence", evidence[ph.provider])] if ph.provider in evidence else [])
            cands.append(AlertCandidate(
                alert_type=AlertType.PROVIDER_HEALTH, source=AlertSource(AlertSourceKind.DATA_SNAPSHOT, "marketdata"),
                context=AlertContext(provider=ph.provider), headline=amsg(K.PROVIDER_STATE, provider=ph.provider, state=st),
                reasons=(ph.reason,) if ph.reason is not None else (), family=(("provider", ph.provider),), state=(("state", st),),
                observation_key=f"snapshot:provider:{ph.provider}:{st}:{_iso(at)}", observed_at=at, evidence=ev,
                details={"state": st, "consecutive_failures": ph.consecutive_failures, "outage_episodes": ph.outage_episodes,
                         "last_failure_class": ph.last_failure_class, "requires_operator": ph.requires_operator,
                         "next_attempt_at": ph.next_attempt_at}))
        for ih in snapshot.instruments:
            st = ih.state.value
            if st == "AVAILABLE" and not include_healthy:
                continue
            cands.append(AlertCandidate(
                alert_type=AlertType.INSTRUMENT_HEALTH, source=AlertSource(AlertSourceKind.DATA_SNAPSHOT, "marketdata"),
                context=_context(resolver, ih.symbol), headline=amsg(K.INSTRUMENT_STATE, symbol=ih.symbol, state=st),
                reasons=(ih.reason,) if ih.reason is not None else (), family=(("symbol", ih.symbol),), state=(("state", st),),
                observation_key=f"snapshot:instrument:{ih.symbol}:{st}:{_iso(at)}", observed_at=at,
                evidence=(("snapshot.at", _iso(at)),),
                details={"state": st, "consecutive_failures": ih.consecutive_failures, "quarantined_until": ih.quarantined_until}))
        for ru in snapshot.rollups:
            st = ru.state.value
            if st == "HEALTHY" and not include_healthy:
                continue
            scope = getattr(ru.scope, "value", ru.scope)
            cands.append(AlertCandidate(
                alert_type=AlertType.SYSTEM_HEALTH, source=AlertSource(AlertSourceKind.DATA_SNAPSHOT, "marketdata"), context=AlertContext(),
                headline=amsg(K.ROLLUP_STATE, scope=scope, subject=ru.subject, state=st, scannable=ru.scannable, total=ru.total),
                family=(("scope", scope), ("subject", ru.subject)), state=(("state", st),),
                observation_key=f"snapshot:rollup:{scope}:{ru.subject}:{st}:{_iso(at)}", observed_at=at, evidence=(("snapshot.at", _iso(at)),),
                details={"state": st, "scope": scope, "subject": ru.subject, "total": ru.total, "scannable": ru.scannable}))
    except _BAD_INPUT:
        return MapResult((), (reject(QualificationOutcome.REJECTED_MALFORMED, "data system snapshot"),), 0)
    return MapResult(tuple(cands))


# ---------------------------------------------------------------- Phase 11 events
def _event_candidate(ev) -> AlertCandidate:
    kind = getattr(ev.kind, "value", ev.kind)
    subject, at, detail = ev.symbol, ev.at, dict(ev.detail)
    if not isinstance(subject, str) or not subject:
        raise AlertValidationError("event has no subject")
    src = AlertSource(AlertSourceKind.DATA_EVENT, "marketdata")
    obs = f"event:{kind}:{subject}:{_iso(at)}:{digest(list(ev.detail))[:10]}"
    if kind == DataEventKind.PROVIDER_STATE_CHANGED.value:
        to = str(detail["to_state"])
        return AlertCandidate(AlertType.PROVIDER_HEALTH, src, AlertContext(provider=subject), amsg(K.PROVIDER_STATE, provider=subject, state=to),
                              (("provider", subject),), (("state", to),), obs, at, details={"state": to, "from_state": detail.get("from_state")})
    if kind == DataEventKind.INSTRUMENT_STATE_CHANGED.value:
        to = str(detail["to_state"])
        return AlertCandidate(AlertType.INSTRUMENT_HEALTH, src, AlertContext(symbol=subject), amsg(K.INSTRUMENT_STATE, symbol=subject, state=to),
                              (("symbol", subject),), (("state", to),), obs, at, details={"state": to, "from_state": detail.get("from_state")})
    head = amsg(K.DATA_EVENT, kind=kind, subject=subject)
    if kind in (DataEventKind.DATA_STALE.value, DataEventKind.DATA_REJECTED.value):
        tf = str(detail.get("timeframe", "?"))
        extra = {k: detail.get(k) for k in ("freshness", "status", "reason") if k in detail}
        return AlertCandidate(AlertType.DATA_QUALITY, src, AlertContext(symbol=subject, timeframe=tf), head,
                              (("kind", kind), ("symbol", subject), ("timeframe", tf)), (), obs, at, details={"event_kind": kind, "timeframe": tf, **extra})
    if kind in (DataEventKind.PROVIDER_ERROR.value, DataEventKind.RATE_LIMITED.value):
        extra = {k: detail.get(k) for k in ("failure_class", "error", "retry_after") if k in detail}
        return AlertCandidate(AlertType.PROVIDER_FAULT, src, AlertContext(provider=subject), head,
                              (("kind", kind), ("provider", subject)), (), obs, at, details={"event_kind": kind, **extra})
    raise KeyError(kind)


def map_events(events, strict: bool = True) -> MapResult:
    """strict=True: every unsupported event is an audited REJECTED_UNSUPPORTED. strict=False: they are only counted in `skipped`
    (use this when feeding a busy stream that contains routine events such as DATA_INGESTED)."""
    cands, rejs, skipped = [], [], 0
    for ev in events:
        try:
            kind = getattr(ev.kind, "value", ev.kind)
            if kind not in SUPPORTED_EVENT_KINDS:
                if strict:
                    rejs.append(reject(QualificationOutcome.REJECTED_UNSUPPORTED, f"event {kind}"))
                else:
                    skipped += 1
                continue
            cands.append(_event_candidate(ev))
        except _BAD_INPUT:
            rejs.append(reject(QualificationOutcome.REJECTED_MALFORMED, f"event {getattr(getattr(ev, 'kind', None), 'value', '?')}"))
    return MapResult(tuple(cands), tuple(rejs), skipped)
