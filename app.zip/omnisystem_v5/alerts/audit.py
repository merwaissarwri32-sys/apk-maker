"""Alert audit trail - Phase 12. One AlertAuditRecord per processed observation answers: why was it generated / rejected, what
produced it, which identity, which severity, which message key, was it deduplicated or suppressed, what did routing decide,
was delivery attempted, what happened, was it retried, why did it fail. Records are immutable and canonically serialisable.
The in-memory log is bounded and transient (NOT durable)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from omnisystem_v5.alerts.enums import AlertDedupVerdict, AlertSeverity, AlertType, QualificationOutcome
from omnisystem_v5.alerts.model import AlertSource
from omnisystem_v5.alerts.routing import RoutingDecision
from omnisystem_v5.marketdata.canonical import canonical_dict, canonical_json
from omnisystem_v5.marketdata.i18n import StructuredMessage


@dataclass(frozen=True)
class AlertAuditRecord:
    at: datetime
    observation_key: str
    qualification: QualificationOutcome
    source: AlertSource | None = None
    alert_id: str | None = None
    alert_type: AlertType | None = None
    severity: AlertSeverity | None = None
    headline: StructuredMessage | None = None
    rejection: StructuredMessage | None = None
    verdict: AlertDedupVerdict | None = None
    routing: RoutingDecision | None = None
    deliveries: tuple = ()
    failures: tuple = ()               # ("stage:ExceptionClassName", ...) - class names only
    telemetry_errors: int = 0

    def to_dict(self) -> dict:
        return canonical_dict(self)

    def to_json(self) -> str:
        return canonical_json(self)


class AuditLog(Protocol):
    def append(self, record: AlertAuditRecord) -> None: ...


class InMemoryAuditLog:
    def __init__(self, max_records: int = 10000):
        if max_records < 1:
            raise ValueError("max_records must be >= 1")
        self._max = max_records
        self.records: list = []
        self.dropped = 0

    def append(self, record: AlertAuditRecord) -> None:
        self.records.append(record)
        if len(self.records) > self._max:
            del self.records[0]
            self.dropped += 1
