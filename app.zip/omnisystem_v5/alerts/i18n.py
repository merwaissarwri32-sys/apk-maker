"""Alert localization - Phase 12. Consumes the Phase 11 boundary (StructuredMessage / InMemoryCatalog / Locale);
the alert core stays language-neutral: it only ever holds key + structured parameters.

Phase 11's MessageKey enum is frozen, so alert keys live in their own AlertMessageKey enum. The Phase 11 catalog is
keyed by the enum member, so the merged catalog below is keyed by BOTH enums (values are disjoint - tested), and
existing Phase 11 keys (e.g. provider health reasons) still render through the same catalog.
The Persian (fa) strings are NOT native-speaker reviewed (same status as the Phase 11 fa catalog).
"""
from __future__ import annotations

import re
from enum import Enum

from omnisystem_v5.marketdata.catalog_en import MESSAGES as MD_EN
from omnisystem_v5.marketdata.catalog_fa import MESSAGES as MD_FA
from omnisystem_v5.marketdata.i18n import InMemoryCatalog, StructuredMessage, msg


class AlertMessageKey(str, Enum):
    SIGNAL_HEADLINE = "alert.signal.headline"
    SIGNAL_LEVELS = "alert.signal.levels"
    SIGNAL_RISK = "alert.signal.risk"
    SIGNAL_DISCLAIMER = "alert.signal.disclaimer"
    PROVIDER_STATE = "alert.provider.state"
    INSTRUMENT_STATE = "alert.instrument.state"
    ROLLUP_STATE = "alert.rollup.state"
    CYCLE_HEALTH = "alert.cycle.health"
    DATA_EVENT = "alert.data.event"
    NOTIFY_NEW = "alert.notify.new"
    NOTIFY_UPDATED = "alert.notify.updated"
    NOTIFY_REMINDER = "alert.notify.reminder"
    SEVERITY_INFO = "alert.severity.info"
    SEVERITY_NOTICE = "alert.severity.notice"
    SEVERITY_WARNING = "alert.severity.warning"
    SEVERITY_CRITICAL = "alert.severity.critical"
    REJECT_MALFORMED = "alert.reject.malformed"
    REJECT_UNSUPPORTED = "alert.reject.unsupported"
    REJECT_UPSTREAM = "alert.reject.upstream"
    REJECT_BELOW_MIN_SEVERITY = "alert.reject.below_min_severity"
    REJECT_SOURCE_DISABLED = "alert.reject.source_disabled"


K = AlertMessageKey
REQUIRED_PARAMS = {
    K.SIGNAL_HEADLINE: frozenset({"symbol", "direction", "horizon", "timeframe", "engine"}),
    K.SIGNAL_LEVELS: frozenset({"entry_zone", "invalidation_zone", "targets"}),
    K.SIGNAL_RISK: frozenset({"verdict", "reward_risk"}),
    K.SIGNAL_DISCLAIMER: frozenset(),
    K.PROVIDER_STATE: frozenset({"provider", "state"}),
    K.INSTRUMENT_STATE: frozenset({"symbol", "state"}),
    K.ROLLUP_STATE: frozenset({"scope", "subject", "state", "scannable", "total"}),
    K.CYCLE_HEALTH: frozenset({"health"}),
    K.DATA_EVENT: frozenset({"kind", "subject"}),
    K.NOTIFY_NEW: frozenset(), K.NOTIFY_UPDATED: frozenset(), K.NOTIFY_REMINDER: frozenset(),
    K.SEVERITY_INFO: frozenset(), K.SEVERITY_NOTICE: frozenset(), K.SEVERITY_WARNING: frozenset(), K.SEVERITY_CRITICAL: frozenset(),
    K.REJECT_MALFORMED: frozenset({"ref"}), K.REJECT_UNSUPPORTED: frozenset({"ref"}), K.REJECT_UPSTREAM: frozenset({"ref"}),
    K.REJECT_BELOW_MIN_SEVERITY: frozenset({"ref"}), K.REJECT_SOURCE_DISABLED: frozenset({"ref"}),
}

EN_ALERTS = {
    K.SIGNAL_HEADLINE: "{direction} setup on {symbol} ({horizon}, {timeframe}, engine {engine})",
    K.SIGNAL_LEVELS: "Entry zone {entry_zone}; invalidation {invalidation_zone}; targets {targets}",
    K.SIGNAL_RISK: "Risk verdict: {verdict}; reward/risk {reward_risk}",
    K.SIGNAL_DISCLAIMER: "Informational only. A setup is not a prediction and carries no guarantee of profit.",
    K.PROVIDER_STATE: "Data provider {provider} is now {state}",
    K.INSTRUMENT_STATE: "Instrument {symbol} is now {state}",
    K.ROLLUP_STATE: "{scope} {subject} is {state} ({scannable} of {total} scannable)",
    K.CYCLE_HEALTH: "Scanner cycle health: {health}",
    K.DATA_EVENT: "Data event {kind} for {subject}",
    K.NOTIFY_NEW: "New alert",
    K.NOTIFY_UPDATED: "Updated alert",
    K.NOTIFY_REMINDER: "Reminder",
    K.SEVERITY_INFO: "Info", K.SEVERITY_NOTICE: "Notice", K.SEVERITY_WARNING: "Warning", K.SEVERITY_CRITICAL: "Critical",
    K.REJECT_MALFORMED: "Input was malformed and did not become an alert: {ref}",
    K.REJECT_UNSUPPORTED: "Input is not a supported alert source: {ref}",
    K.REJECT_UPSTREAM: "The producer did not release this item, so no alert was raised: {ref}",
    K.REJECT_BELOW_MIN_SEVERITY: "Below the minimum alert severity: {ref}",
    K.REJECT_SOURCE_DISABLED: "Alerts from this source are disabled: {ref}",
}

FA_ALERTS = {
    K.SIGNAL_HEADLINE: "ستاپ {direction} روی {symbol} ({horizon}، {timeframe}، موتور {engine})",
    K.SIGNAL_LEVELS: "ناحیه ورود {entry_zone}؛ ابطال {invalidation_zone}؛ اهداف {targets}",
    K.SIGNAL_RISK: "نتیجه ریسک: {verdict}؛ نسبت ریوارد به ریسک {reward_risk}",
    K.SIGNAL_DISCLAIMER: "فقط جنبه اطلاع‌رسانی دارد. ستاپ پیش‌بینی نیست و تضمینی برای سود ندارد.",
    K.PROVIDER_STATE: "وضعیت ارائه‌دهنده داده {provider} اکنون {state} است",
    K.INSTRUMENT_STATE: "وضعیت نماد {symbol} اکنون {state} است",
    K.ROLLUP_STATE: "{scope} {subject} در وضعیت {state} است ({scannable} از {total} قابل اسکن)",
    K.CYCLE_HEALTH: "سلامت چرخه اسکنر: {health}",
    K.DATA_EVENT: "رویداد داده {kind} برای {subject}",
    K.NOTIFY_NEW: "هشدار جدید",
    K.NOTIFY_UPDATED: "هشدار به‌روزشده",
    K.NOTIFY_REMINDER: "یادآوری",
    K.SEVERITY_INFO: "اطلاع", K.SEVERITY_NOTICE: "توجه", K.SEVERITY_WARNING: "هشدار", K.SEVERITY_CRITICAL: "بحرانی",
    K.REJECT_MALFORMED: "ورودی نامعتبر بود و به هشدار تبدیل نشد: {ref}",
    K.REJECT_UNSUPPORTED: "ورودی منبع هشدار پشتیبانی‌شده نیست: {ref}",
    K.REJECT_UPSTREAM: "تولیدکننده این مورد را منتشر نکرده است، بنابراین هشداری صادر نشد: {ref}",
    K.REJECT_BELOW_MIN_SEVERITY: "پایین‌تر از حداقل شدت هشدار: {ref}",
    K.REJECT_SOURCE_DISABLED: "هشدار از این منبع غیرفعال است: {ref}",
}

SEVERITY_KEY = {"INFO": K.SEVERITY_INFO, "NOTICE": K.SEVERITY_NOTICE, "WARNING": K.SEVERITY_WARNING, "CRITICAL": K.SEVERITY_CRITICAL}
_PLACEHOLDER = re.compile(r"\{([a-z_]+)\}")


def placeholders(template: str) -> frozenset:
    return frozenset(_PLACEHOLDER.findall(template))


def alert_catalog() -> InMemoryCatalog:
    """Phase 11 tables + alert tables, same fallback chain as Phase 11 (tag -> language -> en -> neutral string)."""
    return InMemoryCatalog({"en": {**MD_EN, **EN_ALERTS}, "fa": {**MD_FA, **FA_ALERTS}})


def amsg(key: AlertMessageKey, **params) -> StructuredMessage:
    """Build a StructuredMessage and verify the parameter set is exactly the declared one (fail closed)."""
    if not isinstance(key, AlertMessageKey) or set(params) != set(REQUIRED_PARAMS[key]):
        from omnisystem_v5.alerts.errors import AlertValidationError
        raise AlertValidationError(f"message {getattr(key, 'value', key)!r} requires parameters {sorted(REQUIRED_PARAMS.get(key, ()))}, got {sorted(params)}")
    return msg(key, **params)
