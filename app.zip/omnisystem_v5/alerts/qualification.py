"""Alert qualification - Phase 12. Decides whether an observation may become an alert, and with which severity.
Pure. Returns either Qualified(severity) or Rejection(outcome, language-neutral message, ref)."""
from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.alerts.enums import AlertSeverity, QualificationOutcome
from omnisystem_v5.alerts.i18n import AlertMessageKey as K
from omnisystem_v5.alerts.i18n import amsg
from omnisystem_v5.alerts.model import AlertCandidate
from omnisystem_v5.alerts.policy import AlertPolicy
from omnisystem_v5.marketdata.i18n import StructuredMessage


@dataclass(frozen=True)
class Qualified:
    severity: AlertSeverity


@dataclass(frozen=True)
class Rejection:
    outcome: QualificationOutcome
    message: StructuredMessage
    ref: str


_KEY = {QualificationOutcome.REJECTED_MALFORMED: K.REJECT_MALFORMED, QualificationOutcome.REJECTED_UNSUPPORTED: K.REJECT_UNSUPPORTED,
        QualificationOutcome.REJECTED_UPSTREAM: K.REJECT_UPSTREAM}


def reject(outcome: QualificationOutcome, ref: str) -> Rejection:
    ref = "".join(c if c.isprintable() else "?" for c in str(ref))[:120]
    return Rejection(outcome, amsg(_KEY[outcome], ref=ref), ref)


def qualify(candidate: AlertCandidate, policy: AlertPolicy):
    ref = candidate.observation_key
    if candidate.source.kind not in policy.qualification.enabled_sources:
        return Rejection(QualificationOutcome.SUPPRESSED_BY_POLICY, amsg(K.REJECT_SOURCE_DISABLED, ref=ref[:120]), ref)
    severity = policy.severity.severity_for(candidate)
    if severity is None:
        return reject(QualificationOutcome.REJECTED_UNSUPPORTED, ref)
    if not severity.at_least(policy.qualification.min_severity):
        return Rejection(QualificationOutcome.SUPPRESSED_BY_POLICY, amsg(K.REJECT_BELOW_MIN_SEVERITY, ref=ref[:120]), ref)
    return Qualified(severity)
