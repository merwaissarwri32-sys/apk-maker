"""Alert construction - Phase 12. The only place an Alert is created from a qualified candidate."""
from __future__ import annotations

from datetime import datetime

from omnisystem_v5.alerts.enums import AlertSeverity, AlertState
from omnisystem_v5.alerts.identity import compute_identity
from omnisystem_v5.alerts.model import Alert, AlertCandidate


def build_alert(candidate: AlertCandidate, severity: AlertSeverity, now: datetime) -> Alert:
    return Alert(
        identity=compute_identity(candidate.alert_type, candidate.family, candidate.state),
        alert_type=candidate.alert_type, source=candidate.source, severity=severity, context=candidate.context,
        headline=candidate.headline, observation_key=candidate.observation_key, observed_at=candidate.observed_at,
        created_at=now, reasons=candidate.reasons, details=candidate.details, evidence=candidate.evidence,
        priority=candidate.priority, state=AlertState.ACTIVE)
