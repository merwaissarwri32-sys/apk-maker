"""Alert pipeline - Phase 12. A thin, explicit composition of the independent stages (NOT a manager holding their logic):

  observe (sources.map_*)  ->  qualify  ->  build_alert  ->  dedup.observe  ->  router.decide  ->  build_envelope
                           ->  DeliveryExecutor.deliver (per envelope)  ->  dedup.record_delivery  ->  audit + telemetry

Guarantees: each observation is processed in isolation (a failure in any stage is recorded and the rest continue); nothing here
raises to the caller except BaseException; telemetry / audit failures are swallowed and counted; no background threads; no hidden
retries (the only retries are inside DeliveryExecutor, bounded); nothing is sent unless it qualified, was not deduplicated, was
routed and produced a valid envelope. Input order is preserved (mappers emit a deterministic order). It never touches trading
decisions: it only reads what the frozen layers already computed.
"""
from __future__ import annotations

from omnisystem_v5.alerts.audit import AlertAuditRecord
from omnisystem_v5.alerts.construction import build_alert
from omnisystem_v5.alerts.dedup import expire, observe, record_delivery
from omnisystem_v5.alerts.delivery import rejected_result
from omnisystem_v5.alerts.enums import AlertDedupVerdict, DeliveryStatus, QualificationOutcome
from omnisystem_v5.alerts.envelope import build_envelope, envelope_id_for
from omnisystem_v5.alerts.errors import PayloadValidationError
from omnisystem_v5.alerts.qualification import Rejection, qualify, reject
from omnisystem_v5.alerts.sources import MapResult, map_events, map_report, map_snapshot
from omnisystem_v5.alerts.telemetry import AlertEventKind as E
from omnisystem_v5.alerts.telemetry import emit_alert_event


class AlertPipeline:
    def __init__(self, *, clock, policy, router, transports, executor, catalog, store, audit=None, sink=None):
        self._clock, self._policy, self._router, self._transports = clock, policy, router, transports
        self._executor, self._catalog, self._store, self._audit, self._sink = executor, catalog, store, audit, sink

    # ------------------------------------------------------------ entry points
    def process_report(self, report, resolver=None, include_healthy: bool = False) -> tuple:
        return self.process(self._mapped(map_report, report, resolver, include_healthy))

    def process_snapshot(self, snapshot, resolver=None, include_healthy: bool = False) -> tuple:
        return self.process(self._mapped(map_snapshot, snapshot, resolver, include_healthy))

    def process_events(self, events, strict: bool = True) -> tuple:
        return self.process(self._mapped(map_events, events, strict))

    def process(self, mapped: MapResult) -> tuple:
        now = self._clock.now()
        records = []
        self._expire(now)
        for rej in mapped.rejections:
            records.append(self._rejected(now, rej.ref, rej))
        for cand in mapped.candidates:
            records.append(self._one(cand))
        return tuple(records)

    # ------------------------------------------------------------ internals
    @staticmethod
    def _mapped(fn, *args) -> MapResult:
        try:
            return fn(*args)
        except Exception:
            return MapResult((), (reject(QualificationOutcome.REJECTED_MALFORMED, fn.__name__),), 0)

    def _ev(self, kind, subject=None, **detail) -> int:
        return 0 if emit_alert_event(self._sink, kind, self._clock.now(), subject, **detail) else 1

    def _log(self, record: AlertAuditRecord) -> AlertAuditRecord:
        if self._audit is not None:
            try:
                self._audit.append(record)
            except Exception:
                pass
        return record

    def _expire(self, now) -> None:
        try:
            state, expired = expire(self._store.load(), now, self._policy.dedup)
            self._store.save(state)
            for r in expired:
                self._ev(E.ALERT_EXPIRED, f"{r.family}.{r.fingerprint}")
        except Exception:
            self._ev(E.PIPELINE_ERROR, None, stage="expire")

    def _rejected(self, now, ref, rej: Rejection, candidate=None) -> AlertAuditRecord:
        hard = rej.outcome in (QualificationOutcome.REJECTED_MALFORMED, QualificationOutcome.REJECTED_UNSUPPORTED)
        tel = self._ev(E.ALERT_REJECTED if hard else E.ALERT_SUPPRESSED, None, outcome=rej.outcome, ref=ref)
        return self._log(AlertAuditRecord(now, ref, rej.outcome, source=getattr(candidate, "source", None), headline=getattr(candidate, "headline", None),
                                          rejection=rej.message, telemetry_errors=tel))

    def _one(self, cand) -> AlertAuditRecord:
        now, stage, tel, alert = self._clock.now(), "qualify", 0, None
        verdict = decision = None
        results: list = []
        try:
            q = qualify(cand, self._policy)
            if isinstance(q, Rejection):
                return self._rejected(now, cand.observation_key, q, cand)
            stage = "construct"
            alert = build_alert(cand, q.severity, now)
            tel += self._ev(E.ALERT_CREATED, alert.alert_id, severity=alert.severity, alert_type=alert.alert_type, headline=alert.headline.key)
            stage = "dedup"
            state, verdict = observe(self._store.load(), alert, now, self._policy.dedup)
            self._store.save(state)
            if not verdict.notifies:
                kind = E.ALERT_SUPPRESSED if verdict == AlertDedupVerdict.COOLDOWN else E.ALERT_DEDUPLICATED
                tel += self._ev(kind, alert.alert_id, verdict=verdict)
                return self._finish(now, cand, alert, verdict, None, results, tel)
            stage = "routing"
            decision = self._router.decide(alert, now)
            tel += self._ev(E.ROUTING_DECIDED, alert.alert_id, outcome=decision.outcome, routes=len(decision.routes), suppressed=len(decision.suppressed))
            if not decision.routes:
                tel += self._ev(E.ALERT_SUPPRESSED, alert.alert_id, reason="no_eligible_target")
            stage = "delivery"
            for route in decision.routes:
                target = self._router.policy.target(route.target_id)
                try:
                    env = build_envelope(alert, verdict, route, target, self._catalog)
                except PayloadValidationError:
                    results.append(rejected_result(envelope_id_for(alert, target.target_id, verdict), alert.alert_id, target.target_id, target.channel))
                    continue
                results.append(self._executor.deliver(env, self._transports.get(env.channel)))
            stage = "bookkeeping"
            delivered = any(r.status == DeliveryStatus.DELIVERED for r in results)
            deliverable = bool(decision.routes) or decision.transient_suppression
            self._store.save(record_delivery(self._store.load(), alert.identity.family, deliverable=deliverable, delivered=delivered))
            return self._finish(now, cand, alert, verdict, decision, results, tel)
        except Exception as exc:
            tel += self._ev(E.PIPELINE_ERROR, getattr(alert, "alert_id", None), stage=stage, error=type(exc).__name__)
            if alert is not None and stage in ("routing", "delivery", "bookkeeping"):
                try:
                    self._store.save(record_delivery(self._store.load(), alert.identity.family, deliverable=True, delivered=False))
                except Exception:
                    pass
            return self._finish(now, cand, alert, verdict, decision, results, tel, failures=(f"{stage}:{type(exc).__name__}",))

    def _finish(self, now, cand, alert, verdict, decision, results, tel, failures=()) -> AlertAuditRecord:
        tel += sum(r.telemetry_errors for r in results)
        return self._log(AlertAuditRecord(
            at=now, observation_key=cand.observation_key, qualification=QualificationOutcome.QUALIFIED, source=cand.source,
            alert_id=getattr(alert, "alert_id", None), alert_type=cand.alert_type, severity=getattr(alert, "severity", None),
            headline=cand.headline, verdict=verdict, routing=decision, deliveries=tuple(results), failures=failures, telemetry_errors=tel))
