# MERWIS AI — Phase 5: Risk Engine — Final Report

**Scope executed: Risk Engine only.** Master Decision Engine, Execution Engine,
Autonomous Scanner, Auto Trading, and broker/exchange integration were NOT built.
**Phase 6 was NOT started.**

---

## 1. Final Risk Engine Architecture

```
                    (any Intelligence Engine's candidate)
                                  │
                    intelligence/risk_bridge.py   ← the ONLY file that
                                  │                  imports both sides
                                  ▼
                     risk.contracts.TradeCandidateInput
                                  │
        ┌─────────────────────────┼──────────────────────────┐
        ▼                         ▼                          ▼
  AccountState              RiskPolicy                 (InstrumentSpec,
  (equity, existing          (all thresholds,           optional, inside
   exposure/risk,             fully configurable,        TradeCandidateInput)
   loss streaks)              no hard-coded magic)
        └─────────────────────────┬──────────────────────────┘
                                  ▼
                         risk.engine.assess_risk()
                                  │
        Stage 1: data integrity        → DATA_INVALID
        Stage 2: direction / SL shape  → REJECTED or RISK_BLOCKED
        Stage 3: take-profit shape     → REJECTED
        Stage 4: reward:risk           → REJECTED
        Stage 5: position sizing       → RISK_BLOCKED
        Stage 6: account-level limits  → RISK_BLOCKED
        Stage 7: otherwise             → WARNING or VALID
                                  │
                                  ▼
                     risk.result.RiskAssessmentResult
                (decision, structured reason codes, warnings,
                 position size, risk %, R:R — is_actionable property)
                                  │
                                  ▼
                (Future: Master Decision Engine consumes this directly)
```

**Independence guarantee (verified, not just claimed):** `risk/*.py` has zero
`import` statements referencing `intelligence`, `quant`, or `context`. Grep-verified:

```
$ grep -rn "from omnisystem_v5\.\(intelligence\|quant\|context\)" omnisystem_v5/risk/
(no output)
```

The engine performs no market analysis, no structure/liquidity/FVG detection, no
scenario classification — it only evaluates the numbers it's given.

---

## 2. Files Created

```
omnisystem_v5/risk/
├── __init__.py
├── enums.py             Direction, RiskDecision, RejectionReasonCode (30 codes),
│                         WarningCode (7 codes)
├── contracts.py          InstrumentSpec, AccountState, RiskPolicy, TradeCandidateInput
├── result.py             RiskAssessmentResult (+ is_actionable property)
├── position_sizing.py    calculate_position_size() — pure, deterministic
├── validators.py         validate_data_integrity, validate_direction_and_sl,
│                         validate_take_profits, compute_reward_and_rr,
│                         validate_rr, validate_account_limits
└── engine.py              assess_risk() — the 7-stage orchestrator

omnisystem_v5/intelligence/
└── risk_bridge.py        from_scalp_candidate / from_intraday_candidate /
                          from_short_swing_candidate — the ONE file bridging
                          Intelligence candidate types to TradeCandidateInput

omnisystem_v5/tests/
├── test_phase5_position_sizing.py       (9 tests)
├── test_phase5_data_direction_sl.py     (24 tests)
├── test_phase5_take_profit_rr.py        (18 tests)
├── test_phase5_account_limits.py        (16 tests)
├── test_phase5_engine_integration.py    (23 tests)
└── test_phase5_risk_bridge.py           (6 tests)
```

**Files modified: none.** Phase 1–4 code was not touched.

---

## 3. Risk Contract (`contracts.py`)

| Field group | Contents |
|---|---|
| `TradeCandidateInput` | symbol, direction, entry, stop_loss, take_profits (tuple, TP1..TPn), horizon (label), source (label), instrument, requested_risk_pct |
| `AccountState` | equity, currency, existing_open_risk_amount, existing_exposure_amount, existing_open_positions_count, daily_loss_amount, consecutive_losses |
| `InstrumentSpec` (optional) | tick_size, price_decimals, min_position_size, position_step, contract_size |
| `RiskPolicy` | every threshold below — fully overridable, nothing hard-coded in engine logic |

`RiskAssessmentResult` carries: decision, entry/SL/TPs (echoed), risk_amount, risk_percentage, reward_amounts, reward_risk_ratios (per TP), primary_reward_risk_ratio, position_size, position_notional, rejection_reasons (structured codes), warnings (structured codes), details (paired human text), `is_actionable` property.

This contract is intentionally horizon-agnostic — a future Master Decision Engine consumes `RiskAssessmentResult` without needing to know whether the candidate came from Scalp, Intraday, or Short-Swing.

---

## 4. Risk Policies (all configuration-driven, in `RiskPolicy`)

| Policy | Default | Configurable per |
|---|---|---|
| `max_risk_per_trade_pct` | 1.0% | strategy/asset/user/regime — just pass a different `RiskPolicy` |
| `max_total_open_risk_pct` | 5.0% | same |
| `max_exposure_pct` | 20.0% | same |
| `max_concurrent_risk_count` | None (unlimited) | same |
| `daily_loss_limit_pct` | None (disabled) | same |
| `consecutive_loss_guard` | None (disabled) | same |
| `min_reward_risk_ratio` | **2.0 (1:2)** — the spec's default, NOT hard-coded | same |
| `min_sl_distance_pct` | 0.05% | same |
| `max_sl_distance_pct` | 10.0% | same |
| `min_tp_distance_pct` | 0.05% | same |
| `rr_marginal_buffer` | 0.1 | same |

No threshold lives as a bare number inside `engine.py`/`validators.py` — every comparison reads from a `RiskPolicy` instance passed in by the caller.

---

## 5. Position Sizing Logic

```
target_risk_amount = equity * (risk_pct / 100)
per_unit_risk       = abs(entry - stop_loss) * contract_size
raw_quantity        = target_risk_amount / per_unit_risk
```

- `position_step` present → floored (rounded DOWN only, never up).
- Result below `min_position_size` → `POSITION_SIZE_IMPOSSIBLE` (never bumped up to the minimum — that would silently increase risk beyond what was requested).
- **There is no reward/target parameter anywhere in `calculate_position_size`'s signature** — structurally impossible to inflate size to chase a profit goal (verified by a dedicated test inspecting the function signature).

---

## 6. Validation Rules Summary

- **Data integrity** (first, fail-closed): missing fields, NaN, ±infinity, non-positive equity/entry/SL, invalid direction, no TP, duplicate TPs, invalid instrument spec → `DATA_INVALID`.
- **SL**: wrong side, equals entry, too tight, too wide, tick-size misalignment → `REJECTED` (structural) or `RISK_BLOCKED` (too-wide specifically, since it's a risk-limit concern).
- **TP**: wrong side, equals entry, invalid ordering (strict `<`/`>`, duplicates now correctly caught after a bug fix — see §11), too close → `REJECTED`. An unusually *distant* TP is explicitly NOT rejected here (that's a market-analysis judgment, out of scope for Risk Engine — separation of concerns).
- **R:R**: computed from TP1 (the nearest, most conservative target) only decides pass/fail, even if TP2/TP3 look excellent → `REJECTED` if below `min_reward_risk_ratio`; `WARNING` if within `rr_marginal_buffer` of it.
- **Account limits**: max risk/trade, max total open risk, max exposure, max concurrent positions, daily loss limit, consecutive-loss guard — each independently checked, all violations surfaced together at the validator level (`validate_account_limits`), though `engine.py`'s stage pipeline still short-circuits per-stage for a single clean decision.

---

## 7. Reject Reason Codes (structured, never bare strings)

**Rejection codes (30):** `DATA_MISSING_FIELD`, `DATA_NOT_FINITE`, `DATA_NONPOSITIVE_EQUITY`, `DATA_NONPOSITIVE_ENTRY`, `DATA_NONPOSITIVE_STOP_LOSS`, `DATA_INVALID_DIRECTION`, `DATA_NO_TAKE_PROFIT`, `DATA_DUPLICATE_TAKE_PROFIT`, `DATA_UNSUPPORTED_INSTRUMENT_SPEC`, `SL_EQUALS_ENTRY`, `SL_WRONG_SIDE`, `SL_TOO_TIGHT`, `SL_TOO_WIDE`, `SL_PRECISION_INVALID`, `TP_WRONG_SIDE`, `TP_EQUALS_ENTRY`, `TP_INVALID_ORDERING`, `TP_TOO_CLOSE`, `RR_BELOW_MINIMUM`, `POSITION_SIZE_ZERO`, `POSITION_SIZE_IMPOSSIBLE`, `MAX_RISK_PER_TRADE_EXCEEDED`, `MAX_TOTAL_OPEN_RISK_EXCEEDED`, `MAX_EXPOSURE_EXCEEDED`, `MAX_CONCURRENT_RISK_EXCEEDED`, `DAILY_LOSS_LIMIT_EXCEEDED`, `CONSECUTIVE_LOSS_GUARD_TRIGGERED`.

**Warning codes (7):** `RR_MARGINAL`, `TP_FAR_BEYOND_TYPICAL_RANGE` (reserved, not currently emitted — see limitations), `SL_NEAR_MAX_ALLOWED_DISTANCE`, `EXPOSURE_NEAR_LIMIT`, `OPEN_RISK_NEAR_LIMIT`, `POSITION_SIZE_ROUNDED_DOWN`, `ONLY_PARTIAL_TAKE_PROFITS_PROVIDED`.

---

## 8. New Tests: 96

| File | Count | Focus |
|---|---|---|
| `test_phase5_position_sizing.py` | 9 | Formula, boundaries (zero/negative risk, zero distance), instrument rounding-down, never-inflate-for-reward |
| `test_phase5_data_direction_sl.py` | 24 | NaN/inf, non-positive equity/entry, missing/duplicate TP, SL wrong-side/tight/wide/precision, floating-point precision edge case |
| `test_phase5_take_profit_rr.py` | 18 | TP ordering (incl. duplicate-TP bug fix), wrong side, R:R exactly-at-minimum vs slightly-below, marginal-buffer warning, TP1-only-decides |
| `test_phase5_account_limits.py` | 16 | Each of the 6 account-level limits independently, near-limit warnings, multiple-simultaneous-violations |
| `test_phase5_engine_integration.py` | 23 | Full pipeline (VALID/WARNING/REJECTED/RISK_BLOCKED/DATA_INVALID), determinism (identical input → identical output, 5x repeat), adversarial (huge/tiny numbers, inconsistent candidates), instrument/precision end-to-end |
| `test_phase5_risk_bridge.py` | 6 | Scalp candidate → TradeCandidateInput mapping, end-to-end through `assess_risk` |

---

## 9. Full Test Result

```
Phase 5 new tests:        96/96  PASS
Full project suite:      339/339 PASS   (243 pre-existing + 96 new)
```

**Zero regression** — Phase 1–4 test count (243) is unchanged and all still pass.

---

## 10. Architecture Changes to Prior Phases

**None.** No file under `schemas/`, `data/`, `context/`, `calculations/`, `quant/`, or `intelligence/`'s existing modules (Bull/Bear/Scalp/Intraday/Short-Swing/entry_zone/event_risk/regime/mtf_bias/reaction) was modified. The only new file touching the intelligence layer is the additive `risk_bridge.py`, which imports *into* `risk/` but is not imported *by* anything in Phase 1–4 — existing engines are completely unaware the Risk Engine exists.

---

## 11. Bug Found and Fixed (this session)

`validate_take_profits`'s ordering check originally used `sorted(tps) == list(tps)`, which is **non-strict** — it silently accepted duplicate consecutive TP values (e.g. `(105, 105, 115)`) as "correctly ordered." Fixed to a strict pairwise comparison (`tps[i] < tps[i+1]` for LONG, `>` for SHORT), so duplicate/non-strictly-ordered TPs are now correctly rejected with `TP_INVALID_ORDERING`. Caught by a dedicated adversarial test before this report was written; no downstream code depended on the old (wrong) behavior.

---

## 12. Remaining Limitations

1. **No portfolio-level cross-symbol correlation check** — `max_total_open_risk_pct`/`max_exposure_pct` sum flat dollar amounts the caller supplies; the engine doesn't know if two open positions are correlated (e.g. two long BTC pairs). This is a reasonable v1 boundary, not a hidden gap — `AccountState` is explicitly documented as caller-aggregated.
2. **`WarningCode.TP_FAR_BEYOND_TYPICAL_RANGE` is defined but never emitted** — deliberately, per separation-of-concerns (judging "how far is too far" for a target is a market-analysis call, not Risk Engine's job). Kept in the enum for a future policy hook if that changes.
3. **The risk_bridge only carries a single TP per horizon candidate today** because Scalp/Intraday/Short-Swing engines still only produce one target zone each (a Phase 4 limitation, documented there, unchanged in Phase 5). `TradeCandidateInput.take_profits` already supports TP1-TP3+; the bridge will pass them all through the moment the horizon engines produce them.
4. **No persistence/audit log** for risk decisions — every `assess_risk()` call is stateless and its result is not stored anywhere; a future audit/compliance layer would need to wrap this.
5. **Currency conversion is not handled** — `AccountState.currency` is a label only; if a candidate's instrument is priced in a different currency than the account, nothing in this engine converts between them.
6. **Tick-size validation only checks the stop-loss**, not the entry or take-profit prices, since SL precision is the field most consequential to broker order acceptance in typical retail platforms — this was a scope choice, not an oversight, but a stricter implementation would check all four prices.

---

## 13. Recommended Phase 6 (NOT executed)

Build the **Master Decision Engine** next: the component that (a) receives candidates from Bull/Bear-derived Scalp/Intraday/Short-Swing engines, (b) bridges each through `risk_bridge.py` into `assess_risk()`, (c) only ever forwards a candidate onward when `RiskAssessmentResult.is_actionable` is `True`, and (d) is the first place in the whole system where a single, final, structured decision object (still NOT an execution order) is produced by reconciling Intelligence evidence with Risk Engine approval. This is the natural next seam: Risk Engine is now a complete, independently tested authority ready to be consumed exactly as designed in §1's contract, and Master Decision Engine is explicitly what the Risk Contract was built to plug into without modification.
