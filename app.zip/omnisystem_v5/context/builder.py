"""
MarketContext builder — MERWIS AI, Phase 2.

This is the ONLY place that turns a Phase 1 MarketDataEnvelope into a
Phase 2 MarketContext. It performs no AI reasoning: every field is
either a real deterministic calculation or an explicit None with a
recorded reason. Phase 1 contracts are consumed as-is and unmodified.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from omnisystem_v5.calculations.atr import latest_atr
from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.calculations.fvg import detect_fair_value_gaps
from omnisystem_v5.calculations.liquidity import detect_liquidity_zones
from omnisystem_v5.calculations.returns import calculate_volatility
from omnisystem_v5.calculations.structure_events import detect_structure_breaks
from omnisystem_v5.calculations.support_resistance import detect_support_resistance
from omnisystem_v5.calculations.swings import find_swing_points, label_hh_hl_lh_ll
from omnisystem_v5.calculations.trend import classify_trend
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MarketContext, MultiTimeframeMarketContext, OHLCVContext, VolatilityMetrics
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import MarketDataEnvelope


@dataclass(frozen=True)
class MarketContextConfig:
    atr_period: int = 14
    swing_window: int = 2
    sr_tolerance_pct: float = 0.0015
    liquidity_tolerance_pct: float = 0.0005
    sr_min_touches: int = 2
    # Minimum bars needed for a meaningful structure read (not just the
    # bare mathematical minimum) — chosen so at least a handful of
    # swings can realistically form. Explicit and overridable.
    min_bars_required: int = 30


# Maps Phase 1 QualityStatus -> Phase 2 ContextStatus. STALE is treated
# conservatively as DATA_UNAVAILABLE: stale price data should not be
# used to derive "current" structure, since that would silently present
# outdated information as if it were current.
_QUALITY_TO_CONTEXT_STATUS = {
    QualityStatus.DATA_UNAVAILABLE: ContextStatus.DATA_UNAVAILABLE,
    QualityStatus.INSUFFICIENT_DATA: ContextStatus.INSUFFICIENT_CONTEXT,
    QualityStatus.INVALID: ContextStatus.INVALID_CONTEXT,
    QualityStatus.ERROR: ContextStatus.DATA_UNAVAILABLE,
    QualityStatus.STALE: ContextStatus.DATA_UNAVAILABLE,
}


def _empty_context(
    symbol: str, timeframe: Timeframe, status: ContextStatus, provenance, reasons: list[str]
) -> MarketContext:
    return MarketContext(
        symbol=symbol,
        timeframe=timeframe,
        status=status,
        calculated_at=datetime.now(timezone.utc),
        provenance=provenance,
        reasons=tuple(reasons),
    )


def build_market_context(
    symbol: str,
    envelope: MarketDataEnvelope,
    config: MarketContextConfig | None = None,
) -> MarketContext:
    """Builds a single-timeframe MarketContext from a Phase 1 envelope.
    Never fabricates data: any shortfall results in an explicit non-OK
    status and an empty result set, with reasons recorded."""
    config = config or MarketContextConfig()
    timeframe = envelope.timeframe

    # 1. Mirror Phase 1's quality verdict if it wasn't OK.
    if envelope.quality_status != QualityStatus.OK:
        mapped_status = _QUALITY_TO_CONTEXT_STATUS[envelope.quality_status]
        reasons = list(envelope.reasons) + [
            f"underlying MarketDataEnvelope.quality_status={envelope.quality_status.value}"
        ]
        return _empty_context(symbol, timeframe, mapped_status, envelope.provenance, reasons)

    bars = list(envelope.bars)

    # 2. Check this layer's own minimum bar requirement.
    if len(bars) < config.min_bars_required:
        reasons = [
            f"only {len(bars)} bars available, {config.min_bars_required} required "
            "for a meaningful structure calculation"
        ]
        return _empty_context(symbol, timeframe, ContextStatus.INSUFFICIENT_CONTEXT, envelope.provenance, reasons)

    reasons: list[str] = []
    now = datetime.now(timezone.utc)

    # 3. OHLCV snapshot.
    latest_bar = bars[-1]
    ohlcv_ctx = OHLCVContext(
        latest_open=latest_bar.open,
        latest_high=latest_bar.high,
        latest_low=latest_bar.low,
        latest_close=latest_bar.close,
        latest_volume=latest_bar.volume,
        latest_bar_time=latest_bar.close_time,
        bar_count=len(bars),
    )
    current_price = latest_bar.close

    # 4. Volatility metrics — individually optional; missing pieces are
    #    recorded, they never block the rest of the context.
    atr_value = None
    vol_reasons: list[str] = []
    try:
        atr_point = latest_atr(bars, period=config.atr_period)
        atr_value = atr_point.value
    except InsufficientDataError as e:
        vol_reasons.append(str(e))

    returns_vol = None
    try:
        returns_vol = calculate_volatility(bars)
    except InsufficientDataError as e:
        vol_reasons.append(str(e))

    volatility = VolatilityMetrics(
        timeframe=timeframe,
        calculated_at=now,
        atr=atr_value,
        atr_period=config.atr_period,
        returns_volatility=returns_vol,
        reasons=tuple(vol_reasons),
    )

    # 5. Swing points + HH/HL/LH/LL labeling.
    try:
        swings = find_swing_points(bars, timeframe, window=config.swing_window)
    except InsufficientDataError as e:
        reasons.append(str(e))
        swings = []

    hh_ll_events = label_hh_hl_lh_ll(swings, timeframe) if swings else []

    # 6. Trend classification.
    trend = classify_trend(hh_ll_events, timeframe, as_of=now)

    # 7. BOS/CHoCH breaks.
    break_events = detect_structure_breaks(bars, swings, timeframe) if swings else []

    all_structure_events = tuple(sorted(hh_ll_events + break_events, key=lambda e: e.timestamp))

    # 8. Support/resistance and liquidity zones.
    sr_levels = tuple(
        detect_support_resistance(
            swings, timeframe, tolerance_pct=config.sr_tolerance_pct, min_touches=config.sr_min_touches
        )
    ) if swings else tuple()

    liquidity_zones = tuple(
        detect_liquidity_zones(swings, timeframe, tolerance_pct=config.liquidity_tolerance_pct)
    ) if swings else tuple()

    # 9. Fair value gaps.
    try:
        fvgs = tuple(detect_fair_value_gaps(bars, timeframe))
    except InsufficientDataError as e:
        reasons.append(str(e))
        fvgs = tuple()

    return MarketContext(
        symbol=symbol,
        timeframe=timeframe,
        status=ContextStatus.OK,
        calculated_at=now,
        provenance=envelope.provenance,
        current_price=current_price,
        ohlcv_context=ohlcv_ctx,
        volatility=volatility,
        trend=trend,
        swing_points=tuple(swings),
        structure_events=all_structure_events,
        support_resistance=sr_levels,
        liquidity_zones=liquidity_zones,
        fair_value_gaps=fvgs,
        reasons=tuple(reasons),
        bars=tuple(bars),
    )


def build_multi_timeframe_context(
    symbol: str,
    envelopes: dict[Timeframe, MarketDataEnvelope],
    config: MarketContextConfig | None = None,
) -> MultiTimeframeMarketContext:
    """Builds an independent MarketContext per timeframe. Each timeframe
    is calculated completely separately — this function never shares or
    mixes bars, swings, or events across timeframes."""
    contexts = {
        tf: build_market_context(symbol, env, config)
        for tf, env in envelopes.items()
    }
    return MultiTimeframeMarketContext(
        symbol=symbol,
        calculated_at=datetime.now(timezone.utc),
        contexts=contexts,
    )
