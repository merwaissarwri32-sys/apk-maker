"""
Enumerations for the Market Context / deterministic structure layer.
"""

from enum import Enum


class ContextStatus(str, Enum):
    """Top-level status of a MarketContext. Mirrors, but is distinct from,
    Phase 1's QualityStatus — this layer adds its own INSUFFICIENT_CONTEXT
    case for when the underlying data passed Phase 1's gate but still
    isn't enough for a mathematically valid structure calculation
    (e.g., enough bars to pass min_bars_required in Phase 1, but fewer
    than this layer's swing/ATR window requires)."""

    OK = "OK"
    INSUFFICIENT_CONTEXT = "INSUFFICIENT_CONTEXT"
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"
    INVALID_CONTEXT = "INVALID_CONTEXT"


class SwingType(str, Enum):
    HIGH = "HIGH"
    LOW = "LOW"


class TrendState(str, Enum):
    UPTREND = "UPTREND"
    DOWNTREND = "DOWNTREND"
    RANGE = "RANGE"
    UNDEFINED = "UNDEFINED"  # not enough confirmed swings to classify


class StructureEventType(str, Enum):
    SWING_HIGH = "SWING_HIGH"
    SWING_LOW = "SWING_LOW"
    HIGHER_HIGH = "HIGHER_HIGH"
    LOWER_HIGH = "LOWER_HIGH"
    EQUAL_HIGH = "EQUAL_HIGH"
    HIGHER_LOW = "HIGHER_LOW"
    LOWER_LOW = "LOWER_LOW"
    EQUAL_LOW = "EQUAL_LOW"
    BOS_BULLISH = "BOS_BULLISH"
    BOS_BEARISH = "BOS_BEARISH"
    CHOCH_BULLISH = "CHOCH_BULLISH"
    CHOCH_BEARISH = "CHOCH_BEARISH"


class LiquidityType(str, Enum):
    EQUAL_HIGHS = "EQUAL_HIGHS"   # buy-side liquidity resting above
    EQUAL_LOWS = "EQUAL_LOWS"     # sell-side liquidity resting below


class SRLevelType(str, Enum):
    SUPPORT = "SUPPORT"
    RESISTANCE = "RESISTANCE"


class FVGType(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
