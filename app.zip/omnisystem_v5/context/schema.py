"""
Market Context schemas — MERWIS AI, Phase 2.

These are the structured, deterministic outputs that future AI agents
(Bull Engine, Bear Engine, Quant Engine, Macro Engine, Order Flow Engine,
Master Decision Engine) will consume. No AI reasoning happens here —
this module only defines shapes. All fields are either a real calculated
value or explicitly None with a reason recorded, never a guess.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.context.enums import (
    ContextStatus,
    FVGType,
    LiquidityType,
    SRLevelType,
    StructureEventType,
    SwingType,
    TrendState,
)
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance


class ContextValidationError(ValueError):
    """Raised when a Phase 2 schema object fails its own invariants."""


def _require_tz(value: datetime, name: str) -> None:
    if value.tzinfo is None:
        raise ContextValidationError(f"{name} must be timezone-aware (UTC)")


@dataclass(frozen=True)
class SwingPoint:
    """A confirmed local extreme. 'Confirmed' means: at the time this
    object is produced, `window` bars exist on both sides of it, so
    the swing will never change — no lookahead risk downstream."""

    swing_type: SwingType
    price: float
    timestamp: datetime          # the swing bar's own open_time
    bar_index: int                # index of the swing bar within the input series
    confirmed_at_index: int       # index of the bar at which this swing became confirmed
    timeframe: Timeframe

    def __post_init__(self):
        _require_tz(self.timestamp, "timestamp")


@dataclass(frozen=True)
class StructureEvent:
    """A single auditable structure event (HH/HL/LH/LL, BOS, or CHoCH).

    `confidence` is populated ONLY when there is a mathematically
    justified basis for a numeric value (there generally isn't, for
    this deterministic layer — these are boolean pattern matches, not
    probabilistic estimates) so it defaults to None. Do not populate it
    with an invented number.
    """

    event_type: StructureEventType
    timestamp: datetime
    price: float
    timeframe: Timeframe
    calculation_source: str       # human-readable explanation of exactly how this was derived
    confidence: float | None = None

    def __post_init__(self):
        _require_tz(self.timestamp, "timestamp")
        if self.confidence is not None and not (0.0 <= self.confidence <= 1.0):
            raise ContextValidationError("confidence must be within [0, 1] when provided")


@dataclass(frozen=True)
class TrendClassification:
    state: TrendState
    timeframe: Timeframe
    as_of: datetime
    basis: str  # explicit explanation, e.g. "last swing high=HIGHER_HIGH, last swing low=HIGHER_LOW"

    def __post_init__(self):
        _require_tz(self.as_of, "as_of")


@dataclass(frozen=True)
class VolatilityMetrics:
    timeframe: Timeframe
    calculated_at: datetime
    atr: float | None
    atr_period: int
    returns_volatility: float | None   # sample stdev of simple returns
    reasons: tuple[str, ...] = field(default_factory=tuple)  # why atr/vol might be None

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")


@dataclass(frozen=True)
class SupportResistanceLevel:
    level_type: SRLevelType
    price: float                  # average price of the clustered swings
    timeframe: Timeframe
    touch_count: int
    first_formed_at: datetime
    last_touched_at: datetime

    def __post_init__(self):
        _require_tz(self.first_formed_at, "first_formed_at")
        _require_tz(self.last_touched_at, "last_touched_at")
        if self.touch_count < 1:
            raise ContextValidationError("touch_count must be >= 1")


@dataclass(frozen=True)
class LiquidityZone:
    liquidity_type: LiquidityType
    price_level: float             # average price of the clustered equal highs/lows
    timeframe: Timeframe
    touch_count: int
    formed_at: datetime            # timestamp of the most recent contributing swing

    def __post_init__(self):
        _require_tz(self.formed_at, "formed_at")
        if self.touch_count < 2:
            raise ContextValidationError("a liquidity zone requires at least 2 equal touches")


@dataclass(frozen=True)
class FairValueGap:
    fvg_type: FVGType
    top: float
    bottom: float
    timeframe: Timeframe
    formed_at: datetime            # timestamp of the middle candle in the 3-candle pattern
    filled: bool                   # determined ONLY from bars provided at calculation time
    filled_at: datetime | None = None

    def __post_init__(self):
        _require_tz(self.formed_at, "formed_at")
        if self.filled_at is not None:
            _require_tz(self.filled_at, "filled_at")
        if self.top <= self.bottom:
            raise ContextValidationError("FVG top must be greater than bottom")


@dataclass(frozen=True)
class OHLCVContext:
    """Snapshot of the most recent bar plus the count of bars used."""

    latest_open: float
    latest_high: float
    latest_low: float
    latest_close: float
    latest_volume: float
    latest_bar_time: datetime
    bar_count: int

    def __post_init__(self):
        _require_tz(self.latest_bar_time, "latest_bar_time")


@dataclass(frozen=True)
class MarketContext:
    """The single structured object future engines (Bull/Bear/Quant/
    Macro/OrderFlow/AI agents/Master Decision) are meant to consume.
    They must never reach past this object into raw provider data.
    """

    symbol: str
    timeframe: Timeframe
    status: ContextStatus
    calculated_at: datetime
    provenance: DataProvenance | None

    current_price: float | None = None
    ohlcv_context: OHLCVContext | None = None
    volatility: VolatilityMetrics | None = None
    trend: TrendClassification | None = None
    swing_points: tuple[SwingPoint, ...] = field(default_factory=tuple)
    structure_events: tuple[StructureEvent, ...] = field(default_factory=tuple)
    support_resistance: tuple[SupportResistanceLevel, ...] = field(default_factory=tuple)
    liquidity_zones: tuple[LiquidityZone, ...] = field(default_factory=tuple)
    fair_value_gaps: tuple[FairValueGap, ...] = field(default_factory=tuple)
    reasons: tuple[str, ...] = field(default_factory=tuple)
    # Added in Phase 3: the same validated, quality-gated bar series used to
    # compute this context. Without this, downstream engines (e.g. the Quant
    # Engine's VWAP/ROC/RSI/EMA/rolling-volatility calculations) would have
    # no way to access historical bars without reaching back into raw
    # provider data, which violates the "consume MarketContext only" rule.
    # Purely additive: default is empty, existing fields/behavior unchanged.
    bars: tuple = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        if self.status != ContextStatus.OK and (
            self.current_price is not None
            or self.ohlcv_context is not None
            or self.swing_points
            or self.structure_events
            or self.bars
        ):
            raise ContextValidationError(
                f"status={self.status} must not carry calculated fields — "
                "never infer/populate results when context is not OK"
            )
        # multi-timeframe integrity: every event/swing must match this context's own timeframe
        for sp in self.swing_points:
            if sp.timeframe != self.timeframe:
                raise ContextValidationError(
                    f"swing point timeframe {sp.timeframe} does not match context timeframe {self.timeframe}"
                )
        for ev in self.structure_events:
            if ev.timeframe != self.timeframe:
                raise ContextValidationError(
                    f"structure event timeframe {ev.timeframe} does not match context timeframe {self.timeframe}"
                )


@dataclass(frozen=True)
class MultiTimeframeMarketContext:
    """A bundle of per-timeframe MarketContext objects for one symbol.
    Each timeframe's context is computed entirely independently — this
    object never merges or mixes calculations across timeframes."""

    symbol: str
    calculated_at: datetime
    contexts: dict  # Timeframe -> MarketContext (kept as dict for lookup convenience)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        for tf, ctx in self.contexts.items():
            if ctx.timeframe != tf:
                raise ContextValidationError(
                    f"context stored under key {tf} has mismatched internal timeframe {ctx.timeframe}"
                )
            if ctx.symbol != self.symbol:
                raise ContextValidationError(
                    f"context for {tf} has symbol {ctx.symbol}, expected {self.symbol}"
                )

    def get(self, timeframe: Timeframe) -> MarketContext | None:
        return self.contexts.get(timeframe)
