"""ScannerConfig - MERWIS AI, Phase 10. Only operationally meaningful knobs; every
strategy parameter stays in the existing engine configs, which are embedded as-is."""
from __future__ import annotations

from dataclasses import dataclass, field

from omnisystem_v5.decision.policy import DecisionPolicy
from omnisystem_v5.context.builder import MarketContextConfig
from omnisystem_v5.intelligence.enums import Horizon
from omnisystem_v5.intelligence.intraday_engine import IntradayEngineConfig
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig
from omnisystem_v5.quant.engine import QuantEngineConfig
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.scanner.dedup import DedupPolicy
from omnisystem_v5.scanner.health import HealthPolicy
from omnisystem_v5.scanner.identity import FingerprintPolicy
from omnisystem_v5.scanner.scheduler import SchedulePolicy
from omnisystem_v5.scanner.universe import UniverseFilter
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.validation.resampling import seconds_for_timeframe
from omnisystem_v5.validation.warmup import context_bar_requirement


class ScannerConfigError(ValueError):
    pass


@dataclass(frozen=True)
class ScannerConfig:
    horizons: tuple = (Horizon.SCALP, Horizon.INTRADAY, Horizon.SHORT_SWING)
    scalp_timeframe: Timeframe = Timeframe.M5
    market_context_config: MarketContextConfig = field(default_factory=MarketContextConfig)
    quant_engine_config: QuantEngineConfig = field(default_factory=QuantEngineConfig)
    scalp_engine_config: ScalpEngineConfig = field(default_factory=ScalpEngineConfig)
    intraday_engine_config: IntradayEngineConfig = field(default_factory=IntradayEngineConfig)
    short_swing_engine_config: ShortSwingEngineConfig = field(default_factory=ShortSwingEngineConfig)
    risk_policy: RiskPolicy = field(default_factory=RiskPolicy)
    decision_policy: DecisionPolicy = field(default_factory=DecisionPolicy)
    universe_filter: UniverseFilter = field(default_factory=UniverseFilter)
    schedule: SchedulePolicy = field(default_factory=SchedulePolicy)
    dedup: DedupPolicy = field(default_factory=DedupPolicy)
    fingerprint: FingerprintPolicy = field(default_factory=FingerprintPolicy)
    health: HealthPolicy = field(default_factory=HealthPolicy)
    staleness_bars: float = 2.0            # max age of the newest closed bar, in bars of its own timeframe
    fetch_limit: int = 200                 # bars requested per (symbol, timeframe)
    max_fetch_attempts: int = 2            # only timeouts are retried
    max_symbols_per_cycle: int | None = None
    max_signals_per_cycle: int | None = None

    def __post_init__(self):
        if not self.horizons or len(set(self.horizons)) != len(self.horizons) \
                or any(not isinstance(h, Horizon) for h in self.horizons):
            raise ScannerConfigError("horizons must be a non-empty tuple of unique Horizon values")
        if self.staleness_bars <= 0 or self.max_fetch_attempts < 1:
            raise ScannerConfigError("staleness_bars must be > 0 and max_fetch_attempts >= 1")
        for name in ("max_symbols_per_cycle", "max_signals_per_cycle"):
            v = getattr(self, name)
            if v is not None and v < 1:
                raise ScannerConfigError(f"{name} must be >= 1 or None")
        for h, eng in ((Horizon.INTRADAY, self.intraday_engine_config), (Horizon.SHORT_SWING, self.short_swing_engine_config)):
            if h in self.horizons and seconds_for_timeframe(eng.execution_timeframe) >= seconds_for_timeframe(eng.higher_timeframe):
                raise ScannerConfigError(f"{h.value}: execution timeframe must be shorter than the higher timeframe")
        need = context_bar_requirement(self.market_context_config, self.quant_engine_config)
        if self.fetch_limit < need:
            raise ScannerConfigError(f"fetch_limit={self.fetch_limit} is below the {need} bars the contexts require; "
                                     "no horizon could ever reach OK status")
        if self.dedup.expiry_seconds < self.schedule.interval_seconds:
            raise ScannerConfigError("dedup.expiry_seconds must be >= schedule.interval_seconds, "
                                     "otherwise a live setup would expire between two consecutive scans")

    @property
    def min_bars(self) -> int:
        return context_bar_requirement(self.market_context_config, self.quant_engine_config)
