"""Setup identity - MERWIS AI, Phase 10.

A tracked setup is identified by CONTENT ONLY: family (symbol, direction,
horizon, source engine), execution timeframe, structural scenario and the
setup's price geometry (entry zone, invalidation zone, targets).

  * NO wall-clock value and NO candidate_id ever enters an identity
    (candidate_id embeds the engine's wall-clock stamp - Phase 9 finding F1).
  * `current_price` is deliberately excluded: it moves every bar, the setup does not.
  * Market regime is deliberately excluded: it is derived from the same bars and
    flips independently of the setup geometry; including it would fragment one
    setup into several identities.

Two mechanisms, one purpose:
  fingerprint()  - canonical, quantized hash: stable audit identifier.
  same_setup()   - tolerance comparison used for dedup, so that a level
                   drifting across a quantization bucket boundary is NOT
                   mistaken for a new setup.

Scale normalization (primary): ATR-relative. Bucket = atr_bucket_fraction * ATR.
Fallback (only when ATR is missing, non-finite or <= 0 - never invented):
bucket = fallback_pct percent of the entry-zone midpoint. The basis used is
recorded on the descriptor ("ATR" or "PCT_FALLBACK") and is part of the hash.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass


class IdentityError(ValueError):
    pass


@dataclass(frozen=True)
class FingerprintPolicy:
    atr_bucket_fraction: float = 0.5   # quantization bucket, in ATRs
    materiality_atr: float = 1.0       # level movement (in ATRs) that makes a setup "materially changed"
    fallback_pct: float = 0.25         # bucket / materiality unit (percent of entry mid) when ATR is unusable

    def __post_init__(self):
        for name in ("atr_bucket_fraction", "materiality_atr", "fallback_pct"):
            v = getattr(self, name)
            if not (isinstance(v, (int, float)) and math.isfinite(v) and v > 0):
                raise ValueError(f"{name} must be a positive finite number")


@dataclass(frozen=True)
class SetupDescriptor:
    symbol: str
    direction: str
    horizon: str
    source_engine: str
    timeframe: str
    scenario: str
    entry_zone: tuple          # (bottom, top)
    invalidation_zone: tuple   # (bottom, top)
    targets: tuple             # target zone bottoms, in order
    atr: float | None          # ATR used as the scale, or None when unusable
    basis: str                 # "ATR" | "PCT_FALLBACK"
    unit: float                # absolute price size of one quantization unit (bucket / fallback bucket)
    quantized: tuple           # integer buckets of every level, in a fixed order

    @property
    def family(self) -> tuple:
        return (self.symbol, self.direction, self.horizon, self.source_engine)

    @property
    def fingerprint(self) -> str:
        payload = {
            "family": list(self.family), "tf": self.timeframe, "scenario": self.scenario,
            "basis": self.basis, "q": list(self.quantized),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _usable_atr(atr) -> bool:
    return isinstance(atr, (int, float)) and not isinstance(atr, bool) and math.isfinite(atr) and atr > 0


def _levels(entry, inval, targets) -> list:
    return [entry[0], entry[1], inval[0], inval[1], *targets]


def build_descriptor(raw, normalized, atr, policy: FingerprintPolicy | None = None) -> SetupDescriptor:
    """raw = the horizon engine's own candidate (zones live there);
    normalized = its decision-layer projection (direction/horizon/engine)."""
    policy = policy or FingerprintPolicy()
    try:
        entry = (float(raw.preferred_entry_zone.bottom), float(raw.preferred_entry_zone.top))
        inval = (float(raw.invalidation_zone.bottom), float(raw.invalidation_zone.top))
        targets = tuple(float(z.bottom) for z in raw.target_zones)
        timeframe = raw.timeframe.value
    except AttributeError as exc:
        raise IdentityError(f"candidate lacks required setup geometry: {exc}") from exc
    levels = _levels(entry, inval, targets)
    if not targets or any(not math.isfinite(x) or x <= 0 for x in levels):
        raise IdentityError("setup geometry must be finite, positive and have at least one target")
    scenario = getattr(raw, "scenario_type", None)
    scenario = scenario.value if scenario is not None else ""

    mid = (entry[0] + entry[1]) / 2.0
    if _usable_atr(atr):
        basis, scale, used_atr = "ATR", atr, float(atr)
        unit = policy.atr_bucket_fraction * scale
    else:
        basis, used_atr = "PCT_FALLBACK", None
        unit = (policy.fallback_pct / 100.0) * mid
    quantized = tuple(math.floor(x / unit) for x in levels)
    return SetupDescriptor(
        symbol=normalized.symbol, direction=normalized.direction.value, horizon=normalized.horizon,
        source_engine=normalized.source_engine, timeframe=timeframe, scenario=scenario,
        entry_zone=entry, invalidation_zone=inval, targets=targets,
        atr=used_atr, basis=basis, unit=unit, quantized=quantized,
    )


def same_setup(reference: SetupDescriptor, other: SetupDescriptor, policy: FingerprintPolicy) -> bool:
    """True when `other` is the same setup as `reference` (no material change).
    Tolerance is expressed in the REFERENCE's own scale (ATR or fallback percent)."""
    if reference.family != other.family or reference.timeframe != other.timeframe:
        return False
    if reference.scenario != other.scenario or len(reference.targets) != len(other.targets):
        return False
    # materiality is (materiality_atr / atr_bucket_fraction) buckets of the REFERENCE's unit -
    # identical to materiality_atr * ATR on the ATR basis, and the same proportion on the fallback basis.
    tolerance = (policy.materiality_atr / policy.atr_bucket_fraction) * reference.unit
    a = _levels(reference.entry_zone, reference.invalidation_zone, reference.targets)
    b = _levels(other.entry_zone, other.invalidation_zone, other.targets)
    return all(abs(x - y) <= tolerance for x, y in zip(a, b))
