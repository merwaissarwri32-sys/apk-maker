"""Timeframe integrity - MERWIS AI, Phase 10.

One place that answers, for a given ScannerConfig: which timeframes does each
horizon need, are the fetched timeframes fresh and mutually synchronized, and
which horizons can therefore run. Horizon->timeframe relationships are READ from
the existing engine configs (never re-declared). Structural conflict between
timeframes is NOT re-computed here: the Intraday/Short-Swing engines already
return NO_TRADE_CONFLICTING_STRUCTURE; the evaluator surfaces that verbatim.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from omnisystem_v5.intelligence.enums import Horizon
from omnisystem_v5.scanner.failures import FailureClass
from omnisystem_v5.validation.resampling import seconds_for_timeframe

HORIZON_ORDER = (Horizon.SCALP, Horizon.INTRADAY, Horizon.SHORT_SWING)


def horizon_timeframes(config, horizon: Horizon) -> tuple:
    """Timeframes a horizon consumes, ordered lower -> higher."""
    if horizon == Horizon.SCALP:
        return (config.scalp_timeframe,)
    engine = config.intraday_engine_config if horizon == Horizon.INTRADAY else config.short_swing_engine_config
    return (engine.execution_timeframe, engine.higher_timeframe)


def enabled_horizons(config) -> tuple:
    return tuple(h for h in HORIZON_ORDER if h in config.horizons)


def required_timeframes(config) -> tuple:
    """Union over enabled horizons, unique, ascending by duration."""
    tfs = {tf for h in enabled_horizons(config) for tf in horizon_timeframes(config, h)}
    return tuple(sorted(tfs, key=seconds_for_timeframe))


def check_envelope_time(envelope, now, staleness_bars: float):
    """Freshness / completeness against the INJECTED clock. Returns (FailureClass, detail) or None."""
    last_close = envelope.bars[-1].close_time
    if last_close > now:
        return FailureClass.INVALID_DATA, f"latest bar closes at {last_close.isoformat()}, after now: forming bar or clock skew"
    step = seconds_for_timeframe(envelope.timeframe)
    age = (now - last_close).total_seconds()
    if age > staleness_bars * step:
        return FailureClass.STALE_DATA, f"latest closed bar is {age:.0f}s old, limit {staleness_bars * step:.0f}s ({staleness_bars} x {envelope.timeframe.value})"
    return None


def check_synchronization(envelopes: dict, ordered_tfs: tuple):
    """Lower timeframe data must not lag the higher timeframe's newest closed bar
    (a higher bar closes exactly when its last lower bar closes)."""
    for lower, higher in zip(ordered_tfs, ordered_tfs[1:]):
        lo, hi = envelopes[lower].bars[-1].close_time, envelopes[higher].bars[-1].close_time
        if lo < hi:
            return (FailureClass.UNSYNCHRONIZED_TIMEFRAMES,
                    f"{lower.value} data ends {lo.isoformat()} but {higher.value} data ends {hi.isoformat()}")
    return None


@dataclass(frozen=True)
class HorizonBlock:
    horizon: Horizon
    failure_class: FailureClass
    detail: str


@dataclass(frozen=True)
class HorizonPlan:
    runnable: tuple = field(default_factory=tuple)
    blocked: tuple = field(default_factory=tuple)    # tuple[HorizonBlock]


def plan_horizons(config, ok_envelopes: dict, failures: dict) -> HorizonPlan:
    """ok_envelopes: tf -> gated envelope; failures: tf -> (FailureClass, detail)."""
    runnable, blocked = [], []
    for h in enabled_horizons(config):
        tfs = horizon_timeframes(config, h)
        missing = [tf for tf in tfs if tf not in ok_envelopes]
        if missing:
            cls, detail = failures.get(missing[0], (FailureClass.PROVIDER_UNAVAILABLE, "timeframe not fetched"))
            blocked.append(HorizonBlock(h, cls, f"{missing[0].value}: {detail}"))
            continue
        sync = check_synchronization(ok_envelopes, tfs) if len(tfs) > 1 else None
        if sync:
            blocked.append(HorizonBlock(h, sync[0], sync[1]))
            continue
        runnable.append(h)
    return HorizonPlan(runnable=tuple(runnable), blocked=tuple(blocked))
