"""Injectable time source. The scanner never calls datetime.now() itself:
every time-dependent decision (freshness, cooldown, expiry, scheduling,
risk `now`) uses the Clock handed to the engine, so tests never sleep and
identical inputs + identical clock => identical results."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Protocol


class Clock(Protocol):
    def now(self) -> datetime: ...


def _require_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        raise ValueError("clock time must be timezone-aware (UTC)")
    return value.astimezone(timezone.utc)


class SystemClock:
    def now(self) -> datetime:
        return datetime.now(timezone.utc)


class FixedClock:
    def __init__(self, at: datetime):
        self._at = _require_utc(at)

    def now(self) -> datetime:
        return self._at


class ManualClock:
    """Test/replay clock that only moves when told to."""

    def __init__(self, at: datetime):
        self._at = _require_utc(at)

    def now(self) -> datetime:
        return self._at

    def advance(self, seconds: float) -> datetime:
        if seconds < 0:
            raise ValueError("a clock cannot move backwards")
        self._at = self._at + timedelta(seconds=seconds)
        return self._at

    def set(self, at: datetime) -> None:
        at = _require_utc(at)
        if at < self._at:
            raise ValueError("a clock cannot move backwards")
        self._at = at
