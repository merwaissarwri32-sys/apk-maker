"""Failure taxonomy - MERWIS AI, Phase 10.

Every failure the scanner can observe is classified into exactly one
FailureClass. FEED_LEVEL classes describe the DATA FEED as a whole (they can
indicate a systemic outage); the rest describe a defect of one symbol's data.
"""
from __future__ import annotations

from enum import Enum

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.schemas.market_data import SchemaValidationError


class FailureClass(str, Enum):
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    PROVIDER_TIMEOUT = "PROVIDER_TIMEOUT"
    PROVIDER_RATE_LIMITED = "PROVIDER_RATE_LIMITED"
    MALFORMED_RESPONSE = "MALFORMED_RESPONSE"
    UNUSABLE_ORIGIN = "UNUSABLE_ORIGIN"          # e.g. SIMULATED data offered to a live scan
    STALE_DATA = "STALE_DATA"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    INVALID_DATA = "INVALID_DATA"                # gaps, duplicates, ordering, forming/future bar
    UNSYNCHRONIZED_TIMEFRAMES = "UNSYNCHRONIZED_TIMEFRAMES"
    INTERNAL_ERROR = "INTERNAL_ERROR"            # a bug in evaluation - always surfaced, never swallowed


FEED_LEVEL = frozenset({
    FailureClass.PROVIDER_UNAVAILABLE,
    FailureClass.PROVIDER_TIMEOUT,
    FailureClass.PROVIDER_RATE_LIMITED,
    FailureClass.MALFORMED_RESPONSE,
    FailureClass.STALE_DATA,
    FailureClass.UNSYNCHRONIZED_TIMEFRAMES,
})

RETRYABLE = frozenset({FailureClass.PROVIDER_TIMEOUT})


class ProviderRateLimitedError(Exception):
    """Adapters raise this when the provider signals a rate limit."""

    def __init__(self, message: str = "rate limited", retry_after_seconds: float | None = None):
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


def classify_fetch_exception(exc: Exception) -> FailureClass:
    if isinstance(exc, ProviderRateLimitedError):
        return FailureClass.PROVIDER_RATE_LIMITED
    if isinstance(exc, TimeoutError):
        return FailureClass.PROVIDER_TIMEOUT
    if isinstance(exc, (DataUnavailableError, ConnectionError)):
        return FailureClass.PROVIDER_UNAVAILABLE
    if isinstance(exc, (SchemaValidationError, ValueError, KeyError, TypeError)):
        return FailureClass.MALFORMED_RESPONSE
    return FailureClass.INTERNAL_ERROR
