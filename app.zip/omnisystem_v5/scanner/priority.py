"""Signal priority - MERWIS AI, Phase 10.

COMPUTATIONAL PRIORITY, NOT A PROBABILITY OF PROFIT. It orders alert-ready signals
for downstream attention/cap purposes only. It is a lexicographic tuple of named
ordinals (no sums, no weights, no magic score):

  1..8  the Decision Layer's own rank_key over the candidate's ScoreComponents
        (reused - not re-implemented; order given by DecisionPolicy.scoring)
  9     risk_verdict      : Risk Engine VALID=2, WARNING=1
  10    data_freshness    : newest closed bar <= 1 bar old =2, within staleness limit =1
  11    liquidity_tier    : tercile of quote volume inside the CURRENT scan universe (unknown=0)
"""
from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.decision.scoring import explain_rank_key, rank_key
from omnisystem_v5.risk.enums import RiskDecision

PRIORITY_KIND = "COMPUTATIONAL_PRIORITY_NOT_PROBABILITY"


@dataclass(frozen=True)
class SignalPriority:
    components: tuple      # ((name, ordinal), ...) in significance order
    sort_key: tuple        # ascending sort key: negated ordinals, then symbol, horizon, direction
    kind: str = PRIORITY_KIND

    @property
    def ordinals(self) -> tuple:
        return tuple(v for _, v in self.components)


def liquidity_tiers(specs) -> dict:
    known = sorted(s.quote_volume_24h for s in specs if s.quote_volume_24h is not None)
    tiers = {}
    if not known:
        return {s.symbol: 0 for s in specs}
    t1, t2 = known[len(known) // 3], known[(2 * len(known)) // 3]
    for s in specs:
        v = s.quote_volume_24h
        tiers[s.symbol] = 0 if v is None else int(v >= t1) + int(v >= t2)
    return tiers


def compute_priority(decision, symbol, direction, horizon, age_bars, staleness_bars, liquidity_tier, decision_policy) -> SignalPriority:
    quality = decision.selected_candidate.quality
    named = list(explain_rank_key(quality, decision_policy.scoring))
    ranks = rank_key(quality, decision_policy.scoring)
    comps = [(name, r) for (name, _), r in zip(named, ranks)]
    comps.append(("risk_verdict", 2 if decision.risk_result.decision == RiskDecision.VALID else 1))
    comps.append(("data_freshness", 2 if age_bars <= 1.0 else (1 if age_bars <= staleness_bars else 0)))
    comps.append(("liquidity_tier", liquidity_tier))
    key = (tuple(-v for _, v in comps), symbol, horizon, direction)
    return SignalPriority(components=tuple(comps), sort_key=key)
