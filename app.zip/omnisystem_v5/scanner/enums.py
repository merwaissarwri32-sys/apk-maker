"""Scanner enumerations - MERWIS AI, Phase 10.

Lifecycle states here describe PROCESSING state only. Analytical validity
(is this trade acceptable?) lives exclusively in decision.contracts.FinalDecision
and risk.result.RiskAssessmentResult - the scanner never keeps a parallel
notion of "valid".
"""
from enum import Enum


class SignalState(str, Enum):
    DETECTED = "DETECTED"      # survived Decision + Risk gate this cycle; not yet through dedup/cooldown
    EMITTED = "EMITTED"        # released to the downstream dispatcher (NOT a statement about trade validity)
    SUPPRESSED = "SUPPRESSED"  # terminal: duplicate / cooldown / cap-deferred
    EXPIRED = "EXPIRED"        # terminal: an EMITTED signal no longer being tracked


class DedupVerdict(str, Enum):
    NEW = "NEW"
    MATERIAL_CHANGE = "MATERIAL_CHANGE"   # same family, materially different setup -> re-emit
    DUPLICATE = "DUPLICATE"               # same setup still active
    COOLDOWN = "COOLDOWN"                 # same setup re-appeared inside cooldown after expiry
    DEFERRED_CAP = "DEFERRED_CAP"         # would have been emitted, but max_signals_per_cycle reached

    @property
    def emits(self) -> bool:
        return self in (DedupVerdict.NEW, DedupVerdict.MATERIAL_CHANGE)


class SymbolScanStatus(str, Enum):
    EVALUATED = "EVALUATED"                    # at least one horizon ran on gated data
    REJECTED = "REJECTED"                      # no horizon could run (fail closed) - see failure class
    SKIPPED_BUDGET = "SKIPPED_BUDGET"          # beyond max_symbols_per_cycle; scanned in a later cycle
    SKIPPED_QUARANTINE = "SKIPPED_QUARANTINE"  # repeatedly failing symbol, in back-off
    SKIPPED_RATE_LIMIT = "SKIPPED_RATE_LIMIT"  # cycle aborted after a provider rate limit


class CycleHealth(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    SYSTEMIC_FAILURE = "SYSTEMIC_FAILURE"
    NO_WORK = "NO_WORK"                        # nothing was attempted (empty universe, all quarantined...)


class TradingStatus(str, Enum):
    TRADING = "TRADING"
    HALTED = "HALTED"
    DELISTED = "DELISTED"


class MarketType(str, Enum):
    SPOT = "SPOT"
    PERPETUAL = "PERPETUAL"
    EQUITY = "EQUITY"
    FX = "FX"
    OTHER = "OTHER"
