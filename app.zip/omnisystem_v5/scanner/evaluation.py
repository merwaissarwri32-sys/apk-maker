"""Evaluation composition - MERWIS AI, Phase 10.

ORCHESTRATION ONLY. Composes existing PUBLIC APIs, in the same order the frozen
replay uses, and adds no strategy, indicator, structure or risk logic:

  MarketContext -> QuantContext -> Bull/Bear -> Scalp/Intraday/Short-Swing
  -> decision_bridge -> per-symbol decide() (Risk Engine hard gate inside)

`now` is passed explicitly to decide(); engine-internal wall-clock stamps are
metadata (verified: none of them reaches a comparison or a branch) and are never
used for identity by the scanner.
Event-risk context is not supplied (no event feed exists before Phase 11+): the
engines then report EVENT_DATA_UNAVAILABLE exactly as they do in replay.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from omnisystem_v5.context.builder import build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.decision.engine import decide
from omnisystem_v5.decision.enums import DecisionOutcome
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.decision_bridge import (
    from_intraday_candidate, from_scalp_candidate, from_short_swing_candidate)
from omnisystem_v5.intelligence.enums import Horizon
from omnisystem_v5.intelligence.intraday_engine import detect_intraday_candidate
from omnisystem_v5.intelligence.scalp_engine import detect_scalp_candidate
from omnisystem_v5.intelligence.short_swing_engine import detect_short_swing_candidate
from omnisystem_v5.quant.engine import build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.validation.resampling import seconds_for_timeframe


@dataclass(frozen=True)
class DiscoveredCandidate:
    """A horizon engine's own candidate + its decision-layer projection. ATR is the
    execution timeframe's MarketContext ATR (None if that context has none)."""
    horizon: Horizon
    raw: object
    normalized: object
    execution_timeframe: object
    atr: float | None


@dataclass(frozen=True)
class HorizonNote:
    horizon: Horizon
    code: str
    detail: str


@dataclass(frozen=True)
class SymbolEvaluation:
    symbol: str
    discovered: tuple = field(default_factory=tuple)
    notes: tuple = field(default_factory=tuple)
    decision: object = None                       # FinalDecision | None (None = nothing to decide)
    age_bars: tuple = field(default_factory=tuple)  # ((Timeframe, age in bars of that timeframe), ...)

    @property
    def winner(self):
        d = self.decision
        if d is None or d.outcome == DecisionOutcome.NO_TRADE:
            return None
        return next((c for c in self.discovered if c.normalized.candidate_id == d.selected_candidate.candidate_id), None)


def evaluate_symbol(symbol, envelopes, runnable, config, account, now) -> SymbolEvaluation:
    cache = {}

    def ctx(tf):
        if tf not in cache:
            m = build_market_context(symbol, envelopes[tf], config.market_context_config)
            q = build_quant_context(symbol, m, config.quant_engine_config) if m.status == ContextStatus.OK else None
            cache[tf] = (m, q)
        return cache[tf]

    def usable(tf):
        m, q = ctx(tf)
        return m.status == ContextStatus.OK and q is not None and q.status == QuantStatus.OK

    def atr_of(tf):
        m, _ = ctx(tf)
        return m.volatility.atr if m.volatility is not None else None

    discovered, notes = [], []

    def note_status(h, tfs):
        bad = [f"{tf.value}: market={ctx(tf)[0].status.value}, quant={ctx(tf)[1].status.value if ctx(tf)[1] else 'n/a'}"
               for tf in tfs if not usable(tf)]
        notes.append(HorizonNote(h, "NO_TRADE_INSUFFICIENT_DATA", "; ".join(bad)))

    def note_result(h, result):
        reasons = ",".join(getattr(r, "value", str(r)) for r in result.rejection_reasons) or result.status.value
        notes.append(HorizonNote(h, reasons, " | ".join(result.notes)))

    for h in runnable:
        if h == Horizon.SCALP:
            tf = config.scalp_timeframe
            if not usable(tf):
                note_status(h, (tf,)); continue
            m, q = ctx(tf)
            bull, bear = build_bull_case(symbol, m, q), build_bear_case(symbol, m, q)
            result = detect_scalp_candidate(symbol, m, q, bull, bear, config.scalp_engine_config)
            bridge, exec_tf = from_scalp_candidate, tf
        else:
            eng, detect, bridge = ((config.intraday_engine_config, detect_intraday_candidate, from_intraday_candidate)
                                   if h == Horizon.INTRADAY else
                                   (config.short_swing_engine_config, detect_short_swing_candidate, from_short_swing_candidate))
            exec_tf, higher_tf = eng.execution_timeframe, eng.higher_timeframe
            if not (usable(exec_tf) and usable(higher_tf)):
                note_status(h, (exec_tf, higher_tf)); continue
            mtf = MultiTimeframeMarketContext(symbol=symbol, calculated_at=now,
                                              contexts={exec_tf: ctx(exec_tf)[0], higher_tf: ctx(higher_tf)[0]})
            result = detect(symbol, mtf, {exec_tf: ctx(exec_tf)[1], higher_tf: ctx(higher_tf)[1]}, eng)
        if result.status.value != "ZONE_IDENTIFIED":
            note_result(h, result); continue
        for raw in result.candidates:
            discovered.append(DiscoveredCandidate(h, raw, bridge(raw), exec_tf, atr_of(exec_tf)))

    decision = None
    if discovered:
        decision = decide([c.normalized for c in discovered], account, config.risk_policy,
                          config.decision_policy, now=now)

    ages = tuple((tf, (now - envelopes[tf].bars[-1].close_time).total_seconds() / seconds_for_timeframe(tf))
                 for tf in sorted(envelopes, key=seconds_for_timeframe))
    return SymbolEvaluation(symbol=symbol, discovered=tuple(discovered), notes=tuple(notes),
                            decision=decision, age_bars=ages)
