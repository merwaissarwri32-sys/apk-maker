"""Executor boundary - MERWIS AI, Phase 10. The default is sequential and deterministic.
A future concurrent executor must return results IN INPUT ORDER; the domain never
depends on completion order. `stop_when` lets the engine stop issuing work after a
provider rate limit; an executor may only return fewer results than items if it fired."""
from __future__ import annotations

from typing import Callable, Protocol, Sequence


class Executor(Protocol):
    def map(self, fn: Callable, items: Sequence, stop_when: Callable | None = None) -> list: ...


class SequentialExecutor:
    def map(self, fn, items, stop_when=None) -> list:
        out = []
        for item in items:
            result = fn(item)
            out.append(result)
            if stop_when is not None and stop_when(result):
                break
        return out
