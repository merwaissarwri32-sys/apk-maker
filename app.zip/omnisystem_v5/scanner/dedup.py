"""Deduplication / cooldown / expiry - MERWIS AI, Phase 10.

Pure functions over an immutable DedupState; no globals, no clock reads.
A signal FAMILY is (symbol, direction, horizon, source engine); at most one
signal per family is active at a time.

Boundary semantics (all strict, all tested):
  * expiry:   an active signal expires when  now - last_seen_at  >  expiry
  * cooldown: the same setup is suppressed while  now - emitted_at  <  cooldown
  * a MATERIALLY different setup in the same family bypasses cooldown (re-emits)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.scanner.enums import DedupVerdict, SignalState
from omnisystem_v5.scanner.identity import FingerprintPolicy, same_setup
from omnisystem_v5.scanner.signals import ScanSignal, transition
from dataclasses import replace


@dataclass(frozen=True)
class DedupPolicy:
    cooldown_seconds: float = 900.0
    expiry_seconds: float = 300.0

    def __post_init__(self):
        if self.cooldown_seconds < 0 or self.expiry_seconds <= 0:
            raise ValueError("cooldown_seconds must be >= 0 and expiry_seconds > 0")


def _order(signals) -> tuple:
    return tuple(sorted(signals, key=lambda s: (*s.family, s.fingerprint)))


@dataclass(frozen=True)
class DedupState:
    active: tuple = field(default_factory=tuple)    # EMITTED signals currently tracked
    recent: tuple = field(default_factory=tuple)    # EXPIRED signals still inside their cooldown window


def expire(state: DedupState, now: datetime, policy: DedupPolicy,
           effective_expiry_seconds: float | None = None) -> tuple:
    """Returns (new_state, newly_expired_signals)."""
    limit = effective_expiry_seconds if effective_expiry_seconds is not None else policy.expiry_seconds
    still, expired = [], []
    for s in state.active:
        if (now - s.last_seen_at).total_seconds() > limit:
            expired.append(transition(s, SignalState.EXPIRED, reason="not re-detected within expiry window"))
        else:
            still.append(s)
    recent = [s for s in (*state.recent, *expired) if (now - s.emitted_at).total_seconds() < policy.cooldown_seconds]
    return DedupState(active=_order(still), recent=_order(recent)), tuple(_order(expired))


def observe(state: DedupState, detected: ScanSignal, now: datetime, dedup: DedupPolicy,
            fp: FingerprintPolicy) -> tuple:
    """Returns (new_state, resulting_signal, superseded_signal_or_None).
    `detected` must be in state DETECTED."""
    family = detected.family
    active = next((s for s in state.active if s.family == family), None)
    recents = [s for s in state.recent if s.family == family]

    if active is not None:
        if same_setup(active.descriptor, detected.descriptor, fp):
            touched = replace(active, last_seen_at=now, seen_count=active.seen_count + 1)
            others = [s for s in state.active if s is not active]
            suppressed = transition(detected, SignalState.SUPPRESSED, verdict=DedupVerdict.DUPLICATE,
                                    reason="same setup still active", first_seen_at=active.first_seen_at,
                                    seen_count=touched.seen_count, emitted_at=None)
            return DedupState(_order([*others, touched]), state.recent), suppressed, None
        superseded = transition(active, SignalState.EXPIRED, reason="superseded by a materially different setup")
        emitted = _emit(detected, now, DedupVerdict.MATERIAL_CHANGE, "materially different from the active setup")
        others = [s for s in state.active if s is not active]
        return (DedupState(_order([*others, emitted]), _order([*state.recent, superseded])), emitted, superseded)

    if any(same_setup(r.descriptor, detected.descriptor, fp) for r in recents):
        suppressed = transition(detected, SignalState.SUPPRESSED, verdict=DedupVerdict.COOLDOWN,
                                reason="same setup re-appeared inside cooldown")
        return state, suppressed, None

    verdict = DedupVerdict.MATERIAL_CHANGE if recents else DedupVerdict.NEW
    reason = "materially different from a setup still in cooldown" if recents else "first detection"
    emitted = _emit(detected, now, verdict, reason)
    return DedupState(_order([*state.active, emitted]), state.recent), emitted, None


def _emit(detected: ScanSignal, now: datetime, verdict: DedupVerdict, reason: str) -> ScanSignal:
    return transition(detected, SignalState.EMITTED, emitted_at=now, verdict=verdict, reason=reason)
