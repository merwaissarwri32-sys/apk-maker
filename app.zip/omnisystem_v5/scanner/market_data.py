"""Market-data boundary - MERWIS AI, Phase 10.

The scanner consumes MarketDataEnvelope through a tiny structural protocol
(DataIngestionService already satisfies it). Every envelope is RE-GATED here,
because a source may bypass data.quality_gate:

  1. shape: right type, right market, right timeframe          -> MALFORMED_RESPONSE
  2. quality_status must be OK (mapped per status)
  3. origin must be LIVE/HISTORICAL (SIMULATED refused)         -> UNUSABLE_ORIGIN
  4. enough bars for the Market/Quant contexts                  -> INSUFFICIENT_DATA
  5. bar sequence re-validated with data.validation             -> INVALID_DATA
  6. freshness + incomplete/future bar vs the INJECTED clock    -> STALE_DATA / INVALID_DATA

NOTE on staleness: data.quality_gate measures freshness against the wall clock
(DataProvenance.freshness_seconds) with a single 300 s limit, which would mark every
4h/1d series STALE. The scanner therefore expects its source to be built with
scanner_quality_config() (wall-clock staleness disabled) and applies its own
per-timeframe, injected-clock freshness in step 6.
"""
from __future__ import annotations

from typing import Protocol

from omnisystem_v5.data.quality_gate import QualityGateConfig
from omnisystem_v5.data.validation import validate_bar_sequence
from omnisystem_v5.scanner.failures import RETRYABLE, FailureClass, classify_fetch_exception
from omnisystem_v5.scanner.timeframes import check_envelope_time
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import MarketDataEnvelope

_STATUS_TO_CLASS = {
    QualityStatus.STALE: FailureClass.STALE_DATA,
    QualityStatus.INSUFFICIENT_DATA: FailureClass.INSUFFICIENT_DATA,
    QualityStatus.INVALID: FailureClass.INVALID_DATA,
    QualityStatus.DATA_UNAVAILABLE: FailureClass.PROVIDER_UNAVAILABLE,
    QualityStatus.ERROR: FailureClass.PROVIDER_UNAVAILABLE,
}


class MarketDataSource(Protocol):
    def get_market_data(self, market: str, timeframe: Timeframe, limit: int = 200) -> MarketDataEnvelope: ...


def scanner_quality_config(min_bars_required: int = 20) -> QualityGateConfig:
    return QualityGateConfig(max_staleness_seconds=float("inf"), min_bars_required=min_bars_required)


def gate_envelope(envelope, symbol: str, timeframe: Timeframe, now, min_bars: int, staleness_bars: float):
    """Returns None if usable, else (FailureClass, detail)."""
    if not isinstance(envelope, MarketDataEnvelope):
        return FailureClass.MALFORMED_RESPONSE, f"source returned {type(envelope).__name__}, not a MarketDataEnvelope"
    if envelope.timeframe != timeframe or envelope.market != symbol:
        return FailureClass.MALFORMED_RESPONSE, (
            f"asked for {symbol} {timeframe.value}, got {envelope.market} {envelope.timeframe.value}")
    if envelope.quality_status != QualityStatus.OK:
        detail = "; ".join(envelope.reasons) or f"quality_status={envelope.quality_status.value}"
        return _STATUS_TO_CLASS[envelope.quality_status], detail
    if envelope.provenance.origin not in (DataOrigin.LIVE, DataOrigin.HISTORICAL):
        return FailureClass.UNUSABLE_ORIGIN, f"origin {envelope.provenance.origin.value} is not usable for scanning"
    if len(envelope.bars) < min_bars:
        return FailureClass.INSUFFICIENT_DATA, f"{len(envelope.bars)} bars, {min_bars} required"
    seq = validate_bar_sequence(list(envelope.bars), timeframe)
    if not seq.ok:
        return FailureClass.INVALID_DATA, "; ".join(seq.issues[:3])
    return check_envelope_time(envelope, now, staleness_bars)


def fetch_timeframe(source, symbol, timeframe, limit, now, min_bars, staleness_bars, max_attempts):
    """Returns (envelope_or_None, failure_or_None) where failure = (FailureClass, detail).
    Only TIMEOUT is retried (bounded by max_attempts); rate limits are never retried in-cycle."""
    last = None
    for _ in range(max(1, max_attempts)):
        try:
            envelope = source.get_market_data(symbol, timeframe, limit)
        except Exception as exc:  # classified, never swallowed: the class + message are reported
            cls = classify_fetch_exception(exc)
            last = (cls, f"{type(exc).__name__}: {exc}")
            if cls in RETRYABLE:
                continue
            return None, last
        problem = gate_envelope(envelope, symbol, timeframe, now, min_bars, staleness_bars)
        return (None, problem) if problem else (envelope, None)
    return None, last
