"""Observability boundary - MERWIS AI, Phase 10. The domain emits typed events
to a sink; it contains no logging code. A failing sink can never break a scan."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Protocol


class EventKind(str, Enum):
    SCAN_STARTED = "SCAN_STARTED"
    SYMBOL_EVALUATED = "SYMBOL_EVALUATED"
    SYMBOL_REJECTED = "SYMBOL_REJECTED"
    SYMBOL_SKIPPED = "SYMBOL_SKIPPED"
    CANDIDATE_DISCOVERED = "CANDIDATE_DISCOVERED"
    SIGNAL_EMITTED = "SIGNAL_EMITTED"
    SIGNAL_SUPPRESSED = "SIGNAL_SUPPRESSED"
    SIGNAL_EXPIRED = "SIGNAL_EXPIRED"
    HEALTH_ASSESSED = "HEALTH_ASSESSED"
    SCAN_COMPLETED = "SCAN_COMPLETED"


@dataclass(frozen=True)
class TelemetryEvent:
    kind: EventKind
    at: datetime
    symbol: str | None = None
    detail: tuple = field(default_factory=tuple)   # ((key, value), ...)


class TelemetrySink(Protocol):
    def emit(self, event: TelemetryEvent) -> None: ...


class NullSink:
    def emit(self, event: TelemetryEvent) -> None:
        return None


class InMemorySink:
    def __init__(self):
        self.events: list[TelemetryEvent] = []

    def emit(self, event: TelemetryEvent) -> None:
        self.events.append(event)

    def of_kind(self, kind: EventKind) -> list:
        return [e for e in self.events if e.kind == kind]
