"""Thin, injectable run loop. No sleeping happens unless the caller supplies a real
`sleep`; tests drive it with a ManualClock and a fake sleep."""
from __future__ import annotations

from omnisystem_v5.scanner.scheduler import is_due, next_due_at
from omnisystem_v5.scanner.state import ScanState


class ScannerRunner:
    def __init__(self, engine, clock, schedule, sleep, account_provider, poll_seconds: float = 1.0):
        self._engine, self._clock, self._schedule = engine, clock, schedule
        self._sleep, self._account, self._poll = sleep, account_provider, poll_seconds

    def tick(self, state: ScanState):
        """Runs a cycle iff due. Returns (state, report_or_None)."""
        now = self._clock.now()
        if not is_due(now, state.last_cycle_started_at, state.last_health, state.consecutive_systemic, self._schedule):
            return state, None
        result = self._engine.run_cycle(state, self._account())
        return result.state, result.report

    def run(self, state: ScanState, should_stop, on_report=None) -> ScanState:
        while not should_stop():
            state, report = self.tick(state)
            if report is not None and on_report is not None:
                on_report(report)
            if should_stop():
                break
            now = self._clock.now()
            due = next_due_at(state.last_cycle_started_at, state.last_health, state.consecutive_systemic, now, self._schedule)
            self._sleep(max(0.0, min(self._poll, (due - now).total_seconds())) or self._poll)
        return state
