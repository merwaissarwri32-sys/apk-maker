"""HOW to scan - MERWIS AI, Phase 10. run_cycle(state, account) -> CycleResult(report, new_state).

The engine is a pure-ish orchestrator: all time comes from the injected Clock, all
carried state is the immutable ScanState the caller passes in/out, and all output is
data. It NEVER places or routes an order: the only products are ScanSignals whose
authoritative content is a FinalDecision produced by the existing Decision Engine
(with the Risk Engine hard gate). No network call exists in this package; the
MarketDataSource supplied by the caller is the only I/O boundary.
"""
from __future__ import annotations

import math
import time
from dataclasses import replace

from omnisystem_v5.decision.enums import DecisionOutcome
from omnisystem_v5.scanner import dedup as dedup_mod
from omnisystem_v5.scanner.enums import CycleHealth, DedupVerdict, SignalState, SymbolScanStatus
from omnisystem_v5.scanner.evaluation import evaluate_symbol
from omnisystem_v5.scanner.executor import SequentialExecutor
from omnisystem_v5.scanner.failures import FailureClass
from omnisystem_v5.scanner.health import assess_health
from omnisystem_v5.scanner.identity import build_descriptor
from omnisystem_v5.scanner.market_data import fetch_timeframe
from omnisystem_v5.scanner.priority import compute_priority, liquidity_tiers
from omnisystem_v5.scanner.report import CycleResult, CycleTimings, ScanReport, SymbolScanResult
from omnisystem_v5.scanner.signals import detect_signal, transition
from omnisystem_v5.scanner.state import ScanState
from omnisystem_v5.scanner.telemetry import EventKind, NullSink, TelemetryEvent
from omnisystem_v5.scanner.timeframes import horizon_timeframes, plan_horizons, required_timeframes
from omnisystem_v5.scanner.universe import resolve_universe


class ScanEngine:
    def __init__(self, source, universe, config, clock, sink=None, executor=None, timer=None, evaluator=None,
                 batch_size: int = 25):
        if batch_size < 1:
            raise ValueError("batch_size must be >= 1")
        self._source, self._universe, self._cfg, self._clock = source, universe, config, clock
        self._sink = sink or NullSink()
        self._executor = executor or SequentialExecutor()
        self._timer = timer or time.perf_counter
        self._evaluate = evaluator or evaluate_symbol
        self._batch = batch_size
        self._telemetry_errors = 0

    # ---- telemetry (a broken sink must never break a scan) ----
    def _emit(self, kind, now, symbol=None, **detail):
        try:
            self._sink.emit(TelemetryEvent(kind, now, symbol, tuple(sorted(detail.items()))))
        except Exception:
            self._telemetry_errors += 1

    # ---- one symbol: fetch -> gate -> plan -> evaluate. Never raises. ----
    def _scan_symbol(self, spec, account, now):
        t0 = self._timer()
        cfg, symbol = self._cfg, spec.symbol
        try:
            oks, fails, rate_limited = {}, {}, False
            for tf in required_timeframes(cfg):
                if rate_limited:
                    fails[tf] = (FailureClass.PROVIDER_RATE_LIMITED, "skipped after rate limit on this symbol")
                    continue
                env, problem = fetch_timeframe(self._source, symbol, tf, cfg.fetch_limit, now, cfg.min_bars,
                                               cfg.staleness_bars, cfg.max_fetch_attempts)
                if problem is None:
                    oks[tf] = env
                else:
                    fails[tf] = problem
                    rate_limited = problem[0] == FailureClass.PROVIDER_RATE_LIMITED
            plan = plan_horizons(cfg, oks, fails)
            if not plan.runnable:
                first = plan.blocked[0]
                notes = tuple(f"{b.horizon.value}:{b.failure_class.value}:{b.detail}" for b in plan.blocked)
                res = SymbolScanResult(symbol, SymbolScanStatus.REJECTED, first.failure_class, first.detail, notes=notes)
                return res, self._timer() - t0
            ev = self._evaluate(symbol, oks, plan.runnable, cfg, account, now)
            notes = tuple(f"{b.horizon.value}:{b.failure_class.value}:{b.detail}" for b in plan.blocked) + \
                    tuple(f"{n.horizon.value}:{n.code}:{n.detail}" for n in ev.notes)
            d = ev.decision
            trace = tuple((r.source_engine, r.direction.value, r.status.value, *r.reasons)
                          for r in (d.candidate_trace if d else ()))
            res = SymbolScanResult(
                symbol, SymbolScanStatus.EVALUATED, horizons_run=tuple(h.value for h in plan.runnable), notes=notes,
                candidates_discovered=len(ev.discovered),
                decision_outcome=d.outcome.value if d else "NO_CANDIDATE",
                decision_reason=d.reason_code.value if d else None, candidate_trace=trace, evaluation=ev)
            return res, self._timer() - t0
        except Exception as exc:   # evaluation bug: classified INTERNAL_ERROR and surfaced, never hidden
            return (SymbolScanResult(symbol, SymbolScanStatus.REJECTED, FailureClass.INTERNAL_ERROR,
                                     f"{type(exc).__name__}: {exc}"), self._timer() - t0)

    def run_cycle(self, state: ScanState, account) -> CycleResult:
        cfg, t_start = self._cfg, self._timer()
        now = self._clock.now()
        self._telemetry_errors = 0
        self._emit(EventKind.SCAN_STARTED, now)

        # -- WHAT: universe (a failing universe source is a cycle-level failure, reported) --
        try:
            resolved = resolve_universe(self._universe.symbols(now), cfg.universe_filter)
        except Exception as exc:
            return self._finish_failed_universe(state, now, t_start, exc)
        specs = resolved.specs
        tiers = liquidity_tiers(specs)

        # -- expiry first (time-based; rotation-aware) --
        quarantined = [s for s in specs if state.ledger.is_quarantined(s.symbol, now)]
        quarantined_symbols = {s.symbol for s in quarantined}
        eligible = [s for s in specs if s.symbol not in quarantined_symbols]
        per_cycle = cfg.max_symbols_per_cycle
        rotation = math.ceil(len(eligible) / per_cycle) if (per_cycle and eligible) else 1
        eff_expiry = cfg.dedup.expiry_seconds + (rotation - 1) * cfg.schedule.interval_seconds
        dstate, expired = dedup_mod.expire(state.dedup, now, cfg.dedup, eff_expiry)

        # -- rotation: symbol-based cursor, wraps, robust to universe changes --
        start = next((i for i, s in enumerate(eligible) if state.resume_after is None or s.symbol > state.resume_after), 0)
        rotated = eligible[start:] + eligible[:start]
        to_scan = rotated[:per_cycle] if per_cycle else rotated
        budget_skipped = rotated[len(to_scan):]

        # -- HOW: batches through the executor; a rate limit stops further work --
        outcomes, rate_limited, timings = [], False, []
        for i in range(0, len(to_scan), self._batch):
            batch = to_scan[i:i + self._batch]
            got = self._executor.map(lambda sp: self._scan_symbol(sp, account, now), batch,
                                     stop_when=lambda r: r[0].failure_class == FailureClass.PROVIDER_RATE_LIMITED)
            outcomes.extend(got)
            if any(r.failure_class == FailureClass.PROVIDER_RATE_LIMITED for r, _ in got):
                rate_limited = True
                break
        scanned = [r for r, _ in outcomes]
        timings = tuple((r.symbol, round(sec, 6)) for r, sec in outcomes)
        aborted = to_scan[len(outcomes):]
        results = list(scanned)
        results += [SymbolScanResult(s.symbol, SymbolScanStatus.SKIPPED_RATE_LIMIT) for s in aborted]
        results += [SymbolScanResult(s.symbol, SymbolScanStatus.SKIPPED_BUDGET) for s in budget_skipped]
        results += [SymbolScanResult(s.symbol, SymbolScanStatus.SKIPPED_QUARANTINE) for s in quarantined]
        results.sort(key=lambda r: r.symbol)
        for r in results:
            kind = {SymbolScanStatus.EVALUATED: EventKind.SYMBOL_EVALUATED,
                    SymbolScanStatus.REJECTED: EventKind.SYMBOL_REJECTED}.get(r.status, EventKind.SYMBOL_SKIPPED)
            self._emit(kind, now, r.symbol, status=r.status.value,
                       failure=r.failure_class.value if r.failure_class else "", discovered=r.candidates_discovered)

        # -- health + failure ledger --
        health, reasons = assess_health(results, rate_limited, cfg.health)
        self._emit(EventKind.HEALTH_ASSESSED, now, health=health.value)
        ledger = state.ledger.update(results, health, now, cfg.health)
        consecutive = state.consecutive_systemic + 1 if health == CycleHealth.SYSTEMIC_FAILURE else 0

        # -- candidates -> priority -> dedup/cooldown -> cap (one winner per symbol, from Decision) --
        detected = []
        spec_by_symbol = {s.symbol: s for s in specs}
        for r in scanned:
            ev = r.evaluation
            if ev is None:
                continue
            for _ in ev.discovered:
                self._emit(EventKind.CANDIDATE_DISCOVERED, now, r.symbol)
            win = ev.winner
            if win is None:
                continue
            desc = build_descriptor(win.raw, win.normalized, win.atr, cfg.fingerprint)
            age = dict(ev.age_bars)[win.execution_timeframe]
            prio = compute_priority(ev.decision, r.symbol, desc.direction, desc.horizon, age, cfg.staleness_bars,
                                    tiers.get(r.symbol, 0), cfg.decision_policy)
            detected.append(detect_signal(desc, ev.decision, now, prio))
        detected.sort(key=lambda s: s.priority.sort_key)

        emitted, suppressed = [], []
        for sig in detected:
            if cfg.max_signals_per_cycle is not None and len(emitted) >= cfg.max_signals_per_cycle:
                probe_state, probe, _ = dedup_mod.observe(dstate, sig, now, cfg.dedup, cfg.fingerprint)
                if probe.verdict is not None and probe.verdict.emits:
                    suppressed.append(transition(sig, SignalState.SUPPRESSED, verdict=DedupVerdict.DEFERRED_CAP,
                                                 reason="max_signals_per_cycle reached; not tracked, may emit next cycle"))
                    continue            # state untouched: deferral must not consume the setup
                dstate = probe_state    # duplicate/cooldown verdicts never consume the cap
                suppressed.append(probe)
                continue
            dstate, out, superseded = dedup_mod.observe(dstate, sig, now, cfg.dedup, cfg.fingerprint)
            if superseded is not None:
                expired = expired + (superseded,)
            (emitted if out.state == SignalState.EMITTED else suppressed).append(out)
        for s in emitted:
            self._emit(EventKind.SIGNAL_EMITTED, now, s.descriptor.symbol, verdict=s.verdict.value, fingerprint=s.fingerprint)
        for s in suppressed:
            self._emit(EventKind.SIGNAL_SUPPRESSED, now, s.descriptor.symbol, verdict=s.verdict.value)
        for s in expired:
            self._emit(EventKind.SIGNAL_EXPIRED, now, s.descriptor.symbol, reason=s.reason)

        last_scanned = scanned[-1].symbol if scanned else state.resume_after
        new_state = ScanState(dedup=dstate, ledger=ledger, resume_after=last_scanned, last_cycle_started_at=now,
                              last_health=health, consecutive_systemic=consecutive)
        total = self._timer() - t_start
        self._emit(EventKind.SCAN_COMPLETED, now, health=health.value, scanned=len(scanned), emitted=len(emitted))
        report = ScanReport(started_at=now, health=health, health_reasons=reasons, universe_size=len(specs),
                            excluded=resolved.excluded, results=tuple(results), emitted=tuple(emitted),
                            suppressed=tuple(suppressed), expired=tuple(expired), rate_limited=rate_limited,
                            telemetry_errors=self._telemetry_errors,
                            timings=CycleTimings(round(total, 6), timings))
        return CycleResult(report, new_state)

    def _finish_failed_universe(self, state, now, t_start, exc):
        reasons = (f"universe source failed: {type(exc).__name__}: {exc}",)
        dstate, expired = dedup_mod.expire(state.dedup, now, self._cfg.dedup)
        new_state = replace(state, dedup=dstate, last_cycle_started_at=now, last_health=CycleHealth.SYSTEMIC_FAILURE,
                            consecutive_systemic=state.consecutive_systemic + 1)
        self._emit(EventKind.HEALTH_ASSESSED, now, health=CycleHealth.SYSTEMIC_FAILURE.value)
        self._emit(EventKind.SCAN_COMPLETED, now, health=CycleHealth.SYSTEMIC_FAILURE.value, scanned=0, emitted=0)
        report = ScanReport(started_at=now, health=CycleHealth.SYSTEMIC_FAILURE, health_reasons=reasons, universe_size=0,
                            excluded=(), results=(), emitted=(), suppressed=(), expired=expired,
                            telemetry_errors=self._telemetry_errors,
                            timings=CycleTimings(round(self._timer() - t_start, 6)))
        return CycleResult(report, new_state)
