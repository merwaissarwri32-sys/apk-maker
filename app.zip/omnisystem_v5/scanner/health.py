"""Failure ledger + cycle health - MERWIS AI, Phase 10.

PRECISE SEMANTICS (all covered by tests)

attempted  = symbols actually scanned this cycle (EVALUATED or REJECTED).
             Quarantined, budget-skipped and rate-limit-aborted symbols are NOT
             attempted, so a universe full of known-bad symbols cannot trip health.
failed     = attempted symbols with status REJECTED (no horizon could run).
feed_failed= failed symbols whose primary failure class is FEED_LEVEL.

  attempted == 0                                   -> NO_WORK
  attempted <  min_sample                          -> never SYSTEMIC; DEGRADED if a rate limit,
                                                      an internal error, or every attempted symbol
                                                      failed at feed level; else HEALTHY
  attempted >= min_sample:
      feed_failed/attempted >= systemic_ratio  or  failed == attempted  -> SYSTEMIC_FAILURE
      failed/attempted >= degraded_ratio  or internal error or rate limit -> DEGRADED
      else HEALTHY

Health NEVER discards a symbol that passed every data gate: a SYSTEMIC cycle still
routes the surviving symbols' signals (they are individually fresh, synchronized and
validated). Health only (a) is reported, (b) freezes failure counters, (c) drives
scheduler back-off.

Failure counters (quarantine) only INCREMENT in HEALTHY cycles, i.e. when the failure
is demonstrably specific to that symbol. In DEGRADED/SYSTEMIC cycles failures are
attributed to the feed, not the symbol, so recovery never finds the whole universe
quarantined. A successful evaluation always resets the symbol's counter.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

from omnisystem_v5.scanner.enums import CycleHealth, SymbolScanStatus
from omnisystem_v5.scanner.failures import FEED_LEVEL, FailureClass


@dataclass(frozen=True)
class HealthPolicy:
    min_sample: int = 5
    systemic_ratio: float = 0.8
    degraded_ratio: float = 0.3
    quarantine_after: int = 3
    quarantine_seconds: float = 900.0

    def __post_init__(self):
        if self.min_sample < 1 or self.quarantine_after < 1 or self.quarantine_seconds < 0:
            raise ValueError("invalid HealthPolicy")
        if not (0 < self.degraded_ratio <= self.systemic_ratio <= 1):
            raise ValueError("require 0 < degraded_ratio <= systemic_ratio <= 1")


def assess_health(results, rate_limited: bool, policy: HealthPolicy) -> tuple:
    attempted = [r for r in results if r.status in (SymbolScanStatus.EVALUATED, SymbolScanStatus.REJECTED)]
    n = len(attempted)
    if n == 0:
        return CycleHealth.NO_WORK, ("no symbol was attempted this cycle",)
    failed = [r for r in attempted if r.status == SymbolScanStatus.REJECTED]
    feed_failed = [r for r in failed if r.failure_class in FEED_LEVEL]
    internal = [r for r in failed if r.failure_class == FailureClass.INTERNAL_ERROR]
    facts = f"attempted={n} failed={len(failed)} feed_failed={len(feed_failed)} internal_errors={len(internal)}"

    reasons = []
    if rate_limited:
        reasons.append("provider rate limit hit; remaining symbols deferred")
    if internal:
        reasons.append(f"{len(internal)} internal error(s)")

    if n < policy.min_sample:
        degraded = rate_limited or bool(internal) or (len(feed_failed) == n)
        if len(feed_failed) == n:
            reasons.append(f"every attempted symbol failed at feed level (sample {n} < min_sample {policy.min_sample}: not declared systemic)")
        return (CycleHealth.DEGRADED if degraded else CycleHealth.HEALTHY), (*reasons, facts)

    if len(feed_failed) / n >= policy.systemic_ratio or len(failed) == n:
        reasons.append("feed-level failure ratio at/above systemic threshold" if len(feed_failed) / n >= policy.systemic_ratio
                       else "no attempted symbol produced usable data")
        return CycleHealth.SYSTEMIC_FAILURE, (*reasons, facts)
    if len(failed) / n >= policy.degraded_ratio or internal or rate_limited:
        if len(failed) / n >= policy.degraded_ratio:
            reasons.append("failure ratio at/above degraded threshold")
        return CycleHealth.DEGRADED, (*reasons, facts)
    return CycleHealth.HEALTHY, (*reasons, facts)


@dataclass(frozen=True)
class LedgerEntry:
    consecutive_failures: int
    last_class: FailureClass
    quarantined_until: datetime | None = None


@dataclass(frozen=True)
class FailureLedger:
    entries: tuple = field(default_factory=tuple)   # ((symbol, LedgerEntry), ...) sorted by symbol

    def _map(self) -> dict:
        return dict(self.entries)

    def entry(self, symbol: str):
        return self._map().get(symbol)

    def is_quarantined(self, symbol: str, now: datetime) -> bool:
        e = self._map().get(symbol)
        return bool(e and e.quarantined_until is not None and now < e.quarantined_until)

    def update(self, results, health: CycleHealth, now: datetime, policy: HealthPolicy) -> "FailureLedger":
        m = self._map()
        for r in results:
            if r.status == SymbolScanStatus.EVALUATED:
                m.pop(r.symbol, None)
            elif r.status == SymbolScanStatus.REJECTED and health == CycleHealth.HEALTHY:
                prev = m.get(r.symbol)
                count = (prev.consecutive_failures if prev else 0) + 1
                until = now + timedelta(seconds=policy.quarantine_seconds) if count >= policy.quarantine_after else None
                m[r.symbol] = LedgerEntry(count, r.failure_class, until)
        return FailureLedger(entries=tuple(sorted(m.items())))
