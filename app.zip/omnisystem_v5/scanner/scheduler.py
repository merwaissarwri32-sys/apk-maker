"""WHEN to scan - MERWIS AI, Phase 10. Pure functions of (times, health); never sleeps."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

from omnisystem_v5.scanner.enums import CycleHealth


@dataclass(frozen=True)
class SchedulePolicy:
    interval_seconds: float = 60.0
    backoff_factor: float = 2.0          # applied per consecutive SYSTEMIC cycle
    max_backoff_seconds: float = 900.0

    def __post_init__(self):
        if self.interval_seconds <= 0 or self.backoff_factor < 1 or self.max_backoff_seconds < self.interval_seconds:
            raise ValueError("invalid SchedulePolicy")


def delay_after(health: CycleHealth | None, consecutive_systemic: int, policy: SchedulePolicy) -> float:
    if health == CycleHealth.SYSTEMIC_FAILURE:
        return min(policy.interval_seconds * policy.backoff_factor ** max(1, consecutive_systemic),
                   policy.max_backoff_seconds)
    return policy.interval_seconds


def next_due_at(last_started: datetime | None, health: CycleHealth | None, consecutive_systemic: int,
                now: datetime, policy: SchedulePolicy) -> datetime:
    if last_started is None:
        return now
    return last_started + timedelta(seconds=delay_after(health, consecutive_systemic, policy))


def is_due(now: datetime, last_started, health, consecutive_systemic, policy) -> bool:
    return now >= next_due_at(last_started, health, consecutive_systemic, now, policy)
