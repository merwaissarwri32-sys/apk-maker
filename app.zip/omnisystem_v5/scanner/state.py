"""Immutable scanner state carried between cycles by the caller (no globals)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.scanner.dedup import DedupState
from omnisystem_v5.scanner.enums import CycleHealth
from omnisystem_v5.scanner.health import FailureLedger


@dataclass(frozen=True)
class ScanState:
    dedup: DedupState = field(default_factory=DedupState)
    ledger: FailureLedger = field(default_factory=FailureLedger)
    resume_after: str | None = None            # symbol-based rotation cursor (robust to universe changes)
    last_cycle_started_at: datetime | None = None
    last_health: CycleHealth | None = None
    consecutive_systemic: int = 0
