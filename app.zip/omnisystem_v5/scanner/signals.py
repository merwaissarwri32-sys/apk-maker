"""ScanSignal + lifecycle - MERWIS AI, Phase 10.

ScanSignal is the ONE scanner-owned object: identity + processing state.
It carries the authoritative FinalDecision by reference (compare=False - the
decision embeds wall-clock-derived ids, Phase 9 F1) and never re-states
analytical validity. There are no Decision-ready / Execution-ready wrapper
types: an actionable FinalDecision (outcome != NO_TRADE, risk_result.is_actionable
- enforced by FinalDecision.__post_init__) IS the execution-ready concept.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime

from omnisystem_v5.scanner.enums import DedupVerdict, SignalState
from omnisystem_v5.scanner.identity import SetupDescriptor


class InvalidTransitionError(ValueError):
    pass


ALLOWED_TRANSITIONS = {
    SignalState.DETECTED: frozenset({SignalState.EMITTED, SignalState.SUPPRESSED}),
    SignalState.EMITTED: frozenset({SignalState.EXPIRED}),
    SignalState.SUPPRESSED: frozenset(),
    SignalState.EXPIRED: frozenset(),
}


@dataclass(frozen=True)
class ScanSignal:
    fingerprint: str
    descriptor: SetupDescriptor
    state: SignalState
    first_seen_at: datetime
    last_seen_at: datetime
    emitted_at: datetime | None = None
    seen_count: int = 1
    verdict: DedupVerdict | None = None
    reason: str = ""
    priority: object = None                                   # SignalPriority | None
    decision: object = field(default=None, compare=False, repr=False)   # FinalDecision (authoritative)

    def __post_init__(self):
        if self.state in (SignalState.EMITTED, SignalState.EXPIRED) and self.emitted_at is None:
            raise ValueError(f"state {self.state.value} requires emitted_at")
        if self.state == SignalState.SUPPRESSED and (self.verdict is None or self.verdict.emits):
            raise ValueError("a SUPPRESSED signal requires a non-emitting verdict")
        if self.state == SignalState.EMITTED and (self.verdict is None or not self.verdict.emits):
            raise ValueError("an EMITTED signal requires an emitting verdict")
        if self.state == SignalState.DETECTED and (self.emitted_at is not None or self.verdict is not None):
            raise ValueError("a DETECTED signal has no emission or verdict yet")

    @property
    def family(self) -> tuple:
        return self.descriptor.family


def detect_signal(descriptor: SetupDescriptor, decision, now: datetime, priority=None) -> ScanSignal:
    return ScanSignal(fingerprint=descriptor.fingerprint, descriptor=descriptor, state=SignalState.DETECTED,
                      first_seen_at=now, last_seen_at=now, priority=priority, decision=decision)


def transition(signal: ScanSignal, target: SignalState, **changes) -> ScanSignal:
    if target not in ALLOWED_TRANSITIONS[signal.state]:
        raise InvalidTransitionError(f"{signal.state.value} -> {target.value} is not allowed")
    return replace(signal, state=target, **changes)
