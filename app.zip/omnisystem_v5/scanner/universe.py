"""Market universe abstraction - MERWIS AI, Phase 10.

WHAT to scan. Provider-agnostic: a Universe yields SymbolSpec metadata;
resolve_universe() applies a UniverseFilter and returns a deterministically
ordered, de-duplicated result together with an auditable exclusion list.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable, Protocol

from omnisystem_v5.scanner.enums import MarketType, TradingStatus


class UniverseError(ValueError):
    pass


_SEPARATORS = re.compile(r"[/\-_:\s]+")
_VALID = re.compile(r"^[A-Z0-9.]+(/[A-Z0-9.]+)?$")


def normalize_symbol(raw: str) -> str:
    """Canonical internal form: upper-case, BASE/QUOTE when a separator was used
    (BTC-USDT, btc_usdt, 'BTC USDT' -> BTC/USDT); separator-free symbols
    (BTCUSDT, AAPL) are only upper-cased. Anything else fails closed."""
    if not isinstance(raw, str):
        raise UniverseError(f"symbol must be a string, got {type(raw).__name__}")
    text = raw.strip().upper()
    if _SEPARATORS.match(text) or _SEPARATORS.search(text[-1:] or "x"):
        raise UniverseError(f"invalid symbol {raw!r}")      # dangling separator: ambiguous, fail closed
    parts = _SEPARATORS.split(text)
    if not parts or len(parts) > 2:
        raise UniverseError(f"invalid symbol {raw!r}")
    canonical = "/".join(parts)
    if not _VALID.match(canonical):
        raise UniverseError(f"invalid symbol {raw!r}")
    return canonical


@dataclass(frozen=True)
class SymbolSpec:
    symbol: str
    market_type: MarketType = MarketType.SPOT
    quote_currency: str | None = None
    status: TradingStatus = TradingStatus.TRADING
    quote_volume_24h: float | None = None      # liquidity proxy, in quote currency; None = unknown
    metadata: tuple = field(default_factory=tuple)   # ((key, value), ...) - opaque to the core

    def __post_init__(self):
        canonical = normalize_symbol(self.symbol)
        object.__setattr__(self, "symbol", canonical)
        implied = canonical.split("/")[1] if "/" in canonical else None
        if self.quote_currency is None:
            object.__setattr__(self, "quote_currency", implied)
        else:
            q = self.quote_currency.strip().upper()
            if implied is not None and q != implied:
                raise UniverseError(f"quote_currency {q} contradicts symbol {canonical}")
            object.__setattr__(self, "quote_currency", q)
        v = self.quote_volume_24h
        if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0):
            raise UniverseError(f"quote_volume_24h must be a finite number >= 0, got {v!r}")


class Universe(Protocol):
    def symbols(self, now: datetime) -> Iterable[SymbolSpec]: ...


class StaticUniverse:
    def __init__(self, specs: Iterable[SymbolSpec]):
        self._specs = tuple(specs)

    def symbols(self, now: datetime) -> Iterable[SymbolSpec]:
        return self._specs


@dataclass(frozen=True)
class UniverseFilter:
    include: frozenset | None = None
    exclude: frozenset = frozenset()
    market_types: frozenset | None = None
    quote_currencies: frozenset | None = None
    min_quote_volume_24h: float | None = None
    require_trading: bool = True

    def __post_init__(self):
        if self.include is not None:
            object.__setattr__(self, "include", frozenset(normalize_symbol(s) for s in self.include))
        object.__setattr__(self, "exclude", frozenset(normalize_symbol(s) for s in self.exclude))
        if self.quote_currencies is not None:
            object.__setattr__(self, "quote_currencies", frozenset(q.strip().upper() for q in self.quote_currencies))


@dataclass(frozen=True)
class ResolvedUniverse:
    specs: tuple
    excluded: tuple = ()      # ((symbol, reason), ...) sorted by symbol


def resolve_universe(specs: Iterable[SymbolSpec], flt: UniverseFilter | None = None) -> ResolvedUniverse:
    flt = flt or UniverseFilter()
    unique: dict[str, SymbolSpec] = {}
    for spec in specs:
        if not isinstance(spec, SymbolSpec):
            raise UniverseError(f"universe yielded a non-SymbolSpec: {type(spec).__name__}")
        prior = unique.get(spec.symbol)
        if prior is None:
            unique[spec.symbol] = spec
        elif prior != spec:
            raise UniverseError(f"conflicting specs for {spec.symbol}")   # ambiguity is not resolved silently

    kept, excluded = [], []
    for symbol in sorted(unique):
        spec = unique[symbol]
        reason = _exclusion_reason(spec, flt)
        if reason:
            excluded.append((symbol, reason))
        else:
            kept.append(spec)
    return ResolvedUniverse(specs=tuple(kept), excluded=tuple(excluded))


def _exclusion_reason(spec: SymbolSpec, flt: UniverseFilter) -> str | None:
    if spec.symbol in flt.exclude:
        return "explicitly excluded"
    if flt.include is not None and spec.symbol not in flt.include:
        return "not in include list"
    if flt.require_trading and spec.status != TradingStatus.TRADING:
        return f"trading status {spec.status.value}"
    if flt.market_types is not None and spec.market_type not in flt.market_types:
        return f"market type {spec.market_type.value} not enabled"
    if flt.quote_currencies is not None and spec.quote_currency not in flt.quote_currencies:
        return f"quote currency {spec.quote_currency} not enabled"
    if flt.min_quote_volume_24h is not None:
        if spec.quote_volume_24h is None:
            return "liquidity unknown (fail closed)"
        if spec.quote_volume_24h < flt.min_quote_volume_24h:
            return "below minimum liquidity"
    return None
