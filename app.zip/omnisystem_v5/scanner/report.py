"""Cycle report - MERWIS AI, Phase 10.

Everything that participates in equality is DETERMINISTIC. Wall-clock-derived data
(FinalDecision ids, engine stamps) and latency are carried compare=False and are
excluded from canonical_dict(), which is the byte-stable projection used by the
determinism tests and by any downstream consumer that needs reproducibility.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.scanner.enums import CycleHealth, SymbolScanStatus
from omnisystem_v5.scanner.state import ScanState


@dataclass(frozen=True)
class SymbolScanResult:
    symbol: str
    status: SymbolScanStatus
    failure_class: object = None            # FailureClass | None
    failure_detail: str = ""
    horizons_run: tuple = field(default_factory=tuple)
    notes: tuple = field(default_factory=tuple)               # ("HORIZON:code:detail", ...)
    candidates_discovered: int = 0
    decision_outcome: str | None = None
    decision_reason: str | None = None
    candidate_trace: tuple = field(default_factory=tuple)      # ((source_engine, direction, status, reasons...), ...)
    evaluation: object = field(default=None, compare=False, repr=False)   # SymbolEvaluation (audit)


@dataclass(frozen=True)
class CycleTimings:
    total_seconds: float
    per_symbol_seconds: tuple = field(default_factory=tuple)   # ((symbol, seconds), ...)


def signal_canonical(s) -> dict:
    d, desc = s.decision, s.descriptor
    out = {
        "fingerprint": s.fingerprint, "state": s.state.value, "verdict": s.verdict.value if s.verdict else None,
        "reason": s.reason, "seen_count": s.seen_count,
        "symbol": desc.symbol, "direction": desc.direction, "horizon": desc.horizon,
        "engine": desc.source_engine, "timeframe": desc.timeframe, "scenario": desc.scenario,
        "basis": desc.basis, "entry_zone": list(desc.entry_zone), "invalidation_zone": list(desc.invalidation_zone),
        "targets": list(desc.targets),
        "priority": list(s.priority.ordinals) if s.priority else None,
        "first_seen_at": s.first_seen_at.isoformat(), "last_seen_at": s.last_seen_at.isoformat(),
        "emitted_at": s.emitted_at.isoformat() if s.emitted_at else None,
    }
    if d is not None and d.risk_result is not None:
        r = d.risk_result
        out["risk"] = {"decision": r.decision.value, "entry": r.entry, "stop_loss": r.stop_loss,
                       "take_profits": list(r.take_profits), "rr": r.primary_reward_risk_ratio,
                       "risk_amount": r.risk_amount, "position_size": r.position_size}
    return out


@dataclass(frozen=True)
class ScanReport:
    started_at: datetime
    health: CycleHealth
    health_reasons: tuple
    universe_size: int
    excluded: tuple
    results: tuple                       # tuple[SymbolScanResult], scan order
    emitted: tuple                       # ScanSignal(EMITTED), priority order
    suppressed: tuple                    # ScanSignal(SUPPRESSED)
    expired: tuple                       # ScanSignal(EXPIRED)
    rate_limited: bool = False
    telemetry_errors: int = field(default=0, compare=False)
    timings: CycleTimings | None = field(default=None, compare=False)

    def count(self, status: SymbolScanStatus) -> int:
        return sum(1 for r in self.results if r.status == status)

    def canonical_dict(self) -> dict:
        return {
            "started_at": self.started_at.isoformat(), "health": self.health.value,
            "health_reasons": list(self.health_reasons), "universe_size": self.universe_size,
            "excluded": [list(e) for e in self.excluded], "rate_limited": self.rate_limited,
            "results": [{
                "symbol": r.symbol, "status": r.status.value,
                "failure_class": r.failure_class.value if r.failure_class else None,
                "failure_detail": r.failure_detail, "horizons_run": list(r.horizons_run), "notes": list(r.notes),
                "candidates_discovered": r.candidates_discovered, "decision_outcome": r.decision_outcome,
                "decision_reason": r.decision_reason, "candidate_trace": [list(t) for t in r.candidate_trace],
            } for r in self.results],
            "emitted": [signal_canonical(s) for s in self.emitted],
            "suppressed": [signal_canonical(s) for s in self.suppressed],
            "expired": [signal_canonical(s) for s in self.expired],
        }

    def canonical_json(self) -> str:
        return json.dumps(self.canonical_dict(), sort_keys=True, separators=(",", ":"), default=str)


@dataclass(frozen=True)
class CycleResult:
    report: ScanReport
    state: ScanState
