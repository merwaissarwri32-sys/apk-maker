# MERWIS AI - Phase 7: Validation & Performance Evidence Layer - Final Report

Boundaries respected: no Execution Engine, no Auto Trading, no Broker/Exchange
integration, no live data provider, no order placement, no market-prediction
engine were built. Phase 8 was not started.

---

## 1. Final Architecture

```
Historical OHLCV bars (caller-provided, never fabricated)
                |
        validate_historical_dataset()   <- blocking data-quality gate
                |
        run_replay()  (Historical Replay Engine)
                |
   for each replay step idx (chronological, sliding window bars[lo:idx+1]):
                |
        build_market_context -> build_quant_context -> build_bull_case /
        build_bear_case -> detect_scalp_candidate -> decision_bridge ->
        decide()  [Risk Engine hard gate, unmodified from Phase 5]
                |
        (LONG/SHORT) -> find_entry_fill -> simulate_position_lifecycle
        -> TradeRecord (FINAL_EXIT / EXPIRED / INVALIDATED / REJECTED_BY_RISK)
                |
                v
        BacktestResult (dataset, data_quality, trades, reproducibility)
                |
        calculate_performance_metrics()  -> PerformanceMetrics
                |
        build_validation_report()  -> ValidationReport (A-J sections)
                |
        render_markdown() -> human-readable report
```

Independence/reuse guarantee: validation/ calls the exact Phase 2-6
production functions (build_market_context, build_quant_context,
build_bull_case, build_bear_case, detect_scalp_candidate,
from_scalp_candidate, decide) - no parallel or approximate decision
algorithm exists anywhere in this phase. The Risk Engine's hard gate
(is_actionable) was never bypassed; every LONG/SHORT TradeRecord came
from an actionable RiskAssessmentResult.

---

## 2. Root-Cause Bugs Found and Fixed This Phase

Building a genuine end-to-end replay (not just unit tests of individual
layers) surfaced two real, previously-undetected integration bugs:

1. Non-deterministic trade_id: originally derived from
   decision_id/candidate_id, which embed a wall-clock calculated_at
   timestamp set inside the Intelligence/Decision layers. Fixed by
   deriving trade_id purely from data-derived fields (symbol, direction,
   signal_time from bar data, entry zone, SL, TPs) in
   validation/replay_engine.py - never from another layer's
   wall-clock-tainted ID. No Phase 1-6 code was touched for this fix.

2. SL_WRONG_SIDE from entry-zone-midpoint bridging: risk_bridge.py and
   decision_bridge.py used the midpoint of a ScalpCandidate's
   preferred_entry_zone as "entry" for Risk Engine evaluation, but the
   engine's invalidation/target/R:R selection was computed relative to
   quant_context.current_price internally. When the entry zone sat on
   the far side of the invalidation level relative to current price,
   the bridge-computed entry ended up on the wrong side of the
   stop-loss, causing spurious rejections. Root-cause fix: added a
   current_price: float | None = None field (additive, backward
   compatible) to ScalpCandidate/IntradayCandidate/ShortSwingCandidate,
   populated by all three engines from the exact reference price they
   already use internally, and changed both bridges to prefer it via
   _resolve_entry_price() (falling back to the old midpoint only for
   legacy candidates without the field).

Both bugs have dedicated regression tests (TestRootCauseRegression in
test_phase7_replay_engine.py) that explicitly reconstruct the
originally-observed failure shape and assert it no longer occurs.

---

## 3. Contracts / Schemas Created

| Module | Contracts |
|---|---|
| validation/enums.py | TradeLifecycleState, ExitReason, DataQualityIssueType, ValidationPeriodType, SlippageModel |
| validation/contracts.py | ExecutionConfig, ReplayConfig, PeriodSplit, HistoricalDatasetDescriptor (+ deterministic content hash), DataQualityIssue/DataQualityReport, SimulatedFill, TradeRecord, ReproducibilityRecord, BacktestResult |
| validation/performance.py | EquityCurvePoint, DrawdownInfo, RMultipleStats, DirectionalBreakdown, GroupBreakdown, PerformanceMetrics |
| validation/report.py | SignalStatistics, RiskStatistics, FailureModeEntry, ValidationReport (A-J sections, to_dict()) |
| validation/walk_forward.py | WalkForwardConfig, PeriodSplit reuse, WalkForwardEngine (abstract) |
| validation/monte_carlo.py | MonteCarloMethod, MonteCarloConfig, MonteCarloResult, MonteCarloSampler (abstract) |

Additive-only changes to prior phases: current_price field on the three
Intelligence candidate schemas (Section 2, item 2).

---

## 4. Historical Replay Engine - Guarantees

- No look-ahead: at step idx, only bars[lo:idx+1] is ever passed into
  context/quant/intelligence/decision - a slice that structurally
  cannot reach idx+1 or beyond. Verified by TestLookAheadProtection:
  mutating bars far in the future leaves every earlier decision's
  trade_id and state byte-identical, and a spy on build_market_context
  confirms no window ever exceeds the configured lookback or contains
  a bar later than the window's own last bar.
- Determinism: two independent run_replay() calls on identical
  bars/config produce identical trade_id, pnl, r_multiple, and
  reproducibility.run_id - verified directly and as a named regression
  test for the wall-clock bug (Section 2, item 1).
- Realistic execution, no fabricated microstructure: entry fills at the
  worse edge of the entry zone, SL assumed to trigger first on an
  ambiguous bar, spread/slippage/fees are explicit ExecutionConfig
  values - documented in the report's Limitations, never presented as
  measured fact.
- Fail-closed data quality: validate_historical_dataset() blocks replay
  entirely (empty trades, is_valid=False) on duplicate timestamps,
  out-of-order bars, or impossible OHLC - never produces a
  silently-wrong "successful" backtest.

---

## 5. Performance Analytics - Design Discipline

Every metric that can be mathematically undefined for a given sample
(profit factor with no losses, Sharpe/Sortino with zero variance or a
single trade) is returned as None with a paired reason string in
PerformanceMetrics.reasons - never 0.0, inf, or a silently fabricated
number. sample_size_warning (default threshold: 20 closed trades) is
set independently of any individual metric's own undefined-ness, so a
report can never present statistically thin results with false
confidence.

Sharpe/Sortino are explicitly computed on a per-trade return series
(pnl / risk_amount), documented as such - not a calendar-time
annualized figure, since replay steps are event-driven signals, not
fixed periods.

Regime/directional/setup breakdowns are built only from labels already
present on TradeRecord (e.g. market_regime, which comes straight from
the Intelligence layer's own MarketRegime classification) - no regime
label is invented by the validation layer itself.

---

## 6. Validation Reporting Layer

ValidationReport is a structured dataclass first (to_dict() for UI/API
consumption) and a markdown renderer second (render_markdown()),
covering exactly the ten required sections: A. System Validation, B.
Data Quality, C. Execution Assumptions, D. Signal Statistics, E.
Trading Performance, F. Risk Statistics, G. Regime Analysis, H. Failure
Modes, I. Limitations, J. Reproducibility. Failure modes are aggregated
and sorted by frequency from real rejection_detail strings recorded
during replay - never invented categories. The Limitations section is
static and honest (Section 9 below is its source of truth).

---

## 7. Walk-Forward Foundation (explicitly NOT a full implementation)

split_walk_forward_periods() is a pure, deterministic, index-only
partitioner producing TRAINING -> VALIDATION -> OUT_OF_SAMPLE windows
that are contiguous, non-overlapping, and strictly chronological -
enforced by _assert_no_overlap_and_chronological(), which raises rather
than silently accepting a degenerate split. WalkForwardEngine is an ABC
whose three methods (run_training_window, run_validation_window,
run_out_of_sample_window) all raise NotImplementedError - there is no
optimization loop, no parameter search, and no "best window" selection
logic anywhere in this phase.

## 8. Monte Carlo Foundation (explicitly NOT a full implementation)

MonteCarloConfig mandates an explicit int random_seed (no
unseeded/hidden RNG is possible). make_seeded_rng() is the one
sanctioned source of randomness for future work, verified independent
of the global random module's state. MonteCarloResult.implemented
defaults to False with a note explicitly stating no simulations were
run - MonteCarloSampler is an ABC whose methods raise
NotImplementedError. No trade-order shuffling, bootstrap resampling, or
stress test is actually performed in Phase 7.

---

## 9. Known Limitations (honest, non-exhaustive-but-complete list)

1. Sequential single-position replay only (max_concurrent_positions
   must be 1) - overlapping positions are not simulated; run_replay
   raises ValueError rather than silently ignoring a different value.
2. Scalp horizon only is wired into the replay loop. Intraday and
   Short-Swing have the identical bridge pattern available
   (decision_bridge.from_intraday_candidate / from_short_swing_candidate
   already exist from Phase 6) but are not yet called by run_replay.
3. No real historical bid/ask data - spread/slippage/fees are explicit
   configurable assumptions (ExecutionConfig), never fabricated as
   measured fact.
4. Intrabar SL/TP ambiguity resolved conservatively (SL assumed first)
   - this can only understate, never overstate, simulated performance.
5. Sharpe/Sortino are per-trade, not calendar-time-annualized.
6. Walk-Forward and Monte Carlo are foundation/contracts only - no
   optimization, resampling, or stress testing is implemented.
7. PerformanceMetrics fee accounting relies entirely on the execution
   simulator's already-net pnl figure; total_pnl and net_pnl are
   therefore currently the same number (both already net of the
   simulator's fee/slippage assumptions) - there is no separate
   gross-vs-net view distinguishing "trading P&L" from "P&L after an
   additional layer of costs."
8. No persistence layer - every run_replay()/build_validation_report()
   call is stateless; nothing is saved across process runs.

---

## 10. Files Created (Phase 7)

```
omnisystem_v5/validation/
    __init__.py
    enums.py
    contracts.py
    data_quality.py
    execution.py
    replay_engine.py
    performance.py
    report.py
    walk_forward.py
    monte_carlo.py

omnisystem_v5/tests/
    test_phase7_data_quality.py       (9 tests)
    test_phase7_execution.py          (21 tests)
    test_phase7_replay_engine.py      (12 tests)
    test_phase7_performance.py        (17 tests)
    test_phase7_report.py             (9 tests)
    test_phase7_walk_forward.py       (15 tests)
    test_phase7_monte_carlo.py        (13 tests)
```

## 11. Files Modified (additive only, root-cause fixes)

```
intelligence/scalp_schema.py         + current_price field
intelligence/intraday_schema.py      + current_price field
intelligence/short_swing_schema.py   + current_price field
intelligence/scalp_engine.py         populate current_price
intelligence/intraday_engine.py      populate current_price
intelligence/short_swing_engine.py   populate current_price
intelligence/risk_bridge.py          use _resolve_entry_price() instead of zone midpoint
intelligence/decision_bridge.py      use _resolve_entry_price() instead of zone midpoint
```

No file under schemas/, data/, context/, calculations/, quant/, risk/,
or decision/ was touched.

---

## 12. Test Results

```
Phase 7 new tests:         96/96  PASS
  data_quality:             9
  execution:               21
  replay_engine:           12
  performance:             17
  report:                   9
  walk_forward:            15
  monte_carlo:             13

Full project suite:      488/488 PASS
  (392 Phase 1-6 baseline + 42 Phase 7 data_quality/execution/replay_engine
   tests from earlier in this phase + 54 performance/report/walk-forward/
   monte-carlo tests added this session)
```

Re-run immediately before this report - confirmed identical result.

## 13. Regression Status

ZERO REGRESSION. All tests present before this phase's work (434,
itself inclusive of the full Phase 1-6 suite of 392) continue to pass
unchanged.

---

## 14. Phase 7 Status: READY FOR FINAL SIGN-OFF

Scoped deliverables (Historical Replay Engine, Data Quality Gate,
Execution Simulator, Performance Analytics, Validation Reporting, and
explicitly-declared Walk-Forward/Monte-Carlo foundations) are complete,
tested, and documented. Two genuine integration bugs were found and
fixed at the root, each with a dedicated regression test. No metric,
capability, or statistical claim in this report exceeds what is
actually implemented - anything foundation-only is labeled as such
throughout.

## 15. Recommended Phase 8 (NOT executed)

Wire Intraday and Short-Swing into run_replay (the bridge pattern
already exists) and extend the replay loop to evaluate all three
horizons per step, using the same Decision Layer conflict-resolution
machinery from Phase 6 to arbitrate between them - the natural next
step now that the single-horizon replay path is proven correct, before
attempting real Walk-Forward optimization or Monte Carlo robustness
testing on top of it.
