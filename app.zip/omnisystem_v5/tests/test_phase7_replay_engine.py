import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.scalp_schema import PriceZone, ScalpCandidate, ScalpCandidateEvidence, ScalpDetectionResult
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.contracts import ExecutionConfig, ReplayConfig
from omnisystem_v5.validation.enums import ExitReason, TradeLifecycleState
from omnisystem_v5.validation.replay_engine import run_replay

UTC = timezone.utc
T0 = datetime.now(UTC) - timedelta(hours=1000)


def _bar(i, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v,
                     open_time=T0 + timedelta(hours=i), close_time=T0 + timedelta(hours=i + 1))


def _flat_bars(n, base=100.0):
    return [_bar(i, base, base + 0.3, base - 0.3, base, v=10) for i in range(n)]


def _evidence(level=AlignmentLevel.STRONG):
    return ScalpCandidateEvidence(
        structure_alignment=level, liquidity_alignment=level, momentum_alignment=level,
        volume_alignment=level, volatility_alignment=level, vwap_alignment=level,
        fvg_alignment=level, risk_reward_quality=level, multi_timeframe_alignment=level,
    )


def _make_scalp_candidate(direction, current_price, entry_zone, sl, tp, calculated_at):
    rr = calculate_risk_reward(entry=current_price, invalidation=sl, target=tp)
    return ScalpCandidate(
        symbol="BTCUSDT", horizon=Horizon.SCALP, direction=direction, timeframe=Timeframe.H1,
        calculated_at=calculated_at, expected_holding_period=ExpectedHoldingPeriod.MINUTES_TO_HOURS,
        preferred_entry_zone=PriceZone(bottom=entry_zone[0], top=entry_zone[1]),
        invalidation_zone=PriceZone(bottom=sl, top=sl), target_zones=(PriceZone(bottom=tp, top=tp),),
        risk_reward=rr, evidence=_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, data_quality="OK", confirmation_required=True,
        status=ScalpStatus.ZONE_IDENTIFIED, current_price=current_price,
    )


def _patched_result(candidate):
    return ScalpDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.H1, calculated_at=candidate.calculated_at,
                                 status=ScalpStatus.ZONE_IDENTIFIED, candidates=(candidate,))


def _no_signal_result():
    return ScalpDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.H1, calculated_at=datetime.now(UTC),
                                 status=ScalpStatus.NO_VALID_SCALP)


class TestFullLifecycleLong(unittest.TestCase):
    def _bars_with_long_setup(self, warmup=60):
        bars = _flat_bars(warmup, base=100.0)
        bars.append(_bar(warmup, 100.0, 100.5, 99.5, 100.0))
        return bars

    def test_long_take_profit_hit(self):
        bars = self._bars_with_long_setup()
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BULLISH, current_price=100.0,
                                           entry_zone=(99.0, 100.0), sl=95.0, tp=115.0, calculated_at=signal_time)
        bars.append(_bar(len(bars), 99.5, 100.2, 98.8, 99.8))
        bars.append(_bar(len(bars), 100.0, 116.0, 99.5, 115.5))

        with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100,
                                   risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
            result = run_replay(bars, config)

        closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT]
        self.assertEqual(len(closed), 1)
        t = closed[0]
        self.assertEqual(t.direction, "LONG")
        self.assertEqual(t.exit_reason, ExitReason.TAKE_PROFIT)
        self.assertAlmostEqual(t.entry_fill.price, 100.0)
        self.assertAlmostEqual(t.exit_fill.price, 115.0)
        self.assertGreater(t.pnl, 0)
        self.assertAlmostEqual(t.r_multiple, (115.0 - 100.0) / (100.0 - 95.0), places=6)

    def test_long_stop_loss_hit(self):
        bars = self._bars_with_long_setup()
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BULLISH, current_price=100.0,
                                           entry_zone=(99.0, 100.0), sl=95.0, tp=115.0, calculated_at=signal_time)
        bars.append(_bar(len(bars), 99.5, 100.2, 98.8, 99.8))
        bars.append(_bar(len(bars), 99.0, 99.5, 94.0, 94.5))

        with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100,
                                   risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
            result = run_replay(bars, config)

        closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT]
        self.assertEqual(len(closed), 1)
        t = closed[0]
        self.assertEqual(t.exit_reason, ExitReason.STOP_LOSS)
        self.assertAlmostEqual(t.exit_fill.price, 95.0)
        self.assertLess(t.pnl, 0)
        self.assertAlmostEqual(t.r_multiple, -1.0, places=6)


class TestFullLifecycleShort(unittest.TestCase):
    def _bars_with_short_setup(self, warmup=60):
        bars = _flat_bars(warmup, base=100.0)
        bars.append(_bar(warmup, 100.0, 100.5, 99.5, 100.0))
        return bars

    def test_short_take_profit_hit(self):
        bars = self._bars_with_short_setup()
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BEARISH, current_price=100.0,
                                           entry_zone=(100.0, 101.0), sl=105.0, tp=85.0, calculated_at=signal_time)
        bars.append(_bar(len(bars), 100.2, 100.8, 99.8, 100.5))
        bars.append(_bar(len(bars), 100.0, 100.5, 84.0, 84.5))

        with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100,
                                   risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
            result = run_replay(bars, config)

        closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT]
        self.assertEqual(len(closed), 1)
        t = closed[0]
        self.assertEqual(t.direction, "SHORT")
        self.assertEqual(t.exit_reason, ExitReason.TAKE_PROFIT)
        self.assertAlmostEqual(t.entry_fill.price, 100.0)
        self.assertAlmostEqual(t.exit_fill.price, 85.0)
        self.assertGreater(t.pnl, 0)
        self.assertAlmostEqual(t.r_multiple, (100.0 - 85.0) / (105.0 - 100.0), places=6)

    def test_short_stop_loss_hit(self):
        bars = self._bars_with_short_setup()
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BEARISH, current_price=100.0,
                                           entry_zone=(100.0, 101.0), sl=105.0, tp=85.0, calculated_at=signal_time)
        bars.append(_bar(len(bars), 100.2, 100.8, 99.8, 100.5))
        bars.append(_bar(len(bars), 100.0, 106.0, 99.5, 105.5))

        with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100,
                                   risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
            result = run_replay(bars, config)

        closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT]
        self.assertEqual(len(closed), 1)
        t = closed[0]
        self.assertEqual(t.exit_reason, ExitReason.STOP_LOSS)
        self.assertAlmostEqual(t.exit_fill.price, 105.0)
        self.assertLess(t.pnl, 0)
        self.assertAlmostEqual(t.r_multiple, -1.0, places=6)


class TestEntryNeverFilled(unittest.TestCase):
    def test_expires_when_price_never_reaches_zone(self):
        bars = _flat_bars(60, base=100.0)
        bars.append(_bar(60, 100.0, 100.5, 99.5, 100.0))
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BULLISH, current_price=100.0,
                                           entry_zone=(50.0, 51.0), sl=95.0, tp=115.0, calculated_at=signal_time)
        for i in range(30):
            bars.append(_bar(len(bars), 100.0, 100.5, 99.5, 100.0))

        with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100,
                                   execution=ExecutionConfig(entry_timeout_bars=10),
                                   risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
            result = run_replay(bars, config)

        expired = [t for t in result.trades if t.state == TradeLifecycleState.EXPIRED]
        self.assertEqual(len(expired), 1)
        self.assertEqual(expired[0].exit_reason, ExitReason.ENTRY_NEVER_FILLED)


class TestRootCauseRegression(unittest.TestCase):
    def test_bridge_uses_current_price_not_zone_midpoint(self):
        from omnisystem_v5.intelligence.decision_bridge import from_scalp_candidate as decision_from_scalp
        from omnisystem_v5.intelligence.risk_bridge import from_scalp_candidate as risk_from_scalp

        candidate = _make_scalp_candidate(
            DirectionBias.BULLISH, current_price=117.20,
            entry_zone=(115.50, 115.80), sl=115.80, tp=130.20, calculated_at=datetime.now(UTC),
        )
        zone_midpoint = (115.50 + 115.80) / 2.0

        risk_input = risk_from_scalp(candidate)
        decision_input = decision_from_scalp(candidate)

        self.assertEqual(risk_input.entry, 117.20)
        self.assertNotEqual(risk_input.entry, zone_midpoint)
        self.assertEqual(decision_input.entry, 117.20)
        self.assertGreater(risk_input.entry, risk_input.stop_loss)

    def test_bridge_falls_back_to_midpoint_when_current_price_absent(self):
        from omnisystem_v5.intelligence.risk_bridge import from_scalp_candidate
        import dataclasses

        candidate = _make_scalp_candidate(
            DirectionBias.BULLISH, current_price=100.0,
            entry_zone=(99.0, 101.0), sl=95.0, tp=110.0, calculated_at=datetime.now(UTC),
        )
        legacy = dataclasses.replace(candidate, current_price=None)
        risk_input = from_scalp_candidate(legacy)
        self.assertEqual(risk_input.entry, 100.0)

    def test_trade_id_deterministic_across_repeated_runs(self):
        bars = _flat_bars(60, base=100.0)
        bars.append(_bar(60, 100.0, 100.5, 99.5, 100.0))
        signal_time = bars[-1].close_time
        candidate = _make_scalp_candidate(DirectionBias.BULLISH, current_price=100.0,
                                           entry_zone=(99.0, 100.0), sl=95.0, tp=115.0, calculated_at=signal_time)
        bars.append(_bar(len(bars), 99.5, 100.2, 98.8, 99.8))
        bars.append(_bar(len(bars), 100.0, 116.0, 99.5, 115.5))

        def run_once():
            with patch("omnisystem_v5.validation.replay_engine.detect_scalp_candidate") as mock_detect:
                mock_detect.side_effect = lambda *a, **k: (_patched_result(candidate) if mock_detect.call_count == 1 else _no_signal_result())
                config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                       min_bars_required=40, max_lookback_bars=100,
                                       risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
                return run_replay(bars, config)

        r1 = run_once()
        r2 = run_once()
        self.assertEqual([t.trade_id for t in r1.trades], [t.trade_id for t in r2.trades])
        self.assertEqual([t.pnl for t in r1.trades], [t.pnl for t in r2.trades])
        self.assertEqual(r1.reproducibility.run_id, r2.reproducibility.run_id)


class TestLookAheadProtection(unittest.TestCase):
    def test_mutating_far_future_bars_does_not_change_early_decisions(self):
        base_bars = _flat_bars(80, base=100.0)
        for i in range(20):
            base_bars.append(_bar(len(base_bars), 100.0 + i * 0.1, 100.5 + i * 0.1, 99.5 + i * 0.1, 100.2 + i * 0.1))

        tampered_bars = list(base_bars)
        for i in range(20):
            tampered_bars.append(_bar(len(tampered_bars), 1000.0, 2000.0, 10.0, 1500.0, v=99999))

        config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                               min_bars_required=40, max_lookback_bars=100)

        r1 = run_replay(base_bars, config)
        r2 = run_replay(tampered_bars, config)

        shared_end = base_bars[-1].close_time
        r1_shared = [t for t in r1.trades if t.signal_time <= shared_end]
        r2_shared = [t for t in r2.trades if t.signal_time <= shared_end]
        self.assertEqual([t.trade_id for t in r1_shared], [t.trade_id for t in r2_shared])
        self.assertEqual([t.state for t in r1_shared], [t.state for t in r2_shared])

    def test_sliding_window_never_exceeds_available_bars(self):
        bars = _flat_bars(80, base=100.0)
        for i in range(30):
            bars.append(_bar(len(bars), 100.0 + i * 0.1, 100.5 + i * 0.1, 99.5 + i * 0.1, 100.2 + i * 0.1))

        seen_windows = []
        from omnisystem_v5.context.builder import build_market_context as original

        def spy(symbol, envelope, config):
            seen_windows.append(envelope.bars)
            return original(symbol, envelope, config)

        with patch("omnisystem_v5.validation.replay_engine.build_market_context", side_effect=spy):
            config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                                   min_bars_required=40, max_lookback_bars=100)
            run_replay(bars, config)

        self.assertTrue(len(seen_windows) > 0)
        for window in seen_windows:
            self.assertLessEqual(len(window), 100)
            last_time = window[-1].open_time
            self.assertTrue(all(b.open_time <= last_time for b in window))


class TestDataQualityGateBlocksReplay(unittest.TestCase):
    def test_invalid_dataset_produces_no_trades(self):
        bars = _flat_bars(60, base=100.0)
        bars.append(OHLCVBar(open=100, high=101, low=99, close=100, volume=10,
                              open_time=bars[-1].open_time, close_time=bars[-1].close_time))
        config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0, min_bars_required=40)
        result = run_replay(bars, config)
        self.assertFalse(result.data_quality.is_valid)
        self.assertEqual(result.trades, ())


class TestNoTradePassthrough(unittest.TestCase):
    def test_no_valid_scalp_produces_no_trade_records(self):
        bars = _flat_bars(120, base=100.0)
        config = ReplayConfig(symbol="BTCUSDT", timeframe=Timeframe.H1, initial_capital=10000.0,
                               min_bars_required=40, max_lookback_bars=100)
        result = run_replay(bars, config)
        self.assertEqual(len(result.trades), 0)


if __name__ == "__main__":
    unittest.main()
