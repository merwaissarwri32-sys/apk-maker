import unittest
from datetime import datetime, timezone

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.risk_bridge import from_scalp_candidate
from omnisystem_v5.intelligence.scalp_schema import PriceZone, ScalpCandidate, ScalpCandidateEvidence
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.risk.engine import assess_risk
from omnisystem_v5.risk.contracts import AccountState, RiskPolicy

UTC = timezone.utc


def _evidence(level=AlignmentLevel.MODERATE):
    return ScalpCandidateEvidence(
        structure_alignment=level, liquidity_alignment=level, momentum_alignment=level,
        volume_alignment=level, volatility_alignment=level, vwap_alignment=level,
        fvg_alignment=level, risk_reward_quality=level, multi_timeframe_alignment=level,
    )


def _scalp_candidate(direction=DirectionBias.BULLISH, entry_zone=(99.0, 101.0), invalidation=92.0, target=124.0):
    from omnisystem_v5.schemas.enums import Timeframe
    now = datetime.now(UTC)
    mid_entry = (entry_zone[0] + entry_zone[1]) / 2
    rr = calculate_risk_reward(entry=mid_entry, invalidation=invalidation, target=target)
    return ScalpCandidate(
        symbol="BTCUSDT", horizon=Horizon.SCALP, direction=direction, timeframe=Timeframe.M15, calculated_at=now,
        expected_holding_period=ExpectedHoldingPeriod.MINUTES_TO_HOURS,
        preferred_entry_zone=PriceZone(bottom=entry_zone[0], top=entry_zone[1]),
        invalidation_zone=PriceZone(bottom=invalidation, top=invalidation),
        target_zones=(PriceZone(bottom=target, top=target),),
        risk_reward=rr, evidence=_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, data_quality="OK", confirmation_required=True,
        status=ScalpStatus.ZONE_IDENTIFIED,
    )


class TestScalpBridge(unittest.TestCase):
    def test_bullish_maps_to_long(self):
        c = _scalp_candidate(direction=DirectionBias.BULLISH)
        risk_input = from_scalp_candidate(c)
        self.assertEqual(risk_input.direction, Direction.LONG)

    def test_bearish_maps_to_short(self):
        c = _scalp_candidate(direction=DirectionBias.BEARISH, entry_zone=(99.0, 101.0), invalidation=108.0, target=76.0)
        risk_input = from_scalp_candidate(c)
        self.assertEqual(risk_input.direction, Direction.SHORT)

    def test_entry_is_midpoint_of_zone(self):
        c = _scalp_candidate(entry_zone=(98.0, 102.0))
        risk_input = from_scalp_candidate(c)
        self.assertAlmostEqual(risk_input.entry, 100.0)

    def test_stop_loss_and_target_pulled_from_zones(self):
        c = _scalp_candidate(invalidation=92.0, target=124.0)
        risk_input = from_scalp_candidate(c)
        self.assertAlmostEqual(risk_input.stop_loss, 92.0)
        self.assertEqual(risk_input.take_profits, (124.0,))

    def test_horizon_and_source_labeled(self):
        c = _scalp_candidate()
        risk_input = from_scalp_candidate(c)
        self.assertEqual(risk_input.horizon, "SCALP")
        self.assertEqual(risk_input.source, "ScalpEngine")

    def test_bridged_candidate_flows_through_risk_engine_end_to_end(self):
        c = _scalp_candidate(entry_zone=(99.0, 101.0), invalidation=92.0, target=124.0)
        risk_input = from_scalp_candidate(c, requested_risk_pct=1.0)
        result = assess_risk(risk_input, AccountState(equity=10000.0), RiskPolicy())
        # entry=100, sl=92 (8 risk), tp=124 (24 reward) -> RR=3.0, comfortably valid
        self.assertIn(result.decision.value, ("VALID", "WARNING"))
        self.assertTrue(result.is_actionable)


if __name__ == "__main__":
    unittest.main()
