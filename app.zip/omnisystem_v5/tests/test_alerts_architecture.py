"""Phase 12 - architecture / static-safety guards. They protect the frozen Phase 1-11 layers, the dependency direction
(frozen layers -> alerts, never the reverse), the safety boundary (no execution, network, secrets, threads, randomness) and the
exactness of the Phase 12 guard extensions (D2..D5). Nothing here weakens a Phase 1-11 assertion."""
import ast
import hashlib
import importlib
import re
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
ALERTS = PKG / "alerts"
TESTS = PKG / "tests"

# ---- Phase 12 AUTHORIZED guard extensions, recorded as reversible (new_text, old_text) pairs. Reversing them must reproduce the
# ---- exact Phase 11 file (hash in phase12_guard_manifest.txt). Any other edit to these two files makes these tests fail.
GUARD_EDITS = {'test_scanner_engine.py': [('            if rel[0] in ("scanner", "tests", "marketdata", "alerts"):\n', '            if rel[0] in ("scanner", "tests", "marketdata"):\n')], 'test_marketdata_architecture.py': [('            if rel[0] in ("marketdata", "tests", "alerts"):\n', '            if rel[0] in ("marketdata", "tests"):\n'), ('    D1_NEW = \'if rel[0] in ("scanner", "tests", "marketdata", "alerts"):\'      # D1 + Phase 12 authorized edit P12-G1 (adds "alerts" only)\n', '    D1_NEW = \'if rel[0] in ("scanner", "tests", "marketdata"):\'\n'), ('        allowed = lambda rel: (rel.startswith("omnisystem_v5/marketdata/") or rel.startswith("omnisystem_v5/alerts/") or\n', '        allowed = lambda rel: (rel.startswith("omnisystem_v5/marketdata/") or\n'), ('                               re.match(r"omnisystem_v5/tests/(test_alerts_\\w+\\.py|alerts_fixtures\\.py|phase12_guard_manifest\\.txt)$", rel) or\n                               re.match(r"omnisystem_v5/PHASE1[12]_\\w+\\.md$", rel))\n', '                               re.match(r"omnisystem_v5/PHASE11_\\w+\\.md$", rel))\n')]}

ALLOWED_OMNI_IMPORTS = frozenset({
    ("omnisystem_v5.marketdata.canonical", "canonical_dict"), ("omnisystem_v5.marketdata.canonical", "canonical_json"),
    ("omnisystem_v5.marketdata.canonical", "digest"), ("omnisystem_v5.marketdata.catalog_en", "MESSAGES"),
    ("omnisystem_v5.marketdata.catalog_fa", "MESSAGES"), ("omnisystem_v5.marketdata.config", "RetryPolicy"),
    ("omnisystem_v5.marketdata.config", "ThrottlePolicy"), ("omnisystem_v5.marketdata.events", "CompositeSink"),
    ("omnisystem_v5.marketdata.events", "DataEventKind"), ("omnisystem_v5.marketdata.events", "emit"),
    ("omnisystem_v5.marketdata.i18n", "EN"), ("omnisystem_v5.marketdata.i18n", "InMemoryCatalog"),
    ("omnisystem_v5.marketdata.i18n", "Locale"), ("omnisystem_v5.marketdata.i18n", "LocalizedMessage"),
    ("omnisystem_v5.marketdata.i18n", "MessageCatalog"), ("omnisystem_v5.marketdata.i18n", "MessageKey"),
    ("omnisystem_v5.marketdata.i18n", "StructuredMessage"), ("omnisystem_v5.marketdata.i18n", "msg"),
    ("omnisystem_v5.marketdata.retry", "Throttle"), ("omnisystem_v5.marketdata.retry", "compute_delay"),
    ("omnisystem_v5.scanner.failures", "FailureClass"), ("omnisystem_v5.scanner.failures", "classify_fetch_exception"),
})
ALLOWED_STDLIB = frozenset({"__future__", "dataclasses", "datetime", "enum", "json", "math", "re", "typing"})
APPROVED_EXCEPTIONS = frozenset({"AlertValidationError", "AlertConfigError", "PayloadValidationError", "TransportRejectedError",
                                 "TransportAuthError", "TransportConfigError"})


class Base(unittest.TestCase):
    def absent(self, text, pattern, msg=None):
        """Like assertNotRegex but reports only the offending match (never dumps the whole module text)."""
        m = re.search(pattern, text)
        self.assertIsNone(m, f"{msg or ''} pattern {pattern!r} matched {m.group(0)!r}" if m else None)


def alert_files():
    return sorted(ALERTS.glob("*.py"))


def source(f):
    return f.read_text(encoding="utf-8")


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def manifest():
    out = {}
    for line in (TESTS / "phase12_guard_manifest.txt").read_text().splitlines():
        kind, digest, path = line.split()
        out[(kind, path)] = digest
    return out


def exemption_tuples(path):
    """Every tuple literal compared with `rel[0] in (...)` in a guard file (AST, so formatting cannot hide a change)."""
    found = []
    for n in ast.walk(ast.parse(Path(path).read_text(encoding="utf-8"))):
        if isinstance(n, ast.Compare) and isinstance(n.left, ast.Subscript) and ast.unparse(n.left) == "rel[0]":
            for c in n.comparators:
                if isinstance(c, ast.Tuple):
                    found.append(tuple(e.value for e in c.elts))
    return found


class TestAuthorizedGuardExtensions(Base):
    NAMES = ("test_scanner_engine.py", "test_marketdata_architecture.py")

    def test_reversing_the_recorded_edits_reproduces_the_exact_phase_11_files(self):
        m = manifest()
        for name in self.NAMES:
            with self.subTest(file=name):
                text = source(TESTS / name)
                for new, old in GUARD_EDITS[name]:
                    self.assertEqual(text.count(new), 1, f"authorized edit not present exactly once in {name}")
                    text = text.replace(new, old)
                self.assertEqual(sha(text), m[("PRE", f"omnisystem_v5/tests/{name}")], f"{name} contains an UNAUTHORIZED change")

    def test_the_current_guard_files_are_pinned(self):
        m = manifest()
        for name in self.NAMES:
            with self.subTest(file=name):
                self.assertEqual(sha(source(TESTS / name)), m[("POST", f"omnisystem_v5/tests/{name}")])

    def test_only_alerts_was_added_to_the_exemption_tuples(self):
        self.assertEqual(exemption_tuples(TESTS / "test_scanner_engine.py"), [("scanner", "tests", "marketdata", "alerts")])
        self.assertEqual(exemption_tuples(TESTS / "test_marketdata_architecture.py"), [("marketdata", "tests", "alerts")])

    def test_the_file_allowlist_admits_only_the_phase_12_names(self):
        text = source(TESTS / "test_marketdata_architecture.py")
        self.assertIn('rel.startswith("omnisystem_v5/alerts/")', text)
        self.assertIn(r"(test_alerts_\w+\.py|alerts_fixtures\.py|phase12_guard_manifest\.txt)", text)
        self.assertIn(r"PHASE1[12]_\w+\.md", text)
        self.assertEqual(len(GUARD_EDITS["test_marketdata_architecture.py"]), 4)
        self.assertEqual(len(GUARD_EDITS["test_scanner_engine.py"]), 1)

    def test_the_frozen_phase_10_manifest_file_itself_is_unchanged(self):
        m = manifest()
        self.assertEqual(sha((TESTS / "phase10_frozen_manifest.txt").read_text()), "a81431ca9a9c4adb25317259b877d8f95fd1280982f9037e80dd39651f0fff57")
        self.assertEqual(len([l for l in (TESTS / "phase10_frozen_manifest.txt").read_text().splitlines() if l.strip()]), 174)


class TestDependencyDirection(Base):
    def test_alerts_imports_only_the_named_frozen_contracts_and_the_stdlib(self):
        used, std = set(), set()
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):
                if isinstance(n, ast.ImportFrom) and n.module:
                    if n.module.startswith("omnisystem_v5.alerts"):
                        continue
                    if n.module.startswith("omnisystem_v5"):
                        used |= {(n.module, a.name) for a in n.names}
                    else:
                        std.add(n.module)
                elif isinstance(n, ast.Import):
                    std |= {a.name for a in n.names}
        self.assertEqual(used, ALLOWED_OMNI_IMPORTS)
        self.assertEqual(std - ALLOWED_STDLIB, set())

    def test_alerts_never_imports_the_decision_risk_intelligence_quant_or_data_layers(self):
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):
                mod = getattr(n, "module", None) if isinstance(n, ast.ImportFrom) else None
                if mod:
                    for banned in ("decision", "risk", "intelligence", "quant", "context", "validation", "calculations", "schemas", "data", "tests"):
                        self.assertFalse(mod.startswith(f"omnisystem_v5.{banned}"), f"{f.name} imports {mod}")

    def test_no_frozen_layer_depends_on_alerts(self):
        for f in sorted(PKG.rglob("*.py")):
            rel = f.relative_to(PKG).parts
            if rel[0] in ("alerts", "tests"):
                continue
            self.absent(source(f), r"omnisystem_v5\.alerts|from omnisystem_v5 import alerts|import alerts", str(f))

    def test_scanner_and_marketdata_in_particular_never_import_alerts(self):
        for pkg in ("scanner", "marketdata"):
            for f in (PKG / pkg).rglob("*.py"):
                self.assertNotIn("alerts", " ".join(ast.unparse(n) for n in ast.walk(ast.parse(source(f))) if isinstance(n, (ast.Import, ast.ImportFrom))), str(f))

    def test_alerts_never_imports_the_tests_package_or_a_phase_13_plus_module(self):
        for f in alert_files():
            self.absent(source(f), r"omnisystem_v5\.tests|omnisystem_v5\.(ui|trader|identity|billing|admin|assistant|execution)\b")

    def test_every_module_imports_cleanly(self):
        for f in alert_files():
            importlib.import_module(f"omnisystem_v5.alerts.{f.stem}") if f.stem != "__init__" else importlib.import_module("omnisystem_v5.alerts")


class TestReuseNotDuplication(Base):
    def test_alerts_reuses_the_frozen_contracts_by_identity(self):
        from omnisystem_v5.alerts import delivery, i18n, model, routing, telemetry
        from omnisystem_v5.marketdata import canonical, config, events, retry
        from omnisystem_v5.marketdata import i18n as md_i18n
        from omnisystem_v5.scanner import failures
        self.assertIs(delivery.RetryPolicy, config.RetryPolicy)
        self.assertIs(delivery.compute_delay, retry.compute_delay)
        self.assertIs(routing.Throttle, retry.Throttle)
        self.assertIs(routing.ThrottlePolicy, config.ThrottlePolicy)
        self.assertIs(delivery.FailureClass, failures.FailureClass)
        self.assertIs(delivery.classify_fetch_exception, failures.classify_fetch_exception)
        self.assertIs(telemetry._emit, events.emit)
        self.assertIs(model.StructuredMessage, md_i18n.StructuredMessage)
        self.assertIs(model.canonical_json, canonical.canonical_json)
        self.assertIs(i18n.InMemoryCatalog, md_i18n.InMemoryCatalog)

    def test_no_class_in_alerts_shadows_a_frozen_scanner_or_marketdata_class(self):
        def names(d):
            return {n.name for f in (PKG / d).rglob("*.py") for n in ast.walk(ast.parse(source(f))) if isinstance(n, ast.ClassDef)}
        mine = {n.name for f in alert_files() for n in ast.walk(ast.parse(source(f))) if isinstance(n, ast.ClassDef)}
        self.assertEqual(mine & (names("scanner") | names("marketdata")), set())

    def test_the_only_exceptions_defined_are_the_approved_set(self):
        defined = set()
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):
                if isinstance(n, ast.ClassDef) and any(isinstance(b, ast.Name) and b.id in ("Exception", "ValueError", "RuntimeError", "TypeError", "OSError") for b in n.bases):
                    defined.add(n.name)
        self.assertEqual(defined, APPROVED_EXCEPTIONS)

    def test_no_clock_clone_or_second_clock_protocol_is_defined(self):
        self.absent("\n".join(source(f) for f in alert_files()), r"class\s+\w*(Clock|Sleep|Sink)\w*\s*[(:]")


class TestSafetyBoundaries(Base):
    def setUp(self):
        self.text = {f.name: source(f) for f in alert_files()}
        self.all = "\n".join(self.text.values())

    def test_no_network_process_thread_or_async_primitives(self):
        banned = ("socket", "http", "urllib", "requests", "ssl", "smtplib", "ftplib", "subprocess", "threading", "multiprocessing", "asyncio",
                  "concurrent", "os", "sys", "shutil", "pathlib", "tempfile", "pickle", "marshal", "ctypes", "importlib", "random", "secrets", "uuid", "time")
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):
                mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [n.module] if isinstance(n, ast.ImportFrom) and n.module else []
                for m in mods:
                    self.assertNotIn(m.split(".")[0], banned, f"{f.name} imports {m}")

    def test_no_wall_clock_reads_no_sleep_no_file_io_no_dynamic_code(self):
        for pat in (r"datetime\.(now|utcnow|today)\(", r"\bdate\.today\(", r"utcnow", r"time\.sleep", r"os\.environ", r"getenv"):
            self.absent(self.all, pat)
        banned_calls = {"eval", "exec", "compile", "open", "print", "hash", "__import__", "input", "breakpoint", "globals", "locals", "vars"}
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):                       # AST, so docstrings that mention these words are not calls
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
                    self.assertNotIn(n.func.id, banned_calls, f"{f.name} calls {n.func.id}()")
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
                    self.assertNotIn(n.func.id, ("setattr", "delattr"), f"{f.name} mutates attributes dynamically")      # reading via getattr is fine

    def test_object_setattr_is_confined_to_the_validating_model(self):
        self.assertEqual([n for n, t in self.text.items() if "object.__setattr__" in t], ["model.py"])

    def test_no_urls_secrets_or_credentials(self):
        self.absent(self.all, r"https?://|wss?://|ftp://")
        self.absent(self.all, r"(?i)(api[_-]?key|secret|passwd|password|token|bearer|webhook_url|chat_id)\s*[=:]\s*[\"'][^\"']+[\"']")
        self.absent(self.all, r"\b[A-Za-z0-9+/_-]{32,}\b(?<![0-9a-f]{32})")          # no long opaque literals (keys/tokens)
        self.absent(self.all, r"(?i)telegram|twilio|smtp|sendgrid|firebase|fcm|apns|slack\.com|pagerduty")

    def test_no_execution_capability(self):
        self.absent(self.all, r"(?i)\b(place|submit|send|create|cancel|modify|amend|route)_?(order|trade|position)s?\b")
        self.absent(self.all, r"(?i)\b(broker|brokerage|exchange_api|ccxt|binance|metatrader|mt5|fix_protocol|execute_trade|order_book_write)\b")
        for f in alert_files():
            for n in ast.walk(ast.parse(source(f))):
                if isinstance(n, ast.FunctionDef):
                    tokens = set(re.findall(r"[a-z]+", re.sub(r"([A-Z])", r"_\1", n.name).lower()))
                    self.assertFalse(tokens & {"place", "submit", "cancel", "execute", "trade", "order", "broker"}, f"{f.name}:{n.name}")

    def test_no_billing_identity_admin_ui_assistant_or_later_phase_leakage(self):
        self.absent(self.all, r"(?i)billing|subscri|invoice|wallet|payment|entitlement|rbac|permission_|admin_console|paid_plan|marketplace")
        self.absent(self.all, r"(?i)trader_lab|dashboard|frontend|react|html|\bdom\b|widget|assistant|\bllm\b|openai|anthropic|autonomous")

    def test_no_global_mutable_state(self):
        for f in alert_files():
            for n in ast.parse(source(f)).body:
                if isinstance(n, ast.Assign) and isinstance(n.value, (ast.List, ast.Dict, ast.Set, ast.ListComp, ast.DictComp, ast.SetComp)):
                    for t in n.targets:
                        self.assertTrue(t.id.isupper() or t.id.startswith("_") and t.id.lstrip("_").isupper(), f"{f.name}: mutable module global {t.id}")
                self.assertNotIsInstance(n, ast.Global)
            self.absent(source(f), r"\bglobal\s+\w+")

    def test_retry_loops_exist_only_in_the_delivery_executor(self):
        for name, t in self.text.items():
            if name != "delivery.py":
                self.absent(t, r"while\s+True|while\s+\w+\s*:")
        self.assertEqual(len(re.findall(r"while\s+True", self.text["delivery.py"])), 1)

    def test_every_alert_event_kind_name_is_one_of_the_specified_set(self):
        from omnisystem_v5.alerts.telemetry import AlertEventKind
        for required in ("ALERT_CREATED", "ALERT_DEDUPLICATED", "ALERT_SUPPRESSED", "ROUTING_DECIDED", "DELIVERY_STARTED", "DELIVERY_SUCCEEDED",
                         "DELIVERY_FAILED", "RETRY_SCHEDULED", "RETRY_EXHAUSTED"):
            self.assertIn(required, AlertEventKind.__members__)

    def test_alert_fields_never_contain_a_probability_or_confidence_field(self):
        import dataclasses
        from omnisystem_v5.alerts import model
        for cls in (model.Alert, model.AlertCandidate, model.AlertPriority):
            self.assertFalse({f.name for f in dataclasses.fields(cls)} & {"probability", "confidence", "win_rate", "score", "expected_return", "profit"})

    def test_endpoints_cannot_be_urls(self):
        from omnisystem_v5.alerts.errors import AlertConfigError
        from omnisystem_v5.alerts.enums import NotificationChannel
        from omnisystem_v5.alerts.routing import NotificationTarget
        for ref in ("https://x.example/hook", "a/b", "tok=abc", "A", "", "x" * 65, "a b", "../etc"):
            with self.assertRaises(AlertConfigError):
                NotificationTarget("a", NotificationChannel.WEBHOOK, endpoint_ref=ref)


class TestNoLeakageOutsideTheDeclaredPhase(Base):
    def test_only_the_phase_12_files_were_added_outside_the_frozen_manifest_and_phase_11(self):
        extra = {p.name for p in TESTS.glob("*alerts*")} | {p.name for p in TESTS.glob("phase12*")}
        self.assertEqual(extra, {"alerts_fixtures.py", "test_alerts_domain.py", "test_alerts_dedup.py", "test_alerts_routing_delivery.py",
                                 "test_alerts_pipeline.py", "test_alerts_architecture.py", "test_alerts_determinism.py", "phase12_guard_manifest.txt"})
        reports = {p.name for p in PKG.glob("PHASE1*_*.md")}
        self.assertLessEqual({"PHASE12_FINAL_REPORT.md"}, reports | {"PHASE12_FINAL_REPORT.md"})
        self.assertFalse(list(PKG.glob("PHASE13*")) or list(PKG.glob("PHASE14*")))

    def test_the_package_directory_contains_only_python_modules(self):
        for p in ALERTS.iterdir():
            self.assertTrue(p.suffix == ".py" or p.name == "__pycache__", p.name)


if __name__ == "__main__":
    unittest.main()
