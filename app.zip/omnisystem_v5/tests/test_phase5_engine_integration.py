import math
import unittest
from datetime import datetime, timezone

from omnisystem_v5.risk.contracts import AccountState, InstrumentSpec, RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.engine import assess_risk
from omnisystem_v5.risk.enums import Direction, RejectionReasonCode, RiskDecision

UTC = timezone.utc


def _candidate(**kwargs):
    defaults = dict(symbol="BTCUSDT", direction=Direction.LONG, entry=100.0, stop_loss=92.0,
                     take_profits=(120.0, 128.0, 136.0), requested_risk_pct=1.0)
    defaults.update(kwargs)
    return TradeCandidateInput(**defaults)


def _account(**kwargs):
    defaults = dict(equity=10000.0)
    defaults.update(kwargs)
    return AccountState(**defaults)


class TestFullPipelineValid(unittest.TestCase):
    def test_clean_valid_case(self):
        r = assess_risk(_candidate(), _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.VALID)
        self.assertTrue(r.is_actionable)
        self.assertAlmostEqual(r.position_size, 12.5)
        self.assertAlmostEqual(r.risk_percentage, 1.0)
        self.assertEqual(r.reward_risk_ratios, (2.5, 3.5, 4.5))
        self.assertEqual(r.primary_reward_risk_ratio, 2.5)

    def test_valid_short_case(self):
        c = _candidate(direction=Direction.SHORT, entry=100.0, stop_loss=108.0, take_profits=(76.0, 68.0, 60.0))
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.VALID)


class TestFullPipelineWarning(unittest.TestCase):
    def test_single_tp_produces_warning_not_rejection(self):
        c = _candidate(take_profits=(120.0,))
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.WARNING)
        self.assertTrue(r.is_actionable)


class TestFullPipelineDataInvalid(unittest.TestCase):
    def test_nan_short_circuits_before_any_other_stage(self):
        c = _candidate(entry=math.nan)
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)
        self.assertFalse(r.is_actionable)
        self.assertIsNone(r.position_size)

    def test_infinite_stop_loss(self):
        c = _candidate(stop_loss=math.inf)
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)

    def test_zero_equity_short_circuits(self):
        r = assess_risk(_candidate(), _account(equity=0.0), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)

    def test_negative_equity(self):
        r = assess_risk(_candidate(), _account(equity=-1.0), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)


class TestFullPipelineRejected(unittest.TestCase):
    def test_sl_on_wrong_side(self):
        c = _candidate(stop_loss=105.0)
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.REJECTED)
        self.assertIn(RejectionReasonCode.SL_WRONG_SIDE, r.rejection_reasons)

    def test_sl_equals_entry(self):
        c = _candidate(stop_loss=100.0)
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.REJECTED)

    def test_tp_on_wrong_side(self):
        c = _candidate(take_profits=(90.0,))
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.REJECTED)
        self.assertIn(RejectionReasonCode.TP_WRONG_SIDE, r.rejection_reasons)

    def test_poor_rr_rejected(self):
        c = _candidate(stop_loss=92.0, take_profits=(102.0,))  # rr well under 2.0
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.REJECTED)
        self.assertIn(RejectionReasonCode.RR_BELOW_MINIMUM, r.rejection_reasons)


class TestFullPipelineRiskBlocked(unittest.TestCase):
    def test_sl_too_wide_is_risk_blocked_not_rejected(self):
        """Distinct from structural invalidity: SL is on the correct
        side and non-zero, it's just farther than the policy allows."""
        c = _candidate(stop_loss=50.0, take_profits=(300.0,))
        r = assess_risk(c, _account(), RiskPolicy(max_sl_distance_pct=10.0))
        self.assertEqual(r.decision, RiskDecision.RISK_BLOCKED)
        self.assertIn(RejectionReasonCode.SL_TOO_WIDE, r.rejection_reasons)

    def test_exposure_limit_blocks_otherwise_valid_trade(self):
        c = _candidate(stop_loss=98.0, take_profits=(105.0,))  # tight SL -> big position -> high notional
        r = assess_risk(c, _account(), RiskPolicy(max_exposure_pct=20.0))
        self.assertEqual(r.decision, RiskDecision.RISK_BLOCKED)
        self.assertIn(RejectionReasonCode.MAX_EXPOSURE_EXCEEDED, r.rejection_reasons)

    def test_daily_loss_guard_blocks(self):
        policy = RiskPolicy(daily_loss_limit_pct=2.0)
        account = _account(daily_loss_amount=250.0)  # 2.5%
        r = assess_risk(_candidate(), account, policy)
        self.assertEqual(r.decision, RiskDecision.RISK_BLOCKED)
        self.assertIn(RejectionReasonCode.DAILY_LOSS_LIMIT_EXCEEDED, r.rejection_reasons)


class TestNeverActionableWhenAmbiguous(unittest.TestCase):
    def test_all_non_valid_non_warning_decisions_are_not_actionable(self):
        cases = [
            _candidate(entry=math.nan),                          # DATA_INVALID
            _candidate(stop_loss=105.0),                          # REJECTED
            _candidate(stop_loss=50.0, take_profits=(300.0,)),    # RISK_BLOCKED
        ]
        for c in cases:
            r = assess_risk(c, _account(), RiskPolicy(max_sl_distance_pct=10.0))
            self.assertFalse(r.is_actionable, f"decision={r.decision} must not be actionable")


class TestDeterminism(unittest.TestCase):
    def test_identical_input_produces_identical_output(self):
        c = _candidate()
        acc = _account()
        policy = RiskPolicy()
        fixed_time = datetime.now(UTC)
        r1 = assess_risk(c, acc, policy, now=fixed_time)
        r2 = assess_risk(c, acc, policy, now=fixed_time)
        self.assertEqual(r1.decision, r2.decision)
        self.assertEqual(r1.position_size, r2.position_size)
        self.assertEqual(r1.risk_amount, r2.risk_amount)
        self.assertEqual(r1.reward_risk_ratios, r2.reward_risk_ratios)
        self.assertEqual(r1.rejection_reasons, r2.rejection_reasons)
        self.assertEqual(r1.warnings, r2.warnings)

    def test_no_hidden_state_across_calls(self):
        """Calling assess_risk many times with the same input must never
        drift — there is no internal counter, cache, or mutable state."""
        c = _candidate()
        acc = _account()
        policy = RiskPolicy()
        results = [assess_risk(c, acc, policy) for _ in range(5)]
        decisions = {r.decision for r in results}
        sizes = {r.position_size for r in results}
        self.assertEqual(len(decisions), 1)
        self.assertEqual(len(sizes), 1)


class TestPrecisionAndInstrumentIntegration(unittest.TestCase):
    def test_instrument_spec_flows_through_full_pipeline(self):
        instr = InstrumentSpec(symbol="BTCUSDT", tick_size=0.5, position_step=0.001, min_position_size=0.001)
        c = _candidate(stop_loss=92.5, instrument=instr)  # 92.5 aligns to tick 0.5
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertIn(r.decision, (RiskDecision.VALID, RiskDecision.WARNING))

    def test_misaligned_tick_size_rejected_end_to_end(self):
        instr = InstrumentSpec(symbol="BTCUSDT", tick_size=0.5)
        c = _candidate(stop_loss=92.3, instrument=instr)  # not aligned to 0.5
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.REJECTED)
        self.assertIn(RejectionReasonCode.SL_PRECISION_INVALID, r.rejection_reasons)


class TestAdversarial(unittest.TestCase):
    def test_huge_numeric_values_do_not_crash(self):
        c = _candidate(entry=1e18, stop_loss=1e18 - 1e15, take_profits=(1e18 + 3e15,))
        r = assess_risk(c, _account(equity=1e15), RiskPolicy())
        self.assertIn(r.decision, (RiskDecision.VALID, RiskDecision.WARNING, RiskDecision.RISK_BLOCKED))

    def test_extremely_tiny_but_valid_numbers(self):
        c = _candidate(entry=0.0001, stop_loss=0.00009, take_profits=(0.00013,))
        r = assess_risk(c, _account(), RiskPolicy(min_sl_distance_pct=0.0001, max_sl_distance_pct=50))
        self.assertIn(r.decision, (RiskDecision.VALID, RiskDecision.WARNING, RiskDecision.REJECTED, RiskDecision.RISK_BLOCKED))

    def test_inconsistent_candidate_missing_tp_and_bad_sl_reports_first_stage_only(self):
        """Data integrity catches the missing TP before SL-shape checks
        even run — confirms strict stage ordering under multiple faults."""
        c = _candidate(stop_loss=105.0, take_profits=())  # both SL-wrong-side AND no-TP
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)
        self.assertIn(RejectionReasonCode.DATA_NO_TAKE_PROFIT, r.rejection_reasons)

    def test_unsupported_instrument_spec_fails_closed(self):
        instr = InstrumentSpec(symbol="X", contract_size=float("nan"))
        c = _candidate(instrument=instr)
        r = assess_risk(c, _account(), RiskPolicy())
        self.assertEqual(r.decision, RiskDecision.DATA_INVALID)


if __name__ == "__main__":
    unittest.main()
