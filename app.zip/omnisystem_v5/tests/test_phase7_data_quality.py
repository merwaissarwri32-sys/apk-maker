import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.data_quality import validate_historical_dataset
from omnisystem_v5.validation.enums import DataQualityIssueType

UTC = timezone.utc
T0 = datetime.now(UTC)


def _bar(i, o=100.0, h=101.0, l=99.0, c=100.5, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v,
                     open_time=T0 + timedelta(hours=i), close_time=T0 + timedelta(hours=i + 1))


def _clean_series(n=80):
    return [_bar(i, 100 + i * 0.1, 100 + i * 0.1 + 1, 100 + i * 0.1 - 1, 100 + i * 0.1 + 0.2) for i in range(n)]


class TestCleanDataset(unittest.TestCase):
    def test_clean_dataset_is_valid_with_no_issues(self):
        report = validate_historical_dataset(_clean_series(80), Timeframe.H1, min_bars_required=60)
        self.assertTrue(report.is_valid)
        self.assertEqual(len(report.issues), 0)
        self.assertTrue(report.warmup_sufficient)


class TestInsufficientWarmup(unittest.TestCase):
    def test_too_few_bars_flagged_but_not_blocking(self):
        report = validate_historical_dataset(_clean_series(10), Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.warmup_sufficient)
        self.assertTrue(report.is_valid)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.INSUFFICIENT_WARMUP for i in report.issues))


class TestDuplicateTimestamp(unittest.TestCase):
    def test_duplicate_timestamp_is_blocking(self):
        bars = _clean_series(80)
        bars[10] = _bar(9)
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.is_valid)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.DUPLICATE_TIMESTAMP for i in report.issues))


class TestOutOfOrder(unittest.TestCase):
    def test_out_of_order_bar_is_blocking(self):
        bars = _clean_series(80)
        bars[20], bars[21] = bars[21], bars[20]
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.is_valid)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.OUT_OF_ORDER for i in report.issues))


class TestImpossibleOhlc(unittest.TestCase):
    """Real OHLCVBar objects validate OHLC sanity at construction (Phase 1
    already prevents this at ingestion) - these checks in data_quality.py
    exist as a defensive second layer for malformed/duck-typed inputs
    from outside the normal ingestion path, so we use plain stand-in
    objects here rather than trying to construct an invalid OHLCVBar."""

    def _fake(self, o, h, l, c, open_time, close_time):
        class FakeBar:
            pass
        f = FakeBar()
        f.open, f.high, f.low, f.close, f.volume = o, h, l, c, 10.0
        f.open_time, f.close_time = open_time, close_time
        return f

    def test_high_below_low_is_blocking(self):
        bars = _clean_series(80)
        bars[15] = self._fake(100, 95, 99, 100, bars[15].open_time, bars[15].close_time)
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.is_valid)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.IMPOSSIBLE_OHLC for i in report.issues))

    def test_close_above_high_is_blocking(self):
        bars = _clean_series(80)
        bars[15] = self._fake(100, 101, 99, 105, bars[15].open_time, bars[15].close_time)
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.is_valid)


class TestGapDetection(unittest.TestCase):
    def test_abnormal_gap_flagged_non_blocking(self):
        # Gap placed at the END of the series (nothing after it), so
        # inserting a later timestamp can never create an out-of-order
        # side effect - isolates the gap check from the ordering check.
        bars = _clean_series(40)
        far_future = OHLCVBar(open=100, high=101, low=99, close=100.5,
                               volume=10, open_time=bars[-1].open_time + timedelta(hours=20),
                               close_time=bars[-1].open_time + timedelta(hours=21))
        bars = bars + [far_future]
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.ABNORMAL_GAP for i in report.issues))
        self.assertTrue(report.is_valid)

    def test_missing_candle_flagged_for_moderate_gap(self):
        bars = _clean_series(40)
        moderate_future = OHLCVBar(open=100, high=101, low=99, close=100.5,
                                    volume=10, open_time=bars[-1].open_time + timedelta(hours=2),
                                    close_time=bars[-1].open_time + timedelta(hours=3))
        bars = bars + [moderate_future]
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.MISSING_CANDLE for i in report.issues))


class TestMissingFields(unittest.TestCase):
    def test_none_timestamp_flagged_and_blocking(self):
        bars = _clean_series(80)

        class FakeBar:
            open = 100.0
            high = 101.0
            low = 99.0
            close = 100.5
            volume = 10.0
            open_time = None
            close_time = None

        bars[10] = FakeBar()
        report = validate_historical_dataset(bars, Timeframe.H1, min_bars_required=60)
        self.assertFalse(report.is_valid)
        self.assertTrue(any(i.issue_type == DataQualityIssueType.MISSING_REQUIRED_FIELD for i in report.issues))


if __name__ == "__main__":
    unittest.main()
