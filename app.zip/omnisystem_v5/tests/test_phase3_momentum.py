import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.quant.momentum import calculate_ema, calculate_momentum, calculate_rsi, calculate_roc
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_closes(closes, t0):
    bars = []
    for i, c in enumerate(closes):
        bars.append(
            OHLCVBar(open=c, high=c + 1, low=c - 1, close=c, volume=10.0,
                     open_time=t0 + timedelta(hours=i), close_time=t0 + timedelta(hours=i, minutes=59))
        )
    return bars


class TestROC(unittest.TestCase):
    def test_roc_hand_calculation(self):
        t0 = datetime.now(UTC)
        closes = [100, 101, 102, 103, 110]
        bars = _bars_from_closes(closes, t0)
        roc = calculate_roc(bars, period=4)
        self.assertAlmostEqual(roc, (110 - 100) / 100)

    def test_roc_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([100, 101], t0)
        with self.assertRaises(InsufficientDataError):
            calculate_roc(bars, period=5)

    def test_roc_invalid_period_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([100, 101], t0)
        with self.assertRaises(ValueError):
            calculate_roc(bars, period=0)

    def test_roc_zero_prior_close_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([0, 101], t0)
        with self.assertRaises(ValueError):
            calculate_roc(bars, period=1)


class TestMomentum(unittest.TestCase):
    def test_momentum_hand_calculation(self):
        t0 = datetime.now(UTC)
        closes = [100, 101, 102, 103, 110]
        bars = _bars_from_closes(closes, t0)
        self.assertAlmostEqual(calculate_momentum(bars, period=4), 10.0)

    def test_momentum_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([100], t0)
        with self.assertRaises(InsufficientDataError):
            calculate_momentum(bars, period=3)


class TestRSI(unittest.TestCase):
    def test_rsi_all_gains_is_100(self):
        t0 = datetime.now(UTC)
        closes = [100 + i for i in range(20)]  # strictly increasing
        bars = _bars_from_closes(closes, t0)
        rsi = calculate_rsi(bars, period=14)
        self.assertAlmostEqual(rsi, 100.0)

    def test_rsi_all_losses_is_0(self):
        t0 = datetime.now(UTC)
        closes = [100 - i for i in range(20)]  # strictly decreasing
        bars = _bars_from_closes(closes, t0)
        rsi = calculate_rsi(bars, period=14)
        self.assertAlmostEqual(rsi, 0.0)

    def test_rsi_flat_prices_is_50(self):
        t0 = datetime.now(UTC)
        closes = [100.0] * 20
        bars = _bars_from_closes(closes, t0)
        rsi = calculate_rsi(bars, period=14)
        self.assertAlmostEqual(rsi, 50.0)

    def test_rsi_stays_within_bounds_for_mixed_series(self):
        t0 = datetime.now(UTC)
        closes = [100, 102, 101, 105, 103, 107, 104, 108, 106, 110, 107, 111, 109, 113, 112]
        bars = _bars_from_closes(closes, t0)
        rsi = calculate_rsi(bars, period=14)
        self.assertTrue(0.0 <= rsi <= 100.0)

    def test_rsi_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([100, 101, 102], t0)
        with self.assertRaises(InsufficientDataError):
            calculate_rsi(bars, period=14)


class TestEMA(unittest.TestCase):
    def test_ema_seed_is_simple_average(self):
        t0 = datetime.now(UTC)
        closes = [10, 20, 30]
        bars = _bars_from_closes(closes, t0)
        ema = calculate_ema(bars, period=3)
        self.assertAlmostEqual(ema, 20.0)  # exactly `period` bars -> seed only

    def test_ema_smoothing_step_matches_formula(self):
        t0 = datetime.now(UTC)
        closes = [10, 20, 30, 40]
        bars = _bars_from_closes(closes, t0)
        seed = sum(closes[:3]) / 3  # 20.0
        multiplier = 2 / (3 + 1)
        expected = closes[3] * multiplier + seed * (1 - multiplier)
        ema = calculate_ema(bars, period=3)
        self.assertAlmostEqual(ema, expected, places=8)

    def test_ema_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([10, 20], t0)
        with self.assertRaises(InsufficientDataError):
            calculate_ema(bars, period=5)

    def test_ema_invalid_period_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([10, 20], t0)
        with self.assertRaises(ValueError):
            calculate_ema(bars, period=0)


if __name__ == "__main__":
    unittest.main()
