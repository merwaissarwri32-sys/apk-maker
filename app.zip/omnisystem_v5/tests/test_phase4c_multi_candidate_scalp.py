import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.enums import ScalpStatus
from omnisystem_v5.intelligence.event_risk import EventRiskContext, EventRiskStatus
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig, detect_scalp_candidate, detect_scalp_candidates
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _envelope(bars, timeframe=Timeframe.H1):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))


def _build_contexts(bars, timeframe=Timeframe.H1):
    env = _envelope(bars, timeframe)
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _range_then_breakout_bars(t0):
    """Same hand-verified construction used in test_phase4_scalp_engine.py
    - known to produce a valid BULLISH candidate. Imported logic is
    duplicated intentionally here to keep this test file self-contained."""
    bars = []
    price = 100.0
    for i in range(60):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5))
    for i in range(60, 65):
        price += 3.0
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 2, price - 1, price + 1, v=30))
    for i in range(65, 80):
        price -= 0.8
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price - 0.3, v=15))
    for i in range(80, 100):
        price += 1.0 if i % 2 == 0 else -1.0
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2))
    return bars


class TestBackwardCompatibility(unittest.TestCase):
    def test_singular_api_unchanged_on_known_scenario(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        self.assertEqual(len(result.candidates), 1)


class TestMultiCandidateApi(unittest.TestCase):
    def test_plural_api_returns_same_single_candidate_by_default(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        self.assertLessEqual(len(result.candidates), 1)

    def test_plural_api_does_not_reject_on_balanced_evidence(self):
        """The plural API evaluates each side independently — it must never
        apply the singular API's 'too balanced' cross-comparison rejection."""
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(), max_candidates=2)
        for c in result.candidates:
            self.assertNotIn("BALANCED", str(result.rejection_reasons))

    def test_max_candidates_caps_output(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(), max_candidates=1)
        self.assertLessEqual(len(result.candidates), 1)

    def test_ranking_is_deterministic_by_confluence_then_rr(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(), max_candidates=5)
        if len(result.candidates) > 1:
            confluences = []
            for c in result.candidates:
                from omnisystem_v5.intelligence.enums import alignment_rank, AlignmentLevel
                confluences.append(sum(1 for lv in c.evidence.as_dict().values() if alignment_rank(lv) >= alignment_rank(AlignmentLevel.MODERATE)))
            self.assertEqual(confluences, sorted(confluences, reverse=True))

    def test_no_candidates_returns_no_valid_scalp_with_reasons(self):
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = [_bar(t0 + timedelta(hours=i), 100.0, 100.5, 99.5, 100.0) for i in range(90)]
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertTrue(len(result.rejection_reasons) > 0)

    def test_zone_identified_vs_confirmed_separation_preserved(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidates("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        for c in result.candidates:
            self.assertEqual(c.status, ScalpStatus.ZONE_IDENTIFIED)
            self.assertTrue(c.confirmation_required)


class TestEventRiskIntegration(unittest.TestCase):
    def test_confirmed_event_risk_blocks_scalp(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        event_risk = EventRiskContext(
            symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_AVAILABLE, checked_at=datetime.now(UTC),
            high_impact_event_near=True, window_minutes=30,
        )
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(), event_risk=event_risk)
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)

    def test_unavailable_event_risk_does_not_block_but_is_noted(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        event_risk = EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_UNAVAILABLE, checked_at=datetime.now(UTC))
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(), event_risk=event_risk)
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        self.assertTrue(any("event risk" in r.lower() for r in result.candidates[0].reasons))


if __name__ == "__main__":
    unittest.main()
