"""Phase 12 - domain, identity, localization, sources (REAL Phase 10/11 objects) and qualification. All data is SYNTHETIC."""
import dataclasses
import json
import unittest
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from omnisystem_v5.alerts.construction import build_alert
from omnisystem_v5.alerts.enums import (ALERT_TRANSITIONS, DELIVERY_TRANSITIONS, AlertDedupVerdict, AlertSeverity, AlertSourceKind, AlertState,
                                        AlertType, DeliveryStatus, QualificationOutcome)
from omnisystem_v5.alerts.errors import AlertConfigError, AlertValidationError
from omnisystem_v5.alerts.i18n import (EN_ALERTS, FA_ALERTS, REQUIRED_PARAMS, SEVERITY_KEY, AlertMessageKey as K, alert_catalog, amsg, placeholders)
from omnisystem_v5.alerts.identity import compute_identity
from omnisystem_v5.alerts.model import Alert, AlertCandidate, AlertContext, AlertIdentity, AlertPriority, AlertSource
from omnisystem_v5.alerts.policy import AlertPolicy, QualificationPolicy, SeverityPolicy
from omnisystem_v5.alerts.qualification import Qualified, Rejection, qualify
from omnisystem_v5.alerts.sources import (SUPPORTED_EVENT_KINDS, CatalogContextResolver, map_events, map_report, map_signal, map_snapshot)
from omnisystem_v5.marketdata.i18n import EN, FA, MessageKey, StructuredMessage, msg
from omnisystem_v5.scanner.enums import SignalState
from omnisystem_v5.tests.alerts_fixtures import real_outage_world, real_scan_world

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)


def cand(state="UNAVAILABLE", type_=AlertType.PROVIDER_HEALTH, key="obs-1", source=AlertSourceKind.DATA_SNAPSHOT, **over):
    base = dict(alert_type=type_, source=AlertSource(source, "md"), context=AlertContext(provider="p1"),
                headline=amsg(K.PROVIDER_STATE, provider="p1", state=state), family=(("provider", "p1"),), state=(("state", state),),
                observation_key=key, observed_at=T0, details=(("state", state),))
    base.update(over)
    return AlertCandidate(**base)


def alert(sev=AlertSeverity.CRITICAL, now=T0, **kw):
    return build_alert(cand(**kw), sev, now)


class TestEnums(unittest.TestCase):
    def test_severity_is_totally_ordered(self):
        s = [AlertSeverity.INFO, AlertSeverity.NOTICE, AlertSeverity.WARNING, AlertSeverity.CRITICAL]
        self.assertEqual([x.rank for x in s], [0, 1, 2, 3])
        self.assertTrue(AlertSeverity.CRITICAL.at_least(AlertSeverity.CRITICAL))
        self.assertFalse(AlertSeverity.NOTICE.at_least(AlertSeverity.WARNING))

    def test_alert_state_machine_only_allows_active_expired_cycle(self):
        self.assertEqual(ALERT_TRANSITIONS[AlertState.ACTIVE], {AlertState.EXPIRED})
        self.assertEqual(ALERT_TRANSITIONS[AlertState.EXPIRED], {AlertState.ACTIVE})

    def test_delivery_state_machine_is_total_and_terminals_are_final(self):
        self.assertEqual(set(DELIVERY_TRANSITIONS), set(DeliveryStatus))
        for st in DeliveryStatus:
            self.assertEqual(st.terminal, DELIVERY_TRANSITIONS[st] == frozenset(), st)
        self.assertNotIn(DeliveryStatus.DELIVERED, DELIVERY_TRANSITIONS[DeliveryStatus.FAILED])

    def test_only_four_verdicts_notify(self):
        self.assertEqual({v for v in AlertDedupVerdict if v.notifies},
                         {AlertDedupVerdict.NEW, AlertDedupVerdict.MATERIAL_CHANGE, AlertDedupVerdict.RENOTIFY, AlertDedupVerdict.REDELIVER})


class TestAlertContract(unittest.TestCase):
    def test_valid_alert_is_constructed_and_active(self):
        a = alert()
        self.assertEqual(a.state, AlertState.ACTIVE)
        self.assertEqual(a.detail("state"), "UNAVAILABLE")
        self.assertRegex(a.alert_id, r"^[0-9a-f]{20}\.[0-9a-f]{20}$")

    def test_invalid_inputs_never_become_alerts(self):
        bad = [dict(observed_at=datetime(2026, 1, 1)), dict(key=""), dict(key="a\x00b"), dict(family=()),
               dict(context="BTC"), dict(headline="plain text"), dict(headline=StructuredMessage("not-an-enum")),
               dict(details=(("x", float("nan")),)), dict(details=(("x", 1), ("x", 2))), dict(details=(("x", object()),)),
               dict(priority="high"), dict(source="scanner")]
        for over in bad:
            with self.subTest(over=list(over)):
                with self.assertRaises((AlertValidationError, AttributeError, TypeError)):
                    cand(**over)

    def test_control_characters_in_untrusted_strings_are_refused(self):
        with self.assertRaises(AlertValidationError):
            AlertContext(symbol="BTC/USDT\n[inject]")
        with self.assertRaises(AlertValidationError):
            AlertSource(AlertSourceKind.DATA_EVENT, "x" * 65)

    def test_alert_rejects_wrong_types(self):
        a = alert()
        for field, value in (("severity", "CRITICAL"), ("state", "ACTIVE"), ("identity", "x"), ("created_at", datetime(2026, 1, 1))):
            with self.subTest(field=field):
                with self.assertRaises(AlertValidationError):
                    dataclasses.replace(a, **{field: value})

    def test_alert_is_immutable(self):
        with self.assertRaises(dataclasses.FrozenInstanceError):
            alert().severity = AlertSeverity.INFO

    def test_priority_validation(self):
        AlertPriority("COMPUTATIONAL_PRIORITY_NOT_PROBABILITY", (("a", 1),))
        for bad in ((("a", "x"),), (("a", True),), (("a",),)):
            with self.assertRaises(AlertValidationError):
                AlertPriority("k", bad)

    def test_canonical_serialisation_is_stable_sorted_and_parseable(self):
        a = alert()
        j = a.to_json()
        self.assertEqual(j, alert().to_json())
        self.assertEqual(json.loads(j)["identity"]["family"], a.identity.family)
        self.assertEqual(list(json.loads(j)), sorted(json.loads(j)))

    def test_the_core_alert_is_language_neutral(self):
        a = alert()
        self.assertNotIn("now", a.to_json().replace("alert.provider.state", ""))          # only the key + params, no rendered sentence
        self.assertIn("alert.provider.state", a.to_json())
        self.assertNotIn("is now", a.to_json())


class TestIdentity(unittest.TestCase):
    def test_identity_is_deterministic_and_independent_of_time_and_source(self):
        a = alert(now=T0)
        b = alert(now=T0 + timedelta(days=30), source=AlertSourceKind.DATA_EVENT, key="different-observation")
        self.assertEqual(a.identity, b.identity)
        for _ in range(200):
            self.assertEqual(compute_identity(AlertType.PROVIDER_HEALTH, (("provider", "p1"),), (("state", "UNAVAILABLE"),)), a.identity)

    def test_state_change_changes_fingerprint_not_family(self):
        a, b = alert(state="UNAVAILABLE"), alert(state="DEGRADED")
        self.assertEqual(a.identity.family, b.identity.family)
        self.assertNotEqual(a.identity.fingerprint, b.identity.fingerprint)

    def test_different_family_fields_or_type_change_the_family(self):
        base = compute_identity(AlertType.PROVIDER_HEALTH, (("provider", "p1"),), ())
        self.assertNotEqual(base.family, compute_identity(AlertType.PROVIDER_HEALTH, (("provider", "p2"),), ()).family)
        self.assertNotEqual(base.family, compute_identity(AlertType.PROVIDER_FAULT, (("provider", "p1"),), ()).family)

    def test_pair_order_does_not_matter(self):
        a = compute_identity(AlertType.SIGNAL, (("symbol", "X"), ("direction", "LONG")), (("f", "1"),))
        b = compute_identity(AlertType.SIGNAL, (("direction", "LONG"), ("symbol", "X")), (("f", "1"),))
        self.assertEqual(a, b)

    def test_malformed_identity_is_refused(self):
        for bad in (("x" * 20, "y" * 20), ("a" * 19, "b" * 20), ("A" * 20, "b" * 20)):
            with self.assertRaises(AlertValidationError):
                AlertIdentity(*bad)


class TestLocalization(unittest.TestCase):
    def test_every_key_is_in_both_catalogs_with_identical_placeholders(self):
        for k in K:
            with self.subTest(key=k.value):
                self.assertIn(k, EN_ALERTS)
                self.assertIn(k, FA_ALERTS)
                self.assertEqual(placeholders(EN_ALERTS[k]), REQUIRED_PARAMS[k])
                self.assertEqual(placeholders(FA_ALERTS[k]), REQUIRED_PARAMS[k])
        self.assertEqual(set(EN_ALERTS), set(K))
        self.assertEqual(set(FA_ALERTS), set(K))

    def test_alert_keys_are_disjoint_from_phase11_keys(self):
        self.assertFalse({k.value for k in K} & {k.value for k in MessageKey})

    def test_en_and_fa_render_differently_from_the_same_structured_message(self):
        c, m = alert_catalog(), amsg(K.PROVIDER_STATE, provider="p1", state="UNAVAILABLE")
        en, fa = c.render(m, EN), c.render(m, FA)
        self.assertEqual(en.text, "Data provider p1 is now UNAVAILABLE")
        self.assertIn("p1", fa.text)
        self.assertNotEqual(en.text, fa.text)
        self.assertFalse(en.fallback or fa.fallback)

    def test_phase11_keys_still_render_through_the_merged_catalog(self):
        r = alert_catalog().render(msg(MessageKey.PROVIDER_HEALTHY), FA)
        self.assertFalse(r.fallback)

    def test_missing_key_falls_back_to_the_neutral_string_never_raises(self):
        r = alert_catalog().render(StructuredMessage(K.SIGNAL_DISCLAIMER, ()), __import__("omnisystem_v5.marketdata.i18n", fromlist=["Locale"]).Locale("de"))
        self.assertEqual(r.text, EN_ALERTS[K.SIGNAL_DISCLAIMER])                      # de -> default language chain
        orphan = alert_catalog().render(StructuredMessage(SEVERITY_KEY["INFO"], (("x", "1"),)), EN)
        self.assertFalse(orphan.fallback)

    def test_message_with_wrong_parameters_is_refused(self):
        for params in ({}, {"provider": "p"}, {"provider": "p", "state": "s", "extra": "x"}):
            with self.assertRaises(AlertValidationError):
                amsg(K.PROVIDER_STATE, **params)

    def test_signal_disclaimer_never_promises_profit(self):
        for text in (EN_ALERTS[K.SIGNAL_DISCLAIMER], FA_ALERTS[K.SIGNAL_DISCLAIMER]):
            self.assertNotIn("guaranteed profit", text.lower())
        self.assertIn("no guarantee", EN_ALERTS[K.SIGNAL_DISCLAIMER])


class TestSignalSource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report, cls.catalog, cls.snap, cls.events = real_scan_world()

    def test_real_emitted_signals_become_signal_candidates_without_recomputation(self):
        res = map_report(self.report, CatalogContextResolver(self.catalog))
        sigs = [c for c in res.candidates if c.alert_type == AlertType.SIGNAL]
        self.assertEqual({c.context.symbol: c.context.direction for c in sigs}, {"BTC/USDT": "LONG", "ETH/USDT": "SHORT"})
        for c, s in zip(sigs, self.report.emitted):
            r = s.decision.risk_result
            self.assertEqual(c.detail("risk_verdict"), r.decision.value)
            self.assertEqual(c.detail("entry"), r.entry)
            self.assertEqual(c.detail("stop_loss"), r.stop_loss)
            self.assertEqual(c.detail("decision_outcome"), s.decision.outcome.value)
            self.assertEqual(c.state, (("fingerprint", s.fingerprint),))

    def test_catalog_context_resolves_asset_class_and_venue(self):
        c = map_report(self.report, CatalogContextResolver(self.catalog)).candidates[0]
        self.assertEqual((c.context.asset_class, c.context.venue, c.context.instrument), ("CRYPTO", "TESTX", f"CRYPTO:{c.context.symbol}"))
        self.assertIsNone(map_report(self.report).candidates[0].context.asset_class)          # no resolver -> no invented context

    def test_priority_is_carried_unchanged_and_labelled_computational(self):
        s = self.report.emitted[0]
        c = map_signal(s)
        self.assertEqual(c.priority.kind, "COMPUTATIONAL_PRIORITY_NOT_PROBABILITY")
        self.assertEqual(c.priority.components, tuple((a, b) for a, b in s.priority.components))

    def test_no_probability_confidence_or_sizing_is_invented_or_leaked(self):
        keys = {k for c in map_report(self.report).candidates for k, _ in c.details}
        for banned in ("probability", "confidence", "score", "win_rate", "position_size", "position_notional", "risk_amount", "equity"):
            self.assertNotIn(banned, keys)

    def test_non_emitted_signals_are_upstream_rejections_not_alerts(self):
        from omnisystem_v5.scanner.signals import transition
        from omnisystem_v5.tests.alerts_fixtures import real_suppressed_report
        rep2 = real_suppressed_report()
        self.assertEqual((len(rep2.emitted), len(rep2.suppressed)), (0, 2))                    # the REAL scanner suppressed them
        self.assertTrue(all(s.state == SignalState.SUPPRESSED for s in rep2.suppressed))
        expired = transition(self.report.emitted[0], SignalState.EXPIRED, reason="expired")
        for label, fake in (("suppressed", rep2), ("expired", dataclasses.replace(self.report, emitted=(), suppressed=(), expired=(expired,)))):
            with self.subTest(kind=label):
                res = map_report(fake)
                self.assertEqual([c for c in res.candidates if c.alert_type == AlertType.SIGNAL], [])
                self.assertTrue(res.rejections)
                self.assertEqual({r.outcome for r in res.rejections}, {QualificationOutcome.REJECTED_UPSTREAM})

    def test_malformed_signals_and_reports_fail_closed(self):
        bad_sig = SimpleNamespace(state=SimpleNamespace(value="EMITTED"), fingerprint="fp", decision=None)
        res = map_report(SimpleNamespace(emitted=(bad_sig,), suppressed=(), expired=(), health=self.report.health, health_reasons=(),
                                         started_at=self.report.started_at, universe_size=0))
        self.assertEqual([r.outcome for r in res.rejections], [QualificationOutcome.REJECTED_MALFORMED])
        self.assertEqual(map_report(object()).rejections[0].outcome, QualificationOutcome.REJECTED_MALFORMED)
        with self.assertRaises(Exception):
            map_signal(bad_sig)

    def test_a_non_actionable_risk_result_cannot_become_a_signal_alert(self):
        s = self.report.emitted[0]
        risky = SimpleNamespace(state=s.state, fingerprint=s.fingerprint, descriptor=s.descriptor, emitted_at=s.emitted_at, first_seen_at=s.first_seen_at,
                                verdict=s.verdict, seen_count=1, priority=None,
                                decision=SimpleNamespace(outcome=s.decision.outcome, risk_result=SimpleNamespace(is_actionable=False)))
        with self.assertRaises(AlertValidationError):
            map_signal(risky)

    def test_healthy_cycle_is_not_mapped_by_default_but_can_be(self):
        self.assertEqual([c for c in map_report(self.report).candidates if c.alert_type == AlertType.SYSTEM_HEALTH], [])
        inc = [c for c in map_report(self.report, include_healthy=True).candidates if c.alert_type == AlertType.SYSTEM_HEALTH]
        self.assertEqual([c.detail("state") for c in inc], ["HEALTHY"])
        self.assertEqual(inc[0].source.kind, AlertSourceKind.SCANNER_CYCLE)

    def test_mapping_is_deterministic(self):
        self.assertEqual(map_report(self.report, CatalogContextResolver(self.catalog)), map_report(self.report, CatalogContextResolver(self.catalog)))


class TestSnapshotAndEventSources(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snap, cls.events = real_outage_world()

    def test_outage_snapshot_yields_provider_instrument_and_rollup_candidates(self):
        res = map_snapshot(self.snap)
        by = {(c.alert_type, c.detail("state")) for c in res.candidates}
        self.assertIn((AlertType.PROVIDER_HEALTH, "UNAVAILABLE"), by)
        self.assertTrue({s for t, s in by if t == AlertType.SYSTEM_HEALTH} & {"DEGRADED", "UNAVAILABLE"})
        self.assertNotIn((AlertType.PROVIDER_HEALTH, "HEALTHY"), by)
        prov = next(c for c in res.candidates if c.alert_type == AlertType.PROVIDER_HEALTH)
        self.assertEqual(prov.context.provider, "cryptofeed")
        self.assertTrue(prov.reasons and isinstance(prov.reasons[0], StructuredMessage))              # Phase 11 reason reused, not re-worded
        self.assertIn("provider.evidence", dict(prov.evidence))

    def test_include_healthy_adds_the_healthy_provider(self):
        states = {(c.context.provider, c.detail("state")) for c in map_snapshot(self.snap, include_healthy=True).candidates if c.alert_type == AlertType.PROVIDER_HEALTH}
        self.assertIn(("fxfeed", "HEALTHY"), states)

    def test_malformed_snapshot_fails_closed(self):
        self.assertEqual(map_snapshot(object()).rejections[0].outcome, QualificationOutcome.REJECTED_MALFORMED)

    def test_snapshot_and_event_views_of_one_outage_share_one_identity(self):
        snap_c = next(c for c in map_snapshot(self.snap).candidates if c.alert_type == AlertType.PROVIDER_HEALTH)
        ev_c = [c for c in map_events(self.events, strict=False).candidates
                if c.alert_type == AlertType.PROVIDER_HEALTH and c.detail("state") == "UNAVAILABLE"]
        self.assertTrue(ev_c)
        a = compute_identity(snap_c.alert_type, snap_c.family, snap_c.state)
        b = compute_identity(ev_c[0].alert_type, ev_c[0].family, ev_c[0].state)
        self.assertEqual(a, b)
        self.assertNotEqual(snap_c.source.kind, ev_c[0].source.kind)

    def test_strict_mode_rejects_unsupported_events_and_lenient_mode_counts_them(self):
        strict, lenient = map_events(self.events), map_events(self.events, strict=False)
        unsupported = [e for e in self.events if getattr(e.kind, "value", e.kind) not in SUPPORTED_EVENT_KINDS]
        self.assertTrue(unsupported)
        self.assertEqual(len([r for r in strict.rejections if r.outcome == QualificationOutcome.REJECTED_UNSUPPORTED]), len(unsupported))
        self.assertEqual((lenient.skipped, lenient.rejections), (len(unsupported), ()))
        self.assertEqual(strict.candidates, lenient.candidates)

    def test_malformed_events_are_rejected(self):
        good = next(e for e in self.events if getattr(e.kind, "value", e.kind) == "PROVIDER_STATE_CHANGED")
        nosubject = dataclasses.replace(good, symbol=None)
        nodetail = dataclasses.replace(good, detail=())
        res = map_events([object(), nosubject, nodetail])
        self.assertEqual([r.outcome for r in res.rejections], [QualificationOutcome.REJECTED_MALFORMED] * 3)

    def test_event_observation_keys_are_replay_stable(self):
        self.assertEqual([c.observation_key for c in map_events(self.events, strict=False).candidates],
                         [c.observation_key for c in map_events(self.events, strict=False).candidates])


class TestQualification(unittest.TestCase):
    def test_severity_tables_cover_every_real_state(self):
        from omnisystem_v5.marketdata.health import InstrumentState, ProviderState
        from omnisystem_v5.marketdata.state import RollupState
        from omnisystem_v5.scanner.enums import CycleHealth
        p = SeverityPolicy()
        self.assertEqual({k for k, _ in p.provider_by_state}, {s.value for s in ProviderState})
        self.assertEqual({k for k, _ in p.instrument_by_state}, {s.value for s in InstrumentState})
        self.assertLessEqual({s.value for s in RollupState} | {s.value for s in CycleHealth}, {k for k, _ in p.system_by_state})

    def test_qualified_candidate_gets_policy_severity(self):
        q = qualify(cand(state="UNAVAILABLE"), AlertPolicy())
        self.assertEqual(q, Qualified(AlertSeverity.CRITICAL))
        self.assertEqual(qualify(cand(state="DEGRADED"), AlertPolicy()), Qualified(AlertSeverity.WARNING))

    def test_below_minimum_severity_is_suppressed_by_policy(self):
        r = qualify(cand(state="HEALTHY"), AlertPolicy())
        self.assertIsInstance(r, Rejection)
        self.assertEqual(r.outcome, QualificationOutcome.SUPPRESSED_BY_POLICY)
        self.assertEqual(r.message.key, K.REJECT_BELOW_MIN_SEVERITY)
        self.assertEqual(qualify(cand(state="HEALTHY"), AlertPolicy(qualification=QualificationPolicy(min_severity=AlertSeverity.INFO))), Qualified(AlertSeverity.INFO))

    def test_unknown_fact_has_no_severity_and_is_unsupported(self):
        r = qualify(cand(state="SOMETHING_NEW"), AlertPolicy())
        self.assertEqual((r.outcome, r.message.key), (QualificationOutcome.REJECTED_UNSUPPORTED, K.REJECT_UNSUPPORTED))

    def test_disabled_source_is_suppressed(self):
        pol = AlertPolicy(qualification=QualificationPolicy(enabled_sources=frozenset({AlertSourceKind.SCANNER_SIGNAL})))
        r = qualify(cand(), pol)
        self.assertEqual((r.outcome, r.message.key), (QualificationOutcome.SUPPRESSED_BY_POLICY, K.REJECT_SOURCE_DISABLED))

    def test_invalid_policies_fail_closed_at_construction(self):
        with self.assertRaises(AlertConfigError):
            SeverityPolicy(signal_by_risk=(("VALID", "NOTICE"),))
        with self.assertRaises(AlertConfigError):
            SeverityPolicy(provider_by_state=(("A", AlertSeverity.INFO), ("A", AlertSeverity.INFO)))
        with self.assertRaises(AlertConfigError):
            QualificationPolicy(enabled_sources=frozenset())
        with self.assertRaises(AlertConfigError):
            QualificationPolicy(min_severity="NOTICE")

    def test_severity_priority_and_urgency_are_distinct_types(self):
        from omnisystem_v5.alerts.enums import NotificationUrgency
        self.assertEqual(len({AlertSeverity, AlertPriority, NotificationUrgency}), 3)
        self.assertNotIn("priority", {f.name for f in dataclasses.fields(AlertSeverity)} if dataclasses.is_dataclass(AlertSeverity) else set())


if __name__ == "__main__":
    unittest.main()
