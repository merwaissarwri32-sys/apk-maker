import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.contracts import ExecutionConfig
from omnisystem_v5.validation.enums import ExitReason, SlippageModel
from omnisystem_v5.validation.execution import (
    adjusted_entry_price,
    adjusted_exit_price,
    calculate_fee,
    find_entry_fill,
    simulate_position_lifecycle,
)

UTC = timezone.utc
T0 = datetime.now(UTC)


def _bar(i, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v,
                     open_time=T0 + timedelta(hours=i), close_time=T0 + timedelta(hours=i + 1))


class TestPriceAdjustment(unittest.TestCase):
    def test_no_cost_config_leaves_price_unchanged(self):
        config = ExecutionConfig()
        adjusted, slip = adjusted_entry_price(100.0, Direction.LONG, config)
        self.assertEqual(adjusted, 100.0)
        self.assertEqual(slip, 0.0)

    def test_long_entry_fills_higher_with_spread(self):
        config = ExecutionConfig(spread_pct=0.1)
        adjusted, _ = adjusted_entry_price(100.0, Direction.LONG, config)
        self.assertGreater(adjusted, 100.0)

    def test_short_entry_fills_lower_with_spread(self):
        config = ExecutionConfig(spread_pct=0.1)
        adjusted, _ = adjusted_entry_price(100.0, Direction.SHORT, config)
        self.assertLess(adjusted, 100.0)

    def test_long_exit_fills_lower_with_spread(self):
        config = ExecutionConfig(spread_pct=0.1)
        adjusted, _ = adjusted_exit_price(100.0, Direction.LONG, config)
        self.assertLess(adjusted, 100.0)

    def test_short_exit_fills_higher_with_spread(self):
        config = ExecutionConfig(spread_pct=0.1)
        adjusted, _ = adjusted_exit_price(100.0, Direction.SHORT, config)
        self.assertGreater(adjusted, 100.0)

    def test_fixed_pct_slippage_always_against_trader(self):
        config = ExecutionConfig(slippage_model=SlippageModel.FIXED_PCT, slippage_value=0.5)
        long_entry, _ = adjusted_entry_price(100.0, Direction.LONG, config)
        short_entry, _ = adjusted_entry_price(100.0, Direction.SHORT, config)
        self.assertGreater(long_entry, 100.0)
        self.assertLess(short_entry, 100.0)

    def test_fixed_ticks_slippage(self):
        config = ExecutionConfig(slippage_model=SlippageModel.FIXED_TICKS, slippage_value=0.25)
        adjusted, slip = adjusted_entry_price(100.0, Direction.LONG, config)
        self.assertAlmostEqual(slip, 0.25)
        self.assertAlmostEqual(adjusted, 100.25)

    def test_fee_calculation(self):
        config = ExecutionConfig(fee_pct_per_side=0.05)
        fee = calculate_fee(1000.0, config)
        self.assertAlmostEqual(fee, 0.5)

    def test_zero_fee_config(self):
        config = ExecutionConfig()
        self.assertEqual(calculate_fee(1000.0, config), 0.0)


class TestEntryFill(unittest.TestCase):
    def test_fill_found_on_first_overlapping_bar(self):
        config = ExecutionConfig(entry_timeout_bars=10)
        bars = [_bar(0, 105, 106, 104, 105.5), _bar(1, 99, 100, 98, 99.5)]
        fill, consumed = find_entry_fill(bars, entry_bottom=98.5, entry_top=99.5, direction=Direction.LONG, config=config)
        self.assertIsNotNone(fill)
        self.assertEqual(consumed, 2)

    def test_long_fill_uses_worse_edge_of_zone(self):
        config = ExecutionConfig()
        bars = [_bar(0, 99, 100, 98, 99.5)]
        fill, _ = find_entry_fill(bars, entry_bottom=98.0, entry_top=99.0, direction=Direction.LONG, config=config)
        self.assertAlmostEqual(fill.price, 99.0)

    def test_short_fill_uses_worse_edge_of_zone(self):
        config = ExecutionConfig()
        bars = [_bar(0, 99, 100, 98, 99.5)]
        fill, _ = find_entry_fill(bars, entry_bottom=98.0, entry_top=99.0, direction=Direction.SHORT, config=config)
        self.assertAlmostEqual(fill.price, 98.0)

    def test_no_fill_within_timeout_returns_none(self):
        config = ExecutionConfig(entry_timeout_bars=3)
        bars = [_bar(i, 200, 201, 199, 200.5) for i in range(5)]
        fill, consumed = find_entry_fill(bars, entry_bottom=98.0, entry_top=99.0, direction=Direction.LONG, config=config)
        self.assertIsNone(fill)
        self.assertEqual(consumed, 3)

    def test_entry_timeout_bars_bounds_the_search(self):
        config = ExecutionConfig(entry_timeout_bars=2)
        bars = [_bar(0, 200, 201, 199, 200.5), _bar(1, 200, 201, 199, 200.5), _bar(2, 99, 100, 98, 99.5)]
        fill, consumed = find_entry_fill(bars, entry_bottom=98.0, entry_top=99.0, direction=Direction.LONG, config=config)
        self.assertIsNone(fill)


class TestPositionLifecycle(unittest.TestCase):
    def test_stop_loss_hit(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 101, 99, 100.5), _bar(1, 99, 100, 90, 91)]
        result = simulate_position_lifecycle(bars, Direction.LONG, entry_price=100.0, stop_loss=95.0, take_profit=110.0, config=config)
        self.assertEqual(result["exit_reason"], ExitReason.STOP_LOSS)
        self.assertEqual(result["duration_bars"], 2)

    def test_take_profit_hit(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 101, 99, 100.5), _bar(1, 108, 112, 107, 111)]
        result = simulate_position_lifecycle(bars, Direction.LONG, entry_price=100.0, stop_loss=95.0, take_profit=110.0, config=config)
        self.assertEqual(result["exit_reason"], ExitReason.TAKE_PROFIT)

    def test_ambiguous_bar_assumes_stop_loss_first(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 115, 90, 105)]
        result = simulate_position_lifecycle(bars, Direction.LONG, entry_price=100.0, stop_loss=95.0, take_profit=110.0, config=config)
        self.assertEqual(result["exit_reason"], ExitReason.STOP_LOSS)

    def test_short_position_stop_and_target(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 106, 99, 101)]
        result = simulate_position_lifecycle(bars, Direction.SHORT, entry_price=100.0, stop_loss=105.0, take_profit=90.0, config=config)
        self.assertEqual(result["exit_reason"], ExitReason.STOP_LOSS)

    def test_no_resolution_leaves_position_open(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 101, 99, 100.5), _bar(1, 100, 102, 98, 101)]
        result = simulate_position_lifecycle(bars, Direction.LONG, entry_price=100.0, stop_loss=90.0, take_profit=120.0, config=config)
        self.assertIsNone(result["exit_fill"])
        self.assertIsNone(result["exit_reason"])
        self.assertEqual(result["duration_bars"], 2)

    def test_mae_mfe_tracked_correctly_long(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 103, 97, 101), _bar(1, 101, 106, 99, 105)]
        result = simulate_position_lifecycle(bars, Direction.LONG, entry_price=100.0, stop_loss=90.0, take_profit=120.0, config=config)
        self.assertAlmostEqual(result["mae"], 3.0)
        self.assertAlmostEqual(result["mfe"], 6.0)

    def test_mae_mfe_tracked_correctly_short(self):
        config = ExecutionConfig()
        bars = [_bar(0, 100, 103, 97, 101)]
        result = simulate_position_lifecycle(bars, Direction.SHORT, entry_price=100.0, stop_loss=110.0, take_profit=80.0, config=config)
        self.assertAlmostEqual(result["mae"], 3.0)
        self.assertAlmostEqual(result["mfe"], 3.0)


if __name__ == "__main__":
    unittest.main()
