import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.reaction import evaluate_confirmation
from omnisystem_v5.intelligence.scalp_schema import PriceZone, ScalpCandidate, ScalpCandidateEvidence
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _evidence(level=AlignmentLevel.MODERATE):
    return ScalpCandidateEvidence(
        structure_alignment=level, liquidity_alignment=level, momentum_alignment=level,
        volume_alignment=level, volatility_alignment=level, vwap_alignment=level,
        fvg_alignment=level, risk_reward_quality=level, multi_timeframe_alignment=level,
    )


def _candidate(direction=DirectionBias.BULLISH, entry=(99.0, 101.0), invalidation=95.0, target=115.0,
               status=ScalpStatus.ZONE_IDENTIFIED):
    now = datetime.now(UTC)
    entry_zone = PriceZone(bottom=entry[0], top=entry[1])
    mid_entry = (entry[0] + entry[1]) / 2
    if direction == DirectionBias.BULLISH:
        inv_zone = PriceZone(bottom=invalidation, top=invalidation)
        tgt_zone = PriceZone(bottom=target, top=target)
        rr = calculate_risk_reward(entry=mid_entry, invalidation=invalidation, target=target)
    else:
        inv_zone = PriceZone(bottom=invalidation, top=invalidation)
        tgt_zone = PriceZone(bottom=target, top=target)
        rr = calculate_risk_reward(entry=mid_entry, invalidation=invalidation, target=target)
    return ScalpCandidate(
        symbol="BTCUSDT", horizon=Horizon.SCALP, direction=direction, timeframe=Timeframe.H1,
        calculated_at=now, expected_holding_period=ExpectedHoldingPeriod.MINUTES_TO_HOURS,
        preferred_entry_zone=entry_zone, invalidation_zone=inv_zone, target_zones=(tgt_zone,),
        risk_reward=rr, evidence=_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, data_quality="OK", confirmation_required=True, status=status,
    )


class TestReactionConfirmation(unittest.TestCase):
    def test_no_bars_leaves_status_unchanged(self):
        c = _candidate()
        updated = evaluate_confirmation(c, [])
        self.assertEqual(updated.status, ScalpStatus.ZONE_IDENTIFIED)

    def test_terminal_status_never_changes(self):
        c = _candidate(status=ScalpStatus.CONFIRMED)
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 50, 51, 49, 50)]  # wildly irrelevant bars
        updated = evaluate_confirmation(c, bars)
        self.assertEqual(updated.status, ScalpStatus.CONFIRMED)

    def test_price_never_enters_zone_stays_identified(self):
        c = _candidate(entry=(99.0, 101.0), invalidation=95.0, target=115.0)
        t0 = datetime.now(UTC)
        # bars stay well above the entry zone, never dip into [99,101]
        bars = [_bar(t0 + timedelta(hours=i), 110, 112, 108, 111) for i in range(3)]
        updated = evaluate_confirmation(c, bars)
        self.assertEqual(updated.status, ScalpStatus.ZONE_IDENTIFIED)

    def test_invalidation_breached_before_entry_marks_invalidated(self):
        c = _candidate(direction=DirectionBias.BULLISH, entry=(99.0, 101.0), invalidation=95.0, target=115.0)
        t0 = datetime.now(UTC)
        # price crashes straight through invalidation without ever touching entry zone
        bars = [_bar(t0, 105, 106, 90, 91)]
        updated = evaluate_confirmation(c, bars)
        self.assertEqual(updated.status, ScalpStatus.INVALIDATED)
        self.assertFalse(updated.confirmation_required)

    def test_enters_zone_but_no_reaction_yet_is_pending(self):
        c = _candidate(direction=DirectionBias.BULLISH, entry=(99.0, 101.0), invalidation=95.0, target=115.0)
        t0 = datetime.now(UTC)
        # touches the zone but closes back inside it, no confirmation close above top
        bars = [_bar(t0, 102, 102.5, 99.5, 100.0)]
        updated = evaluate_confirmation(c, bars)
        self.assertEqual(updated.status, ScalpStatus.CONFIRMATION_PENDING)

    def test_enters_zone_and_reaction_confirms_bullish(self):
        c = _candidate(direction=DirectionBias.BULLISH, entry=(99.0, 101.0), invalidation=95.0, target=115.0)
        t0 = datetime.now(UTC)
        touch = _bar(t0, 100, 101.5, 99.0, 100.5)
        confirm = _bar(t0 + timedelta(hours=1), 100.5, 103, 100, 102.5)  # closes above zone top (101)
        updated = evaluate_confirmation(c, [touch, confirm])
        self.assertEqual(updated.status, ScalpStatus.CONFIRMED)
        self.assertFalse(updated.confirmation_required)

    def test_enters_zone_and_reaction_confirms_bearish(self):
        c = _candidate(direction=DirectionBias.BEARISH, entry=(99.0, 101.0), invalidation=105.0, target=85.0)
        t0 = datetime.now(UTC)
        touch = _bar(t0, 100, 101.0, 99.5, 99.8)
        confirm = _bar(t0 + timedelta(hours=1), 99.8, 100, 97, 97.5)  # closes below zone bottom (99)
        updated = evaluate_confirmation(c, [touch, confirm])
        self.assertEqual(updated.status, ScalpStatus.CONFIRMED)

    def test_invalidation_breached_after_entry_overrides_pending(self):
        c = _candidate(direction=DirectionBias.BULLISH, entry=(99.0, 101.0), invalidation=95.0, target=115.0)
        t0 = datetime.now(UTC)
        touch = _bar(t0, 100, 101.5, 99.0, 100.0)
        crash = _bar(t0 + timedelta(hours=1), 99.0, 99.5, 90.0, 91.0)  # closes below invalidation (95)
        updated = evaluate_confirmation(c, [touch, crash])
        self.assertEqual(updated.status, ScalpStatus.INVALIDATED)

    def test_never_mutates_input_candidate(self):
        c = _candidate()
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 110, 112, 108, 111)]
        evaluate_confirmation(c, bars)
        self.assertEqual(c.status, ScalpStatus.ZONE_IDENTIFIED)  # original untouched


if __name__ == "__main__":
    unittest.main()
