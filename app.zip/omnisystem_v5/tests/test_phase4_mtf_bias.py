import unittest
from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, TrendState
from omnisystem_v5.context.schema import MarketContext, MultiTimeframeMarketContext, TrendClassification
from omnisystem_v5.intelligence.enums import ConflictStatus
from omnisystem_v5.intelligence.mtf_bias import aggregate_multi_timeframe_bias
from omnisystem_v5.schemas.enums import Timeframe

UTC = timezone.utc


def _ctx(tf, trend=TrendState.UPTREND, status=ContextStatus.OK):
    now = datetime.now(UTC)
    return MarketContext(
        symbol="BTCUSDT", timeframe=tf, status=status, calculated_at=now, provenance=None,
        current_price=100.0 if status == ContextStatus.OK else None,
        trend=TrendClassification(state=trend, timeframe=tf, as_of=now, basis="test") if status == ContextStatus.OK else None,
    )


class TestMultiTimeframeBias(unittest.TestCase):
    def test_aligned_when_both_uptrend(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={Timeframe.H4: _ctx(Timeframe.H4, TrendState.UPTREND), Timeframe.M15: _ctx(Timeframe.M15, TrendState.UPTREND)},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.ALIGNED)

    def test_conflicting_when_opposite_trends(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={Timeframe.H4: _ctx(Timeframe.H4, TrendState.UPTREND), Timeframe.M15: _ctx(Timeframe.M15, TrendState.DOWNTREND)},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.CONFLICTING)

    def test_partial_when_higher_trend_lower_range(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={Timeframe.H4: _ctx(Timeframe.H4, TrendState.UPTREND), Timeframe.M15: _ctx(Timeframe.M15, TrendState.RANGE)},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.PARTIAL)

    def test_insufficient_when_missing_timeframe(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={Timeframe.H4: _ctx(Timeframe.H4, TrendState.UPTREND)},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.INSUFFICIENT)
        self.assertEqual(bias.execution_timeframe_structure, TrendState.UNDEFINED)

    def test_insufficient_when_context_status_not_ok(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={
                Timeframe.H4: _ctx(Timeframe.H4, status=ContextStatus.DATA_UNAVAILABLE),
                Timeframe.M15: _ctx(Timeframe.M15, TrendState.UPTREND),
            },
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.INSUFFICIENT)

    def test_microstructure_is_optional_and_reported(self):
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={
                Timeframe.H4: _ctx(Timeframe.H4, TrendState.UPTREND),
                Timeframe.M15: _ctx(Timeframe.M15, TrendState.UPTREND),
                Timeframe.M1: _ctx(Timeframe.M1, TrendState.DOWNTREND),
            },
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15, Timeframe.M1)
        self.assertEqual(bias.microstructure_confirmation, TrendState.DOWNTREND)
        # microstructure disagreement does not change higher/execution conflict status
        self.assertEqual(bias.conflict_status, ConflictStatus.ALIGNED)


if __name__ == "__main__":
    unittest.main()
