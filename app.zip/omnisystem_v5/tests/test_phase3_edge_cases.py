import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus, VolatilityRegime
from omnisystem_v5.quant.volatility import calculate_atr_percentage
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _envelope(bars, timeframe=Timeframe.H1):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))


class TestExtremeVolatility(unittest.TestCase):
    def test_extreme_volatility_series_classified_high_and_does_not_crash(self):
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = []
        price = 1000.0
        for i in range(80):
            swing = 200.0 if i % 2 == 0 else -180.0  # huge relative swings
            price = max(price + swing, 10.0)
            bars.append(_bar(t0 + timedelta(hours=i), price, price + 50, max(price - 50, 1), price + 5))

        env = _envelope(bars)
        mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.status, QuantStatus.OK)
        self.assertIsNotNone(qctx.volatility.atr_pct)
        self.assertEqual(qctx.volatility.regime, VolatilityRegime.HIGH)
        # RSI must still stay within bounds even under extreme moves
        self.assertTrue(0.0 <= qctx.momentum.rsi <= 100.0)


class TestNearZeroDenominators(unittest.TestCase):
    def test_atr_percentage_near_zero_price_does_not_explode_silently(self):
        # not zero, but very small — should still compute, just a large pct
        result = calculate_atr_percentage(atr=1.0, current_price=0.0001)
        self.assertGreater(result, 0)

    def test_flat_market_zero_atr_handled_gracefully_in_normalized_metrics(self):
        """A perfectly flat market produces ATR == 0 and zero-variance
        returns. atr_normalized_momentum and return_zscore must be
        explicitly None with reasons, never a fabricated/inf value."""
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = [_bar(t0 + timedelta(hours=i), 100.0, 100.0, 100.0, 100.0) for i in range(80)]
        env = _envelope(bars)
        mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.status, QuantStatus.OK)
        self.assertEqual(qctx.volatility.atr, 0.0)
        self.assertIsNone(qctx.normalized.atr_normalized_momentum)
        self.assertIsNone(qctx.normalized.return_zscore)
        self.assertTrue(len(qctx.normalized.reasons) > 0)
        # RSI on a perfectly flat market is defined as neutral (50), not fabricated
        self.assertAlmostEqual(qctx.momentum.rsi, 50.0)


if __name__ == "__main__":
    unittest.main()
