import math
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.decision.contracts import NormalizedCandidate, ScoreComponents
from omnisystem_v5.decision.engine import decide
from omnisystem_v5.decision.enums import DecisionOutcome, QualityLevel
from omnisystem_v5.decision.policy import ConflictPolicy, DecisionPolicy, QualityGatePolicy
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.decision_bridge import from_scalp_candidate
from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig, detect_scalp_candidate
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.risk.contracts import AccountState
from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc
NOW = datetime.now(UTC)


def _cand(source="ScalpEngine", direction=Direction.LONG, entry=100.0, sl=None, tps=None,
          quality_level=QualityLevel.STRONG, symbol="BTCUSDT", generated_at=None):
    generated_at = generated_at or NOW
    if sl is None:
        sl = entry - 8 if direction == Direction.LONG else entry + 8
    if tps is None:
        tps = (entry + 24,) if direction == Direction.LONG else (entry - 24,)
    q = ScoreComponents(structural_quality=quality_level, confirmation_quality=quality_level,
                         risk_quality=quality_level, reward_quality=quality_level,
                         timeframe_alignment=quality_level, data_quality=quality_level)
    cid = NormalizedCandidate.make_id(source, symbol, direction, entry, sl, tps, "SCALP", generated_at)
    return NormalizedCandidate(candidate_id=cid, source_engine=source, horizon="SCALP", symbol=symbol,
                                direction=direction, entry=entry, stop_loss=sl, take_profits=tps,
                                generated_at=generated_at, quality=q)


def _account(**kwargs):
    defaults = dict(equity=10000.0)
    defaults.update(kwargs)
    return AccountState(**defaults)


class TestAdversarialNumeric(unittest.TestCase):
    def test_infinity_take_profit(self):
        c = _cand(tps=(math.inf,))
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)

    def test_negative_stop_loss(self):
        c = _cand(sl=-5.0)
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)

    def test_zero_entry(self):
        c = _cand(entry=0.0)
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)

    def test_huge_numbers_do_not_crash(self):
        c = _cand(entry=1e18, sl=1e18 - 1e15, tps=(1e18 + 3e15,))
        d = decide([c], _account(equity=1e15))
        self.assertIn(d.outcome, (DecisionOutcome.LONG, DecisionOutcome.NO_TRADE))

    def test_zero_equity_blocks_everything(self):
        c = _cand()
        d = decide([c], _account(equity=0.0))
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)


class TestAdversarialManyCandidates(unittest.TestCase):
    def test_large_mixed_batch_never_crashes_and_stays_deterministic(self):
        candidates = []
        for i in range(20):
            direction = Direction.LONG if i % 2 == 0 else Direction.SHORT
            candidates.append(_cand(source=f"Engine{i}", direction=direction, entry=100.0 + (i * 0.01),
                                     quality_level=QualityLevel.MODERATE if i % 3 else QualityLevel.STRONG))
        policy = DecisionPolicy(conflict=ConflictPolicy(duplicate_price_tolerance_pct=0.001))
        d1 = decide(candidates, _account(), decision_policy=policy, now=NOW)
        d2 = decide(candidates, _account(), decision_policy=policy, now=NOW)
        self.assertEqual(d1.decision_id, d2.decision_id)
        self.assertEqual(len(d1.candidate_trace), 20)

    def test_all_duplicates_of_each_other_collapses_to_single_decision(self):
        candidates = [_cand(source="ScalpEngine", entry=100.0 + i * 0.001, quality_level=QualityLevel.MODERATE) for i in range(10)]
        d = decide(candidates, _account())
        self.assertEqual(d.outcome, DecisionOutcome.LONG)
        accepted = [r for r in d.candidate_trace if r.status.value == "ACCEPTED"]
        self.assertEqual(len(accepted), 1)


class TestAdversarialStaleFreshness(unittest.TestCase):
    def test_old_generated_at_still_deterministic_and_does_not_crash(self):
        old_time = NOW - timedelta(days=30)
        c = _cand(generated_at=old_time)
        d = decide([c], _account())
        self.assertIn(d.outcome, (DecisionOutcome.LONG, DecisionOutcome.NO_TRADE))


class TestNoTradeNeverForced(unittest.TestCase):
    def test_weak_candidates_never_get_forced_through(self):
        c = _cand(entry=100.0, sl=100.0, tps=(110.0,))
        policy = DecisionPolicy(quality_gate=QualityGatePolicy(min_moderate_plus_components=0))
        d = decide([c], _account(), decision_policy=policy)
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)


class TestRealIntelligencePipelineIntegration(unittest.TestCase):
    def _bar(self, t, o, h, l, c, v=10.0):
        return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))

    def _range_then_breakout(self, t0):
        bars = []
        price = 100.0
        for i in range(60):
            price += 0.5 if (i % 6 < 4) else -0.3
            bars.append(self._bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5))
        for i in range(60, 65):
            price += 3.0
            bars.append(self._bar(t0 + timedelta(hours=i), price, price + 2, price - 1, price + 1, v=30))
        for i in range(65, 80):
            price -= 0.8
            bars.append(self._bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price - 0.3, v=15))
        for i in range(80, 100):
            price += 1.0 if i % 2 == 0 else -1.0
            bars.append(self._bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2))
        return bars

    def test_full_stack_from_bars_to_final_decision(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = self._range_then_breakout(t0)
        now_ts = datetime.now(UTC)
        prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now_ts, data_timestamp=bars[-1].close_time)
        env = MarketDataEnvelope(market="BTCUSDT", timeframe=Timeframe.H1, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))
        mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())

        self.assertEqual(result.status.value, "ZONE_IDENTIFIED")
        scalp_candidate = result.candidates[0]

        normalized = from_scalp_candidate(scalp_candidate)
        self.assertEqual(normalized.symbol, "BTCUSDT")

        final = decide([normalized], _account())
        self.assertIn(final.outcome, (DecisionOutcome.LONG, DecisionOutcome.SHORT, DecisionOutcome.NO_TRADE))
        if final.outcome != DecisionOutcome.NO_TRADE:
            self.assertTrue(final.risk_result.is_actionable)
            self.assertEqual(final.selected_candidate.candidate_id, normalized.candidate_id)


if __name__ == "__main__":
    unittest.main()
