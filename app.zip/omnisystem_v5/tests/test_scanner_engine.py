"""Integration tests: scanner -> real intelligence -> real Decision Engine -> real Risk hard gate.
Bar data is SYNTHETIC (see scanner_fixtures); nothing in the analytical chain is mocked."""
import time
import unittest
from datetime import timedelta

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.decision.enums import DecisionOutcome
from omnisystem_v5.intelligence.enums import Horizon
from omnisystem_v5.scanner import ScanEngine, ScannerConfig, ScannerRunner, ScanState, StaticUniverse, SymbolSpec
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.scanner.enums import CycleHealth, DedupVerdict, SignalState, SymbolScanStatus
from omnisystem_v5.scanner.evaluation import evaluate_symbol
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError
from omnisystem_v5.scanner.scheduler import SchedulePolicy
from omnisystem_v5.scanner.telemetry import EventKind, InMemorySink
from omnisystem_v5.scanner.timeframes import required_timeframes
from omnisystem_v5.scanner.universe import UniverseFilter
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.tests.scanner_fixtures import END, StubSource, account, bars_ending_at, envelope, loose_risk_policy

LONG_SEED, SHORT_SEED, QUIET_SEED = 1, 8, 7      # found by exploration: INTRADAY LONG / INTRADAY SHORT / no candidate


class World:
    def __init__(self, seeds, specs=None, sink=None, evaluator=None, batch=25, universe=None, **cfg):
        self.seeds = dict(seeds)
        self.cfg = ScannerConfig(risk_policy=loose_risk_policy(), **cfg)
        self.clock = ManualClock(END)
        self.source = StubSource(required_timeframes(self.cfg), end=END, seed_for=lambda s: self.seeds[s])
        specs = specs or [SymbolSpec(s) for s in self.seeds]
        self.universe = universe or StaticUniverse(specs)
        self.sink = sink
        self.engine = ScanEngine(self.source, self.universe, self.cfg, self.clock, sink=sink, evaluator=evaluator,
                                 batch_size=batch)
        self.state = ScanState()

    def advance(self, seconds):
        self.clock.advance(seconds)
        self.source.end = self.clock.now()

    def cycle(self, advance=0):
        if advance:
            self.advance(advance)
        res = self.engine.run_cycle(self.state, account())
        self.state = res.state
        return res.report

    def result(self, report, symbol):
        return next(r for r in report.results if r.symbol == symbol)


class TestEndToEnd(unittest.TestCase):
    def test_real_pipeline_discovers_validates_and_emits(self):
        w = World({"BTC/USDT": LONG_SEED, "ETH/USDT": SHORT_SEED, "DOGE/USDT": QUIET_SEED})
        rep = w.cycle()
        self.assertEqual(rep.health, CycleHealth.HEALTHY)
        by = {s.descriptor.symbol: s for s in rep.emitted}
        self.assertEqual(set(by), {"BTC/USDT", "ETH/USDT"})
        self.assertEqual(by["BTC/USDT"].descriptor.direction, "LONG")
        self.assertEqual(by["ETH/USDT"].descriptor.direction, "SHORT")
        for s in rep.emitted:
            self.assertEqual((s.state, s.verdict), (SignalState.EMITTED, DedupVerdict.NEW))
            d = s.decision                                   # authoritative analytical truth is the Decision Engine's
            self.assertNotEqual(d.outcome, DecisionOutcome.NO_TRADE)
            self.assertTrue(d.risk_result.is_actionable)     # Risk Engine hard gate passed
            self.assertEqual(s.descriptor.basis, "ATR")
        quiet = w.result(rep, "DOGE/USDT")
        self.assertEqual((quiet.status, quiet.decision_outcome, quiet.candidates_discovered),
                         (SymbolScanStatus.EVALUATED, "NO_CANDIDATE", 0))
        self.assertTrue(any("INTRADAY" in n or "SCALP" in n or "SHORT_SWING" in n for n in quiet.notes))

    def test_scanner_never_produces_an_order_or_execution_object(self):
        w = World({"BTC/USDT": LONG_SEED})
        rep = w.cycle()
        sig = rep.emitted[0]
        for attr in ("order", "execute", "place_order", "broker"):
            self.assertFalse(hasattr(sig, attr) or hasattr(rep, attr) or hasattr(w.engine, attr), attr)

    def test_rejected_candidates_never_become_signals(self):
        # A strict Risk policy must veto: same data, no emission, Decision trace explains why.
        from omnisystem_v5.risk.contracts import RiskPolicy
        world = World({"BTC/USDT": LONG_SEED})
        world.cfg = ScannerConfig(risk_policy=RiskPolicy(min_reward_risk_ratio=50.0))
        world.engine = ScanEngine(world.source, world.universe, world.cfg, world.clock)
        rep = world.cycle()
        r = world.result(rep, "BTC/USDT")
        self.assertEqual(rep.emitted, ())
        self.assertEqual(r.decision_outcome, "NO_TRADE")
        self.assertGreaterEqual(r.candidates_discovered, 1)
        self.assertTrue(any("REJECTED_RISK" in t for t in r.candidate_trace))

    def test_multiple_horizons_scalp_and_intraday_reach_one_decision_per_symbol(self):
        w = World({"BTC/USDT": 8})
        w.source.amp = 6.0
        rep = w.cycle()
        r = w.result(rep, "BTC/USDT")
        self.assertEqual(r.candidates_discovered, 2)
        self.assertEqual(len(rep.emitted), 1)                     # Decision arbitrates: one winner per symbol
        self.assertEqual(set(r.horizons_run), {"SCALP", "INTRADAY", "SHORT_SWING"})


class TestDedupOverTime(unittest.TestCase):
    def test_repeat_scans_are_suppressed_then_expire_then_cooldown_then_reemit(self):
        w = World({"BTC/USDT": LONG_SEED})
        self.assertEqual(len(w.cycle().emitted), 1)
        rep = w.cycle(advance=60)
        self.assertEqual((rep.emitted, [s.verdict for s in rep.suppressed]), ((), [DedupVerdict.DUPLICATE]))

        w.seeds["BTC/USDT"] = QUIET_SEED                       # setup disappears
        w.cycle(advance=60)
        rep = w.cycle(advance=250)                             # 370 s since last seen > 300 s expiry
        self.assertEqual([s.state for s in rep.expired], [SignalState.EXPIRED])

        w.seeds["BTC/USDT"] = LONG_SEED                        # same setup returns inside cooldown (t=370 < 900)
        rep = w.cycle(advance=60)
        self.assertEqual([s.verdict for s in rep.suppressed], [DedupVerdict.COOLDOWN])
        self.assertEqual(rep.emitted, ())

        rep = w.cycle(advance=600)                             # t > 900 after emission: allowed again
        self.assertEqual([s.verdict for s in rep.emitted], [DedupVerdict.NEW])

    def test_continuous_setup_emits_exactly_once_over_many_cycles(self):
        w = World({"BTC/USDT": LONG_SEED})
        emitted = 0
        for _ in range(40):
            emitted += len(w.cycle(advance=60).emitted)
        self.assertEqual(emitted, 1)
        self.assertEqual(w.state.dedup.active[0].seen_count, 40)


class TestDeterminism(unittest.TestCase):
    SEEDS = {"BTC/USDT": LONG_SEED, "ETH/USDT": SHORT_SEED, "DOGE/USDT": QUIET_SEED, "SOL/USDT": 2}

    def run_once(self, order=None):
        specs = [SymbolSpec(s) for s in (order or self.SEEDS)]
        w = World(self.SEEDS, specs=specs)
        return w.cycle().canonical_json()

    def test_identical_inputs_and_clock_give_byte_identical_reports(self):
        a = self.run_once()
        time.sleep(0.01)                     # real engines stamp wall-clock metadata; it must not leak
        b = self.run_once()
        self.assertEqual(a, b)

    def test_universe_input_order_does_not_matter(self):
        self.assertEqual(self.run_once(), self.run_once(order=list(reversed(list(self.SEEDS)))))

    def test_identity_is_free_of_wall_clock_across_engine_runs(self):
        w1, w2 = World({"BTC/USDT": LONG_SEED}), World({"BTC/USDT": LONG_SEED})
        s1, s2 = w1.cycle().emitted[0], (time.sleep(0.01) or w2.cycle().emitted[0])
        self.assertEqual(s1.fingerprint, s2.fingerprint)
        self.assertNotEqual(s1.decision.selected_candidate.candidate_id, s2.decision.selected_candidate.candidate_id)  # F1: ids differ, identity does not

    def test_multi_cycle_sequences_reproduce(self):
        def sequence():
            w = World(self.SEEDS)
            return [w.cycle(advance=60 if i else 0).canonical_json() for i in range(4)]
        self.assertEqual(sequence(), sequence())


class TestPriorityAndCap(unittest.TestCase):
    def specs(self):
        return [SymbolSpec("CCC/USDT"), SymbolSpec("AAA/USDT", quote_volume_24h=1e9), SymbolSpec("BBB/USDT", quote_volume_24h=1e3)]

    def seeds(self):
        return {"AAA/USDT": LONG_SEED, "BBB/USDT": LONG_SEED, "CCC/USDT": LONG_SEED}

    def test_priority_is_explainable_decomposed_and_ordered_by_named_components(self):
        w = World(self.seeds(), specs=self.specs())
        rep = w.cycle()
        self.assertEqual([s.descriptor.symbol for s in rep.emitted], ["AAA/USDT", "BBB/USDT", "CCC/USDT"])   # liquidity tier breaks the tie
        p = rep.emitted[0].priority
        self.assertEqual(p.kind, "COMPUTATIONAL_PRIORITY_NOT_PROBABILITY")
        names = [n for n, _ in p.components]
        self.assertEqual(names[-3:], ["risk_verdict", "data_freshness", "liquidity_tier"])
        decision_components = len(w.cfg.decision_policy.scoring.component_priority_order)
        self.assertEqual(len(names), decision_components + 3)            # Decision's own components + 3 scanner factors
        self.assertEqual(dict(p.components)["liquidity_tier"], 2)

    def test_cap_defers_without_consuming_the_setup_and_duplicates_do_not_use_the_cap(self):
        w = World(self.seeds(), specs=self.specs(), max_signals_per_cycle=1)
        r1 = w.cycle()
        self.assertEqual([s.descriptor.symbol for s in r1.emitted], ["AAA/USDT"])
        self.assertEqual({s.verdict for s in r1.suppressed}, {DedupVerdict.DEFERRED_CAP})
        self.assertEqual(len(w.state.dedup.active), 1)                   # deferred setups are NOT tracked
        r2 = w.cycle(advance=60)                                         # AAA duplicate (free), BBB takes the slot
        self.assertEqual([s.descriptor.symbol for s in r2.emitted], ["BBB/USDT"])
        self.assertIn(DedupVerdict.DUPLICATE, [s.verdict for s in r2.suppressed])
        r3 = w.cycle(advance=60)
        self.assertEqual([s.descriptor.symbol for s in r3.emitted], ["CCC/USDT"])


def many(n_ok_long=0, n_ok_short=0, n_quiet=0, n_bad=0):
    seeds = {}
    for i in range(n_ok_long):
        seeds[f"L{i:02d}/USDT"] = LONG_SEED
    for i in range(n_ok_short):
        seeds[f"S{i:02d}/USDT"] = SHORT_SEED
    for i in range(n_quiet):
        seeds[f"Q{i:02d}/USDT"] = QUIET_SEED
    for i in range(n_bad):
        seeds[f"X{i:02d}/USDT"] = QUIET_SEED
    return seeds


class TestFailureSemantics(unittest.TestCase):
    def bad(self, w, names, exc=None):
        for n in names:
            w.source.errors[n] = exc or DataUnavailableError("down")

    def test_isolated_bad_symbol_does_not_affect_others_or_health(self):
        w = World(many(n_ok_long=2, n_quiet=4, n_bad=1))
        self.bad(w, ["X00/USDT"])
        rep = w.cycle()
        self.assertEqual(rep.health, CycleHealth.HEALTHY)
        x = w.result(rep, "X00/USDT")
        self.assertEqual((x.status, x.failure_class), (SymbolScanStatus.REJECTED, FailureClass.PROVIDER_UNAVAILABLE))
        self.assertEqual(len(rep.emitted), 2)

    def test_repeated_bad_symbol_is_quarantined_and_no_longer_fetched_without_tripping_health(self):
        w = World(many(n_ok_long=1, n_quiet=6, n_bad=1))
        self.bad(w, ["X00/USDT"])
        for _ in range(3):
            self.assertEqual(w.cycle(advance=60).health, CycleHealth.HEALTHY)
        before = sum(1 for c in w.source.calls if c[0] == "X00/USDT")
        rep = w.cycle(advance=60)
        self.assertEqual(w.result(rep, "X00/USDT").status, SymbolScanStatus.SKIPPED_QUARANTINE)
        self.assertEqual(sum(1 for c in w.source.calls if c[0] == "X00/USDT"), before)      # not even attempted
        self.assertEqual(rep.health, CycleHealth.HEALTHY)
        rep = w.cycle(advance=900)                                                          # quarantine over: probed again
        self.assertEqual(w.result(rep, "X00/USDT").status, SymbolScanStatus.REJECTED)

    def test_many_quarantined_symbols_cannot_suppress_or_trip_the_healthy_remainder(self):
        w = World(many(n_ok_long=2, n_quiet=4, n_bad=20))
        self.bad(w, [f"X{i:02d}/USDT" for i in range(20)])
        # 20/26 failing from the start is not "isolated": counters stay frozen (cycle is not HEALTHY) ...
        rep = w.cycle(advance=60)
        self.assertNotEqual(rep.health, CycleHealth.HEALTHY)
        self.assertEqual(len(rep.emitted), 2)                        # ... and valid opportunities still flow

    def test_provider_wide_outage_is_systemic_then_recovers_without_quarantine_debt(self):
        w = World(many(n_ok_long=3, n_ok_short=3, n_quiet=4))
        names = list(w.seeds)
        self.bad(w, names)
        for i in range(1, 6):
            rep = w.cycle(advance=60)
            self.assertEqual(rep.health, CycleHealth.SYSTEMIC_FAILURE)
            self.assertEqual(rep.emitted, ())
            self.assertEqual(w.state.consecutive_systemic, i)
        self.assertEqual(w.state.ledger.entries, ())                 # feed failures were not blamed on symbols
        w.source.errors.clear()
        rep = w.cycle(advance=60)                                    # recovery is immediate and complete
        self.assertEqual(rep.health, CycleHealth.HEALTHY)
        self.assertEqual(rep.count(SymbolScanStatus.EVALUATED), 10)
        self.assertEqual(len(rep.emitted), 6)
        self.assertEqual(w.state.consecutive_systemic, 0)

    def test_partial_outage_is_degraded_and_valid_signals_still_emit(self):
        w = World(many(n_ok_long=3, n_ok_short=3, n_quiet=4))
        self.bad(w, ["Q00/USDT", "Q01/USDT", "Q02/USDT", "Q03/USDT"], TimeoutError("slow"))
        rep = w.cycle()
        self.assertEqual(rep.health, CycleHealth.DEGRADED)
        self.assertEqual(len(rep.emitted), 6)
        self.assertEqual(w.result(rep, "Q00/USDT").failure_class, FailureClass.PROVIDER_TIMEOUT)

    def test_systemic_cycle_never_suppresses_symbols_that_passed_every_gate(self):
        w = World(many(n_ok_long=1, n_ok_short=1, n_bad=8))
        self.bad(w, [f"X{i:02d}/USDT" for i in range(8)])
        rep = w.cycle()
        self.assertEqual(rep.health, CycleHealth.SYSTEMIC_FAILURE)
        self.assertEqual({s.descriptor.symbol for s in rep.emitted}, {"L00/USDT", "S00/USDT"})
        self.assertTrue(any("systemic" in r for r in rep.health_reasons))

    def test_empty_universe_is_no_work_not_a_failure(self):
        w = World({}, specs=[])
        rep = w.cycle()
        self.assertEqual((rep.health, rep.universe_size, rep.results, rep.emitted), (CycleHealth.NO_WORK, 0, (), ()))
        self.assertEqual(w.state.consecutive_systemic, 0)

    def test_universe_source_failure_is_reported_as_systemic_and_state_is_preserved(self):
        class Broken:
            def symbols(self, now):
                raise RuntimeError("registry down")
        w = World({"BTC/USDT": LONG_SEED})
        w.cycle()
        active_before = w.state.dedup.active
        w.engine = ScanEngine(w.source, Broken(), w.cfg, w.clock)
        rep = w.cycle(advance=60)
        self.assertEqual(rep.health, CycleHealth.SYSTEMIC_FAILURE)
        self.assertIn("registry down", rep.health_reasons[0])
        self.assertEqual(w.state.dedup.active, active_before)         # tracked signals are not lost
        self.assertEqual(w.state.consecutive_systemic, 1)

    def test_rate_limit_aborts_remaining_work_and_is_reported(self):
        w = World(many(n_ok_long=6), batch=2)
        w.source.errors["L01/USDT"] = ProviderRateLimitedError("slow down", 30)
        rep = w.cycle()
        self.assertTrue(rep.rate_limited)
        self.assertEqual(rep.health, CycleHealth.DEGRADED)
        self.assertEqual(w.result(rep, "L01/USDT").failure_class, FailureClass.PROVIDER_RATE_LIMITED)
        for s in ("L02/USDT", "L03/USDT", "L04/USDT", "L05/USDT"):
            self.assertEqual(w.result(rep, s).status, SymbolScanStatus.SKIPPED_RATE_LIMIT)
            self.assertFalse(any(c[0] == s for c in w.source.calls))    # no further requests were sent
        self.assertEqual(w.state.resume_after, "L01/USDT")
        w.source.errors.clear()
        nxt = w.cycle(advance=60)                                       # next cycle resumes AFTER the last scanned symbol
        self.assertEqual(nxt.count(SymbolScanStatus.EVALUATED), 6)
        self.assertEqual(len(nxt.emitted), 5)                           # L00 was already emitted before the abort
        self.assertEqual([(x.descriptor.symbol, x.verdict) for x in nxt.suppressed], [("L00/USDT", DedupVerdict.DUPLICATE)])
        self.assertEqual([c[0] for c in w.source.calls[-30::5]][0], "L02/USDT")

    def test_internal_error_is_surfaced_not_swallowed_and_isolated(self):
        def evaluator(symbol, *a, **k):
            if symbol == "Q00/USDT":
                raise RuntimeError("engine bug")
            return evaluate_symbol(symbol, *a, **k)
        w = World(many(n_ok_long=2, n_quiet=2), evaluator=evaluator)
        rep = w.cycle()
        r = w.result(rep, "Q00/USDT")
        self.assertEqual((r.status, r.failure_class), (SymbolScanStatus.REJECTED, FailureClass.INTERNAL_ERROR))
        self.assertIn("engine bug", r.failure_detail)
        self.assertEqual(rep.health, CycleHealth.DEGRADED)
        self.assertEqual(len(rep.emitted), 2)

    def test_systemic_recovery_backoff_visible_to_scheduler(self):
        w = World(many(n_quiet=6))
        self.bad(w, list(w.seeds))
        w.cycle()
        from omnisystem_v5.scanner.scheduler import next_due_at
        due = next_due_at(w.state.last_cycle_started_at, w.state.last_health, w.state.consecutive_systemic,
                          w.clock.now(), w.cfg.schedule)
        self.assertEqual(due, w.clock.now() + timedelta(seconds=120))


class TestDataProtection(unittest.TestCase):
    def test_all_stale_data_fails_closed_with_no_candidates(self):
        w = World(many(n_ok_long=3, n_quiet=3))
        w.source.end = END - timedelta(days=3)
        rep = w.cycle()
        for r in rep.results:
            self.assertEqual((r.status, r.failure_class), (SymbolScanStatus.REJECTED, FailureClass.STALE_DATA))
            self.assertEqual(r.candidates_discovered, 0)
        self.assertEqual((rep.emitted, rep.health), ((), CycleHealth.SYSTEMIC_FAILURE))

    def test_staleness_is_judged_per_timeframe_so_slow_horizons_survive_a_lagging_fast_feed(self):
        w = World({"BTC/USDT": LONG_SEED})
        w.source.end = END - timedelta(hours=3)
        rep = w.cycle()
        r = w.result(rep, "BTC/USDT")
        self.assertEqual(r.status, SymbolScanStatus.EVALUATED)
        self.assertEqual(r.horizons_run, ("SHORT_SWING",))
        self.assertTrue(any(n.startswith("SCALP:STALE_DATA") for n in r.notes))
        self.assertTrue(any(n.startswith("INTRADAY:STALE_DATA") for n in r.notes))

    def test_malformed_series_is_rejected_before_any_engine_sees_it(self):
        w = World({"BTC/USDT": LONG_SEED})
        for tf in required_timeframes(w.cfg):
            bars = list(bars_ending_at(tf, 100, END))
            w.source.overrides[("BTC/USDT", tf)] = envelope("BTC/USDT", tf, bars[:50] + [bars[49]] + bars[50:])
        called = []
        w.engine = ScanEngine(w.source, w.universe, w.cfg, w.clock, evaluator=lambda *a, **k: called.append(1))
        rep = w.cycle()
        self.assertEqual(w.result(rep, "BTC/USDT").failure_class, FailureClass.INVALID_DATA)
        self.assertEqual(called, [])

    def test_missing_timeframe_blocks_only_dependent_horizons(self):
        w = World({"BTC/USDT": LONG_SEED})
        w.source.errors[("BTC/USDT", Timeframe.H1)] = DataUnavailableError("no 1h")
        rep = w.cycle()
        r = w.result(rep, "BTC/USDT")
        self.assertEqual(r.status, SymbolScanStatus.EVALUATED)
        self.assertNotIn("INTRADAY", r.horizons_run)
        self.assertIn("SCALP", r.horizons_run)
        self.assertTrue(any(n.startswith("INTRADAY:PROVIDER_UNAVAILABLE") for n in r.notes))
        self.assertEqual(rep.emitted, ())                              # intraday setup is NOT synthesized from partial data

    def test_desynchronized_timeframes_block_the_horizon(self):
        w = World({"BTC/USDT": LONG_SEED}, horizons=(Horizon.INTRADAY,))
        tf = Timeframe.M15
        w.source.overrides[("BTC/USDT", tf)] = envelope("BTC/USDT", tf, bars_ending_at(tf, 220, END - timedelta(minutes=15)))
        rep = w.cycle()
        r = w.result(rep, "BTC/USDT")
        self.assertEqual((r.status, r.failure_class), (SymbolScanStatus.REJECTED, FailureClass.UNSYNCHRONIZED_TIMEFRAMES))

    def test_simulated_origin_never_scanned(self):
        from omnisystem_v5.schemas.enums import DataOrigin
        w = World({"BTC/USDT": LONG_SEED})
        for tf in required_timeframes(w.cfg):
            w.source.overrides[("BTC/USDT", tf)] = envelope("BTC/USDT", tf, bars_ending_at(tf, 220, END), origin=DataOrigin.SIMULATED)
        self.assertEqual(w.result(w.cycle(), "BTC/USDT").failure_class, FailureClass.UNUSABLE_ORIGIN)


class TestResourceControl(unittest.TestCase):
    def test_symbol_budget_rotates_fairly_and_covers_the_universe(self):
        w = World(many(n_quiet=5), max_symbols_per_cycle=2)
        per_cycle = []
        for i in range(3):
            rep = w.cycle(advance=60 if i else 0)
            scanned = {r.symbol for r in rep.results if r.status == SymbolScanStatus.EVALUATED}
            self.assertEqual(len(scanned), 2)
            self.assertEqual(rep.count(SymbolScanStatus.SKIPPED_BUDGET), 3)
            per_cycle.append(scanned)
        self.assertEqual(per_cycle, [{"Q00/USDT", "Q01/USDT"}, {"Q02/USDT", "Q03/USDT"}, {"Q04/USDT", "Q00/USDT"}])   # wraps
        self.assertEqual(set().union(*per_cycle), set(w.seeds))

    def test_rotation_survives_universe_membership_changes(self):
        w = World(many(n_quiet=4), max_symbols_per_cycle=2)
        w.cycle()                                                     # scanned Q00, Q01 -> cursor at Q01
        w.engine = ScanEngine(w.source, StaticUniverse([SymbolSpec(s) for s in ("Q00/USDT", "Q02/USDT", "Q03/USDT")]),
                              w.cfg, w.clock)
        rep = w.cycle(advance=60)
        self.assertEqual([r.symbol for r in rep.results if r.status == SymbolScanStatus.EVALUATED], ["Q02/USDT", "Q03/USDT"])

    def test_signals_of_unscanned_symbols_do_not_expire_during_a_rotation(self):
        w = World(many(n_ok_long=1, n_quiet=3), max_symbols_per_cycle=2)   # rotation = 2 cycles -> effective expiry 360 s
        w.cycle()                                                          # scans L00, Q00 ; emits L00
        rep = w.cycle(advance=60)                                          # scans Q01, Q02 (L00 not scanned)
        rep = w.cycle(advance=290)                                         # 350 s since L00 last seen: 300 < 350 < 360
        self.assertEqual(rep.expired, ())
        self.assertEqual(len(w.state.dedup.active), 1)

    def test_batches_are_processed_in_input_order_by_the_executor_boundary(self):
        w = World(many(n_quiet=7), batch=3)
        rep = w.cycle()
        self.assertEqual([r.symbol for r in rep.results], sorted(w.seeds))
        self.assertEqual([c[0] for c in w.source.calls[::5]], sorted(w.seeds))    # 5 timeframes per symbol, sequential


class TestObservability(unittest.TestCase):
    def test_events_cover_the_cycle(self):
        sink = InMemorySink()
        w = World({"BTC/USDT": LONG_SEED, "ETH/USDT": QUIET_SEED, "X/USDT": QUIET_SEED}, sink=sink)
        w.source.errors["X/USDT"] = DataUnavailableError("down")
        w.cycle(); w.cycle(advance=60)
        self.assertEqual(len(sink.of_kind(EventKind.SCAN_STARTED)), 2)
        self.assertEqual(len(sink.of_kind(EventKind.SCAN_COMPLETED)), 2)
        self.assertEqual(len(sink.of_kind(EventKind.SIGNAL_EMITTED)), 1)
        self.assertEqual(len(sink.of_kind(EventKind.SIGNAL_SUPPRESSED)), 1)
        self.assertEqual(len(sink.of_kind(EventKind.SYMBOL_REJECTED)), 2)
        self.assertEqual(len(sink.of_kind(EventKind.SYMBOL_EVALUATED)), 4)
        self.assertGreaterEqual(len(sink.of_kind(EventKind.CANDIDATE_DISCOVERED)), 2)

    def test_a_broken_sink_cannot_break_the_scan(self):
        class Boom:
            def emit(self, e):
                raise IOError("sink down")
        w = World({"BTC/USDT": LONG_SEED}, sink=Boom())
        rep = w.cycle()
        self.assertEqual(len(rep.emitted), 1)
        self.assertGreater(rep.telemetry_errors, 0)

    def test_latency_is_measured_with_the_injected_timer_and_excluded_from_equality(self):
        ticks = iter(range(0, 10_000, 5))
        w = World({"BTC/USDT": LONG_SEED})
        w.engine = ScanEngine(w.source, w.universe, w.cfg, w.clock, timer=lambda: float(next(ticks)))
        rep = w.cycle()
        self.assertGreater(rep.timings.total_seconds, 0)
        self.assertEqual(rep.timings.per_symbol_seconds[0][0], "BTC/USDT")
        w2 = World({"BTC/USDT": LONG_SEED})
        self.assertEqual(rep.canonical_json(), w2.cycle().canonical_json())


class TestRunner(unittest.TestCase):
    def test_runner_respects_schedule_without_sleeping(self):
        w = World({"BTC/USDT": LONG_SEED})
        sleeps = []
        def sleep(s):
            sleeps.append(s); w.advance(s)
        runner = ScannerRunner(w.engine, w.clock, w.cfg.schedule, sleep, account, poll_seconds=20)
        st, rep = runner.tick(ScanState())
        self.assertIsNotNone(rep)
        st, rep = runner.tick(st)
        self.assertIsNone(rep)                                          # not due yet
        cycles = []
        state = runner.run(st, should_stop=lambda: len(cycles) >= 3, on_report=cycles.append)
        self.assertEqual(len(cycles), 3)
        gaps = [(b.started_at - a.started_at).total_seconds() for a, b in zip(cycles, cycles[1:])]
        self.assertEqual(gaps, [60.0, 60.0])
        self.assertTrue(all(0 < s <= 20 for s in sleeps))

    def test_runner_backs_off_on_systemic_failure_and_returns_to_normal_after_recovery(self):
        w = World(many(n_quiet=6))
        for s in w.seeds:
            w.source.errors[s] = DataUnavailableError("down")
        runner = ScannerRunner(w.engine, w.clock, w.cfg.schedule, lambda s: w.advance(s), account, poll_seconds=30)
        reports = []
        def on_report(rep):
            reports.append(rep)
            if len(reports) == 3:
                w.source.errors.clear()                                 # provider recovers after the third failed cycle
        runner.run(ScanState(), should_stop=lambda: len(reports) >= 5, on_report=on_report)
        gaps = [(b.started_at - a.started_at).total_seconds() for a, b in zip(reports, reports[1:])]
        self.assertEqual(gaps, [120.0, 240.0, 480.0, 60.0])             # exponential back-off, then normal cadence
        self.assertEqual([r.health for r in reports], [CycleHealth.SYSTEMIC_FAILURE] * 3 + [CycleHealth.HEALTHY] * 2)


class TestConfigAndBoundaries(unittest.TestCase):
    def test_universe_filter_and_exclusions_are_reported(self):
        specs = [SymbolSpec("BTC/USDT", quote_volume_24h=1e9), SymbolSpec("PEPE/USDT", quote_volume_24h=10.0)]
        w = World({"BTC/USDT": LONG_SEED, "PEPE/USDT": LONG_SEED}, specs=specs,
                  universe_filter=UniverseFilter(min_quote_volume_24h=1e6))
        rep = w.cycle()
        self.assertEqual(rep.excluded, (("PEPE/USDT", "below minimum liquidity"),))
        self.assertEqual([r.symbol for r in rep.results], ["BTC/USDT"])

    def test_scanner_package_has_no_network_execution_or_wall_clock_dependencies(self):
        import pathlib, re
        root = pathlib.Path(__file__).resolve().parents[1]
        banned_import = re.compile(r"^\s*(import|from)\s+(socket|requests|urllib|http|httpx|aiohttp|ssl|omnisystem_v5\.execution|omnisystem_v5\.data\.providers\.(?!base))",
                                   re.M)
        for f in (root / "scanner").glob("*.py"):
            text = f.read_text()
            self.assertIsNone(banned_import.search(text), f.name)
            if f.name != "clock.py":
                self.assertNotIn("datetime.now(", text, f.name)
                self.assertNotIn("time.time(", text, f.name)
                self.assertNotIn("random", text.replace("randomness", ""), f.name)

    def test_no_frozen_layer_imports_the_scanner(self):
        import pathlib
        root = pathlib.Path(__file__).resolve().parents[1]
        for f in root.rglob("*.py"):
            rel = f.relative_to(root).parts
            if rel[0] in ("scanner", "tests", "marketdata", "alerts"):
                continue
            self.assertNotIn("omnisystem_v5.scanner", f.read_text(), str(f))


if __name__ == "__main__":
    unittest.main()
