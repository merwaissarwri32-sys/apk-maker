"""Phase 11: provider/instrument health state machines, bounded retry/backoff, throttle, stream store. SYNTHETIC."""
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.config import InstrumentHealthPolicy, ProviderHealthPolicy, RetryPolicy, ThrottlePolicy
from omnisystem_v5.marketdata.events import DataEventKind, InMemorySink
from omnisystem_v5.marketdata.health import (HealthBook, InstrumentState, ObsKind, ProviderObservation, ProviderState, initial_provider_health,
                                             instrument_scannable, may_attempt, next_instrument_state, next_provider_state,
                                             operator_reset, retry_after_seconds)
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.provider import ProviderAuthError, ProviderPayloadError
from omnisystem_v5.marketdata.retry import RetryExecutor, Throttle, compute_delay, jitter_unit
from omnisystem_v5.marketdata.stream import BarStore, BarUpdate, StreamingFeed
from omnisystem_v5.marketdata.provider import BarRequest
from omnisystem_v5.marketdata.assets import AssetClass
from omnisystem_v5.marketdata.adapters.scripted import scripted_capabilities
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.tests.marketdata_fixtures import ALL_TFS, END, RecordingSleep, row

PP = ProviderHealthPolicy()               # degrade 2, unavailable 5, recover 3, cooldown 30s x2 (max 900), throttle 60s
S = ProviderState
FAIL = ProviderObservation(ObsKind.FAILURE, FailureClass.PROVIDER_TIMEOUT)
OKO = ProviderObservation(ObsKind.SUCCESS)


def step(h, obs, now):
    return next_provider_state(h, obs, now, PP)


def fails(h, n, now):
    for _ in range(n):
        h = step(h, FAIL, now)
    return h


class TestProviderStateMachine(unittest.TestCase):
    def setUp(self):
        self.h0 = initial_provider_health("p", END)

    def test_initial_state(self):
        self.assertEqual((self.h0.state, self.h0.consecutive_failures), (S.HEALTHY, 0))
        self.assertTrue(may_attempt(self.h0, END))

    def test_healthy_tolerates_one_failure_then_degrades(self):
        h = step(self.h0, FAIL, END)
        self.assertEqual((h.state, h.consecutive_failures), (S.HEALTHY, 1))
        h = step(h, FAIL, END)
        self.assertEqual(h.state, S.DEGRADED)
        self.assertEqual(h.reason.key, K.PROVIDER_DEGRADED)
        self.assertEqual(h.last_failure_class, FailureClass.PROVIDER_TIMEOUT)

    def test_success_resets_failure_streak_in_healthy(self):
        h = step(step(self.h0, FAIL, END), OKO, END)
        self.assertEqual((h.state, h.consecutive_failures), (S.HEALTHY, 0))
        self.assertEqual(step(h, FAIL, END).state, S.HEALTHY)                  # streak restarted, not accumulated

    def test_degraded_to_unavailable_after_threshold_with_cooldown(self):
        h = fails(self.h0, 4, END)
        self.assertEqual(h.state, S.DEGRADED)
        h = step(h, FAIL, END)
        self.assertEqual((h.state, h.outage_episodes), (S.UNAVAILABLE, 1))
        self.assertEqual(h.next_attempt_at, END + timedelta(seconds=30))
        self.assertEqual(h.reason.key, K.PROVIDER_UNAVAILABLE)

    def test_unavailable_fails_fast_until_cooldown_then_one_probe(self):
        h = fails(self.h0, 5, END)
        self.assertFalse(may_attempt(h, END))
        self.assertFalse(may_attempt(h, END + timedelta(seconds=29.9)))
        self.assertTrue(may_attempt(h, END + timedelta(seconds=30)))
        self.assertEqual(retry_after_seconds(h, END + timedelta(seconds=10)), 20.0)

    def test_failed_probe_backs_off_exponentially_with_cap(self):
        h, now, waits = fails(self.h0, 5, END), END, []
        for _ in range(8):
            now = h.next_attempt_at
            h = step(h, FAIL, now)
            self.assertEqual(h.state, S.UNAVAILABLE)
            waits.append((h.next_attempt_at - now).total_seconds())
        self.assertEqual(waits[:5], [60.0, 120.0, 240.0, 480.0, 900.0])       # 30 * 2^(episode-1), capped at 900
        self.assertEqual(set(waits[4:]), {900.0})

    def test_probe_success_enters_recovering_then_needs_consecutive_successes(self):
        h = fails(self.h0, 5, END)
        t = h.next_attempt_at
        h = step(h, OKO, t)
        self.assertEqual((h.state, h.consecutive_successes), (S.RECOVERING, 1))
        self.assertTrue(may_attempt(h, t))
        h = step(h, OKO, t)
        self.assertEqual((h.state, h.consecutive_successes), (S.RECOVERING, 2))
        h = step(h, OKO, t)
        self.assertEqual((h.state, h.outage_episodes, h.consecutive_failures), (S.HEALTHY, 0, 0))

    def test_failure_while_recovering_returns_to_unavailable_with_longer_cooldown(self):
        h = fails(self.h0, 5, END)
        t = h.next_attempt_at
        h = step(step(h, OKO, t), FAIL, t)
        self.assertEqual(h.state, S.UNAVAILABLE)
        self.assertEqual(h.outage_episodes, 2)
        self.assertEqual((h.next_attempt_at - t).total_seconds(), 60.0)

    def test_degraded_success_goes_through_recovering(self):
        h = fails(self.h0, 2, END)
        h = step(h, OKO, END)
        self.assertEqual((h.state, h.consecutive_successes), (S.RECOVERING, 1))

    def test_rate_limit_throttles_without_counting_as_failure(self):
        obs = ProviderObservation(ObsKind.RATE_LIMITED, FailureClass.PROVIDER_RATE_LIMITED, 45.0)
        h = step(self.h0, obs, END)
        self.assertEqual((h.state, h.consecutive_failures), (S.THROTTLED, 0))
        self.assertEqual(h.next_attempt_at, END + timedelta(seconds=45))
        self.assertEqual(h.last_failure_class, FailureClass.PROVIDER_RATE_LIMITED)
        self.assertFalse(may_attempt(h, END + timedelta(seconds=44)))
        self.assertTrue(may_attempt(h, END + timedelta(seconds=45)))

    def test_rate_limit_without_retry_after_uses_policy_default(self):
        for ra in (None, 0.0, -3.0):
            h = step(self.h0, ProviderObservation(ObsKind.RATE_LIMITED, FailureClass.PROVIDER_RATE_LIMITED, ra), END)
            self.assertEqual(h.next_attempt_at, END + timedelta(seconds=60))

    def test_throttled_then_success_recovers_and_failure_degrades(self):
        th = step(self.h0, ProviderObservation(ObsKind.RATE_LIMITED, FailureClass.PROVIDER_RATE_LIMITED, 10.0), END)
        t = END + timedelta(seconds=10)
        self.assertEqual(step(th, OKO, t).state, S.RECOVERING)
        self.assertEqual(step(th, FAIL, t).state, S.DEGRADED)

    def test_repeated_rate_limits_never_make_a_provider_unavailable(self):
        h = self.h0
        for i in range(20):
            h = step(h, ProviderObservation(ObsKind.RATE_LIMITED, FailureClass.PROVIDER_RATE_LIMITED, 5.0), END + timedelta(seconds=i))
        self.assertEqual((h.state, h.consecutive_failures), (S.THROTTLED, 0))

    def test_auth_failure_needs_operator_and_is_never_auto_retried(self):
        h = step(self.h0, ProviderObservation(ObsKind.AUTH_FAILURE, FailureClass.PROVIDER_UNAVAILABLE), END)
        self.assertEqual((h.state, h.requires_operator, h.next_attempt_at), (S.UNAVAILABLE, True, None))
        self.assertEqual(h.reason.key, K.PROVIDER_AUTH_FAILURE)
        self.assertFalse(may_attempt(h, END + timedelta(days=365)))
        r = operator_reset(h, END, PP)
        self.assertEqual((r.state, r.requires_operator), (S.RECOVERING, False))
        self.assertTrue(may_attempt(r, END))

    def test_transitions_are_pure_and_deterministic(self):
        before = self.h0
        outs = {repr(step(before, FAIL, END)) for _ in range(10)}
        self.assertEqual(len(outs), 1)
        self.assertEqual(before, initial_provider_health("p", END))

    def test_every_state_is_reachable(self):
        seen = {self.h0.state}
        h = self.h0
        seen.add(step(h, ProviderObservation(ObsKind.RATE_LIMITED, FailureClass.PROVIDER_RATE_LIMITED, 1.0), END).state)
        h = fails(h, 2, END); seen.add(h.state)
        h = fails(h, 3, END); seen.add(h.state)
        h = step(h, OKO, h.next_attempt_at); seen.add(h.state)
        self.assertEqual(seen, set(ProviderState))


class TestInstrumentHealth(unittest.TestCase):
    IP = InstrumentHealthPolicy()                 # degrade 1, quarantine 3, 900 s

    def nxt(self, h, ok, now=END):
        return next_instrument_state(h, "BTC/USDT", ok, now, self.IP)

    def test_progression_degraded_then_quarantined(self):
        h = self.nxt(None, False)
        self.assertEqual(h.state, InstrumentState.DEGRADED)
        h = self.nxt(h, False)
        self.assertEqual((h.state, h.consecutive_failures), (InstrumentState.DEGRADED, 2))
        h = self.nxt(h, False)
        self.assertEqual(h.state, InstrumentState.QUARANTINED)
        self.assertEqual(h.quarantined_until, END + timedelta(seconds=900))
        self.assertFalse(instrument_scannable(h, END + timedelta(seconds=899)))
        self.assertTrue(instrument_scannable(h, END + timedelta(seconds=900)))          # window over: one probe

    def test_probe_outcomes(self):
        q = self.nxt(self.nxt(self.nxt(None, False), False), False)
        t = END + timedelta(seconds=900)
        self.assertEqual(self.nxt(q, True, t).state, InstrumentState.AVAILABLE)
        again = self.nxt(q, False, t)
        self.assertEqual(again.state, InstrumentState.QUARANTINED)
        self.assertEqual(again.quarantined_until, t + timedelta(seconds=900))

    def test_success_resets_everything(self):
        h = self.nxt(self.nxt(None, False), True)
        self.assertEqual((h.state, h.consecutive_failures, h.quarantined_until), (InstrumentState.AVAILABLE, 0, None))

    def test_unknown_instrument_is_scannable(self):
        self.assertTrue(instrument_scannable(None, END))

    def test_computed_only_states_are_never_stored(self):
        h = None
        for ok in (False, False, False, True):
            h = self.nxt(h, ok)
            self.assertNotIn(h.state, (InstrumentState.UNAVAILABLE, InstrumentState.DISABLED))


class TestHealthBookIsolation(unittest.TestCase):
    def setUp(self):
        self.book = HealthBook(PP, InstrumentHealthPolicy())

    def test_one_provider_failing_does_not_touch_another(self):
        for _ in range(5):
            self.book.observe_provider("a", FAIL, END)
        self.book.observe_provider("b", OKO, END)
        self.assertEqual(self.book.provider("a", END).state, S.UNAVAILABLE)
        self.assertEqual(self.book.provider("b", END).state, S.HEALTHY)

    def test_instrument_failures_do_not_touch_other_instruments_or_any_provider(self):
        self.book.provider("a", END)
        for _ in range(3):
            self.book.observe_instrument("BAD/USDT", False, END)
        self.book.observe_instrument("GOOD/USDT", True, END)
        self.assertEqual(self.book.instrument("BAD/USDT").state, InstrumentState.QUARANTINED)
        self.assertEqual(self.book.instrument("GOOD/USDT").state, InstrumentState.AVAILABLE)
        self.assertEqual(self.book.provider("a", END).state, S.HEALTHY)

    def test_listings_are_sorted_for_stable_output(self):
        for n in ("z", "a", "m"):
            self.book.observe_provider(n, OKO, END)
            self.book.observe_instrument(f"{n.upper()}/USDT", True, END)
        self.assertEqual([p.provider for p in self.book.providers()], ["a", "m", "z"])
        self.assertEqual([i.symbol for i in self.book.instruments()], ["A/USDT", "M/USDT", "Z/USDT"])

    def test_reset_provider(self):
        self.book.observe_provider("a", ProviderObservation(ObsKind.AUTH_FAILURE, FailureClass.PROVIDER_UNAVAILABLE), END)
        prev, new = self.book.reset_provider("a", END)
        self.assertEqual((prev.state, new.state), (S.UNAVAILABLE, S.RECOVERING))


class TestBackoffAndJitter(unittest.TestCase):
    def test_jitter_is_deterministic_and_in_range(self):
        vals = [jitter_unit(7, "k", a) for a in range(1, 200)]
        self.assertEqual(vals, [jitter_unit(7, "k", a) for a in range(1, 200)])
        self.assertTrue(all(-1.0 <= v < 1.0 for v in vals))
        self.assertGreater(len(set(vals)), 150)
        self.assertNotEqual(jitter_unit(1, "k", 1), jitter_unit(2, "k", 1))
        self.assertNotEqual(jitter_unit(1, "k", 1), jitter_unit(1, "other", 1))

    def test_delay_grows_exponentially_and_is_capped(self):
        p = RetryPolicy(max_attempts=9, base_delay_seconds=1.0, multiplier=2.0, max_delay_seconds=10.0, jitter_fraction=0.0)
        self.assertEqual([compute_delay(p, "k", a) for a in range(1, 7)], [1.0, 2.0, 4.0, 8.0, 10.0, 10.0])

    def test_jitter_stays_within_fraction_and_never_exceeds_cap(self):
        p = RetryPolicy(max_attempts=9, base_delay_seconds=4.0, multiplier=1.0, max_delay_seconds=4.4, jitter_fraction=0.25)
        for a in range(1, 100):
            d = compute_delay(p, f"k{a}", a)
            self.assertTrue(0.0 <= d <= 4.4, d)
            self.assertTrue(3.0 <= d, d)


class TestRetryExecutor(unittest.TestCase):
    def make(self, **kw):
        self.sleep, self.sink = RecordingSleep(), InMemorySink()
        pol = RetryPolicy(**{"base_delay_seconds": 1.0, "jitter_fraction": 0.0, **kw})
        return RetryExecutor(pol, self.sleep, self.sink)

    def script(self, *items):
        q, calls = list(items), []

        def fn():
            calls.append(1)
            item = q.pop(0)
            if isinstance(item, BaseException):
                raise item
            return item
        return fn, calls

    def test_success_first_try_no_sleep(self):
        ex = self.make(max_attempts=3)
        fn, calls = self.script("ok")
        out = ex.execute(fn, "k", END)
        self.assertEqual((out.value, out.error, out.trace.attempts, self.sleep.calls), ("ok", None, 1, []))

    def test_timeout_then_success_sleeps_with_backoff(self):
        ex = self.make(max_attempts=4)
        fn, calls = self.script(TimeoutError(), TimeoutError(), "ok")
        out = ex.execute(fn, "k", END)
        self.assertEqual((out.value, out.trace.attempts), ("ok", 3))
        self.assertEqual(self.sleep.calls, [1.0, 2.0])
        self.assertEqual(out.trace.failure_classes, (FailureClass.PROVIDER_TIMEOUT,) * 2)
        self.assertEqual(len([e for e in self.sink.events if e.kind == DataEventKind.RETRY_ATTEMPT]), 2)

    def test_attempts_are_bounded_no_uncontrolled_loop(self):
        for n in (1, 2, 5):
            ex = self.make(max_attempts=n)
            fn, calls = self.script(*[TimeoutError()] * 50)
            out = ex.execute(fn, "k", END)
            self.assertIsInstance(out.error, TimeoutError)
            self.assertEqual((len(calls), out.trace.attempts, len(self.sleep.calls)), (n, n, n - 1))

    def test_default_policy_never_retries_or_sleeps(self):
        ex = RetryExecutor(RetryPolicy(), RecordingSleep())
        fn, calls = self.script(TimeoutError())
        out = ex.execute(fn, "k", END)
        self.assertEqual((len(calls), isinstance(out.error, TimeoutError)), (1, True))

    def test_non_retryable_faults_are_not_retried(self):
        for exc in (DataUnavailableError("x"), ConnectionError(), ProviderPayloadError("x"), ValueError(), KeyError("k"), RuntimeError()):
            ex = self.make(max_attempts=5)
            fn, calls = self.script(exc, "never")
            out = ex.execute(fn, "k", END)
            self.assertIs(out.error, exc)
            self.assertEqual((len(calls), self.sleep.calls), (1, []), type(exc))

    def test_auth_failure_is_never_retried_even_if_configured(self):
        ex = self.make(max_attempts=5, retry_on=frozenset(FailureClass))
        fn, calls = self.script(ProviderAuthError("401"), "never")
        out = ex.execute(fn, "k", END)
        self.assertIsInstance(out.error, ProviderAuthError)
        self.assertEqual(len(calls), 1)

    def test_rate_limit_is_not_waited_on_by_default(self):
        ex = self.make(max_attempts=5)
        fn, calls = self.script(ProviderRateLimitedError("rl", 1.0), "never")
        out = ex.execute(fn, "k", END)
        self.assertIsInstance(out.error, ProviderRateLimitedError)
        self.assertEqual((len(calls), self.sleep.calls), (1, []))

    def test_rate_limit_wait_is_bounded_by_policy(self):
        ex = self.make(max_attempts=3, rate_limit_max_wait_seconds=10.0)
        fn, calls = self.script(ProviderRateLimitedError("rl", 5.0), "ok")
        self.assertEqual(ex.execute(fn, "k", END).value, "ok")
        self.assertEqual(self.sleep.calls, [5.0])
        fn, calls = self.script(ProviderRateLimitedError("rl", 20.0), "never")           # longer than the bound: refuse to wait
        self.assertIsInstance(ex.execute(fn, "k", END).error, ProviderRateLimitedError)
        fn, calls = self.script(ProviderRateLimitedError("rl", None), "never")
        self.assertIsInstance(ex.execute(fn, "k", END).error, ProviderRateLimitedError)
        fn, calls = self.script(*[ProviderRateLimitedError("rl", 1.0)] * 10)
        out = ex.execute(fn, "k", END)
        self.assertEqual(len(calls), 3)                                                    # still bounded by max_attempts

    def test_retry_delays_are_reproducible(self):
        traces = []
        for _ in range(3):
            ex = self.make(max_attempts=4, jitter_fraction=0.3, jitter_seed=11)
            fn, _ = self.script(TimeoutError(), TimeoutError(), TimeoutError(), "ok")
            traces.append(ex.execute(fn, "same-key", END).trace)
        self.assertEqual(traces[0], traces[1])
        self.assertEqual(traces[1], traces[2])


class TestThrottle(unittest.TestCase):
    def test_disabled_by_default(self):
        t = Throttle(ThrottlePolicy())
        self.assertTrue(all(t.try_acquire(END)[0] for _ in range(1000)))

    def test_sliding_window(self):
        t = Throttle(ThrottlePolicy(max_requests=3, per_seconds=10.0))
        for i in range(3):
            self.assertEqual(t.try_acquire(END + timedelta(seconds=i)), (True, None))
        ok, wait = t.try_acquire(END + timedelta(seconds=3))
        self.assertFalse(ok)
        self.assertEqual(wait, 7.0)                                          # oldest request leaves the window at +10 s
        self.assertEqual(t.try_acquire(END + timedelta(seconds=10))[0], True)
        self.assertFalse(t.try_acquire(END + timedelta(seconds=10.5))[0])

    def test_denied_requests_are_not_counted(self):
        t = Throttle(ThrottlePolicy(max_requests=1, per_seconds=10.0))
        t.try_acquire(END)
        for i in range(1, 9):
            self.assertFalse(t.try_acquire(END + timedelta(seconds=i))[0])
        self.assertTrue(t.try_acquire(END + timedelta(seconds=10))[0])


class TestStream(unittest.TestCase):
    TF = Timeframe.M5

    def r(self, minutes):
        o = END + timedelta(minutes=minutes)
        return row(open_time=o, close_time=o + timedelta(minutes=5))

    def test_updates_accepted_in_order_and_forming_bar_is_replaced(self):
        s = BarStore()
        self.assertTrue(s.apply_update(BarUpdate("X", self.TF, self.r(0), 1)).accepted)
        self.assertTrue(s.apply_update(BarUpdate("X", self.TF, self.r(5), 2)).accepted)
        upd = row(c=101.0, open_time=END + timedelta(minutes=5), close_time=END + timedelta(minutes=10))
        self.assertTrue(s.apply_update(BarUpdate("X", self.TF, upd, 3)).accepted)
        snap = s.snapshot("X", self.TF, 10)
        self.assertEqual(len(snap), 2)
        self.assertEqual(snap[-1].close, 101.0)

    def test_out_of_order_and_duplicate_sequences_rejected(self):
        s = BarStore()
        s.apply_update(BarUpdate("X", self.TF, self.r(0), 5))
        for seq in (5, 4, 1):
            res = s.apply_update(BarUpdate("X", self.TF, self.r(5), seq))
            self.assertFalse(res.accepted)
            self.assertEqual(res.reason.key, K.STREAM_UPDATE_OUT_OF_ORDER)
        self.assertEqual(s.rejected_count, 3)
        self.assertEqual(len(s.snapshot("X", self.TF, 10)), 1)

    def test_older_bar_after_newer_rejected(self):
        s = BarStore()
        s.apply_update(BarUpdate("X", self.TF, self.r(10)))
        self.assertFalse(s.apply_update(BarUpdate("X", self.TF, self.r(0))).accepted)

    def test_malformed_update_rejected(self):
        s = BarStore()
        res = s.apply_update(BarUpdate("X", self.TF, row(open_time="garbage", close_time=END)))
        self.assertEqual((res.accepted, res.reason.key), (False, K.STREAM_UPDATE_MALFORMED))
        self.assertFalse(s.apply_update(BarUpdate("X", self.TF, row(open_time=datetime(2024, 1, 1), close_time=END))).accepted)

    def test_streams_are_isolated_by_symbol_and_timeframe(self):
        s = BarStore()
        s.apply_update(BarUpdate("X", self.TF, self.r(0), 9))
        self.assertTrue(s.apply_update(BarUpdate("Y", self.TF, self.r(0), 1)).accepted)
        self.assertTrue(s.apply_update(BarUpdate("X", Timeframe.M15, self.r(0), 1)).accepted)

    def test_store_is_bounded(self):
        s = BarStore(max_bars=3)
        for i in range(10):
            s.apply_update(BarUpdate("X", self.TF, self.r(5 * i), i))
        snap = s.snapshot("X", self.TF, 100)
        self.assertEqual(len(snap), 3)
        self.assertEqual(snap[-1].open_time, END + timedelta(minutes=45))

    def test_streaming_feed_serves_store_and_fails_closed_when_empty(self):
        s = BarStore()
        caps = scripted_capabilities({AssetClass.CRYPTO}, {self.TF})
        feed = StreamingFeed("ws", caps, s)
        with self.assertRaises(DataUnavailableError):
            feed.latest_bars(BarRequest("X", self.TF, 10))
        s.seed("X", self.TF, [self.r(0), self.r(5)])
        raw = feed.latest_bars(BarRequest("X", self.TF, 1))
        self.assertEqual((raw.provider_symbol, raw.timeframe, len(raw.rows)), ("X", self.TF, 1))

    def test_seed_refuses_bad_rows(self):
        with self.assertRaises(ValueError):
            BarStore().seed("X", self.TF, [row(open_time="junk", close_time=END)])


if __name__ == "__main__":
    unittest.main()
