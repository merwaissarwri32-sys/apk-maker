import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.resampling import ResamplingError, min_source_bars_for_target, resample_bars

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)


def _bar(i, o, h, l, c, v=10.0, step_minutes=15):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v,
                     open_time=T0 + timedelta(minutes=step_minutes * i),
                     close_time=T0 + timedelta(minutes=step_minutes * (i + 1)))


class TestBasicAggregation(unittest.TestCase):
    def test_four_m15_bars_form_one_h1_bar(self):
        bars = [_bar(i, 100 + i, 100 + i + 1, 100 + i - 1, 100 + i + 0.5) for i in range(4)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(len(h1), 1)
        b = h1[0]
        self.assertEqual(b.open, bars[0].open)
        self.assertEqual(b.close, bars[-1].close)
        self.assertEqual(b.high, max(x.high for x in bars))
        self.assertEqual(b.low, min(x.low for x in bars))
        self.assertEqual(b.volume, sum(x.volume for x in bars))
        self.assertEqual(b.open_time, bars[0].open_time)
        self.assertEqual(b.close_time, bars[-1].close_time)

    def test_sixteen_m15_bars_form_four_h1_bars(self):
        bars = [_bar(i, 100 + i, 100 + i + 1, 100 + i - 1, 100 + i + 0.5) for i in range(16)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(len(h1), 4)

    def test_h1_to_h4_aggregation(self):
        bars = [OHLCVBar(open=100 + i, high=101 + i, low=99 + i, close=100.5 + i, volume=10,
                          open_time=T0 + timedelta(hours=i), close_time=T0 + timedelta(hours=i + 1)) for i in range(8)]
        h4 = resample_bars(bars, Timeframe.H1, Timeframe.H4)
        self.assertEqual(len(h4), 2)

    def test_h4_to_d1_aggregation(self):
        bars = [OHLCVBar(open=100 + i, high=101 + i, low=99 + i, close=100.5 + i, volume=10,
                          open_time=T0 + timedelta(hours=4 * i), close_time=T0 + timedelta(hours=4 * (i + 1))) for i in range(6)]
        d1 = resample_bars(bars, Timeframe.H4, Timeframe.D1)
        self.assertEqual(len(d1), 1)


class TestIncompleteBucketHandling(unittest.TestCase):
    def test_trailing_incomplete_bucket_dropped(self):
        bars = [_bar(i, 100 + i, 100 + i + 1, 100 + i - 1, 100 + i + 0.5) for i in range(5)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(len(h1), 1)

    def test_gap_in_source_data_produces_incomplete_bucket_dropped(self):
        bars = [_bar(0, 100, 101, 99, 100), _bar(1, 100, 101, 99, 100), _bar(3, 100, 101, 99, 100)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(len(h1), 0)

    def test_never_emits_a_forming_candle_as_closed(self):
        import random
        rng = random.Random(1)
        bars = [_bar(i, 100, 101, 99, 100.5) for i in range(rng.randint(1, 50))]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertLessEqual(len(h1), len(bars) // 4)


class TestValidation(unittest.TestCase):
    def test_target_smaller_than_source_rejected(self):
        bars = [_bar(0, 100, 101, 99, 100)]
        with self.assertRaises(ResamplingError):
            resample_bars(bars, Timeframe.H1, Timeframe.M15)

    def test_target_equal_source_rejected(self):
        bars = [_bar(0, 100, 101, 99, 100)]
        with self.assertRaises(ResamplingError):
            resample_bars(bars, Timeframe.M15, Timeframe.M15)

    def test_empty_bars_returns_empty(self):
        self.assertEqual(resample_bars([], Timeframe.M15, Timeframe.H1), [])


class TestDeterminism(unittest.TestCase):
    def test_repeated_calls_identical(self):
        bars = [_bar(i, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(40)]
        r1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        r2 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual([b.open_time for b in r1], [b.open_time for b in r2])
        self.assertEqual([b.close for b in r1], [b.close for b in r2])

    def test_appending_future_bars_does_not_change_earlier_target_bars(self):
        bars = [_bar(i, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(20)]
        r1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        extended = bars + [_bar(i, 9999, 9999, 1, 5000) for i in range(20, 40)]
        r2 = resample_bars(extended, Timeframe.M15, Timeframe.H1)
        self.assertEqual(r1, r2[: len(r1)])


class TestTimestampIntegrityAdversarial(unittest.TestCase):
    """Priority 1 (Phase 8 audit): resample_bars() must not treat a
    bucket as valid merely because it contains `ratio` source bars -
    it must verify those bars are actually the correct, complete,
    non-duplicated set of source intervals for that bucket."""

    def test_missing_first_source_bar_in_bucket_is_dropped(self):
        # bucket 0 is missing its first (:00) M15 bar - only 3 of 4 present
        bars = [_bar(1, 100, 101, 99, 100), _bar(2, 100, 101, 99, 100), _bar(3, 100, 101, 99, 100)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(h1, [])

    def test_missing_middle_source_bar_in_bucket_is_dropped(self):
        # bars 0,1,3 present, bar 2 (:30) missing - only 3 of 4 present
        bars = [_bar(0, 100, 101, 99, 100), _bar(1, 100, 101, 99, 100), _bar(3, 100, 101, 99, 100)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(h1, [])

    def test_missing_last_source_bar_in_bucket_is_dropped(self):
        bars = [_bar(0, 100, 101, 99, 100), _bar(1, 100, 101, 99, 100), _bar(2, 100, 101, 99, 100)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(h1, [])

    def test_duplicate_timestamp_within_bucket_is_rejected_not_silently_counted(self):
        # CRITICAL: bar index 1 (:15) is duplicated and bar index 2 (:30) is
        # genuinely missing. Naive len(group) == ratio (4) would wrongly
        # accept this bucket as complete. Must be detected, not silently
        # aggregated as if it were a real, complete H1 candle.
        bars = [
            _bar(0, 100, 101, 99, 100),
            _bar(1, 100, 101, 99, 100),
            _bar(1, 100, 101, 99, 100),  # duplicate of bar 1's timestamp
            _bar(3, 100, 101, 99, 100),
        ]
        with self.assertRaises(ResamplingError):
            resample_bars(bars, Timeframe.M15, Timeframe.H1)

    def test_duplicate_timestamp_with_conflicting_values_is_rejected(self):
        b0 = _bar(0, 100, 101, 99, 100)
        b1a = _bar(1, 100, 101, 99, 100)
        b1b = OHLCVBar(open=999, high=999, low=999, close=999, volume=1,
                        open_time=b1a.open_time, close_time=b1a.close_time)
        b2 = _bar(2, 100, 101, 99, 100)
        b3 = _bar(3, 100, 101, 99, 100)
        with self.assertRaises(ResamplingError):
            resample_bars([b0, b1a, b1b, b2, b3], Timeframe.M15, Timeframe.H1)

    def test_out_of_order_input_still_buckets_correctly(self):
        ordered = [_bar(i, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(8)]
        shuffled = [ordered[3], ordered[0], ordered[6], ordered[1], ordered[7], ordered[2], ordered[5], ordered[4]]
        h1_ordered = resample_bars(ordered, Timeframe.M15, Timeframe.H1)
        h1_shuffled = resample_bars(shuffled, Timeframe.M15, Timeframe.H1)
        self.assertEqual(h1_ordered, h1_shuffled)
        self.assertEqual(len(h1_ordered), 2)

    def test_malformed_source_timestamp_not_aligned_to_grid_is_rejected(self):
        # A source bar whose open_time does not fall on a clean M15
        # boundary (e.g. :07 instead of :00/:15/:30/:45) is corrupt
        # input and must never be silently folded into a bucket.
        good = [_bar(i, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(3)]
        misaligned = OHLCVBar(open=100, high=101, low=99, close=100.5,
                               volume=10, open_time=T0 + timedelta(minutes=52),
                               close_time=T0 + timedelta(minutes=67))
        with self.assertRaises(ResamplingError):
            resample_bars(good + [misaligned], Timeframe.M15, Timeframe.H1)

    def test_duplicate_plus_missing_combination_across_multiple_buckets(self):
        # Bucket 0 (bars 0-3): bar 1 duplicated, bar 2 missing -> corrupt.
        bars = [
            _bar(0, 100, 101, 99, 100),
            _bar(1, 100, 101, 99, 100),
            _bar(1, 100, 101, 99, 100),
            _bar(3, 100, 101, 99, 100),
            # Bucket 1 (bars 4-7): perfectly fine, must still raise overall
            # since the source series as a whole is corrupt (fail-closed).
            _bar(4, 100, 101, 99, 100), _bar(5, 100, 101, 99, 100),
            _bar(6, 100, 101, 99, 100), _bar(7, 100, 101, 99, 100),
        ]
        with self.assertRaises(ResamplingError):
            resample_bars(bars, Timeframe.M15, Timeframe.H1)

    def test_perfect_sequence_with_exact_expected_starts_is_accepted(self):
        bars = [_bar(i, 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(4)]
        h1 = resample_bars(bars, Timeframe.M15, Timeframe.H1)
        self.assertEqual(len(h1), 1)


class TestMinSourceBarsHelper(unittest.TestCase):
    def test_m15_to_h1_ratio(self):
        self.assertEqual(min_source_bars_for_target(Timeframe.M15, Timeframe.H1, 10), 40)

    def test_h1_to_d1_ratio(self):
        self.assertEqual(min_source_bars_for_target(Timeframe.H1, Timeframe.D1, 5), 120)


if __name__ == "__main__":
    unittest.main()
