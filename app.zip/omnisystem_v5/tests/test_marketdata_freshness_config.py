"""Phase 11: freshness model, single-source limits, attempt budget. SYNTHETIC / deterministic."""
import unittest
from datetime import timedelta

from omnisystem_v5.marketdata.config import (ConfigError, FreshnessPolicy, InstrumentHealthPolicy, MarketDataConfig, ProviderHealthPolicy,
                                             QuotePolicy, RetryPolicy, SharedLimits, ThrottlePolicy, ValidationPolicy, WiringMismatchError)
from omnisystem_v5.marketdata.freshness import FreshnessState as F
from omnisystem_v5.marketdata.freshness import classify_freshness
from omnisystem_v5.scanner import ScannerConfig
from omnisystem_v5.scanner.failures import FailureClass
from omnisystem_v5.scanner.timeframes import check_envelope_time
from omnisystem_v5.schemas.enums import QualityStatus, Timeframe
from omnisystem_v5.tests.marketdata_fixtures import ALL_TFS, END
from omnisystem_v5.tests.scanner_fixtures import bars_ending_at, envelope, loose_risk_policy
from omnisystem_v5.validation.resampling import seconds_for_timeframe

POL = FreshnessPolicy(10.0)


def limits(s=2.0):
    return SharedLimits(s, 40, 200, 2)


class TestClassification(unittest.TestCase):
    def test_states_at_exact_boundaries(self):
        for tf in ALL_TFS:
            step = seconds_for_timeframe(tf)
            last = END
            at = lambda secs: classify_freshness(last, END + timedelta(seconds=secs), tf, limits(), POL).state
            self.assertEqual(at(0), F.FRESH)
            self.assertEqual(at(2 * step), F.FRESH)                       # boundary is inclusive, like the scanner
            self.assertEqual(at(2 * step + 0.001), F.STALE)
            self.assertEqual(at(10 * step), F.STALE)
            self.assertEqual(at(10 * step + 0.001), F.EXPIRED)

    def test_missing_invalid_degraded(self):
        tf = Timeframe.M5
        self.assertEqual(classify_freshness(None, END, tf, limits(), POL).state, F.MISSING)
        self.assertEqual(classify_freshness(END, END, tf, limits(), POL, valid=False).state, F.INVALID)
        self.assertEqual(classify_freshness(END + timedelta(seconds=1), END, tf, limits(), POL).state, F.INVALID)     # closes in the future
        self.assertEqual(classify_freshness(END, END, tf, limits(), POL, degraded=True).state, F.DEGRADED)
        self.assertEqual(classify_freshness(END, END + timedelta(hours=9), tf, limits(), POL, degraded=True).state, F.EXPIRED)

    def test_assessment_reports_limits_from_shared_config(self):
        a = classify_freshness(END, END + timedelta(seconds=1000), Timeframe.M5, limits(3.0), FreshnessPolicy(7.0))
        self.assertEqual((a.stale_after_seconds, a.expired_after_seconds, a.age_seconds), (900.0, 2100.0, 1000.0))
        self.assertEqual(a.state, F.STALE)


class TestSingleSourceOfTruth(unittest.TestCase):
    """GATE: Phase 11 'usable' (FRESH or DEGRADED) == the scanner's usable freshness region. No second threshold."""

    def test_agrees_with_scanner_over_a_dense_grid_of_ages(self):
        for staleness in (0.5, 1.0, 2.0, 2.5, 3.0):
            lim = limits(staleness)
            for tf in ALL_TFS:
                step = seconds_for_timeframe(tf)
                bars = bars_ending_at(tf, 50, END)
                env = envelope("BTC/USDT", tf, bars)
                bound = staleness * step
                ages = {0.0, bound - 1, bound - 1e-6, bound, bound + 1e-6, bound + 1, 5 * step, 10 * step, 100 * step}
                for age in sorted(a for a in ages if a >= 0):
                    now = END + timedelta(seconds=age)
                    scanner_usable = check_envelope_time(env, now, staleness) is None
                    for degraded in (False, True):
                        st = classify_freshness(END, now, tf, lim, POL, True, degraded).state
                        self.assertEqual(st in (F.FRESH, F.DEGRADED), scanner_usable, (staleness, tf, age, degraded))

    def test_future_last_bar_is_unusable_in_both_layers(self):
        env = envelope("BTC/USDT", Timeframe.M5, bars_ending_at(Timeframe.M5, 50, END))
        now = END - timedelta(seconds=1)
        self.assertIsNotNone(check_envelope_time(env, now, 2.0))
        self.assertEqual(classify_freshness(END, now, Timeframe.M5, limits(), POL).state, F.INVALID)

    def test_shared_limits_are_copied_from_the_scanner_config(self):
        scfg = ScannerConfig(risk_policy=loose_risk_policy())
        lim = SharedLimits.from_scanner_config(scfg)
        self.assertEqual((lim.staleness_bars, lim.min_bars, lim.fetch_limit, lim.scanner_max_fetch_attempts),
                         (scfg.staleness_bars, scfg.min_bars, scfg.fetch_limit, scfg.max_fetch_attempts))
        lim.verify_against(scfg)                                           # no exception
        MarketDataConfig.for_scanner(scfg)                                 # and the config builds from it

    def test_divergence_from_scanner_is_detected(self):
        scfg = ScannerConfig(risk_policy=loose_risk_policy())
        mine = SharedLimits.from_scanner_config(scfg)
        for field, value in (("staleness_bars", 3.0), ("fetch_limit", 250), ("max_fetch_attempts", 1)):
            other = ScannerConfig(risk_policy=loose_risk_policy(), **{field: value})
            with self.assertRaises(WiringMismatchError, msg=field):
                mine.verify_against(other)
        # min_bars is derived inside the scanner (from what its contexts require), so divergence is built on our side
        with self.assertRaises(WiringMismatchError):
            SharedLimits(mine.staleness_bars, mine.min_bars + 1, mine.fetch_limit, mine.scanner_max_fetch_attempts).verify_against(scfg)

    def test_freshness_policy_has_no_stale_threshold_of_its_own(self):
        self.assertEqual([f for f in FreshnessPolicy.__dataclass_fields__], ["expired_bars"])
        with self.assertRaises(ConfigError):
            MarketDataConfig(limits=limits(2.0), freshness=FreshnessPolicy(2.0))          # expiry must lie beyond the shared stale bound


class TestAttemptBudget(unittest.TestCase):
    def setUp(self):
        self.scfg = ScannerConfig(risk_policy=loose_risk_policy())                       # scanner retries: 2

    def test_default_multiplication_is_within_budget(self):
        cfg = MarketDataConfig.for_scanner(self.scfg)
        self.assertLessEqual(cfg.retry.max_attempts * cfg.limits.scanner_max_fetch_attempts, cfg.max_total_attempts_per_request)

    def test_retries_cannot_multiply_past_the_global_cap(self):
        with self.assertRaises(WiringMismatchError):
            MarketDataConfig.for_scanner(self.scfg, retry=RetryPolicy(max_attempts=2))     # 2 x 2 = 4 > 3
        MarketDataConfig.for_scanner(self.scfg, retry=RetryPolicy(max_attempts=2), max_total_attempts_per_request=4)
        with self.assertRaises(WiringMismatchError):
            MarketDataConfig.for_scanner(self.scfg, retry=RetryPolicy(max_attempts=5), max_total_attempts_per_request=9)

    def test_cap_is_computed_from_the_scanners_own_setting(self):
        one = ScannerConfig(risk_policy=loose_risk_policy(), max_fetch_attempts=1)
        MarketDataConfig.for_scanner(one, retry=RetryPolicy(max_attempts=3))                 # 3 x 1 = 3 <= 3


class TestPolicyValidation(unittest.TestCase):
    def test_bad_values_are_refused(self):
        bad = [lambda: SharedLimits(0, 40, 200, 2), lambda: SharedLimits(2.0, 0, 200, 2), lambda: SharedLimits(2.0, 40, 30, 2),
               lambda: SharedLimits(float("nan"), 40, 200, 2), lambda: SharedLimits(2.0, True, 200, 2),
               lambda: RetryPolicy(max_attempts=0), lambda: RetryPolicy(multiplier=0.5), lambda: RetryPolicy(jitter_fraction=1.5),
               lambda: RetryPolicy(base_delay_seconds=-1), lambda: RetryPolicy(retry_on=frozenset({"TIMEOUT"})),
               lambda: ThrottlePolicy(max_requests=0), lambda: ThrottlePolicy(per_seconds=0),
               lambda: ProviderHealthPolicy(degrade_after=5, unavailable_after=5), lambda: ProviderHealthPolicy(recover_successes=0),
               lambda: InstrumentHealthPolicy(degrade_after=4, quarantine_after=3), lambda: QuotePolicy(5, 5),
               lambda: ValidationPolicy(max_malformed_bars=-1), lambda: FreshnessPolicy(0)]
        for i, make in enumerate(bad):
            with self.assertRaises(ConfigError, msg=f"case {i}"):
                make()

    def test_defaults_retry_only_timeouts_and_never_waits_on_rate_limits(self):
        r = RetryPolicy()
        self.assertEqual(r.max_attempts, 1)
        self.assertEqual(r.retry_on, frozenset({FailureClass.PROVIDER_TIMEOUT}))
        self.assertEqual(r.rate_limit_max_wait_seconds, 0.0)


if __name__ == "__main__":
    unittest.main()
