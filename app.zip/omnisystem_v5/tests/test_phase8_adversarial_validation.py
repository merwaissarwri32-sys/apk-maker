"""
Phase 8 - Adversarial / Overfitting Validation Utility tests.

Every check below proves the utility function actually DETECTS the
condition it claims to detect (not merely "always returns clean") by
constructing a case engineered to trigger it, alongside a clean case
that must NOT trigger it.
"""
import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from omnisystem_v5.intelligence.enums import DirectionBias
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.tests.test_phase8_multi_horizon_replay import _scalp_candidate, _scalp_result
from omnisystem_v5.tests.test_phase8_walk_forward_runner import (
    _flat_bars, _rapid_fire_result, _rapid_fire_template, _scalp_only_template,
)
from omnisystem_v5.validation.adversarial_validation import (
    ConfigVariant,
    check_look_ahead_leakage,
    check_parameter_sensitivity,
    check_structural_robustness,
    check_window_robustness,
)
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
from omnisystem_v5.validation.walk_forward_runner import Fold, FoldResult, WalkForwardMode, WalkForwardResult, WalkForwardAggregateMetrics
from omnisystem_v5.validation.contracts import BacktestResult, DataQualityReport, HistoricalDatasetDescriptor, ReproducibilityRecord, SimulatedFill, TradeRecord
from omnisystem_v5.validation.enums import TradeLifecycleState, ExitReason

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)
_PATCH_SCALP = "omnisystem_v5.validation.multi_horizon_replay.detect_scalp_candidate"
_PATCH_RUN = "omnisystem_v5.validation.adversarial_validation.run_multi_horizon_replay"


def _dataset(n):
    return HistoricalDatasetDescriptor(symbol="BTCUSDT", timeframe=Timeframe.M15, bar_count=n,
                                        start_timestamp=T0, end_timestamp=T0 + timedelta(minutes=15 * n),
                                        source_description="test", dataset_hash="deadbeef")


def _trade(pnl, state=TradeLifecycleState.FINAL_EXIT, horizon="SCALP"):
    return TradeRecord(trade_id="t", symbol="BTCUSDT", direction="LONG", signal_time=T0, state=state,
                        entry_zone_bottom=99.0, entry_zone_top=100.0, stop_loss=95.0, take_profits=(115.0,),
                        pnl=pnl, horizon=horizon, source_engine="ScalpEngine")


def _fold_result(idx, pnl_list):
    trades = tuple(_trade(p) for p in pnl_list)
    backtest = BacktestResult(dataset=_dataset(10), data_quality=DataQualityReport(), trades=trades)
    fold = Fold(idx, 0, 39, 40, 59)
    return FoldResult(fold=fold, backtest=backtest)


class TestCheckLookAheadLeakage(unittest.TestCase):
    def test_real_engine_reports_no_leak(self):
        # Phase 9 retrofit: previously ran against a no-candidate mock, so
        # zero trades were compared (vacuous). Now real trades close and
        # the comparison must have actually checked some of them.
        bars = _flat_bars(120)
        template = _rapid_fire_template()
        # Root cause of the earlier hidden problem: the old extra bars
        # (_flat_bars(20)[:10]) restart at T0, i.e. duplicate/out-of-order
        # timestamps - run B was silently data-quality-blocked. Real future
        # bars must continue chronologically after the last compared bar.
        future = _flat_bars(130)[120:]
        with patch(_PATCH_SCALP, return_value=_rapid_fire_result()):
            result = check_look_ahead_leakage(bars, template, end_index=99, extra_future_bars=future)
        self.assertGreaterEqual(result.checked_trade_count, 3)
        self.assertFalse(result.leak_detected)

    def test_engineered_leak_is_actually_detected(self):
        # Simulate a hypothetical regression: run_multi_horizon_replay
        # itself is patched (at the point adversarial_validation calls
        # it) to return a result whose fields depend on len(bars) -
        # proving the detector has real teeth, not a rubber stamp.
        bars = _flat_bars(120)
        template = _scalp_only_template(max_lookback_bars=40)

        def fake_run(bars_arg, config_arg, run_id=None):
            n = len(bars_arg)
            trade = _trade(pnl=1.0)
            trade = replace(trade, decision_id=f"leaked-{n}")  # depends on total bar count = a leak
            return BacktestResult(dataset=_dataset(n), data_quality=DataQualityReport(), trades=(trade,))

        with patch(_PATCH_RUN, side_effect=fake_run):
            result = check_look_ahead_leakage(bars, template, end_index=99, extra_future_bars=_flat_bars(20)[:10])
        # only one trade exists in each run, so it IS the "last trade" and
        # is excluded from comparison by design - use two trades instead.
        def fake_run_two_trades(bars_arg, config_arg, run_id=None):
            n = len(bars_arg)
            t1 = replace(_trade(pnl=1.0), decision_id=f"leaked-{n}")
            t2 = _trade(pnl=2.0)
            return BacktestResult(dataset=_dataset(n), data_quality=DataQualityReport(), trades=(t1, t2))

        with patch(_PATCH_RUN, side_effect=fake_run_two_trades):
            result2 = check_look_ahead_leakage(bars, template, end_index=99, extra_future_bars=_flat_bars(20)[:10])
        self.assertTrue(result2.leak_detected)
        self.assertIn(0, result2.differing_trade_indices)

    def test_trade_count_mismatch_is_flagged_as_a_leak(self):
        bars = _flat_bars(120)
        template = _scalp_only_template(max_lookback_bars=40)

        def fake_run(bars_arg, config_arg, run_id=None):
            n = len(bars_arg)
            trades = tuple(_trade(pnl=1.0) for _ in range(n % 3))  # count depends on total bar count
            return BacktestResult(dataset=_dataset(n), data_quality=DataQualityReport(), trades=trades)

        with patch(_PATCH_RUN, side_effect=fake_run):
            result = check_look_ahead_leakage(bars, template, end_index=99, extra_future_bars=_flat_bars(20)[:10])
        self.assertTrue(result.leak_detected)


class TestCheckWindowRobustness(unittest.TestCase):
    def test_evenly_spread_pnl_is_not_flagged_as_dominated(self):
        fold_results = (_fold_result(0, [10.0]), _fold_result(1, [12.0]), _fold_result(2, [9.0]))
        wf_result = WalkForwardResult(mode=WalkForwardMode.ROLLING, dataset_hash="x", fold_results=fold_results,
                                       aggregate=WalkForwardAggregateMetrics(3, 3, 3, 3, 0, 31.0), config_summary={})
        result = check_window_robustness(wf_result, dominance_threshold=0.8)
        self.assertFalse(result.dominated_by_single_window)
        self.assertAlmostEqual(result.pnl_concentration_ratio, 12.0 / 31.0)

    def test_one_fold_dominating_pnl_is_correctly_flagged(self):
        fold_results = (_fold_result(0, [100.0]), _fold_result(1, [1.0]), _fold_result(2, [-1.0]))
        wf_result = WalkForwardResult(mode=WalkForwardMode.ROLLING, dataset_hash="x", fold_results=fold_results,
                                       aggregate=WalkForwardAggregateMetrics(3, 3, 3, 3, 0, 100.0), config_summary={})
        result = check_window_robustness(wf_result, dominance_threshold=0.8)
        self.assertTrue(result.dominated_by_single_window)

    def test_zero_total_pnl_never_fabricates_a_concentration_ratio(self):
        fold_results = (_fold_result(0, []), _fold_result(1, []))
        wf_result = WalkForwardResult(mode=WalkForwardMode.ROLLING, dataset_hash="x", fold_results=fold_results,
                                       aggregate=WalkForwardAggregateMetrics(2, 0, 0, 0, 0, 0.0), config_summary={})
        result = check_window_robustness(wf_result)
        self.assertIsNone(result.pnl_concentration_ratio)
        self.assertIsNone(result.dominated_by_single_window)


class TestCheckParameterSensitivity(unittest.TestCase):
    def test_small_config_change_with_large_pnl_swing_is_flagged(self):
        bars = _flat_bars(60)
        # bar 45 rallies through TP=115 so the baseline trade genuinely wins
        bars[45] = OHLCVBar(open=100.0, high=116.0, low=99.5, close=115.5, volume=10.0,
                            open_time=bars[45].open_time, close_time=bars[45].close_time)
        signal_time = bars[39].close_time
        c = _scalp_candidate(DirectionBias.BULLISH, signal_time, current_price=100.0,
                              entry=(99.0, 100.0), sl=95.0, tp=115.0)
        baseline_cfg = _scalp_only_template(max_lookback_bars=40)
        # max_sl_distance_pct=0.01 rejects the candidate's 5% stop at the real Risk gate
        variant_cfg = replace(baseline_cfg, risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=0.01))

        def side_effect(*a, **k):
            return _scalp_result(c) if a[1].bars[-1].close_time == signal_time else _scalp_result(None)

        with patch(_PATCH_SCALP, side_effect=side_effect):
            result = check_parameter_sensitivity(
                bars, ConfigVariant("baseline", baseline_cfg), (ConfigVariant("tighter_max_sl", variant_cfg),),
                sensitivity_threshold=0.5,
            )
        self.assertGreater(result.baseline.total_pnl, 0)
        self.assertEqual(result.variants[0].closed_trade_count, 0)
        self.assertAlmostEqual(result.max_relative_pnl_change, 1.0)
        self.assertTrue(result.high_sensitivity_flagged)

    def test_zero_baseline_pnl_never_fabricates_a_relative_change(self):
        bars = _flat_bars(60)
        baseline_cfg = _scalp_only_template(max_lookback_bars=40)
        with patch(_PATCH_SCALP, return_value=_scalp_result(None)):
            result = check_parameter_sensitivity(bars, ConfigVariant("baseline", baseline_cfg), ())
        self.assertEqual(result.baseline.total_pnl, 0)
        self.assertIsNone(result.max_relative_pnl_change)
        self.assertIsNone(result.high_sensitivity_flagged)


class TestCheckStructuralRobustness(unittest.TestCase):
    def test_clean_case_reports_no_crash(self):
        bars = _flat_bars(80)
        template = _scalp_only_template(max_lookback_bars=40)
        with patch(_PATCH_SCALP, return_value=_scalp_result(None)):
            result = check_structural_robustness(template, [("clean", bars)])
        self.assertTrue(result.all_cases_handled_without_unhandled_crash)
        self.assertIsNone(result.case_results[0].raised_exception_type)

    def test_corrupt_duplicate_timestamp_case_is_reported_as_blocked_not_a_crash(self):
        bars = _flat_bars(80)
        corrupt = list(bars)
        corrupt[40] = OHLCVBar(open=100, high=100.5, low=99.5, close=100, volume=10,
                                open_time=corrupt[39].open_time, close_time=corrupt[39].close_time)
        template = _scalp_only_template(max_lookback_bars=40)
        result = check_structural_robustness(template, [("duplicate_timestamp", corrupt)])
        self.assertTrue(result.all_cases_handled_without_unhandled_crash)
        self.assertTrue(result.case_results[0].data_quality_blocked)

    def test_a_genuine_crash_is_recorded_not_silently_hidden(self):
        template = _scalp_only_template(max_lookback_bars=40)
        with patch(_PATCH_RUN, side_effect=RuntimeError("simulated genuine bug")):
            result = check_structural_robustness(template, [("crash_case", _flat_bars(80))])
        self.assertFalse(result.all_cases_handled_without_unhandled_crash)
        self.assertEqual(result.case_results[0].raised_exception_type, "RuntimeError")
        self.assertEqual(result.case_results[0].raised_exception_message, "simulated genuine bug")

    def test_multiple_cases_each_reported_independently(self):
        bars = _flat_bars(80)
        template = _scalp_only_template(max_lookback_bars=40)
        call_count = {"n": 0}

        def side_effect(bars_arg, config_arg, run_id=None):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise ValueError("first case fails")
            from omnisystem_v5.validation.multi_horizon_replay import run_multi_horizon_replay as real_run
            return real_run(bars_arg, config_arg, run_id=run_id)

        with patch(_PATCH_RUN, side_effect=side_effect), patch(_PATCH_SCALP, return_value=_scalp_result(None)):
            result = check_structural_robustness(template, [("case_a", bars), ("case_b", bars)])
        self.assertEqual(len(result.case_results), 2)
        self.assertEqual(result.case_results[0].raised_exception_type, "ValueError")
        self.assertIsNone(result.case_results[1].raised_exception_type)  # 2nd case still ran independently


if __name__ == "__main__":
    unittest.main()
