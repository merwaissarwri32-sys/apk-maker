import unittest
from datetime import datetime, timezone

from omnisystem_v5.context.enums import ContextStatus, StructureEventType, SwingType, TrendState
from omnisystem_v5.context.schema import MarketContext, StructureEvent, TrendClassification
from omnisystem_v5.intelligence.enums import MarketRegime
from omnisystem_v5.intelligence.regime import classify_market_regime
from omnisystem_v5.quant.enums import QuantStatus, VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.schema import QuantContext, VolatilityContext
from omnisystem_v5.schemas.enums import Timeframe

UTC = timezone.utc


def _mctx(status=ContextStatus.OK, trend=TrendState.UPTREND, events=()):
    now = datetime.now(UTC)
    return MarketContext(
        symbol="BTCUSDT", timeframe=Timeframe.H1, status=status, calculated_at=now, provenance=None,
        current_price=100.0 if status == ContextStatus.OK else None,
        trend=TrendClassification(state=trend, timeframe=Timeframe.H1, as_of=now, basis="test") if status == ContextStatus.OK else None,
        structure_events=events,
    )


def _qctx(status=QuantStatus.OK, regime=VolatilityRegime.NORMAL, phase=VolatilityPhase.STABLE):
    now = datetime.now(UTC)
    vol = VolatilityContext(
        atr=1.0, atr_period=14, atr_pct=1.0, rolling_volatility=0.01, rolling_window=20,
        regime=regime, phase=phase, basis="test", calculated_at=now,
    ) if status == QuantStatus.OK else None
    return QuantContext(symbol="BTCUSDT", timeframe=Timeframe.H1, status=status, calculated_at=now, provenance=None,
                         current_price=100.0 if status == QuantStatus.OK else None, volatility=vol)


class TestRegimeClassification(unittest.TestCase):
    def test_non_ok_contexts_are_unstable(self):
        regime, _ = classify_market_regime(_mctx(status=ContextStatus.DATA_UNAVAILABLE), _qctx())
        self.assertEqual(regime, MarketRegime.UNSTABLE_UNKNOWN)

    def test_recent_choch_takes_priority_as_reversal(self):
        now = datetime.now(UTC)
        events = (StructureEvent(event_type=StructureEventType.CHOCH_BEARISH, timestamp=now, price=100.0,
                                  timeframe=Timeframe.H1, calculation_source="test"),)
        regime, basis = classify_market_regime(_mctx(events=events), _qctx(phase=VolatilityPhase.EXPANSION))
        self.assertEqual(regime, MarketRegime.REVERSAL)

    def test_expansion_detected_when_no_recent_choch(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.RANGE), _qctx(phase=VolatilityPhase.EXPANSION))
        self.assertEqual(regime, MarketRegime.EXPANSION)

    def test_compression_detected(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.RANGE), _qctx(phase=VolatilityPhase.CONTRACTION))
        self.assertEqual(regime, MarketRegime.COMPRESSION)

    def test_trend_detected_when_stable_volatility(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.UPTREND), _qctx(phase=VolatilityPhase.STABLE))
        self.assertEqual(regime, MarketRegime.TREND)

    def test_range_detected(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.RANGE), _qctx(phase=VolatilityPhase.STABLE, regime=VolatilityRegime.NORMAL))
        self.assertEqual(regime, MarketRegime.RANGE)

    def test_high_volatility_fallback(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.UNDEFINED), _qctx(phase=VolatilityPhase.STABLE, regime=VolatilityRegime.HIGH))
        self.assertEqual(regime, MarketRegime.HIGH_VOLATILITY)

    def test_low_volatility_fallback(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.UNDEFINED), _qctx(phase=VolatilityPhase.STABLE, regime=VolatilityRegime.LOW))
        self.assertEqual(regime, MarketRegime.LOW_VOLATILITY)

    def test_totally_inconclusive_is_unstable(self):
        regime, _ = classify_market_regime(_mctx(trend=TrendState.UNDEFINED), _qctx(phase=VolatilityPhase.STABLE, regime=VolatilityRegime.NORMAL))
        self.assertEqual(regime, MarketRegime.UNSTABLE_UNKNOWN)


if __name__ == "__main__":
    unittest.main()
