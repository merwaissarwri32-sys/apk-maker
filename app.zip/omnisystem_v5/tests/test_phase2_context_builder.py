import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context, build_multi_timeframe_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import ContextValidationError, MarketContext
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _zigzag_bars(n, t0, base=100.0):
    """Deterministic oscillating series that reliably produces several
    confirmed swings with window=2, for a given bar count n."""
    bars = []
    price = base
    direction = 1
    for i in range(n):
        step = 3 if (i // 3) % 2 == 0 else -3
        price = base + step * ((i % 3) + 1) * 0.5 + (i * 0.15)  # gentle upward drift + oscillation
        o = price
        h = price + 1.5
        l = price - 1.5
        c = price + 0.3
        bars.append(_bar(t0 + timedelta(hours=i), o, h, l, c))
    return bars


def _envelope(bars, timeframe=Timeframe.H1, quality=QualityStatus.OK, origin=DataOrigin.HISTORICAL, reasons=()):
    now = datetime.now(UTC)
    data_ts = bars[-1].close_time if bars else now
    prov = DataProvenance(source="test", origin=origin, fetched_at=now, data_timestamp=data_ts)
    return MarketDataEnvelope(
        market="BTCUSDT", timeframe=timeframe, provenance=prov,
        quality_status=quality, bars=tuple(bars), reasons=tuple(reasons),
    )


class TestBuildMarketContextStatusMapping(unittest.TestCase):
    def test_data_unavailable_maps_through(self):
        t0 = datetime.now(UTC)
        prov = DataProvenance(source="x", origin=DataOrigin.UNAVAILABLE, fetched_at=t0, data_timestamp=t0)
        env = MarketDataEnvelope(
            market="BTCUSDT", timeframe=Timeframe.H1, provenance=prov,
            quality_status=QualityStatus.DATA_UNAVAILABLE, bars=(), reasons=("no data",),
        )
        ctx = build_market_context("BTCUSDT", env)
        self.assertEqual(ctx.status, ContextStatus.DATA_UNAVAILABLE)
        self.assertIsNone(ctx.current_price)
        self.assertEqual(len(ctx.swing_points), 0)

    def test_phase1_insufficient_data_maps_to_insufficient_context(self):
        bars = _zigzag_bars(5, datetime.now(UTC) - timedelta(hours=5))
        env = _envelope(bars, quality=QualityStatus.INSUFFICIENT_DATA, reasons=("only 5 bars",))
        ctx = build_market_context("BTCUSDT", env)
        self.assertEqual(ctx.status, ContextStatus.INSUFFICIENT_CONTEXT)

    def test_phase1_invalid_maps_to_invalid_context(self):
        bars = _zigzag_bars(25, datetime.now(UTC) - timedelta(hours=25))
        env = _envelope(bars, quality=QualityStatus.INVALID, reasons=("gap detected",))
        ctx = build_market_context("BTCUSDT", env)
        self.assertEqual(ctx.status, ContextStatus.INVALID_CONTEXT)

    def test_phase1_stale_is_treated_as_data_unavailable(self):
        bars = _zigzag_bars(25, datetime.now(UTC) - timedelta(hours=25))
        env = _envelope(bars, quality=QualityStatus.STALE, reasons=("too old",))
        ctx = build_market_context("BTCUSDT", env)
        self.assertEqual(ctx.status, ContextStatus.DATA_UNAVAILABLE)

    def test_own_min_bars_threshold_triggers_insufficient_context(self):
        bars = _zigzag_bars(10, datetime.now(UTC) - timedelta(hours=10))
        env = _envelope(bars, quality=QualityStatus.OK)
        ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        self.assertEqual(ctx.status, ContextStatus.INSUFFICIENT_CONTEXT)
        self.assertIn("30 required", ctx.reasons[0])


class TestBuildMarketContextHappyPath(unittest.TestCase):
    def test_ok_status_populates_all_core_fields(self):
        t0 = datetime.now(UTC) - timedelta(hours=40)
        bars = _zigzag_bars(40, t0)
        env = _envelope(bars, quality=QualityStatus.OK)
        ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30, atr_period=14))
        self.assertEqual(ctx.status, ContextStatus.OK)
        self.assertEqual(ctx.current_price, bars[-1].close)
        self.assertIsNotNone(ctx.ohlcv_context)
        self.assertEqual(ctx.ohlcv_context.bar_count, 40)
        self.assertIsNotNone(ctx.volatility)
        self.assertIsNotNone(ctx.volatility.atr)
        self.assertIsNotNone(ctx.trend)

    def test_all_structure_events_retain_declared_timeframe(self):
        t0 = datetime.now(UTC) - timedelta(hours=40)
        bars = _zigzag_bars(40, t0)
        env = _envelope(bars, timeframe=Timeframe.H4, quality=QualityStatus.OK)
        ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        self.assertTrue(all(e.timeframe == Timeframe.H4 for e in ctx.structure_events))
        self.assertTrue(all(sp.timeframe == Timeframe.H4 for sp in ctx.swing_points))

    def test_non_ok_context_cannot_carry_calculated_fields(self):
        """Direct schema-level enforcement: constructing a non-OK context
        with calculated fields populated must fail, regardless of how it's built."""
        t0 = datetime.now(UTC)
        with self.assertRaises(ContextValidationError):
            MarketContext(
                symbol="BTCUSDT",
                timeframe=Timeframe.H1,
                status=ContextStatus.DATA_UNAVAILABLE,
                calculated_at=t0,
                provenance=None,
                current_price=100.0,  # not allowed alongside a non-OK status
            )


class TestMultiTimeframeIntegrity(unittest.TestCase):
    def test_each_timeframe_calculated_independently(self):
        t0 = datetime.now(UTC) - timedelta(hours=40)
        bars_h1 = _zigzag_bars(40, t0)
        bars_h4 = _zigzag_bars(10, t0)  # deliberately insufficient for H4
        env_h1 = _envelope(bars_h1, timeframe=Timeframe.H1, quality=QualityStatus.OK)
        env_h4 = _envelope(bars_h4, timeframe=Timeframe.H4, quality=QualityStatus.OK)

        mtf = build_multi_timeframe_context(
            "BTCUSDT", {Timeframe.H1: env_h1, Timeframe.H4: env_h4},
            MarketContextConfig(min_bars_required=30),
        )
        ctx_h1 = mtf.get(Timeframe.H1)
        ctx_h4 = mtf.get(Timeframe.H4)

        self.assertEqual(ctx_h1.status, ContextStatus.OK)
        self.assertEqual(ctx_h4.status, ContextStatus.INSUFFICIENT_CONTEXT)
        # H1 having enough data must not "leak" into H4's result
        self.assertEqual(len(ctx_h4.swing_points), 0)

    def test_mismatched_timeframe_key_rejected(self):
        t0 = datetime.now(UTC) - timedelta(hours=40)
        bars = _zigzag_bars(40, t0)
        env = _envelope(bars, timeframe=Timeframe.H1, quality=QualityStatus.OK)
        ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))

        from omnisystem_v5.context.schema import MultiTimeframeMarketContext

        with self.assertRaises(ContextValidationError):
            MultiTimeframeMarketContext(
                symbol="BTCUSDT",
                calculated_at=datetime.now(UTC),
                contexts={Timeframe.H4: ctx},  # ctx.timeframe is H1, key says H4
            )


if __name__ == "__main__":
    unittest.main()
