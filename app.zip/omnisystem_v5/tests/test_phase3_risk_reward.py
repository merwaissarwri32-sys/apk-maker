import unittest

from omnisystem_v5.quant.risk_reward import RiskRewardError, calculate_r_multiple, calculate_risk_reward


class TestRiskReward(unittest.TestCase):
    def test_basic_long_style_calculation(self):
        result = calculate_risk_reward(entry=100, invalidation=95, target=115)
        self.assertAlmostEqual(result.risk_distance, 5.0)
        self.assertAlmostEqual(result.percentage_risk, 5.0)
        self.assertAlmostEqual(result.reward_distance, 15.0)
        self.assertAlmostEqual(result.potential_reward_pct, 15.0)
        self.assertAlmostEqual(result.reward_risk_ratio, 3.0)

    def test_basic_short_style_calculation(self):
        result = calculate_risk_reward(entry=100, invalidation=105, target=85)
        self.assertAlmostEqual(result.risk_distance, 5.0)
        self.assertAlmostEqual(result.reward_distance, 15.0)
        self.assertAlmostEqual(result.reward_risk_ratio, 3.0)

    def test_without_target_leaves_reward_fields_none(self):
        result = calculate_risk_reward(entry=100, invalidation=95)
        self.assertIsNone(result.target)
        self.assertIsNone(result.reward_distance)
        self.assertIsNone(result.potential_reward_pct)
        self.assertIsNone(result.reward_risk_ratio)
        self.assertAlmostEqual(result.risk_distance, 5.0)

    def test_zero_risk_distance_raises(self):
        with self.assertRaises(RiskRewardError):
            calculate_risk_reward(entry=100, invalidation=100)

    def test_zero_reward_distance_raises(self):
        with self.assertRaises(RiskRewardError):
            calculate_risk_reward(entry=100, invalidation=95, target=100)

    def test_nonpositive_entry_raises(self):
        with self.assertRaises(RiskRewardError):
            calculate_risk_reward(entry=0, invalidation=-5)


class TestRMultiple(unittest.TestCase):
    def test_long_style_positive_r(self):
        # invalidation below entry -> "away from risk" is upward
        r = calculate_r_multiple(entry=100, invalidation=95, exit_price=110)
        self.assertAlmostEqual(r, 2.0)  # moved 10 up, risk was 5 -> +2R

    def test_long_style_negative_r(self):
        r = calculate_r_multiple(entry=100, invalidation=95, exit_price=90)
        self.assertAlmostEqual(r, -2.0)  # moved 10 down (through invalidation) -> -2R

    def test_short_style_positive_r(self):
        # invalidation above entry -> "away from risk" is downward
        r = calculate_r_multiple(entry=100, invalidation=105, exit_price=90)
        self.assertAlmostEqual(r, 2.0)

    def test_short_style_negative_r(self):
        r = calculate_r_multiple(entry=100, invalidation=105, exit_price=110)
        self.assertAlmostEqual(r, -2.0)

    def test_equal_entry_invalidation_raises(self):
        with self.assertRaises(Exception):
            calculate_r_multiple(entry=100, invalidation=100, exit_price=110)


if __name__ == "__main__":
    unittest.main()
