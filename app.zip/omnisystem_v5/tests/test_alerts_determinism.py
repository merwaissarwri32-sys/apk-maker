"""Phase 12 - determinism evidence. Identical inputs + configuration + injected clock must give byte-identical identities,
canonical alerts, envelopes and audit records, in-process and across different PYTHONHASHSEED values (separate interpreters).
All data is SYNTHETIC; the scanner/marketdata objects come from the real, unmodified stack."""
import json
import os
import subprocess
import sys
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from omnisystem_v5.alerts.sources import CatalogContextResolver, map_events, map_report, map_snapshot
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.tests.alerts_fixtures import Harness, real_outage_world, real_scan_world, scenario_digest

REPO = Path(__file__).resolve().parents[2]
SEEDS = ("0", "1", "42", "2026", "random-looking-777")


def run_with_seed(code: str, seed: str) -> str:
    env = {**os.environ, "PYTHONHASHSEED": seed if seed.isdigit() else "7", "PYTHONPATH": str(REPO)}
    out = subprocess.run([sys.executable, "-c", code], cwd=REPO, env=env, capture_output=True, text=True, timeout=300)
    assert out.returncode == 0, out.stderr[-800:]
    return out.stdout.strip()


class TestInProcessDeterminism(unittest.TestCase):
    def test_mapping_is_identical_every_time(self):
        report, catalog, snap, events = real_scan_world()
        osnap, oevents = real_outage_world()
        runs = [(map_report(report, CatalogContextResolver(catalog), include_healthy=True), map_snapshot(osnap, include_healthy=True),
                 map_events(oevents)) for _ in range(5)]
        self.assertTrue(all(r == runs[0] for r in runs))

    def test_alert_identity_and_canonical_json_are_byte_identical_across_runs_and_clocks(self):
        report, catalog, *_ = real_scan_world()

        def ids(start):
            h = Harness(clock=ManualClock(start))
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            return [json.loads(e.payload_json)["identity"] for e in h.recording.sent]
        base = ids(datetime(2024, 3, 1, tzinfo=timezone.utc))
        self.assertEqual(base, ids(datetime(2024, 3, 1, tzinfo=timezone.utc)))
        self.assertEqual(base, ids(datetime(2031, 7, 9, 13, 5, tzinfo=timezone.utc)))          # identity does not depend on wall-clock

    def test_full_pipeline_output_is_byte_identical_across_five_runs(self):
        outputs = {scenario_digest() for _ in range(5)}
        self.assertEqual(len(outputs), 1)

    def test_envelope_ids_are_stable_and_unique_per_target(self):
        report, catalog, *_ = real_scan_world()
        def ids():
            h = Harness()
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            return [e.envelope_id for e in h.recording.sent]
        a = ids()
        self.assertEqual(a, ids())
        self.assertEqual(len(a), len(set(a)))

    def test_delivery_backoff_schedule_is_reproducible(self):
        from omnisystem_v5.alerts.errors import TransportConfigError
        from omnisystem_v5.alerts.transport import ScriptedTransport
        from omnisystem_v5.alerts.routing import NotificationTarget, RoutingPolicy, RoutingRule
        from omnisystem_v5.alerts.enums import NotificationChannel
        from omnisystem_v5.tests.test_alerts_domain import cand

        def waits():
            routing = RoutingPolicy((NotificationTarget("a", NotificationChannel.INTERNAL),), (RoutingRule("all", ("a",)),))
            h = Harness(routing=routing, transports=(ScriptedTransport([TimeoutError()] * 3),))
            h.pipeline.process(__import__("omnisystem_v5.alerts.sources", fromlist=["MapResult"]).MapResult((cand(),)))
            return h.sleep.waits
        self.assertEqual(waits(), waits())
        self.assertEqual(len(waits()), 2)

    def test_dedup_state_serialisation_is_byte_identical(self):
        report, catalog, *_ = real_scan_world()
        def state_json():
            h = Harness()
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            h.clock.advance(10)
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            return json.dumps(h.store.load().to_dict(), sort_keys=True)
        self.assertEqual(state_json(), state_json())


class TestAcrossPythonHashSeeds(unittest.TestCase):
    def test_identity_and_canonical_alert_do_not_depend_on_hash_randomization(self):
        code = ("from omnisystem_v5.tests.test_alerts_domain import cand, alert\n"
                "from omnisystem_v5.alerts.model import AlertContext\n"
                "a = alert(); b = alert(state='DEGRADED')\n"
                "print(a.alert_id, b.alert_id, __import__('hashlib').sha256(a.to_json().encode()).hexdigest())")
        results = {seed: run_with_seed(code, seed) for seed in SEEDS}
        self.assertEqual(len(set(results.values())), 1, results)

    def test_the_whole_real_scanner_marketdata_pipeline_is_identical_across_hash_seeds(self):
        code = "from omnisystem_v5.tests.alerts_fixtures import scenario_digest; print(scenario_digest())"
        results = {seed: run_with_seed(code, seed) for seed in ("0", "1", "42", "2026")}
        self.assertEqual(len(set(results.values())), 1, results)
        self.assertEqual(next(iter(results.values())), scenario_digest())               # and equal to this process's value

    def test_dedup_verdict_sequence_does_not_depend_on_hash_seed(self):
        code = ("from omnisystem_v5.tests.test_alerts_dedup import feed\n"
                "st, v = feed([(0,'a'),(100,'b'),(301,'c'),(401,'d'),(900,'e'),(950,'e')])\n"
                "import json; print(json.dumps([x.value for x in v]), json.dumps(st.to_dict(), sort_keys=True))")
        results = {seed: run_with_seed(code, seed) for seed in SEEDS}
        self.assertEqual(len(set(results.values())), 1, results)


if __name__ == "__main__":
    unittest.main()
