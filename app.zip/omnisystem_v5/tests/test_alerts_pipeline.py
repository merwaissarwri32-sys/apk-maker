"""Phase 12 - end-to-end pipeline over the REAL Phase 10 scanner / Phase 11 marketdata objects, failure isolation, telemetry,
audit, localization and the restart/idempotency seam. All data is SYNTHETIC; transports are in-memory fakes."""
import dataclasses
import json
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.alerts.audit import InMemoryAuditLog
from omnisystem_v5.alerts.dedup import AlertDedupPolicy, AlertDedupState, InMemoryAlertStateStore
from omnisystem_v5.alerts.enums import (AlertDedupVerdict as V, AlertSeverity as S, AlertType, DeliveryFailureKind as F, DeliveryStatus as D,
                                        NotificationChannel as C, QualificationOutcome as Q, RouteSuppression, RoutingOutcome)
from omnisystem_v5.alerts.errors import TransportAuthError
from omnisystem_v5.alerts.i18n import AlertMessageKey as K
from omnisystem_v5.alerts.policy import AlertPolicy, QualificationPolicy
from omnisystem_v5.alerts.routing import AlertRouter, NotificationTarget, QuietHours, RoutingPolicy, RoutingRule
from omnisystem_v5.alerts.sources import CatalogContextResolver, MapResult, map_events, map_report, map_snapshot
from omnisystem_v5.alerts.transport import RecordingTransport, ScriptedTransport, TransportRegistry
from omnisystem_v5.marketdata.config import ThrottlePolicy
from omnisystem_v5.marketdata.events import InMemorySink
from omnisystem_v5.marketdata.i18n import EN, FA, InMemoryCatalog
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.tests.alerts_fixtures import Harness, default_routing, real_outage_world, real_scan_world, real_suppressed_report
from omnisystem_v5.tests.test_alerts_domain import cand
from omnisystem_v5.tests.test_alerts_routing_delivery import mk, tgt


def run(h, *cands):
    return h.pipeline.process(MapResult(tuple(cands)))


class TestRealScannerIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report, cls.catalog, cls.snap, cls.events = real_scan_world()

    def setUp(self):
        self.h = Harness()
        self.res = CatalogContextResolver(self.catalog)

    def test_real_signals_flow_through_every_stage_to_both_locales(self):
        recs = self.h.pipeline.process_report(self.report, self.res)
        self.assertEqual([(r.alert_type, r.verdict, r.routing.outcome) for r in recs], [(AlertType.SIGNAL, V.NEW, RoutingOutcome.ROUTED)] * 2)
        self.assertEqual(len(self.h.recording.sent), 4)
        self.assertTrue(all(d.status == D.DELIVERED for r in recs for d in r.deliveries))
        langs = {(e.target.target_id, e.lines[2].locale.tag) for e in self.h.recording.sent}
        self.assertEqual(langs, {("ops-en", "en"), ("ops-fa", "fa")})
        en = next(e for e in self.h.recording.sent if e.target.target_id == "ops-en" and "BTC/USDT" in e.lines[2].text)
        self.assertTrue(en.lines[2].text.startswith("LONG setup on BTC/USDT"))
        self.assertIn("Entry zone", en.lines[3].text)
        self.assertIn("no guarantee", en.lines[-1].text)                                   # never a profit claim
        self.assertFalse(en.degraded_localization)

    def test_alert_carries_context_priority_and_evidence_from_the_real_contracts(self):
        rec = self.h.pipeline.process_report(self.report, self.res)[0]
        payload = json.loads(self.h.recording.sent[0].payload_json)
        self.assertEqual(payload["context"]["asset_class"], "CRYPTO")
        self.assertEqual(payload["context"]["venue"], "TESTX")
        self.assertEqual(payload["priority"]["kind"], "COMPUTATIONAL_PRIORITY_NOT_PROBABILITY")
        self.assertIn(["scanner.fingerprint", self.report.emitted[0].fingerprint], payload["evidence"])
        self.assertEqual(rec.source.kind.value, "SCANNER_SIGNAL")

    def test_replaying_the_same_report_never_notifies_twice(self):
        self.h.pipeline.process_report(self.report, self.res)
        before = len(self.h.recording.sent)
        recs = self.h.pipeline.process_report(self.report, self.res)
        self.assertEqual([r.verdict for r in recs], [V.EXACT_DUPLICATE] * 2)
        self.assertEqual(len(self.h.recording.sent), before)
        self.assertIn("ALERT_DEDUPLICATED", self.h.kinds())
        self.assertTrue(all(r.routing is None and r.deliveries == () for r in recs))

    def test_scanner_suppressed_signals_are_audited_but_never_alerted(self):
        rec = self.h.pipeline.process_report(real_suppressed_report(), self.res)
        self.assertEqual({r.qualification for r in rec}, {Q.REJECTED_UPSTREAM})
        self.assertEqual(self.h.recording.sent, [])
        self.assertEqual({r.rejection.key for r in rec}, {K.REJECT_UPSTREAM})
        self.assertEqual(set(self.h.kinds()), {"ALERT_SUPPRESSED"})

    def test_a_materially_different_setup_renotifies_as_an_update(self):
        c = map_report(self.report, self.res).candidates[0]
        run(self.h, c)
        changed = dataclasses.replace(c, state=(("fingerprint", "changed-setup"),), observation_key="signal:changed:1")
        rec = run(self.h, changed)[0]
        self.assertEqual(rec.verdict, V.MATERIAL_CHANGE)
        en = [e for e in self.h.recording.sent if e.target.target_id == "ops-en"]
        self.assertEqual(en[-1].lines[1].text, "Updated alert")

    def test_alert_processing_leaves_the_scan_report_untouched(self):
        before = json.dumps(self.report.canonical_dict(), sort_keys=True)
        self.h.pipeline.process_report(self.report, self.res)
        self.assertEqual(json.dumps(self.report.canonical_dict(), sort_keys=True), before)

    def test_candidates_are_processed_in_the_scanners_order(self):
        recs = self.h.pipeline.process_report(self.report, self.res)
        self.assertEqual([r.observation_key.split(":")[1] for r in recs], [s.fingerprint for s in self.report.emitted])


class TestRealDataHealthIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snap, cls.events = real_outage_world()

    def test_outage_snapshot_raises_a_critical_provider_alert_and_a_system_alert(self):
        h = Harness()
        recs = h.pipeline.process_snapshot(self.snap)
        by = {(r.alert_type, r.severity) for r in recs}
        self.assertIn((AlertType.PROVIDER_HEALTH, S.CRITICAL), by)
        self.assertTrue(all(r.routing.outcome == RoutingOutcome.ROUTED for r in recs))
        prov = next(e for e in h.recording.sent if e.severity == S.CRITICAL and "cryptofeed" in e.lines[2].text)
        self.assertEqual(prov.urgency.value, "HIGH")
        self.assertTrue(any(ln.message.key.value.startswith("provider.") for ln in prov.lines[3:]))   # Phase 11 reason reused

    def test_snapshot_replay_is_an_exact_duplicate(self):
        h = Harness()
        h.pipeline.process_snapshot(self.snap)
        self.assertEqual({r.verdict for r in h.pipeline.process_snapshot(self.snap)}, {V.EXACT_DUPLICATE})

    def test_event_view_of_an_outage_already_alerted_via_snapshot_is_not_renotified(self):
        h = Harness()
        h.pipeline.process_snapshot(self.snap)
        sent = len(h.recording.sent)
        last = [e for e in self.events if e.kind.value == "PROVIDER_STATE_CHANGED" and dict(e.detail)["to_state"] == "UNAVAILABLE"][-1]
        recs = h.pipeline.process_events([last], strict=False)
        self.assertEqual([(r.alert_type, r.severity, r.verdict) for r in recs], [(AlertType.PROVIDER_HEALTH, S.CRITICAL, V.STILL_ACTIVE)])
        self.assertEqual(len(h.recording.sent), sent)                            # same condition seen through a second source: no new notification

    def test_events_alone_produce_alerts_and_unsupported_ones_are_audited(self):
        h = Harness()
        recs = h.pipeline.process_events(self.events)
        self.assertTrue(any(r.qualification == Q.REJECTED_UNSUPPORTED for r in recs))
        self.assertTrue(any(r.qualification == Q.QUALIFIED and r.deliveries for r in recs))

    def test_recovery_alerts_need_explicit_opt_in(self):
        info = AlertPolicy(qualification=QualificationPolicy(min_severity=S.INFO))
        h = Harness(policy=info)
        recs = h.pipeline.process_snapshot(self.snap, include_healthy=True)
        self.assertIn(("fxfeed", S.INFO), {(dict(r.headline.params)["provider"], r.severity) for r in recs if r.alert_type == AlertType.PROVIDER_HEALTH})
        self.assertTrue(any(r.severity == S.INFO and r.deliveries for r in recs))
        quiet = Harness().pipeline.process_snapshot(self.snap, include_healthy=True)
        self.assertTrue(any(r.qualification == Q.SUPPRESSED_BY_POLICY for r in quiet))


class TestFailureIsolation(unittest.TestCase):
    def two_channel_routing(self, **kw):
        return RoutingPolicy((tgt("internal"), tgt("push", C.PUSH)), (RoutingRule("all", ("internal", "push"), **kw),))

    def test_one_broken_transport_does_not_affect_the_other(self):
        good, bad = RecordingTransport(), ScriptedTransport([RuntimeError("boom")] * 5, C.PUSH)
        h = Harness(routing=self.two_channel_routing(), transports=(good, bad))
        rec = run(h, cand())[0]
        st = {d.target_id: d.status for d in rec.deliveries}
        self.assertEqual(st, {"internal": D.DELIVERED, "push": D.FAILED})
        self.assertEqual(len(good.sent), 1)
        self.assertFalse(h.store.load().records[0].pending_delivery)          # somebody was told -> no redelivery

    def test_unbound_channel_fails_closed_without_stopping_anything(self):
        good = RecordingTransport()
        h = Harness(routing=self.two_channel_routing(), transports=(good,))
        rec = run(h, cand())[0]
        push = next(d for d in rec.deliveries if d.target_id == "push")
        self.assertEqual((push.status, push.failure_kind, push.detail), (D.FAILED, F.CONFIG, "no_transport_bound"))
        self.assertEqual(len(good.sent), 1)

    def test_total_delivery_failure_is_redelivered_once_per_newer_sighting_and_bounded(self):
        tr = ScriptedTransport([TransportAuthError(), None, None, None])
        h = Harness(transports=(tr,), routing=RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",)),)))
        verdicts = [run(h, cand(key=f"o{i}"))[0].verdict for i in range(1, 6)]
        self.assertEqual(verdicts, [V.NEW, V.REDELIVER, V.STILL_ACTIVE, V.STILL_ACTIVE, V.STILL_ACTIVE])
        self.assertEqual(len(tr.calls), 2)                                     # one failed, one redelivered - never unbounded

    def test_redelivery_is_capped_by_policy(self):
        tr = ScriptedTransport([TransportAuthError()] * 20)
        pol = AlertPolicy(dedup=AlertDedupPolicy(max_redeliveries=2))
        h = Harness(transports=(tr,), policy=pol, routing=RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",)),)))
        verdicts = [run(h, cand(key=f"o{i}"))[0].verdict for i in range(1, 7)]
        self.assertEqual(verdicts[:4], [V.NEW, V.REDELIVER, V.REDELIVER, V.STILL_ACTIVE])
        self.assertEqual(len(tr.calls), 3)

    def test_quiet_hours_suppression_is_not_lost_it_is_delivered_after_the_window(self):
        qh = QuietHours(12 * 60, 13 * 60, S.CRITICAL)
        routing = RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",), quiet_hours=qh),))
        pol = AlertPolicy(dedup=AlertDedupPolicy(expiry_seconds=7200, cooldown_seconds=900, retention_seconds=86400))
        h = Harness(routing=routing, policy=pol, clock=ManualClock(datetime(2026, 3, 1, 12, 30, tzinfo=timezone.utc)))
        r1 = run(h, cand(key="o1"))[0]
        self.assertEqual((r1.verdict, r1.routing.suppressed[0].reason, h.recording.sent), (V.NEW, RouteSuppression.QUIET_HOURS, []))
        h.clock.advance(35 * 60)
        r2 = run(h, cand(key="o2"))[0]
        self.assertEqual((r2.verdict, len(h.recording.sent)), (V.REDELIVER, 1))

    def test_rate_limited_route_is_not_lost_either(self):
        routing = RoutingPolicy((tgt("a", rate_limit=ThrottlePolicy(1, 60)),), (RoutingRule("all", ("a",)),))
        h = Harness(routing=routing, policy=AlertPolicy(dedup=AlertDedupPolicy(expiry_seconds=7200)))
        run(h, cand(key="o1", family=(("provider", "p1"),)), cand(key="x1", family=(("provider", "p2"),)))
        self.assertEqual(len(h.recording.sent), 1)                              # second alert hit the per-target limit
        h.clock.advance(61)
        r = run(h, cand(key="x2", family=(("provider", "p2"),)))[0]
        self.assertEqual((r.verdict, len(h.recording.sent)), (V.REDELIVER, 2))

    def test_invalid_payload_is_rejected_and_never_sent(self):
        bad_catalog = InMemoryCatalog({"en": {K.SEVERITY_CRITICAL: "Crit\x07ical"}})
        h = Harness()
        h.pipeline._catalog = bad_catalog
        rec = run(h, cand())[0]
        self.assertEqual([(d.status, d.failure_kind, d.attempts) for d in rec.deliveries], [(D.REJECTED, F.REJECTED, ())] * 2)
        self.assertEqual(h.recording.sent, [])

    def test_a_stage_exception_is_contained_recorded_and_the_batch_continues(self):
        class Flaky(AlertRouter):
            calls = 0

            def decide(self, alert, now):
                Flaky.calls += 1
                if Flaky.calls == 1:
                    raise RuntimeError("router bug")
                return super().decide(alert, now)
        h = Harness()
        h.pipeline._router = Flaky(default_routing())
        recs = run(h, cand(key="o1", family=(("provider", "p1"),)), cand(key="o2", family=(("provider", "p2"),)))
        self.assertEqual(recs[0].failures, ("routing:RuntimeError",))
        self.assertEqual(recs[1].failures, ())
        self.assertIn("PIPELINE_ERROR", h.kinds())
        self.assertEqual(len(h.recording.sent), 2)                               # the second alert (en + fa) was delivered
        self.assertTrue(h.store.load().get(recs[0].alert_id.split(".")[0]).pending_delivery)    # the first is eligible for redelivery

    def test_a_failing_state_store_is_contained(self):
        class Bad(InMemoryAlertStateStore):
            def load(self):
                raise OSError("disk")
        h = Harness(store=Bad())
        recs = run(h, cand())
        self.assertEqual(recs[0].failures, ("dedup:OSError",))
        self.assertEqual(h.recording.sent, [])

    def test_broken_telemetry_never_breaks_alerting(self):
        class Broken:
            def emit(self, e):
                raise RuntimeError("down")
        h = Harness(sink=Broken())
        rec = run(h, cand())[0]
        self.assertEqual([d.status for d in rec.deliveries], [D.DELIVERED] * 2)
        self.assertGreater(rec.telemetry_errors, 0)
        self.assertEqual(len(h.recording.sent), 2)

    def test_broken_audit_log_never_breaks_alerting(self):
        class Broken:
            def append(self, r):
                raise RuntimeError("audit down")
        h = Harness(audit=Broken())
        self.assertEqual(len(run(h, cand())), 1)
        self.assertEqual(len(h.recording.sent), 2)

    def test_garbage_input_never_raises_and_good_items_still_work(self):
        h = Harness()
        self.assertEqual(h.pipeline.process_report(None)[0].qualification, Q.REJECTED_MALFORMED)
        self.assertEqual(h.pipeline.process_snapshot(42)[0].qualification, Q.REJECTED_MALFORMED)
        self.assertEqual(h.pipeline.process_events(None)[0].qualification, Q.REJECTED_MALFORMED)
        _, evs = real_outage_world()
        recs = h.pipeline.process_events([object(), *evs], strict=False)
        self.assertEqual(recs[0].qualification, Q.REJECTED_MALFORMED)
        self.assertTrue(any(r.deliveries for r in recs))

    def test_the_tie_between_equal_urgency_rules_keeps_the_first_rule(self):
        r = AlertRouter(RoutingPolicy((tgt("a"),), (RoutingRule("first", ("a",), urgency=__import__("omnisystem_v5.alerts.enums", fromlist=["x"]).NotificationUrgency.HIGH),
                                                    RoutingRule("second", ("a",), urgency=__import__("omnisystem_v5.alerts.enums", fromlist=["x"]).NotificationUrgency.HIGH))))
        self.assertEqual(r.decide(mk(), datetime(2026, 1, 1, tzinfo=timezone.utc)).routes[0].rule, "first")


class TestTelemetryAndAudit(unittest.TestCase):
    def test_every_required_event_kind_is_emitted_by_some_path(self):
        tr = ScriptedTransport([TimeoutError(), None, TimeoutError(), TimeoutError(), TimeoutError()])
        h = Harness(transports=(tr,), routing=RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",)),)))
        run(h, cand(key="o1", family=(("provider", "p1"),)))                   # timeout -> RETRY_SCHEDULED -> DELIVERED
        run(h, cand(key="o1", family=(("provider", "p1"),)))                   # ALERT_DEDUPLICATED (exact duplicate)
        run(h, cand(key="q1", family=(("provider", "p2"),)))                   # 3 timeouts -> RETRY_EXHAUSTED -> DELIVERY_FAILED? (exhausted)
        run(h, cand(state="HEALTHY", key="hh"))                                # below min severity -> ALERT_SUPPRESSED
        run(h, cand(state="WHAT", key="w"))                                    # unsupported -> ALERT_REJECTED
        h.clock.advance(400)
        run(h, cand(key="late", family=(("provider", "p3"),)))                 # forces expire() of the earlier ones -> ALERT_EXPIRED
        kinds = set(h.kinds())
        for k in ("ALERT_CREATED", "ALERT_DEDUPLICATED", "ALERT_SUPPRESSED", "ALERT_REJECTED", "ALERT_EXPIRED", "ROUTING_DECIDED", "DELIVERY_STARTED",
                  "DELIVERY_SUCCEEDED", "RETRY_SCHEDULED", "RETRY_EXHAUSTED"):
            self.assertIn(k, kinds)

    def test_delivery_failed_is_emitted_for_permanent_failures(self):
        h = Harness(transports=(ScriptedTransport([TransportAuthError()]),), routing=RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",)),)))
        run(h, cand())
        self.assertIn("DELIVERY_FAILED", h.kinds())

    def test_telemetry_events_use_the_phase11_event_shape_and_carry_the_alert_id_as_subject(self):
        h = Harness()
        rec = run(h, cand())[0]
        ev = [e for e in h.sink.events if e.kind.value == "ALERT_CREATED"][0]
        self.assertEqual(ev.symbol, rec.alert_id)
        self.assertEqual(dict(ev.detail)["severity"], "CRITICAL")
        self.assertTrue(all(isinstance(dict(e.detail), dict) for e in h.sink.events))

    def test_audit_record_answers_the_why_who_what_questions(self):
        h = Harness()
        rec = run(h, cand())[0]
        self.assertEqual(rec.qualification, Q.QUALIFIED)
        for name in ("source", "alert_id", "alert_type", "severity", "headline", "verdict", "routing", "at", "observation_key"):
            self.assertIsNotNone(getattr(rec, name), name)
        self.assertEqual(rec.headline.key, K.PROVIDER_STATE)
        self.assertEqual(dict(rec.headline.params)["provider"], "p1")
        d = rec.deliveries[0]
        self.assertEqual((d.status, len(d.attempts), d.attempts[0].started_at), (D.DELIVERED, 1, h.clock.now()))
        self.assertEqual(rec.routing.matched_rules, ("all",))

    def test_audit_records_retry_and_failure_reasons(self):
        h = Harness(transports=(ScriptedTransport([TimeoutError(), ConnectionError("x"), TimeoutError()]),),
                    routing=RoutingPolicy((tgt("a"),), (RoutingRule("all", ("a",)),)))
        d = run(h, cand())[0].deliveries[0]
        self.assertEqual((d.status, d.failure_kind, d.detail, len(d.attempts)), (D.EXHAUSTED, F.TIMEOUT, "attempts", 3))
        self.assertEqual([a.retry_delay_seconds is not None for a in d.attempts], [True, True, False])

    def test_audit_is_language_neutral_and_canonical(self):
        h = Harness()
        run(h, cand())
        blob = h.audit.records[0].to_json()
        self.assertNotIn("Data provider", blob)
        self.assertNotIn("is now", blob)
        self.assertEqual(json.loads(blob)["headline"]["key"], "alert.provider.state")

    def test_audit_log_is_bounded_and_counts_drops(self):
        h = Harness(audit=InMemoryAuditLog(max_records=2))
        for i in range(5):
            run(h, cand(key=f"o{i}"))
        self.assertEqual((len(h.audit.records), h.audit.dropped), (2, 3))
        with self.assertRaises(ValueError):
            InMemoryAuditLog(0)

    def test_identical_runs_produce_byte_identical_audit_and_envelopes(self):
        def once():
            h = Harness()
            report, catalog, *_ = real_scan_world()
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            h.pipeline.process_report(report, CatalogContextResolver(catalog))
            return ([r.to_json() for r in h.audit.records], [(e.envelope_id, e.payload_json, [x.text for x in e.lines]) for e in h.recording.sent])
        self.assertEqual(once(), once())


class TestRestartSeam(unittest.TestCase):
    def test_restored_state_keeps_the_process_idempotent_across_a_restart(self):
        report, catalog, *_ = real_scan_world()
        a = Harness()
        a.pipeline.process_report(report, CatalogContextResolver(catalog))
        wire = json.dumps(a.store.load().to_dict())
        b = Harness(store=InMemoryAlertStateStore(AlertDedupState.from_dict(json.loads(wire))))
        recs = b.pipeline.process_report(report, CatalogContextResolver(catalog))
        self.assertEqual(({r.verdict for r in recs}, b.recording.sent), ({V.EXACT_DUPLICATE}, []))

    def test_without_restored_state_a_restart_renotifies_documented_limitation(self):
        report, catalog, *_ = real_scan_world()
        Harness().pipeline.process_report(report, CatalogContextResolver(catalog))
        c = Harness()
        self.assertEqual({r.verdict for r in c.pipeline.process_report(report, CatalogContextResolver(catalog))}, {V.NEW})

    def test_the_reference_store_is_transient_by_construction(self):
        self.assertEqual(InMemoryAlertStateStore().load(), AlertDedupState())


if __name__ == "__main__":
    unittest.main()
