import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.quant.enums import VolatilityPhase, VolatilityRegime
from omnisystem_v5.quant.volatility import (
    calculate_atr_percentage,
    calculate_rolling_volatility,
    classify_volatility_phase,
    classify_volatility_regime,
)
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


class TestAtrPercentage(unittest.TestCase):
    def test_hand_calculation(self):
        self.assertAlmostEqual(calculate_atr_percentage(atr=2.0, current_price=100.0), 2.0)

    def test_nonpositive_price_raises(self):
        with self.assertRaises(ValueError):
            calculate_atr_percentage(atr=2.0, current_price=0)


class TestRollingVolatility(unittest.TestCase):
    def test_matches_manual_stdev(self):
        import statistics
        t0 = datetime.now(UTC)
        closes = [100, 102, 101, 105, 103, 107, 104]
        bars = [_bar(t0 + timedelta(hours=i), c, c + 1, c - 1, c) for i, c in enumerate(closes)]
        returns = [(closes[i] - closes[i - 1]) / closes[i - 1] for i in range(1, len(closes))]
        expected = statistics.stdev(returns)
        self.assertAlmostEqual(calculate_rolling_volatility(bars, window=len(returns)), expected, places=10)

    def test_window_too_small_raises(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 100, 101, 99, 100)]
        with self.assertRaises(ValueError):
            calculate_rolling_volatility(bars, window=1)

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0 + timedelta(hours=i), 100 + i, 101 + i, 99 + i, 100.5 + i) for i in range(3)]
        with self.assertRaises(InsufficientDataError):
            calculate_rolling_volatility(bars, window=10)


class TestRegimeClassification(unittest.TestCase):
    def test_low_regime(self):
        self.assertEqual(classify_volatility_regime(0.2, low_threshold_pct=0.5, high_threshold_pct=2.0), VolatilityRegime.LOW)

    def test_high_regime(self):
        self.assertEqual(classify_volatility_regime(3.0, low_threshold_pct=0.5, high_threshold_pct=2.0), VolatilityRegime.HIGH)

    def test_normal_regime(self):
        self.assertEqual(classify_volatility_regime(1.0, low_threshold_pct=0.5, high_threshold_pct=2.0), VolatilityRegime.NORMAL)

    def test_boundary_is_normal_not_high(self):
        # exactly at high_threshold_pct should NOT be HIGH (strict >)
        self.assertEqual(classify_volatility_regime(2.0, low_threshold_pct=0.5, high_threshold_pct=2.0), VolatilityRegime.NORMAL)


class TestPhaseClassification(unittest.TestCase):
    def _bars_with_expanding_range(self, n, t0):
        bars = []
        price = 100.0
        for i in range(n):
            # flat, tight range for most of the series, then a sharp jump
            # in range for the last 10 bars -> unambiguous ATR expansion
            rng = 1.0 if i < n - 10 else 6.0
            bars.append(_bar(t0 + timedelta(hours=i), price, price + rng, price - rng, price + 0.1 * rng))
            price += 0.1
        return bars

    def _bars_with_contracting_range(self, n, t0):
        bars = []
        price = 100.0
        for i in range(n):
            rng = max(0.2, 3.0 - (i * 0.1))
            bars.append(_bar(t0 + timedelta(hours=i), price, price + rng, price - rng, price + 0.1 * rng))
            price += 0.05
        return bars

    def test_expansion_detected(self):
        t0 = datetime.now(UTC)
        bars = self._bars_with_expanding_range(40, t0)
        phase = classify_volatility_phase(bars, atr_period=14, window=5)
        self.assertEqual(phase, VolatilityPhase.EXPANSION)

    def test_contraction_detected(self):
        t0 = datetime.now(UTC)
        bars = self._bars_with_contracting_range(40, t0)
        phase = classify_volatility_phase(bars, atr_period=14, window=5)
        self.assertEqual(phase, VolatilityPhase.CONTRACTION)

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = self._bars_with_expanding_range(10, t0)
        with self.assertRaises(InsufficientDataError):
            classify_volatility_phase(bars, atr_period=14, window=5)


if __name__ == "__main__":
    unittest.main()
