"""Phase 12 - routing, envelope, transport boundary and delivery state machine / bounded retry. SYNTHETIC, injected clock + sleep."""
import dataclasses
import json
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.alerts.construction import build_alert
from omnisystem_v5.alerts.delivery import (FAILURE_CLASS_OF, DeliveryExecutor, DeliveryPolicy, classify_transport_exception)
from omnisystem_v5.alerts.enums import (DELIVERY_TRANSITIONS, AlertDedupVerdict as V, AlertSeverity as S, AlertSourceKind, AlertType, AttemptOutcome,
                                        DeliveryFailureKind as F, DeliveryStatus as D, NotificationChannel as C, NotificationUrgency as U,
                                        RouteSuppression, RoutingOutcome, RuleEffect)
from omnisystem_v5.alerts.envelope import MAX_LINES, NotificationEnvelope, build_envelope, envelope_id_for
from omnisystem_v5.alerts.errors import (AlertConfigError, PayloadValidationError, TransportAuthError, TransportConfigError, TransportRejectedError)
from omnisystem_v5.alerts.i18n import alert_catalog
from omnisystem_v5.alerts.model import AlertContext
from omnisystem_v5.alerts.routing import (AlertRouter, NotificationTarget, QuietHours, NotificationRoute, RoutingPolicy, RoutingRule)
from omnisystem_v5.alerts.telemetry import AlertEventKind as E
from omnisystem_v5.alerts.transport import InMemoryTransport, RecordingTransport, ScriptedTransport, TransportRegistry
from omnisystem_v5.marketdata.config import RetryPolicy, ThrottlePolicy
from omnisystem_v5.marketdata.events import InMemorySink
from omnisystem_v5.marketdata.i18n import EN, FA, InMemoryCatalog, Locale
from omnisystem_v5.marketdata.retry import compute_delay
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError
from omnisystem_v5.tests.alerts_fixtures import AdvancingSleep
from omnisystem_v5.tests.test_alerts_domain import cand

T0 = datetime(2026, 1, 1, 12, 0, tzinfo=timezone.utc)


def mk(sev=S.CRITICAL, state="UNAVAILABLE", type_=AlertType.PROVIDER_HEALTH, source=AlertSourceKind.DATA_SNAPSHOT, key="o1", **ctx):
    c = cand(state=state, type_=type_, source=source, key=key, context=AlertContext(provider="p1", **ctx))
    return build_alert(c, sev, T0)


def tgt(i, ch=C.INTERNAL, loc=EN, **kw):
    return NotificationTarget(i, ch, loc, **kw)


def router(targets, *rules):
    return AlertRouter(RoutingPolicy(tuple(targets), tuple(rules)))


class TestRouting(unittest.TestCase):
    def test_one_target(self):
        d = router([tgt("a")], RoutingRule("r", ("a",))).decide(mk(), T0)
        self.assertEqual((d.outcome, [r.target_id for r in d.routes], d.matched_rules), (RoutingOutcome.ROUTED, ["a"], ("r",)))

    def test_multiple_targets_are_ordered_by_channel_then_id_regardless_of_declaration(self):
        ts = [tgt("z"), tgt("b", C.PUSH), tgt("a")]
        d = router(ts, RoutingRule("r", ("z", "b", "a"))).decide(mk(), T0)
        self.assertEqual([(r.channel, r.target_id) for r in d.routes], [(C.INTERNAL, "a"), (C.INTERNAL, "z"), (C.PUSH, "b")])
        d2 = router(list(reversed(ts)), RoutingRule("r", ("a", "b", "z"))).decide(mk(), T0)
        self.assertEqual(d.routes, d2.routes)

    def test_no_rule_matches_means_no_eligible_target(self):
        d = router([tgt("a")], RoutingRule("r", ("a",), min_severity=S.CRITICAL)).decide(mk(S.INFO), T0)
        self.assertEqual((d.outcome, d.routes, d.matched_rules, d.suppressed), (RoutingOutcome.NO_ELIGIBLE_TARGET, (), (), ()))

    def test_no_rules_at_all_routes_nothing(self):
        self.assertEqual(router([tgt("a")]).decide(mk(), T0).outcome, RoutingOutcome.NO_ELIGIBLE_TARGET)

    def test_severity_threshold(self):
        r = router([tgt("a")], RoutingRule("r", ("a",), min_severity=S.WARNING))
        self.assertEqual([bool(r.decide(mk(s), T0).routes) for s in S], [False, False, True, True])

    def test_filters(self):
        cases = [
            (dict(sources=frozenset({AlertSourceKind.DATA_EVENT})), dict(), False),
            (dict(sources=frozenset({AlertSourceKind.DATA_SNAPSHOT})), dict(), True),
            (dict(types=frozenset({AlertType.SIGNAL})), dict(), False),
            (dict(types=frozenset({AlertType.PROVIDER_HEALTH})), dict(), True),
            (dict(asset_classes=frozenset({"FOREX"})), dict(asset_class="CRYPTO"), False),
            (dict(asset_classes=frozenset({"CRYPTO"})), dict(asset_class="CRYPTO"), True),
            (dict(asset_classes=frozenset({"CRYPTO"})), dict(), False),
            (dict(symbols=frozenset({"BTC/USDT"})), dict(symbol="ETH/USDT"), False),
            (dict(symbols=frozenset({"BTC/USDT"})), dict(symbol="BTC/USDT"), True),
            (dict(providers=frozenset({"p2"})), dict(), False),
            (dict(providers=frozenset({"p1"})), dict(), True),
        ]
        for rule_kw, ctx, expect in cases:
            with self.subTest(rule=str(rule_kw), ctx=str(ctx)):
                d = router([tgt("a")], RoutingRule("r", ("a",), **rule_kw)).decide(mk(**ctx), T0)
                self.assertEqual(bool(d.routes), expect)

    def test_deny_overrides_allow_and_is_recorded(self):
        r = router([tgt("a"), tgt("b")], RoutingRule("allow", ("a", "b")), RoutingRule("deny-a", ("a",), effect=RuleEffect.DENY))
        d = r.decide(mk(), T0)
        self.assertEqual([x.target_id for x in d.routes], ["b"])
        self.assertEqual([(s.target_id, s.reason, s.rule) for s in d.suppressed], [("a", RouteSuppression.DENIED_BY_RULE, "deny-a")])
        self.assertFalse(d.transient_suppression)

    def test_deny_wins_regardless_of_rule_order(self):
        r = router([tgt("a")], RoutingRule("deny", ("a",), effect=RuleEffect.DENY), RoutingRule("allow", ("a",)))
        self.assertEqual(r.decide(mk(), T0).routes, ())

    def test_conflicting_allow_rules_take_the_highest_urgency_and_name_the_winning_rule(self):
        r = router([tgt("a")], RoutingRule("low", ("a",), urgency=U.LOW), RoutingRule("high", ("a",), urgency=U.HIGH), RoutingRule("mid", ("a",), urgency=U.NORMAL))
        d = r.decide(mk(), T0)
        self.assertEqual([(x.urgency, x.rule) for x in d.routes], [(U.HIGH, "high")])
        self.assertEqual(len(d.routes), 1)

    def test_default_urgency_follows_severity_and_is_separate_from_it(self):
        r = router([tgt("a")], RoutingRule("r", ("a",)))
        self.assertEqual([r.decide(mk(s), T0).routes[0].urgency for s in S], [U.LOW, U.NORMAL, U.NORMAL, U.HIGH])

    def test_quiet_hours_suppress_up_to_a_severity_and_wrap_midnight(self):
        qh = QuietHours(22 * 60, 6 * 60, suppress_up_to=S.WARNING)
        r = router([tgt("a")], RoutingRule("r", ("a",), quiet_hours=qh))
        night, early, day = T0.replace(hour=23), T0.replace(hour=5), T0.replace(hour=12)
        self.assertEqual(r.decide(mk(S.WARNING), night).suppressed[0].reason, RouteSuppression.QUIET_HOURS)
        self.assertEqual(r.decide(mk(S.WARNING), early).routes, ())
        self.assertTrue(r.decide(mk(S.CRITICAL), night).routes)
        self.assertTrue(r.decide(mk(S.WARNING), day).routes)
        self.assertTrue(r.decide(mk(S.WARNING), night).transient_suppression)

    def test_quiet_hours_window_edges_are_half_open(self):
        qh = QuietHours(60, 120)
        self.assertEqual([qh.active(T0.replace(hour=h, minute=m)) for h, m in ((0, 59), (1, 0), (1, 59), (2, 0))], [False, True, True, False])

    def test_another_non_quiet_rule_still_delivers(self):
        qh = QuietHours(0, 1439, S.CRITICAL)
        r = router([tgt("a")], RoutingRule("quiet", ("a",), quiet_hours=qh), RoutingRule("always", ("a",)))
        self.assertEqual([x.rule for x in r.decide(mk(), T0).routes], ["always"])

    def test_rate_limit_is_per_target_uses_the_clock_and_suppressed_routes_do_not_consume(self):
        lim = ThrottlePolicy(max_requests=2, per_seconds=60)
        r = router([tgt("a", rate_limit=lim), tgt("b")], RoutingRule("r", ("a", "b")))
        ids = [[x.target_id for x in r.decide(mk(key=f"k{i}"), T0 + timedelta(seconds=i)).routes] for i in range(3)]
        self.assertEqual(ids, [["a", "b"], ["a", "b"], ["b"]])
        d = r.decide(mk(key="k3"), T0 + timedelta(seconds=3))
        self.assertEqual([(s.target_id, s.reason) for s in d.suppressed], [("a", RouteSuppression.RATE_LIMITED)])
        self.assertTrue(d.transient_suppression)
        self.assertEqual([x.target_id for x in r.decide(mk(), T0 + timedelta(seconds=61)).routes], ["a", "b"])

    def test_routing_is_deterministic_across_fresh_routers(self):
        def run():
            r = router([tgt("a", rate_limit=ThrottlePolicy(1, 10)), tgt("b", C.EMAIL)], RoutingRule("r", ("a", "b")))
            return [r.decide(mk(key=f"k{i}"), T0 + timedelta(seconds=i * 4)) for i in range(5)]
        self.assertEqual(run(), run())

    def test_invalid_configuration_fails_closed_at_construction(self):
        a = tgt("a")
        bad = [lambda: RoutingPolicy((a,), (RoutingRule("r", ("ghost",)),)),                     # unknown target
               lambda: RoutingPolicy((a, tgt("a")), ()),                                          # duplicate id
               lambda: RoutingPolicy((a,), (RoutingRule("r", ("a",)), RoutingRule("r", ("a",)))),
               lambda: RoutingPolicy((a,), (), urgency_by_severity=((S.INFO, U.LOW),)),
               lambda: tgt("A B"), lambda: tgt("a", endpoint_ref="https://hooks.example/x"), lambda: tgt("a", endpoint_ref="a b"),
               lambda: NotificationTarget("a", "PUSH"), lambda: RoutingRule("r", ()), lambda: RoutingRule("r", ("a",), min_severity="INFO"),
               lambda: RoutingRule("r", ("a",), sources=frozenset({"x"})), lambda: QuietHours(5, 5), lambda: QuietHours(0, 1440),
               lambda: QuietHours(True, 5), lambda: RoutingPolicy((a,), (object(),))]
        for i, f in enumerate(bad):
            with self.subTest(case=i):
                with self.assertRaises(AlertConfigError):
                    f()


def envelope_for(alert=None, verdict=V.NEW, target=None, catalog=None):
    alert, target = alert or mk(), target or tgt("a")
    return build_envelope(alert, verdict, NotificationRoute(target.target_id, target.channel, U.HIGH, "r"), target, catalog or alert_catalog())


class TestEnvelope(unittest.TestCase):
    def test_lines_are_severity_notice_headline_reasons_in_the_targets_locale(self):
        en = envelope_for(mk(S.CRITICAL, key="o1"))
        self.assertEqual([x.text for x in en.lines][:3], ["Critical", "New alert", "Data provider p1 is now UNAVAILABLE"])
        fa = envelope_for(target=tgt("a", loc=FA))
        self.assertNotEqual(fa.lines[0].text, en.lines[0].text)
        self.assertEqual(fa.lines[0].locale, FA)

    def test_payload_is_canonical_language_neutral_json_of_the_alert(self):
        a = mk()
        e = envelope_for(a)
        self.assertEqual(e.payload_json, a.to_json())
        self.assertEqual(json.loads(e.payload_json)["identity"]["family"], a.identity.family)

    def test_verdict_selects_the_notification_line(self):
        texts = {v: envelope_for(verdict=v).lines[1].text for v in (V.NEW, V.MATERIAL_CHANGE, V.RENOTIFY, V.REDELIVER)}
        self.assertEqual(texts, {V.NEW: "New alert", V.MATERIAL_CHANGE: "Updated alert", V.RENOTIFY: "Reminder", V.REDELIVER: "Reminder"})

    def test_envelope_id_is_deterministic_and_depends_on_target_observation_and_verdict(self):
        a = mk()
        base = envelope_id_for(a, "a", V.NEW)
        self.assertEqual(base, envelope_id_for(a, "a", V.NEW))
        self.assertRegex(base, r"^[0-9a-f]{24}$")
        self.assertEqual(len({base, envelope_id_for(a, "b", V.NEW), envelope_id_for(a, "a", V.REDELIVER), envelope_id_for(mk(key="o2"), "a", V.NEW)}), 4)

    def test_suppressed_verdicts_can_never_produce_an_envelope(self):
        for v in (V.EXACT_DUPLICATE, V.STILL_ACTIVE, V.COOLDOWN):
            with self.assertRaises(PayloadValidationError):
                envelope_for(verdict=v)

    def test_malformed_envelopes_cannot_be_constructed(self):
        good = envelope_for()
        line = good.lines[0]
        ok = dict(envelope_id=good.envelope_id, alert_id=good.alert_id, target=good.target, urgency=U.HIGH, severity=S.CRITICAL, verdict=V.NEW,
                  lines=good.lines, payload_json=good.payload_json)
        bad = {"id": dict(envelope_id="xyz"), "alert_id": dict(alert_id=""), "target": dict(target="t"), "urgency": dict(urgency="HIGH"),
               "no-lines": dict(lines=()), "too-many": dict(lines=(line,) * (MAX_LINES + 1)), "not-localized": dict(lines=("text",)),
               "control": dict(lines=(dataclasses.replace(line, text="a\x07b"),)), "newline": dict(lines=(dataclasses.replace(line, text="a\nb"),)),
               "blank": dict(lines=(dataclasses.replace(line, text="   "),)), "huge-line": dict(lines=(dataclasses.replace(line, text="x" * 1001),)),
               "huge-total": dict(lines=(dataclasses.replace(line, text="x" * 900),) * 10), "payload-not-json": dict(payload_json="{"),
               "payload-not-alert": dict(payload_json="{}"), "payload-list": dict(payload_json="[]"), "payload-huge": dict(payload_json="x" * 16001)}
        NotificationEnvelope(**ok)
        for name, over in bad.items():
            with self.subTest(name):
                with self.assertRaises(PayloadValidationError):
                    NotificationEnvelope(**{**ok, **over})

    def test_untrusted_text_is_never_interpreted_as_a_template(self):
        nasty = "{state} {0.__class__} {provider.__init__}"
        a = build_alert(cand(context=AlertContext(provider="p1"), headline=__import__("omnisystem_v5.alerts.i18n", fromlist=["amsg"]).amsg(
            __import__("omnisystem_v5.alerts.i18n", fromlist=["AlertMessageKey"]).AlertMessageKey.PROVIDER_STATE, provider=nasty, state="X")), S.CRITICAL, T0)
        text = envelope_for(a).lines[2].text
        self.assertEqual(text, f"Data provider {nasty} is now X")

    def test_missing_templates_degrade_to_neutral_text_and_are_flagged(self):
        e = envelope_for(catalog=InMemoryCatalog({"en": {}}))
        self.assertTrue(e.degraded_localization)
        self.assertIn("alert.provider.state", e.lines[2].text)
        self.assertFalse(envelope_for().degraded_localization)

    def test_unknown_locale_uses_the_english_fallback_chain(self):
        e = envelope_for(target=tgt("a", loc=Locale("de")))
        self.assertEqual(e.lines[1].text, "New alert")


class TestTransports(unittest.TestCase):
    def test_recording_and_in_memory_transports(self):
        e = envelope_for()
        rec, mem = RecordingTransport(), InMemoryTransport()
        for t in (rec, mem, mem):
            t.send(e, 5.0)
        self.assertEqual(rec.sent, [e])
        self.assertEqual((len(mem.mailboxes["a"]), mem.duplicates), (1, 1))

    def test_scripted_transport_consumes_its_script_and_fails_loudly_when_exhausted(self):
        e = envelope_for()
        s = ScriptedTransport([None, TimeoutError()])
        s.send(e, 3.0)
        with self.assertRaises(TimeoutError):
            s.send(e, 3.0)
        with self.assertRaises(TransportConfigError):
            s.send(e, 3.0)
        self.assertEqual([t for _, t in s.calls], [3.0] * 3)

    def test_registry_is_immutable_channel_binding(self):
        r = TransportRegistry([RecordingTransport(C.INTERNAL), RecordingTransport(C.PUSH)])
        self.assertIsNotNone(r.get(C.PUSH))
        self.assertIsNone(r.get(C.SMS))
        with self.assertRaises(AlertConfigError):
            TransportRegistry([RecordingTransport(), RecordingTransport()])


class Rig:
    def __init__(self, policy=None, sink=None):
        self.clock = ManualClock(T0)
        self.sleep = AdvancingSleep(self.clock)
        self.sink = InMemorySink() if sink is None else sink
        self.ex = DeliveryExecutor(policy or DeliveryPolicy(), self.clock, self.sleep, self.sink)
        self.env = envelope_for()

    def run(self, script, channel=C.INTERNAL):
        tr = ScriptedTransport(script, channel)
        return self.ex.deliver(self.env, tr), tr

    def kinds(self):
        return [e.kind.value for e in self.sink.events]


def legal(path):
    return all(b in DELIVERY_TRANSITIONS[a] for a, b in zip(path, path[1:]))


class TestDelivery(unittest.TestCase):
    def test_success_on_first_attempt(self):
        r = Rig()
        res, tr = r.run([None])
        self.assertEqual((res.status, len(res.attempts), res.state_path), (D.DELIVERED, 1, (D.PENDING, D.ATTEMPTING, D.DELIVERED)))
        self.assertEqual(r.kinds(), ["DELIVERY_STARTED", "DELIVERY_SUCCEEDED"])
        self.assertEqual(r.sleep.waits, [])
        self.assertEqual(tr.calls[0][1], DeliveryPolicy().timeout_seconds)

    def test_timeout_then_success_waits_the_deterministic_reused_backoff(self):
        r = Rig()
        res, _ = r.run([TimeoutError(), None])
        self.assertEqual(res.status, D.DELIVERED)
        self.assertEqual(res.state_path, (D.PENDING, D.ATTEMPTING, D.RETRY_SCHEDULED, D.ATTEMPTING, D.DELIVERED))
        self.assertEqual(r.sleep.waits, [compute_delay(DeliveryPolicy().retry, r.env.envelope_id, 1)])
        self.assertEqual([a.outcome for a in res.attempts], [AttemptOutcome.FAILURE, AttemptOutcome.SUCCESS])
        self.assertEqual(res.attempts[0].failure_kind, F.TIMEOUT)
        self.assertEqual(r.kinds(), ["DELIVERY_STARTED", "RETRY_SCHEDULED", "DELIVERY_SUCCEEDED"])

    def test_retry_exhaustion_is_bounded_and_does_not_sleep_after_the_last_attempt(self):
        r = Rig()
        res, tr = r.run([TimeoutError()] * 10)
        self.assertEqual((res.status, res.detail, len(res.attempts), len(tr.calls)), (D.EXHAUSTED, "attempts", 3, 3))
        self.assertEqual(len(r.sleep.waits), 2)
        self.assertEqual(r.kinds()[-1], "RETRY_EXHAUSTED")
        self.assertEqual(res.failure_kind, F.TIMEOUT)

    def test_max_attempts_one_means_no_hidden_retry(self):
        r = Rig(DeliveryPolicy(retry=RetryPolicy(max_attempts=1, retry_on=frozenset({FailureClass.PROVIDER_TIMEOUT}))))
        res, tr = r.run([TimeoutError(), None])
        self.assertEqual((res.status, len(tr.calls), r.sleep.waits), (D.EXHAUSTED, 1, []))

    def test_unavailable_is_retryable_by_default_but_only_if_the_policy_says_so(self):
        res, _ = Rig().run([ConnectionError(), None])
        self.assertEqual(res.status, D.DELIVERED)
        only_timeout = DeliveryPolicy(retry=RetryPolicy(max_attempts=3, retry_on=frozenset({FailureClass.PROVIDER_TIMEOUT})))
        res, tr = Rig(only_timeout).run([ConnectionError(), None])
        self.assertEqual((res.status, res.failure_kind, len(tr.calls)), (D.FAILED, F.UNAVAILABLE, 1))

    def test_permanent_failures_are_never_retried(self):
        cases = [(TransportRejectedError("x"), F.REJECTED), (TransportAuthError("x"), F.AUTH), (TransportConfigError("x"), F.CONFIG),
                 (RuntimeError("x"), F.INTERNAL), (ValueError("x"), F.INTERNAL), (KeyError("x"), F.INTERNAL)]
        for exc, kind in cases:
            with self.subTest(kind=kind, exc=type(exc).__name__):
                r = Rig()
                res, tr = r.run([exc, None])
                self.assertEqual((res.status, res.failure_kind, res.detail, len(tr.calls), r.sleep.waits), (D.FAILED, kind, "not_retryable", 1, []))
                self.assertEqual(r.kinds()[-1], "DELIVERY_FAILED")

    def test_rate_limit_is_reported_not_waited_by_default(self):
        r = Rig()
        res, tr = r.run([ProviderRateLimitedError("slow down", 5.0), None])
        self.assertEqual((res.status, res.failure_kind, res.retry_after_seconds, len(tr.calls), r.sleep.waits), (D.FAILED, F.RATE_LIMITED, 5.0, 1, []))

    def test_rate_limit_is_waited_only_inside_the_wait_budget(self):
        pol = DeliveryPolicy(retry=RetryPolicy(max_attempts=3, rate_limit_max_wait_seconds=10.0, retry_on=frozenset({FailureClass.PROVIDER_TIMEOUT})))
        r = Rig(pol)
        res, _ = r.run([ProviderRateLimitedError("x", 5.0), None])
        self.assertEqual((res.status, r.sleep.waits), (D.DELIVERED, [5.0]))
        for after in (30.0, None):
            with self.subTest(after=after):
                r = Rig(pol)
                res, tr = r.run([ProviderRateLimitedError("x", after), None])
                self.assertEqual((res.status, len(tr.calls), r.sleep.waits), (D.FAILED, 1, []))

    def test_total_deadline_stops_retries_early(self):
        pol = DeliveryPolicy(retry=RetryPolicy(max_attempts=5, base_delay_seconds=1.0, multiplier=2.0, jitter_fraction=0.0,
                                               retry_on=frozenset({FailureClass.PROVIDER_TIMEOUT})), deadline_seconds=2.0)
        r = Rig(pol)
        res, tr = r.run([TimeoutError()] * 9)
        self.assertEqual((res.status, res.detail, len(tr.calls), r.sleep.waits), (D.EXHAUSTED, "deadline", 2, [1.0]))

    def test_no_transport_or_wrong_channel_fails_closed(self):
        r = Rig()
        for tr in (None, RecordingTransport(C.PUSH)):
            res = r.ex.deliver(r.env, tr)
            self.assertEqual((res.status, res.failure_kind, res.detail, res.attempts), (D.FAILED, F.CONFIG, "no_transport_bound", ()))
            self.assertEqual(res.state_path, (D.PENDING, D.FAILED))

    def test_a_broken_transport_is_isolated_from_the_next_delivery(self):
        r = Rig()
        broken, fine = ScriptedTransport([RuntimeError("boom")]), RecordingTransport()
        a = r.ex.deliver(r.env, broken)
        b = r.ex.deliver(r.env, fine)
        self.assertEqual((a.status, b.status, len(fine.sent)), (D.FAILED, D.DELIVERED, 1))

    def test_keyboard_interrupt_is_not_swallowed(self):
        with self.assertRaises(KeyboardInterrupt):
            Rig().run([KeyboardInterrupt()])

    def test_exception_messages_are_never_stored(self):
        res, _ = Rig().run([ConnectionError("token=SECRET123 host=internal"), None])
        blob = json.dumps(dataclasses.asdict(res), default=str)
        self.assertNotIn("SECRET123", blob)
        self.assertEqual(res.attempts[0].error_type, "ConnectionError")

    def test_a_failing_injected_sleep_fails_only_this_delivery(self):
        r = Rig()
        bad = DeliveryExecutor(DeliveryPolicy(), r.clock, lambda s: (_ for _ in ()).throw(RuntimeError("sleep")), r.sink)
        res = bad.deliver(r.env, ScriptedTransport([TimeoutError(), None]))
        self.assertEqual((res.status, res.detail, res.state_path[-2:]), (D.FAILED, "sleep_error", (D.RETRY_SCHEDULED, D.FAILED)))

    def test_a_failing_telemetry_sink_never_breaks_delivery(self):
        class Broken:
            def emit(self, event):
                raise RuntimeError("sink down")
        r = Rig(sink=Broken())
        res, _ = r.run([TimeoutError(), None])
        self.assertEqual(res.status, D.DELIVERED)
        self.assertGreaterEqual(res.telemetry_errors, 3)

    def test_every_state_path_is_a_legal_walk_of_the_state_machine(self):
        scripts = [[None], [TimeoutError(), None], [TimeoutError()] * 3, [TransportAuthError()], [ProviderRateLimitedError("x", 1.0)], [ConnectionError(), RuntimeError()]]
        for s in scripts:
            res, _ = Rig().run(list(s))
            with self.subTest(status=res.status.value, n=len(s)):
                self.assertTrue(legal(res.state_path), res.state_path)
                self.assertTrue(res.status.terminal)
                self.assertEqual(res.state_path[0], D.PENDING)
                self.assertEqual(res.state_path[-1], res.status)

    def test_backoff_is_deterministic_across_executors(self):
        a, b = Rig(), Rig()
        a.run([TimeoutError()] * 3)
        b.run([TimeoutError()] * 3)
        self.assertEqual(a.sleep.waits, b.sleep.waits)
        self.assertTrue(all(w > 0 for w in a.sleep.waits))

    def test_classification_reuses_the_frozen_failure_taxonomy(self):
        self.assertEqual(classify_transport_exception(TimeoutError()), F.TIMEOUT)
        self.assertEqual(classify_transport_exception(ConnectionError()), F.UNAVAILABLE)
        self.assertEqual(classify_transport_exception(ProviderRateLimitedError("x", 1.0)), F.RATE_LIMITED)
        self.assertEqual(FAILURE_CLASS_OF[F.TIMEOUT], FailureClass.PROVIDER_TIMEOUT)
        self.assertEqual(FAILURE_CLASS_OF[F.RATE_LIMITED], FailureClass.PROVIDER_RATE_LIMITED)
        self.assertEqual(FAILURE_CLASS_OF[F.UNAVAILABLE], FailureClass.PROVIDER_UNAVAILABLE)
        self.assertNotIn(F.AUTH, FAILURE_CLASS_OF)
        self.assertNotIn(F.CONFIG, FAILURE_CLASS_OF)

    def test_invalid_delivery_policies_fail_closed(self):
        for kw in (dict(retry="x"), dict(timeout_seconds=0), dict(timeout_seconds=True), dict(deadline_seconds=0), dict(deadline_seconds="1")):
            with self.subTest(kw=kw):
                with self.assertRaises(AlertConfigError):
                    DeliveryPolicy(**kw)
        with self.assertRaises(AlertConfigError):
            DeliveryExecutor(DeliveryPolicy(), ManualClock(T0), None)


if __name__ == "__main__":
    unittest.main()
