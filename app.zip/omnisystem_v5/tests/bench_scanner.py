"""Phase 10 scanner benchmarks (run manually: python -m omnisystem_v5.tests.bench_scanner).
NOT collected by unittest discovery (file name does not start with test_).
All data is SYNTHETIC; numbers describe scanner overhead on this machine, not market behaviour."""
from __future__ import annotations

import statistics
import time
from datetime import timedelta

from omnisystem_v5.scanner import ScanEngine, ScannerConfig, ScanState, StaticUniverse, SymbolSpec
from omnisystem_v5.scanner import dedup as D
from omnisystem_v5.scanner.clock import FixedClock
from omnisystem_v5.scanner.identity import FingerprintPolicy
from omnisystem_v5.scanner.signals import detect_signal
from omnisystem_v5.scanner.timeframes import required_timeframes
from omnisystem_v5.tests.scanner_fixtures import END, StubSource, account, loose_risk_policy
from omnisystem_v5.tests.test_scanner_identity_dedup import cand


def bench_cycle(n_symbols, long_ratio):
    cfg = ScannerConfig(risk_policy=loose_risk_policy())
    names = [f"S{i:04d}/USDT" for i in range(n_symbols)]
    seeds = {n: (1 if i < n_symbols * long_ratio else 7) for i, n in enumerate(names)}
    src = StubSource(required_timeframes(cfg), end=END, seed_for=lambda s: seeds[s])
    eng = ScanEngine(src, StaticUniverse([SymbolSpec(n) for n in names]), cfg, FixedClock(END))
    t0 = time.perf_counter()
    res = eng.run_cycle(ScanState(), account())
    dt = time.perf_counter() - t0
    # second cycle: same data, all signals duplicates
    clock2 = FixedClock(END + timedelta(seconds=60))
    eng2 = ScanEngine(src, StaticUniverse([SymbolSpec(n) for n in names]), cfg, clock2)
    t1 = time.perf_counter()
    res2 = eng2.run_cycle(res.state, account())
    dt2 = time.perf_counter() - t1
    return dt, dt2, len(res.report.emitted), len(res2.report.suppressed)


def bench_source_only(n_symbols):
    cfg = ScannerConfig()
    src = StubSource(required_timeframes(cfg), end=END)
    t0 = time.perf_counter()
    for i in range(n_symbols):
        for tf in required_timeframes(cfg):
            src.get_market_data(f"S{i}/USDT", tf)
    return time.perf_counter() - t0


def bench_dedup(n_active):
    fp, dp = FingerprintPolicy(), D.DedupPolicy()
    descs = [cand(symbol=f"S{i:05d}/USDT") for i in range(n_active)]
    state = D.DedupState()
    t0 = time.perf_counter()
    for d in descs:
        state, _, _ = D.observe(state, detect_signal(d, None, END), END, dp, fp)
    build = time.perf_counter() - t0
    t1 = time.perf_counter()
    for d in descs:                                        # every one is now a duplicate
        state, out, _ = D.observe(state, detect_signal(d, None, END), END, dp, fp)
    dup = time.perf_counter() - t1
    return build, dup


if __name__ == "__main__":
    print("== full cycle (real engines), sequential ==")
    print(f"{'symbols':>8} {'cycle s':>9} {'ms/symbol':>10} {'dup-cycle s':>12} {'emitted':>8} {'suppressed':>11}")
    base = None
    for n in (1, 5, 10, 20, 40, 80):
        dt, dt2, em, sup = bench_cycle(n, long_ratio=0.5)
        base = base or dt
        print(f"{n:>8} {dt:>9.3f} {1000 * dt / n:>10.1f} {dt2:>12.3f} {em:>8} {sup:>11}")
    print("\n== source (synthetic bar generation) share, for reference ==")
    for n in (10, 40):
        print(f"{n:>8} symbols: {bench_source_only(n):.3f}s of bar generation (fixture cost, not scanner cost)")
    print("\n== dedup: build N active signals, then N duplicate observations ==")
    print(f"{'N':>8} {'build s':>9} {'per-emit ms':>12} {'dup s':>9} {'per-dup ms':>11}")
    for n in (100, 500, 1000, 2000):
        b, d = bench_dedup(n)
        print(f"{n:>8} {b:>9.3f} {1000 * b / n:>12.3f} {d:>9.3f} {1000 * d / n:>11.3f}")
