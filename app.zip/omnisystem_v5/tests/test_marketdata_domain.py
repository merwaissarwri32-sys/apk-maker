"""Phase 11: asset model, symbol mapping, catalog, sessions, quotes, localization. SYNTHETIC / deterministic."""
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.marketdata.assets import AssetClass, AssetModelError, Instrument, Listing, Venue, market_type_for
from omnisystem_v5.marketdata.catalog import InstrumentCatalog
from omnisystem_v5.marketdata.config import QuotePolicy
from omnisystem_v5.marketdata.freshness import FreshnessState
from omnisystem_v5.marketdata.i18n import EN, FA, InMemoryCatalog, Locale, MessageKey, StructuredMessage, default_catalog, msg
from omnisystem_v5.marketdata.provider import RawQuote
from omnisystem_v5.marketdata.quotes import Quote, QuoteError, assess_quote, normalize_quote
from omnisystem_v5.marketdata.sessions import (AlwaysOpenSession, MarketStatus, SessionConfigError, WeeklySession, WeeklyWindow)
from omnisystem_v5.marketdata.symbol_map import SymbolMap, SymbolMapError, UnknownSymbolError
from omnisystem_v5.scanner.enums import MarketType
from omnisystem_v5.scanner.universe import SymbolSpec
from omnisystem_v5.tests.marketdata_fixtures import VENUE, crypto_instrument, forex_instrument

U = timezone.utc


def dt(*a):
    return datetime(*a, tzinfo=U)


class TestAssets(unittest.TestCase):
    def test_canonical_symbol_matches_symbolspec_contract(self):
        for ins in (crypto_instrument("btc", "usdt"), forex_instrument("eur", "usd")):
            self.assertEqual(SymbolSpec(ins.canonical_symbol).symbol, ins.canonical_symbol)
        self.assertEqual(crypto_instrument("btc", "usdt").canonical_symbol, "BTC/USDT")

    def test_instrument_validation_fails_closed(self):
        for base, quote in (("", "USD"), ("BTC", "BTC"), ("B TC", "USD"), ("BTC", "US/D")):
            with self.assertRaises(AssetModelError):
                Instrument(AssetClass.CRYPTO, base, quote)
        with self.assertRaises(AssetModelError):
            Instrument("CRYPTO", "BTC", "USDT")

    def test_venue_is_not_part_of_instrument_identity(self):
        self.assertEqual(crypto_instrument(), crypto_instrument())
        a, b = Listing(crypto_instrument(), Venue("A")), Listing(crypto_instrument(), Venue("B"))
        self.assertEqual(a.symbol, b.symbol)
        self.assertNotEqual(a, b)

    def test_market_type_table_is_single_source(self):
        self.assertEqual(market_type_for(AssetClass.CRYPTO), MarketType.SPOT)
        self.assertEqual(market_type_for(AssetClass.FOREX), MarketType.FX)
        self.assertEqual(market_type_for(AssetClass.EQUITY), MarketType.EQUITY)
        for ac in AssetClass:
            self.assertIsInstance(market_type_for(ac), MarketType)
        self.assertEqual(Listing(crypto_instrument(), VENUE, market_type=MarketType.PERPETUAL).effective_market_type, MarketType.PERPETUAL)

    def test_listing_validation(self):
        for kw in ({"tick_size": 0}, {"tick_size": float("nan")}, {"price_precision": -1}, {"bar_anchor_offset_seconds": 86400},
                   {"quote_volume_24h": -1.0}, {"tick_size": True}):
            with self.assertRaises(AssetModelError):
                Listing(crypto_instrument(), VENUE, **kw)
        with self.assertRaises(AssetModelError):
            Venue("bad venue")

    def test_future_asset_classes_are_representable_without_core_changes(self):
        for ac, base, quote in ((AssetClass.COMMODITY, "XAU", "USD"), (AssetClass.INDEX, "SPX", "USD"),
                                (AssetClass.EQUITY, "AAPL", "USD"), (AssetClass.FUTURES, "ES", "USD")):
            lst = Listing(Instrument(ac, base, quote), VENUE)
            self.assertEqual(lst.symbol, f"{base}/{quote}")
            self.assertIsInstance(lst.effective_market_type, MarketType)


class TestSymbolMap(unittest.TestCase):
    def test_explicit_bidirectional_mapping(self):
        btc, eth = crypto_instrument("BTC"), crypto_instrument("ETH")
        m = SymbolMap("p", [("BTCUSDT", btc), ("ETHUSDT", eth)])
        self.assertEqual(m.instrument_for("BTCUSDT"), btc)
        self.assertEqual(m.provider_symbol_for(eth), "ETHUSDT")
        self.assertIn(btc, m)
        self.assertEqual([i.canonical_symbol for i in m.instruments()], ["BTC/USDT", "ETH/USDT"])

    def test_unknown_mappings_fail_closed_and_are_never_guessed(self):
        m = SymbolMap("p", [("BTCUSDT", crypto_instrument())])
        for bad in ("btcusdt", "BTC/USDT", "BTC-USDT", "", None):
            with self.assertRaises(UnknownSymbolError):
                m.instrument_for(bad)
        with self.assertRaises(UnknownSymbolError):
            m.provider_symbol_for(crypto_instrument("ETH"))

    def test_ambiguity_rejected_at_build_time(self):
        btc, eth = crypto_instrument("BTC"), crypto_instrument("ETH")
        with self.assertRaises(SymbolMapError):
            SymbolMap("p", [("X", btc), ("X", eth)])
        with self.assertRaises(SymbolMapError):
            SymbolMap("p", [("X", btc), ("Y", btc)])
        for bad in (" BTCUSDT", "BTCUSDT ", ""):
            with self.assertRaises(SymbolMapError):
                SymbolMap("p", [(bad, btc)])
        with self.assertRaises(SymbolMapError):
            SymbolMap("p", [("X", "BTC/USDT")])

    def test_same_instrument_may_use_different_provider_spellings(self):
        btc = crypto_instrument()
        a, b, c = SymbolMap("a", [("BTCUSDT", btc)]), SymbolMap("b", [("BTC/USDT", btc)]), SymbolMap("c", [("BTC-USDT", btc)])
        self.assertEqual({m.instrument_for(s) for m, s in ((a, "BTCUSDT"), (b, "BTC/USDT"), (c, "BTC-USDT"))}, {btc})


class TestCatalog(unittest.TestCase):
    def test_primary_is_first_enabled_in_declared_order(self):
        i = crypto_instrument()
        cat = InstrumentCatalog([Listing(i, Venue("A"), enabled=False), Listing(i, Venue("B")), Listing(i, Venue("C"))])
        self.assertEqual(cat.primary("BTC/USDT").venue.code, "B")
        self.assertEqual(len(cat.listings_for("BTC/USDT")), 3)

    def test_disabled_only_has_no_primary(self):
        cat = InstrumentCatalog([Listing(crypto_instrument(), VENUE, enabled=False)])
        self.assertIsNone(cat.primary("BTC/USDT"))
        self.assertIsNotNone(cat.any_listing("BTC/USDT"))

    def test_collisions_and_duplicates_rejected(self):
        with self.assertRaises(AssetModelError):
            InstrumentCatalog([Listing(crypto_instrument("EUR", "USD"), VENUE), Listing(forex_instrument("EUR", "USD"), Venue("B"))])
        with self.assertRaises(AssetModelError):
            InstrumentCatalog([Listing(crypto_instrument(), VENUE), Listing(crypto_instrument(), VENUE)])
        with self.assertRaises(AssetModelError):
            InstrumentCatalog(["BTC/USDT"])

    def test_symbols_sorted(self):
        cat = InstrumentCatalog([Listing(crypto_instrument("ETH"), VENUE), Listing(crypto_instrument("BTC"), VENUE)])
        self.assertEqual(cat.symbols(), ("BTC/USDT", "ETH/USDT"))


class TestSessions(unittest.TestCase):
    def test_crypto_is_always_open(self):
        s = AlwaysOpenSession()
        for t in (dt(2024, 3, 2, 12), dt(2024, 12, 25, 0), dt(2024, 3, 3, 3)):
            self.assertEqual(s.status(t), MarketStatus.OPEN)
        self.assertEqual(s.next_open(dt(2024, 3, 2, 12)), dt(2024, 3, 2, 12))

    def test_forex_week_winter_boundaries_utc_2200(self):
        s = WeeklySession.forex_ny()
        self.assertEqual(s.status(dt(2024, 3, 1, 21, 59)), MarketStatus.OPEN)
        self.assertEqual(s.status(dt(2024, 3, 1, 22, 0)), MarketStatus.CLOSED)
        self.assertEqual(s.status(dt(2024, 3, 2, 12)), MarketStatus.CLOSED)
        self.assertEqual(s.status(dt(2024, 3, 3, 21, 59)), MarketStatus.CLOSED)
        self.assertEqual(s.status(dt(2024, 3, 3, 22, 0)), MarketStatus.OPEN)

    def test_forex_week_summer_boundaries_shift_with_us_dst(self):
        s = WeeklySession.forex_ny()               # DST began 2024-03-10: open moves to 21:00 UTC
        self.assertEqual(s.status(dt(2024, 3, 10, 20, 59)), MarketStatus.CLOSED)
        self.assertEqual(s.status(dt(2024, 3, 10, 21, 0)), MarketStatus.OPEN)
        self.assertEqual(s.status(dt(2024, 3, 15, 20, 59)), MarketStatus.OPEN)
        self.assertEqual(s.status(dt(2024, 3, 15, 21, 0)), MarketStatus.CLOSED)

    def test_forex_midweek_open_around_the_clock(self):
        s = WeeklySession.forex_ny()
        for t in (dt(2024, 3, 4, 0), dt(2024, 3, 5, 13), dt(2024, 3, 7, 23, 59)):
            self.assertEqual(s.status(t), MarketStatus.OPEN)

    def test_next_open(self):
        s = WeeklySession.forex_ny()
        self.assertEqual(s.next_open(dt(2024, 3, 2, 12)), dt(2024, 3, 3, 22, 0))
        self.assertEqual(s.next_open(dt(2024, 3, 9, 12)), dt(2024, 3, 10, 21, 0))       # DST-aware
        self.assertEqual(s.next_open(dt(2024, 3, 4, 5)), dt(2024, 3, 4, 5))

    def test_explicit_closure_halts(self):
        s = WeeklySession.forex_ny(closures=((dt(2024, 3, 5, 10), dt(2024, 3, 5, 12)),))
        self.assertEqual(s.status(dt(2024, 3, 5, 9, 59)), MarketStatus.OPEN)
        self.assertEqual(s.status(dt(2024, 3, 5, 10)), MarketStatus.HALTED)
        self.assertEqual(s.status(dt(2024, 3, 5, 12)), MarketStatus.OPEN)

    def test_naive_datetime_refused(self):
        for s in (AlwaysOpenSession(), WeeklySession.forex_ny()):
            with self.assertRaises(ValueError):
                s.status(datetime(2024, 3, 4))

    def test_misconfiguration_fails_closed(self):
        with self.assertRaises(SessionConfigError):
            WeeklySession("Not/AZone", (WeeklyWindow(0, 0, 4, 0),))
        with self.assertRaises(SessionConfigError):
            WeeklySession("UTC", ())
        with self.assertRaises(SessionConfigError):
            WeeklyWindow(7, 0, 1, 0)
        with self.assertRaises(SessionConfigError):
            WeeklyWindow(0, 86400, 1, 0)
        with self.assertRaises(SessionConfigError):
            WeeklySession("UTC", (WeeklyWindow(0, 0, 4, 0),), closures=((dt(2024, 1, 2), dt(2024, 1, 1)),))

    def test_deterministic(self):
        s = WeeklySession.forex_ny()
        t = dt(2024, 3, 6, 9, 30)
        self.assertEqual({s.status(t) for _ in range(50)}, {MarketStatus.OPEN})


class TestQuotes(unittest.TestCase):
    T = dt(2024, 3, 1, 12)

    def test_valid_quote_and_normalization(self):
        q = normalize_quote(RawQuote("p", "X", "2024-03-01T12:00:00Z", "99.5", "100.5", 100), "BTC/USDT", "V", "p")
        self.assertEqual((q.bid, q.ask, q.last, q.timestamp), (99.5, 100.5, 100.0, self.T))
        self.assertEqual(Quote("S", "V", "p", self.T, last=1.0).last, 1.0)

    def test_fail_closed(self):
        bad = [dict(bid=float("nan"), ask=1.0), dict(bid=0.0, ask=1.0), dict(bid=-1.0, ask=1.0), dict(bid=2.0, ask=1.0),
               dict(bid=1.0), dict(), dict(last=float("inf")), dict(last=True)]
        for kw in bad:
            with self.assertRaises(QuoteError, msg=str(kw)):
                Quote("S", "V", "p", self.T, **kw)
        with self.assertRaises(QuoteError):
            Quote("S", "V", "p", datetime(2024, 3, 1), last=1.0)
        with self.assertRaises(QuoteError):
            normalize_quote(RawQuote("p", "X", 1709294400, last=1.0), "S", "V", "p")       # epoch: unit would be guessed
        with self.assertRaises(QuoteError):
            normalize_quote(RawQuote("p", "X", self.T, last="abc"), "S", "V", "p")

    def test_locked_market_allowed_crossed_not(self):
        self.assertEqual(Quote("S", "V", "p", self.T, bid=1.0, ask=1.0).ask, 1.0)
        with self.assertRaises(QuoteError) as cm:
            Quote("S", "V", "p", self.T, bid=1.1, ask=1.0)
        self.assertEqual(cm.exception.message.key, MessageKey.QUOTE_CROSSED)

    def test_quote_freshness(self):
        q, pol = Quote("S", "V", "p", self.T, last=1.0), QuotePolicy(5.0, 60.0)
        self.assertEqual(assess_quote(q, self.T + timedelta(seconds=5), pol), FreshnessState.FRESH)
        self.assertEqual(assess_quote(q, self.T + timedelta(seconds=5.001), pol), FreshnessState.STALE)
        self.assertEqual(assess_quote(q, self.T + timedelta(seconds=60.001), pol), FreshnessState.EXPIRED)
        self.assertEqual(assess_quote(q, self.T - timedelta(seconds=1), pol), FreshnessState.INVALID)


class TestLocalization(unittest.TestCase):
    def setUp(self):
        self.cat = default_catalog()

    def test_every_key_has_english(self):
        from omnisystem_v5.marketdata.catalog_en import MESSAGES
        self.assertEqual(set(MESSAGES), set(MessageKey))

    def test_persian_covers_every_key_with_identical_placeholders(self):
        import string
        from omnisystem_v5.marketdata.catalog_en import MESSAGES as en
        from omnisystem_v5.marketdata.catalog_fa import MESSAGES as fa
        self.assertEqual(set(fa), set(MessageKey))
        for k in MessageKey:
            names = lambda t: sorted(f for _, f, _, _ in string.Formatter().parse(t) if f)
            self.assertEqual(names(en[k]), names(fa[k]), k)

    def test_render_locales(self):
        m = msg(MessageKey.DATA_STALE, age_seconds=700.0, limit_seconds=600.0)
        en, fa = self.cat.render(m, EN), self.cat.render(m, FA)
        self.assertIn("stale", en.text)
        self.assertTrue(any("\u0600" <= ch <= "\u06ff" for ch in fa.text))
        self.assertFalse(en.fallback or fa.fallback)
        self.assertEqual(en.message, fa.message)                 # the core message is identical in every language

    def test_fallback_chain_is_deterministic_and_never_raises(self):
        m = msg(MessageKey.DATA_NO_BARS, symbol="X", timeframe="5m")
        de = self.cat.render(m, Locale("de"))
        self.assertTrue(de.fallback)
        self.assertIn("No bars", de.text)
        self.assertEqual(self.cat.render(m, Locale("fa-IR")).locale.language, "fa")
        empty = InMemoryCatalog({}).render(m, EN)
        self.assertTrue(empty.fallback)
        self.assertTrue(empty.text.startswith("data.no_bars"))
        broken = InMemoryCatalog({"en": {MessageKey.DATA_NO_BARS: "{missing}"}}).render(m, EN)
        self.assertTrue(broken.fallback)

    def test_locale_validation(self):
        for bad in ("", "EN", "e", "en_US", 5):
            with self.assertRaises(ValueError):
                Locale(bad)
        self.assertEqual(Locale("fa-IR").language, "fa")

    def test_structured_message_is_language_neutral_and_sorted(self):
        a = msg(MessageKey.DATA_GAP, seconds=5, index=2)
        self.assertEqual(a.params, (("index", "2"), ("seconds", "5")))
        self.assertEqual(a.reason_str(), "data.gap index=2 seconds=5")
        self.assertIsInstance(a, StructuredMessage)


if __name__ == "__main__":
    unittest.main()
