"""
Adversarial tests explicitly requested in the Phase 4 spec (section 16):

- Bullish lower timeframe but bearish 4H
- Liquidity sweep without MSS
- FVG without sufficient structure
- Excellent setup but unacceptable R:R
- Strong signal with stale data
- High volatility scalp
- Missing volume
- Missing lower timeframe data
- Conflicting Bull/Bear evidence
"""

import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.enums import ConflictStatus, NoTradeReason, ScalpStatus
from omnisystem_v5.intelligence.mtf_bias import aggregate_multi_timeframe_bias
from omnisystem_v5.intelligence.regime import classify_market_regime
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig, detect_scalp_candidate
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _envelope(bars, timeframe=Timeframe.H1, quality=QualityStatus.OK):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=quality, bars=tuple(bars))


def _build_contexts(bars, timeframe=Timeframe.H1, quality=QualityStatus.OK):
    env = _envelope(bars, timeframe, quality)
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _uptrend_bars(n, t0, base=100.0):
    bars = []
    price = base
    for i in range(n):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price + 0.2))
    return bars


def _downtrend_bars(n, t0, base=200.0):
    bars = []
    price = base
    for i in range(n):
        price -= 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price - 0.2))
    return bars


class TestBullishLowerTimeframeBearish4H(unittest.TestCase):
    def test_conflicting_htf_and_ltf_reported_not_hidden(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        h4_ctx, _ = _build_contexts(_downtrend_bars(100, t0), timeframe=Timeframe.H4)
        m15_ctx, _ = _build_contexts(_uptrend_bars(100, t0), timeframe=Timeframe.M15)
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC),
            contexts={Timeframe.H4: h4_ctx, Timeframe.M15: m15_ctx},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.CONFLICTING)
        # the conflict must be visible, not resolved/hidden by this layer
        self.assertIn("opposes", bias.basis)


class TestLiquiditySweepWithoutMSS(unittest.TestCase):
    def test_equal_lows_present_but_no_confirming_break_is_only_moderate(self):
        """A liquidity pool with no structural break to confirm a reversal
        must not be treated as strong bullish evidence."""
        t0 = datetime.now(UTC) - timedelta(hours=100)
        # flat-ish market with a couple of equal lows but no clean break/uptrend
        bars = []
        price = 100.0
        for i in range(100):
            price += 0.05 if i % 2 == 0 else -0.05
            bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price))
        mctx, qctx = _build_contexts(bars)
        case = build_bull_case("BTCUSDT", mctx, qctx)
        # liquidity alignment must never jump to STRONG without a confirming break present
        if case.liquidity_alignment.value == "STRONG":
            confirming_breaks = [e for e in mctx.structure_events if "BULLISH" in e.event_type.value and "SWING" not in e.event_type.value]
            self.assertTrue(len(confirming_breaks) > 0, "STRONG liquidity alignment claimed without any confirming break")


class TestFvgWithoutSufficientStructure(unittest.TestCase):
    def test_fvg_alone_does_not_force_a_scenario(self):
        """An FVG can exist with no meaningful trend/structure behind it —
        the engine must still be able to report has_scenario=False."""
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = [_bar(t0 + timedelta(hours=i), 100.0, 100.3, 99.7, 100.0) for i in range(85)]
        # inject a single 3-candle bullish FVG pattern at the end, nothing else structural
        bars.append(_bar(t0 + timedelta(hours=85), 100.0, 100.5, 99.5, 100.0))
        bars.append(_bar(t0 + timedelta(hours=86), 102.0, 106.0, 101.0, 105.0))
        bars.append(_bar(t0 + timedelta(hours=87), 108.0, 109.0, 107.5, 108.5))
        mctx, qctx = _build_contexts(bars)
        case = build_bull_case("BTCUSDT", mctx, qctx)
        # structure_alignment (the has_scenario gate) must not be forced STRONG purely by one FVG
        self.assertIn(case.structure_alignment.value, ("NONE", "WEAK", "MODERATE"))


class TestExcellentSetupUnacceptableRR(unittest.TestCase):
    def test_high_min_rr_threshold_rejects_otherwise_good_setup(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _uptrend_bars(100, t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(min_reward_risk_ratio=50.0))
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)


class TestStrongSignalStaleData(unittest.TestCase):
    def test_stale_data_blocks_scalp_regardless_of_signal_strength(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _uptrend_bars(100, t0)
        env = _envelope(bars, quality=QualityStatus.STALE)
        mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        self.assertEqual(mctx.status, ContextStatus.DATA_UNAVAILABLE)  # STALE maps conservatively (Phase 2/3 rule)
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, result.rejection_reasons)


class TestHighVolatilityScalp(unittest.TestCase):
    def test_extreme_volatility_does_not_crash_and_is_classified(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = []
        price = 1000.0
        for i in range(100):
            swing = 150.0 if i % 2 == 0 else -140.0
            price = max(price + swing, 50.0)
            bars.append(_bar(t0 + timedelta(hours=i), price, price + 40, max(price - 40, 1), price + 5))
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        # must not crash; must return a well-formed result either way
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertIn(result.status, (ScalpStatus.ZONE_IDENTIFIED, ScalpStatus.NO_VALID_SCALP))


class TestMissingVolume(unittest.TestCase):
    def test_zero_volume_never_fabricates_volume_alignment(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = [OHLCVBar(open=b.open, high=b.high, low=b.low, close=b.close, volume=0,
                          open_time=b.open_time, close_time=b.close_time) for b in _uptrend_bars(100, t0)]
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        if result.candidates:
            self.assertEqual(result.candidates[0].evidence.volume_alignment.value, "NONE")


class TestMissingLowerTimeframeData(unittest.TestCase):
    def test_missing_execution_timeframe_yields_insufficient_conflict_status(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        h4_ctx, _ = _build_contexts(_uptrend_bars(100, t0), timeframe=Timeframe.H4)
        mtf = MultiTimeframeMarketContext(
            symbol="BTCUSDT", calculated_at=datetime.now(UTC), contexts={Timeframe.H4: h4_ctx},
        )
        bias = aggregate_multi_timeframe_bias(mtf, Timeframe.H4, Timeframe.M15)
        self.assertEqual(bias.conflict_status, ConflictStatus.INSUFFICIENT)
        self.assertEqual(bias.execution_timeframe_structure.value, "UNDEFINED")


class TestConflictingBullBearEvidence(unittest.TestCase):
    def test_balanced_evidence_rejected_as_no_trade(self):
        """Construct a market where both engines find some (roughly equal,
        weak) evidence — the scalp engine must refuse to pick a side."""
        t0 = datetime.now(UTC) - timedelta(hours=100)
        # a mild sideways chop with small alternating legs -> weak evidence both ways
        bars = []
        price = 100.0
        for i in range(100):
            price += 0.15 if i % 4 < 2 else -0.15
            bars.append(_bar(t0 + timedelta(hours=i), price, price + 0.8, price - 0.8, price + 0.05))
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        # either explicitly balanced, or rejected for some other well-formed reason —
        # the one unacceptable outcome is silently forcing a directional candidate
        # out of genuinely weak/roughly-equal evidence.
        if bull.has_scenario and bear.has_scenario:
            self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)


if __name__ == "__main__":
    unittest.main()
