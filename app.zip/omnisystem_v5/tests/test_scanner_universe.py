import unittest
from datetime import datetime, timezone

from omnisystem_v5.scanner.enums import MarketType, TradingStatus
from omnisystem_v5.scanner.universe import (StaticUniverse, SymbolSpec, UniverseError, UniverseFilter,
                                            normalize_symbol, resolve_universe)


class TestNormalization(unittest.TestCase):
    def test_separator_variants_share_one_canonical_form(self):
        for raw in ("btc-usdt", "BTC_USDT", " btc/usdt ", "BTC USDT", "btc:usdt"):
            self.assertEqual(normalize_symbol(raw), "BTC/USDT")

    def test_separator_free_symbols_only_uppercased(self):
        self.assertEqual(normalize_symbol("btcusdt"), "BTCUSDT")
        self.assertEqual(normalize_symbol("brk.b"), "BRK.B")

    def test_invalid_symbols_fail_closed(self):
        for raw in ("", "   ", "A/B/C", "BTC$USDT", "BTC//", None, 5):
            with self.assertRaises(UniverseError, msg=repr(raw)):
                normalize_symbol(raw)


class TestSymbolSpec(unittest.TestCase):
    def test_quote_currency_derived_and_validated(self):
        self.assertEqual(SymbolSpec("eth-usdt").quote_currency, "USDT")
        with self.assertRaises(UniverseError):
            SymbolSpec("ETH/USDT", quote_currency="USD")

    def test_liquidity_must_be_finite_non_negative(self):
        for bad in (-1, float("nan"), float("inf"), True, "5"):
            with self.assertRaises(UniverseError, msg=repr(bad)):
                SymbolSpec("ETH/USDT", quote_volume_24h=bad)


class TestResolve(unittest.TestCase):
    def specs(self):
        return [SymbolSpec("SOL/USDT", quote_volume_24h=5e6), SymbolSpec("btc-usdt", quote_volume_24h=9e9),
                SymbolSpec("ETH/USDT", quote_volume_24h=None), SymbolSpec("XRP/USD", status=TradingStatus.HALTED),
                SymbolSpec("AAPL", market_type=MarketType.EQUITY, quote_volume_24h=1e9)]

    def test_deterministic_ordering_regardless_of_input_order(self):
        a = resolve_universe(self.specs())
        b = resolve_universe(list(reversed(self.specs())))
        self.assertEqual(a, b)
        self.assertEqual([s.symbol for s in a.specs], sorted(s.symbol for s in a.specs))

    def test_halted_excluded_with_reason(self):
        r = resolve_universe(self.specs())
        self.assertIn(("XRP/USD", "trading status HALTED"), r.excluded)

    def test_unknown_liquidity_fails_closed_when_floor_set(self):
        r = resolve_universe(self.specs(), UniverseFilter(min_quote_volume_24h=1e6))
        reasons = dict(r.excluded)
        self.assertEqual(reasons["ETH/USDT"], "liquidity unknown (fail closed)")
        self.assertNotIn("BTC/USDT", reasons)

    def test_below_floor_include_exclude_market_and_quote_filters(self):
        r = resolve_universe(self.specs(), UniverseFilter(min_quote_volume_24h=6e6, exclude={"aapl"},
                                                          quote_currencies={"usdt"}, market_types={MarketType.SPOT}))
        self.assertEqual([s.symbol for s in r.specs], ["BTC/USDT"])
        reasons = dict(r.excluded)
        self.assertEqual(reasons["SOL/USDT"], "below minimum liquidity")
        self.assertEqual(reasons["AAPL"], "explicitly excluded")
        r2 = resolve_universe(self.specs(), UniverseFilter(include={"sol-usdt"}))
        self.assertEqual([s.symbol for s in r2.specs], ["SOL/USDT"])

    def test_identical_duplicates_merge_conflicting_duplicates_raise(self):
        r = resolve_universe([SymbolSpec("BTC/USDT"), SymbolSpec("btc-usdt")])
        self.assertEqual(len(r.specs), 1)
        with self.assertRaises(UniverseError):
            resolve_universe([SymbolSpec("BTC/USDT", quote_volume_24h=1.0), SymbolSpec("BTC/USDT", quote_volume_24h=2.0)])

    def test_empty_universe(self):
        r = resolve_universe(StaticUniverse([]).symbols(datetime.now(timezone.utc)))
        self.assertEqual((r.specs, r.excluded), ((), ()))

    def test_non_spec_rejected(self):
        with self.assertRaises(UniverseError):
            resolve_universe(["BTC/USDT"])


if __name__ == "__main__":
    unittest.main()
