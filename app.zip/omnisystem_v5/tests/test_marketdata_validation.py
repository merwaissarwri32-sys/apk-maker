"""Phase 11: strict, fail-closed validation. Every corrupt input must be REFUSED, never repaired. SYNTHETIC."""
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from omnisystem_v5.marketdata import validation as V
from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.config import MarketDataConfig, SharedLimits, ValidationPolicy
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.provider import BarRequest, ProviderPayloadError, RawBarRow, RawBars
from omnisystem_v5.marketdata.sessions import WeeklySession
from omnisystem_v5.scanner.failures import FailureClass, classify_fetch_exception
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.tests.marketdata_fixtures import END, VENUE, crypto_instrument, forex_instrument, raw_rows, session_bars
from omnisystem_v5.tests.scanner_fixtures import bars_ending_at
from omnisystem_v5.validation.resampling import seconds_for_timeframe

TF = Timeframe.M5
STEP = timedelta(seconds=300)
LIMITS = SharedLimits(2.0, 40, 200, 2)
LST = Listing(crypto_instrument(), VENUE)
REQ = BarRequest("BTCUSDT", TF, 200)


def good_rows(n=60, tf=TF, end=END):
    return list(raw_rows(bars_ending_at(tf, n, end)))


def raw(rows, tf=TF, symbol="BTCUSDT", echo=True):
    return RawBars("p", symbol, tuple(rows), tf if echo else None)


def run(rows, now=END, policy=None, listing=LST, req=REQ, **kw):
    return V.validate_series(raw(rows, **kw), req, listing, now, policy or ValidationPolicy(), LIMITS)


def keys(out, fatal_only=True):
    return {i.message.key for i in out.issues if i.fatal or not fatal_only}


def mutate(rows, i, **changes):
    r = rows[i]
    d = dict(open=r.open, high=r.high, low=r.low, close=r.close, volume=r.volume, open_time=r.open_time, close_time=r.close_time)
    d.update(changes)
    rows[i] = RawBarRow(**d)
    return rows


class TestHappyPath(unittest.TestCase):
    def test_clean_series_is_ok(self):
        out = run(good_rows())
        self.assertEqual(out.kind, V.OK)
        self.assertEqual(len(out.bars), 60)
        self.assertEqual(out.fatal, ())

    def test_numeric_strings_and_decimals_are_accepted_iso_z_timestamps_too(self):
        rows = good_rows()
        r = rows[0]
        rows[0] = RawBarRow(str(r.open), Decimal(str(r.high)), str(r.low), r.close, str(r.volume),
                            r.open_time.isoformat().replace("+00:00", "Z"), r.close_time.isoformat())
        self.assertEqual(run(rows).kind, V.OK)


class TestNonFiniteAndPrices(unittest.TestCase):
    def test_nan_inf_neg_inf_in_every_numeric_field_rejected(self):
        for value in (float("nan"), float("inf"), float("-inf"), "NaN", "inf", "-Infinity", Decimal("NaN")):
            for f in ("open", "high", "low", "close", "volume"):
                out = run(mutate(good_rows(), 10, **{f: value}))
                self.assertEqual(out.kind, V.INVALID, (value, f))
                self.assertIn(K.DATA_NON_FINITE, keys(out))
                self.assertEqual(out.bars, ())

    def test_non_positive_prices_rejected(self):
        for value in (0, 0.0, -1.0, "-5"):
            for f in ("open", "high", "low", "close"):
                out = run(mutate(good_rows(), 10, **{f: value}))
                self.assertEqual(out.kind, V.INVALID, (value, f))
                self.assertTrue(keys(out) & {K.DATA_NON_POSITIVE_PRICE, K.DATA_OHLC_INVALID})

    def test_negative_volume_rejected_zero_volume_allowed(self):
        self.assertIn(K.DATA_NEGATIVE_VOLUME, keys(run(mutate(good_rows(), 3, volume=-0.1))))
        self.assertEqual(run(mutate(good_rows(), 3, volume=0)).kind, V.OK)      # forex tick volume may legitimately be 0

    def test_garbage_types_rejected(self):
        for value in (None, True, "abc", [], {}, object()):
            self.assertEqual(run(mutate(good_rows(), 4, close=value)).kind, V.INVALID, repr(value))

    def test_positive_price_requirement_can_be_relaxed_only_explicitly(self):
        rows = mutate(mutate(mutate(mutate(good_rows(), 9, open=0.0), 9, high=1.0), 9, low=0.0), 9, close=0.5)
        self.assertEqual(run(rows).kind, V.INVALID)
        self.assertEqual(run(rows, policy=ValidationPolicy(require_positive_prices=False)).kind, V.OK)


class TestOHLC(unittest.TestCase):
    def test_impossible_ohlc_rejected(self):
        r = good_rows()[10]
        for changes in (dict(high=r.low - 1), dict(low=max(r.open, r.close) + 5), dict(high=min(r.open, r.close) - 0.01)):
            out = run(mutate(good_rows(), 10, **changes))
            self.assertEqual(out.kind, V.INVALID, changes)
            self.assertIn(K.DATA_OHLC_INVALID, keys(out))

    def test_ohlc_bounds_may_touch(self):
        self.assertEqual(run(mutate(mutate(good_rows(), 10, high=100.0, low=100.0), 10, open=100.0, close=100.0)).kind, V.OK)


class TestTimestamps(unittest.TestCase):
    def test_naive_and_unparseable_timestamps_rejected(self):
        naive = datetime(2024, 2, 29, 23, 55)
        for f in ("open_time", "close_time"):
            for value in (naive, "2024-02-29T23:55:00", "not-a-date", 1709250000, 1709250000000, None, ""):
                out = run(mutate(good_rows(), 20, **{f: value}))
                self.assertEqual(out.kind, V.INVALID, (f, value))
                self.assertIn(K.DATA_TIMESTAMP_INVALID, keys(out))

    def test_boundary_misalignment_rejected(self):
        rows = good_rows()
        for i in range(len(rows)):                                   # shift the whole grid by 1 minute: contiguous but off-boundary
            r = rows[i]
            mutate(rows, i, open_time=r.open_time + timedelta(minutes=1), close_time=r.close_time + timedelta(minutes=1))
        out = run(rows, now=END + timedelta(minutes=1))
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_TIMESTAMP_MISALIGNED, keys(out))

    def test_sub_second_offset_is_misaligned(self):
        rows = good_rows()
        r = rows[5]
        mutate(rows, 5, open_time=r.open_time + timedelta(microseconds=1))
        self.assertIn(K.DATA_TIMESTAMP_MISALIGNED, keys(run(rows)))

    def test_wrong_bar_duration_rejected(self):
        rows = good_rows()
        mutate(rows, 12, close_time=rows[12].close_time - timedelta(seconds=1))
        self.assertIn(K.DATA_BAR_DURATION_INVALID, keys(run(rows)))

    def test_anchor_offset_shifts_the_boundary_grid(self):
        lst = Listing(crypto_instrument(), VENUE, bar_anchor_offset_seconds=3600)
        bars = bars_ending_at(Timeframe.H4, 60, END - timedelta(hours=3))     # closes at 21:00 UTC: on a 4h grid anchored at 01:00
        req = BarRequest("BTCUSDT", Timeframe.H4, 60)
        out = V.validate_series(raw(raw_rows(bars), tf=Timeframe.H4), req, lst, END, ValidationPolicy(), LIMITS)
        self.assertEqual(out.kind, V.OK)
        out = V.validate_series(raw(raw_rows(bars), tf=Timeframe.H4), req, Listing(crypto_instrument(), VENUE), END, ValidationPolicy(), LIMITS)
        self.assertEqual(out.kind, V.INVALID)


class TestSequence(unittest.TestCase):
    def test_duplicate_bar_rejected_not_deduplicated(self):
        rows = good_rows()
        out = run(rows[:30] + [rows[29]] + rows[30:])
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_DUPLICATE_BAR, keys(out))
        self.assertEqual(out.bars, ())

    def test_out_of_order_rejected_not_sorted(self):
        rows = good_rows()
        rows[20], rows[21] = rows[21], rows[20]
        out = run(rows)
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_OUT_OF_ORDER, keys(out))

    def test_reverse_order_rejected(self):
        self.assertEqual(run(list(reversed(good_rows()))).kind, V.INVALID)

    def test_missing_bar_is_a_gap(self):
        rows = good_rows()
        del rows[30]
        out = run(rows)
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_GAP, keys(out))

    def test_malformed_bar_in_the_middle_rejects_series_by_default(self):
        out = run(mutate(good_rows(), 30, close="abc"))
        self.assertEqual(out.kind, V.INVALID)
        self.assertEqual(out.bars, ())

    def test_tolerated_malformed_drop_is_recorded_and_the_resulting_gap_still_rejects(self):
        pol = ValidationPolicy(max_malformed_bars=1)
        out = run(mutate(good_rows(), 30, close="abc"), policy=pol)
        self.assertEqual(out.kind, V.INVALID)                       # dropping a middle bar creates a gap: never silently OK
        self.assertIn(K.DATA_GAP, keys(out))
        rows = mutate(good_rows(), 0, close="abc")                  # oldest bar: dropping it leaves a contiguous series
        out = run(rows, policy=pol)
        self.assertEqual(out.kind, V.OK)
        self.assertEqual(out.dropped, ((K.DATA_MALFORMED_BAR_DROPPED.value, 1),))
        self.assertIn(K.DATA_MALFORMED_BAR_DROPPED, keys(out, fatal_only=False))
        self.assertEqual(len(out.bars), 59)

    def test_malformed_limit_exceeded_rejects(self):
        rows = mutate(mutate(good_rows(), 0, close="x"), 1, close="y")
        out = run(rows, policy=ValidationPolicy(max_malformed_bars=1))
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_MALFORMED_BAR_LIMIT, keys(out))


class TestFormingAndFuture(unittest.TestCase):
    def test_trailing_forming_bar_dropped_and_recorded_by_default(self):
        rows = good_rows(61, end=END + STEP)                        # last bar closes one step after `now`
        out = run(rows, now=END)
        self.assertEqual(out.kind, V.OK)
        self.assertEqual(len(out.bars), 60)
        self.assertEqual(out.dropped, ((K.DATA_FORMING_BAR_DROPPED.value, 1),))
        self.assertEqual(out.bars[-1].close_time, END)

    def test_forming_bar_rejected_when_policy_forbids_dropping(self):
        out = run(good_rows(61, end=END + STEP), now=END, policy=ValidationPolicy(drop_forming_bar=False))
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_FORMING_BAR, keys(out))

    def test_future_bar_always_rejected(self):
        out = run(good_rows(60, end=END + STEP * 3), now=END)
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_FUTURE_BAR, keys(out))

    def test_only_one_bar_may_be_dropped_as_forming(self):
        out = run(good_rows(62, end=END + STEP * 2), now=END)       # last bar future (open > now) -> reject, never trim repeatedly
        self.assertEqual(out.kind, V.INVALID)


class TestInsufficient(unittest.TestCase):
    def test_too_few_bars(self):
        out = run(good_rows(39))
        self.assertEqual(out.kind, V.INSUFFICIENT)
        self.assertEqual(len(out.bars), 39)
        self.assertIn(K.DATA_INSUFFICIENT_BARS, keys(out))
        self.assertEqual(run(good_rows(40)).kind, V.OK)

    def test_dropping_forming_bar_can_make_series_insufficient(self):
        self.assertEqual(run(good_rows(40, end=END + STEP), now=END).kind, V.INSUFFICIENT)

    def test_empty_response(self):
        out = run([])
        self.assertEqual(out.kind, V.NO_BARS)
        self.assertEqual(out.bars, ())


class TestStructure(unittest.TestCase):
    def test_timeframe_mismatch_is_a_payload_error(self):
        with self.assertRaises(ProviderPayloadError) as cm:
            run(good_rows(), tf=Timeframe.M15)                      # 5m request answered with an explicit 15m echo
        self.assertIn("timeframe", str(cm.exception))
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.MALFORMED_RESPONSE)

    def test_symbol_echo_mismatch(self):
        with self.assertRaises(ProviderPayloadError):
            run(good_rows(), symbol="ETHUSDT")

    def test_timeframe_is_never_inferred_from_payload(self):
        # A payload of 15m-spaced bars with NO echo, requested as 5m, must be refused (misaligned/duration), not reinterpreted.
        out = run(list(raw_rows(bars_ending_at(Timeframe.M15, 60, END))), echo=False)
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_BAR_DURATION_INVALID, keys(out))

    def test_structural_garbage(self):
        for bad in (None, "x", {"rows": []}):
            with self.assertRaises(ProviderPayloadError):
                V.validate_series(bad, REQ, LST, END, ValidationPolicy(), LIMITS)
        with self.assertRaises(ProviderPayloadError):
            V.validate_series(RawBars("p", "BTCUSDT", ({"open": 1},), TF), REQ, LST, END, ValidationPolicy(), LIMITS)
        with self.assertRaises(ProviderPayloadError):
            V.validate_series(RawBars("p", "BTCUSDT", "abc", TF), REQ, LST, END, ValidationPolicy(), LIMITS)

    def test_never_mutates_or_sorts_input(self):
        rows = good_rows()
        before = list(rows)
        run(rows)
        self.assertEqual(rows, before)


class TestSessionGapPolicy(unittest.TestCase):
    """D2: session gaps are never filled or compressed. Default: reject. Opt-in: keep only the trailing contiguous segment."""
    FX = forex_instrument()

    def setUp(self):
        self.session = WeeklySession.forex_ny()
        self.lst = Listing(self.FX, VENUE, session=self.session)
        self.req = BarRequest("EUR_USD", Timeframe.H1, 200)
        self.now = END + timedelta(days=3, hours=5)                 # Mon 2024-03-04 05:00 UTC: the week has been open ~7h
        self.bars = session_bars(Timeframe.H1, 60, self.now, self.session)

    def _run(self, policy, limits=LIMITS):
        return V.validate_series(RawBars("p", "EUR_USD", raw_rows(self.bars), Timeframe.H1), self.req, self.lst, self.now, policy, limits)

    def test_fixture_really_spans_a_weekend(self):
        gaps = [(b.open_time - a.open_time) for a, b in zip(self.bars, self.bars[1:])]
        self.assertGreater(max(gaps), timedelta(hours=40))

    def test_default_rejects_and_does_not_repair(self):
        out = self._run(ValidationPolicy())
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_SESSION_GAP, keys(out))          # named as a session gap, and still refused
        self.assertNotIn(K.DATA_GAP, keys(out))
        self.assertEqual(out.bars, ())

    def test_opt_in_truncates_to_trailing_segment_and_records_it(self):
        out = self._run(ValidationPolicy(truncate_at_session_gap=True), SharedLimits(2.0, 5, 200, 2))
        self.assertEqual(out.kind, V.OK)
        self.assertTrue(all(b.open_time >= datetime(2024, 3, 3, 22, 0, tzinfo=timezone.utc) for b in out.bars))
        self.assertLess(len(out.bars), 60)
        self.assertTrue(any(k == K.DATA_SESSION_GAP_TRUNCATED.value for k, _ in out.dropped))
        # nothing invented: every delivered bar is an original bar, and the delivered series is contiguous
        self.assertTrue(set(b.open_time for b in out.bars) <= set(b.open_time for b in self.bars))
        self.assertEqual(len({b.open_time for b in out.bars}), len(out.bars))

    def test_opt_in_short_segment_is_insufficient_not_padded(self):
        out = self._run(ValidationPolicy(truncate_at_session_gap=True))          # min_bars=40 but only ~7 bars since the open
        self.assertEqual(out.kind, V.INSUFFICIENT)
        self.assertLess(len(out.bars), 40)

    def test_non_session_gap_is_never_truncated_even_when_opted_in(self):
        session = WeeklySession.forex_ny()
        bars = list(session_bars(Timeframe.H1, 60, END, session))               # mid-week Thursday: no session gap inside
        del bars[30]
        req = self.req
        out = V.validate_series(RawBars("p", "EUR_USD", raw_rows(bars), Timeframe.H1), req, self.lst, END,
                                ValidationPolicy(truncate_at_session_gap=True), LIMITS)
        self.assertEqual(out.kind, V.INVALID)
        self.assertIn(K.DATA_GAP, keys(out))                  # a genuinely missing bar is a DATA_GAP, not a session gap

    def test_4h_and_1d_are_structurally_short_of_min_bars_for_forex(self):
        for tf, n in ((Timeframe.H4, 200), (Timeframe.D1, 200)):
            bars = session_bars(tf, n, END, self.session)
            out = V.validate_series(RawBars("p", "EUR_USD", raw_rows(bars), tf), BarRequest("EUR_USD", tf, n), self.lst, END,
                                    ValidationPolicy(truncate_at_session_gap=True), LIMITS)
            self.assertEqual(out.kind, V.INSUFFICIENT, tf)
            self.assertLess(len(out.bars), LIMITS.min_bars, tf)


class TestDeterminism(unittest.TestCase):
    def test_same_input_same_output(self):
        rows = good_rows()
        outs = [run(rows) for _ in range(5)]
        self.assertTrue(all(o == outs[0] for o in outs))
        bad = mutate(good_rows(), 10, close=float("nan"))
        self.assertEqual({repr(run(bad)) for _ in range(5)}.__len__(), 1)


if __name__ == "__main__":
    unittest.main()
