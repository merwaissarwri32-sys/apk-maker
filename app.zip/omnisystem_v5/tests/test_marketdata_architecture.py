"""Phase 11 architectural and safety guards (static analysis + frozen-manifest verification).

Covers: dependency direction (D1), no parallel contracts, no wall-clock / randomness / network / threads / persistence /
execution / alert-transport / secrets, no global mutable state, frozen-envelope contract, and byte-level integrity of every
Phase 1-10 implementation file (only the authorized D1 test edit differs)."""
import ast
import hashlib
import importlib
import re
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]           # .../omnisystem_v5
REPO = PKG.parent
MD = PKG / "marketdata"
ALLOWED_SCANNER_MODULES = {"failures", "clock", "universe", "enums", "telemetry"}          # D1 allow-list
BANNED_IMPORTS = {"socket", "ssl", "http", "urllib", "requests", "httpx", "aiohttp", "websocket", "websockets", "threading", "asyncio",
                  "multiprocessing", "concurrent", "subprocess", "random", "secrets", "sqlite3", "shelve", "pickle", "smtplib", "ftplib",
                  "telnetlib", "xmlrpc"}
TIME_ALLOWED_FILES = {"system.py"}


def py_files(root):
    return sorted(p for p in root.rglob("*.py") if "__pycache__" not in p.parts)


def parse(path):
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def imported_modules(tree):
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            out += [a.name for a in n.names]
        elif isinstance(n, ast.ImportFrom):
            out.append(("." * n.level) + (n.module or ""))
            out += [f"{n.module}.{a.name}" for a in n.names] if n.module else []
    return out


class TestDependencyDirection(unittest.TestCase):
    def test_marketdata_files_exist(self):
        self.assertGreaterEqual(len(py_files(MD)), 25)

    def test_frozen_layers_and_scanner_never_import_marketdata(self):
        offenders = []
        for p in py_files(PKG):
            rel = p.relative_to(PKG).parts
            if rel[0] in ("marketdata", "tests", "alerts"):
                continue
            text = p.read_text(encoding="utf-8")
            if "omnisystem_v5.marketdata" in text or re.search(r"\bimport\s+marketdata\b|from\s+\.+marketdata", text):
                offenders.append(str(p.relative_to(PKG)))
        self.assertEqual(offenders, [], "Phases 1-10 must not depend on Phase 11")

    def test_marketdata_imports_only_allow_listed_scanner_contract_modules(self):
        bad = []
        for p in py_files(MD):
            for line_no, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
                m = re.match(r"\s*(?:from|import)\s+omnisystem_v5\.scanner(?:\.(\w+))?", line)
                if m and m.group(1) not in ALLOWED_SCANNER_MODULES:
                    bad.append(f"{p.name}:{line_no}: {line.strip()}")
                if re.match(r"\s*from\s+omnisystem_v5\s+import\s+.*\bscanner\b", line):
                    bad.append(f"{p.name}:{line_no}: {line.strip()}")
        self.assertEqual(bad, [])

    def test_no_relative_imports_used_to_bypass_the_guard(self):
        bad = [p.name for p in py_files(MD) if re.search(r"^\s*from\s+\.", p.read_text(encoding="utf-8"), re.M)]
        self.assertEqual(bad, [])
        for p in py_files(MD):
            self.assertFalse([n for n in ast.walk(parse(p)) if isinstance(n, ast.ImportFrom) and n.level], p.name)

    def test_no_execution_import_and_no_order_vocabulary(self):
        for p in py_files(MD):
            text = p.read_text(encoding="utf-8")
            self.assertNotIn("omnisystem_v5.execution", text, p.name)
            self.assertIsNone(re.search(r"\b(place|submit|cancel|modify|create)_order\b|\bsend_order\b|\bexecute_trade\b", text), p.name)

    def test_no_alert_transport_leaked_from_phase_12(self):
        for p in py_files(MD):
            self.assertIsNone(re.search(r"telegram|smtp|twilio|sendmail|webhook|push_notification|sms_", p.read_text(encoding="utf-8"), re.I), p.name)

    def test_only_allow_listed_scanner_symbols_are_used(self):
        used = set()
        for p in py_files(MD):
            for n in ast.walk(parse(p)):
                if isinstance(n, ast.ImportFrom) and n.module and n.module.startswith("omnisystem_v5.scanner"):
                    used |= {f"{n.module.split('.')[-1]}.{a.name}" for a in n.names}
        self.assertEqual(used, {"failures.RETRYABLE", "failures.FailureClass", "failures.ProviderRateLimitedError", "failures.classify_fetch_exception",
                                "clock.Clock", "universe.normalize_symbol", "universe.SymbolSpec", "enums.MarketType", "enums.TradingStatus",
                                "telemetry.InMemorySink", "telemetry.NullSink", "telemetry.TelemetryEvent", "telemetry.TelemetrySink"})


class TestNoParallelContracts(unittest.TestCase):
    def test_reused_objects_are_the_very_same_objects(self):
        from omnisystem_v5.marketdata import events, provider, retry, universe
        from omnisystem_v5.marketdata import source
        from omnisystem_v5.scanner import failures, telemetry
        from omnisystem_v5.scanner import universe as su
        self.assertIs(retry.classify_fetch_exception, failures.classify_fetch_exception)
        self.assertIs(retry.ProviderRateLimitedError, failures.ProviderRateLimitedError)
        self.assertIs(source.FailureClass, failures.FailureClass)
        self.assertIs(events.TelemetryEvent, telemetry.TelemetryEvent)
        self.assertIs(events.InMemorySink, telemetry.InMemorySink)
        self.assertIs(universe.SymbolSpec, su.SymbolSpec)
        self.assertTrue(issubclass(provider.ProviderAuthError, provider.DataUnavailableError))
        self.assertTrue(issubclass(provider.ProviderPayloadError, ValueError))

    def test_no_duplicate_of_a_scanner_contract_is_defined_in_marketdata(self):
        forbidden = {"FailureClass", "ProviderRateLimitedError", "Clock", "ManualClock", "SystemClock", "FixedClock", "SymbolSpec", "MarketType",
                     "TelemetrySink", "TelemetryEvent", "NullSink", "InMemorySink", "MarketDataSource", "Universe", "TradingStatus"}
        defined = {n.name for p in py_files(MD) for n in ast.walk(parse(p)) if isinstance(n, ast.ClassDef)}
        self.assertEqual(defined & forbidden, set())

    def test_exception_types_defined_are_only_the_approved_ones(self):
        errors = {n.name for p in py_files(MD) for n in ast.walk(parse(p))
                  if isinstance(n, ast.ClassDef) and any(isinstance(b, ast.Name) and b.id.endswith(("Error", "Exception")) or
                                                         isinstance(b, ast.Name) and b.id in ("ValueError", "LookupError") for b in n.bases)}
        self.assertEqual(errors, {"ProviderAuthError", "ProviderPayloadError", "WiringMismatchError", "ConfigError", "AssetModelError",
                                  "SymbolMapError", "UnknownSymbolError", "SessionConfigError", "QuoteError"})

    def test_failure_scope_is_orthogonal_not_a_second_failure_taxonomy(self):
        from omnisystem_v5.marketdata.issues import FaultScope
        from omnisystem_v5.scanner.failures import FailureClass
        self.assertFalse({m.value for m in FaultScope} & {m.value for m in FailureClass})

    def test_envelope_contract_is_untouched(self):
        import dataclasses
        from omnisystem_v5.schemas.market_data import MarketDataEnvelope
        self.assertEqual([f.name for f in dataclasses.fields(MarketDataEnvelope)],
                         ["market", "timeframe", "provenance", "quality_status", "bars", "reasons", "schema_version"])
        self.assertTrue(MarketDataEnvelope.__dataclass_params__.frozen)


class TestDeterminismAndSafetyStatics(unittest.TestCase):
    def test_banned_imports_anywhere_in_marketdata(self):
        bad = []
        for p in py_files(MD):
            for mod in imported_modules(parse(p)):
                if mod.split(".")[0] in BANNED_IMPORTS:
                    bad.append(f"{p.name}: {mod}")
        self.assertEqual(bad, [])

    def test_real_time_is_confined_to_system_py(self):
        bad = []
        for p in py_files(MD):
            if p.name in TIME_ALLOWED_FILES:
                continue
            tree = parse(p)
            if any(m.split(".")[0] == "time" for m in imported_modules(tree)):
                bad.append(f"{p.name}: imports time")
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
                    f = n.func
                    owner = f.value.id if isinstance(f.value, ast.Name) else (f.value.attr if isinstance(f.value, ast.Attribute) else None)
                    if owner in ("datetime", "date") and f.attr in ("now", "utcnow", "today"):
                        bad.append(f"{p.name}:{n.lineno}: {owner}.{f.attr}()")
                    if owner == "time":
                        bad.append(f"{p.name}:{n.lineno}: time.{f.attr}()")
        self.assertEqual(bad, [])
        self.assertIn("time.monotonic", (MD / "system.py").read_text(encoding="utf-8"))

    def test_no_randomness_threads_persistence_or_print(self):
        for p in py_files(MD):
            tree = parse(p)
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
                    self.assertNotIn(n.func.id, ("open", "print", "input", "exec", "eval", "__import__"), f"{p.name}:{n.lineno}")
            self.assertNotIn("random", p.read_text(encoding="utf-8").lower().replace("jitter", ""), p.name)

    def test_no_global_mutable_state(self):
        bad = []
        for p in py_files(MD):
            for n in parse(p).body:
                if isinstance(n, ast.Assign) and isinstance(n.value, (ast.List, ast.Dict, ast.Set)):
                    for t in n.targets:
                        if isinstance(t, ast.Name) and not t.id.lstrip("_").isupper():
                            bad.append(f"{p.name}: {t.id}")
                if isinstance(n, ast.Global):
                    bad.append(f"{p.name}: global")
        self.assertEqual(bad, [])
        for p in py_files(MD):
            self.assertFalse([n for n in ast.walk(parse(p)) if isinstance(n, ast.Global)], p.name)

    def test_no_secrets_or_credentials_in_marketdata_or_phase11_tests(self):
        files = py_files(MD) + [p for p in (PKG / "tests").glob("*marketdata*.py") if p.name != Path(__file__).name]
        assign = re.compile(r"(api[_-]?key|secret|token|passw(or)?d|bearer|authorization)\s*[:=]\s*[\"'][^\"']{4,}", re.I)
        blob = re.compile(r"[\"'][A-Za-z0-9+/=_\-]{32,}[\"']")
        for p in files:
            text = p.read_text(encoding="utf-8")
            self.assertIsNone(assign.search(text), p.name)
            self.assertIsNone(blob.search(text), p.name)

    def test_no_provider_url_or_host_is_hard_coded(self):
        for p in py_files(MD):
            self.assertIsNone(re.search(r"https?://", p.read_text(encoding="utf-8")), p.name)

    def test_rest_adapter_keeps_its_not_live_verified_label(self):
        text = (MD / "adapters" / "klines_rest.py").read_text(encoding="utf-8")
        self.assertIn("IMPLEMENTED — NOT LIVE-VERIFIED", text)
        for p in py_files(MD):                                   # no module other than the enum definition may even name a live claim
            if p.name != "provider.py":
                self.assertNotIn("LIVE_CONNECTED", p.read_text(encoding="utf-8"), p.name)

    def test_every_module_imports_cleanly(self):
        for p in py_files(MD):
            rel = p.relative_to(PKG).with_suffix("").parts
            name = "omnisystem_v5." + ".".join(rel)
            if rel[-1] == "__init__":
                name = name.rsplit(".", 1)[0]
            importlib.import_module(name)


class TestFrozenManifest(unittest.TestCase):
    """GATE B: every Phase 1-10 file is byte-identical to the recorded manifest; the single authorized exception is the D1 guard edit."""
    MANIFEST = PKG / "tests" / "phase10_frozen_manifest.txt"
    D1_FILE = "omnisystem_v5/tests/test_scanner_engine.py"
    D1_OLD = 'if rel[0] in ("scanner", "tests"):'
    D1_NEW = 'if rel[0] in ("scanner", "tests", "marketdata", "alerts"):'      # D1 + Phase 12 authorized edit P12-G1 (adds "alerts" only)

    def entries(self):
        out = {}
        for line in self.MANIFEST.read_text(encoding="utf-8").splitlines():
            digest, path = line.split("  ", 1)
            out[path] = digest
        return out

    def test_manifest_covers_the_recorded_phase10_tree(self):
        self.assertEqual(len(self.entries()), 174)

    def test_every_frozen_file_is_unchanged(self):
        changed = []
        for path, digest in self.entries().items():
            data = (REPO / path).read_bytes()
            if path == self.D1_FILE:
                text = data.decode("utf-8")
                self.assertEqual(text.count(self.D1_NEW), 1)
                self.assertNotIn(self.D1_OLD, text)
                data = text.replace(self.D1_NEW, self.D1_OLD).encode("utf-8")      # undo ONLY the authorized edit, then compare
            if hashlib.sha256(data).hexdigest() != digest:
                changed.append(path)
        self.assertEqual(changed, [])

    def test_no_frozen_file_was_added_or_removed(self):
        known = set(self.entries())
        allowed = lambda rel: (rel.startswith("omnisystem_v5/marketdata/") or rel.startswith("omnisystem_v5/alerts/") or
                               re.match(r"omnisystem_v5/tests/(test_marketdata_\w+\.py|marketdata_fixtures\.py|phase10_frozen_manifest\.txt)$", rel) or
                               re.match(r"omnisystem_v5/tests/(test_alerts_\w+\.py|alerts_fixtures\.py|phase12_guard_manifest\.txt)$", rel) or
                               re.match(r"omnisystem_v5/PHASE1[12]_\w+\.md$", rel))
        current = {str(p.relative_to(REPO)) for p in PKG.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
        self.assertEqual(sorted(known - current), [], "a frozen file was removed")
        self.assertEqual(sorted(r for r in current - known if not allowed(r)), [], "an unexpected file appeared outside Phase 11 paths")

    def test_d1_edit_is_exactly_one_line(self):
        text = (REPO / self.D1_FILE).read_text(encoding="utf-8")
        self.assertEqual(len(re.findall(r"\"marketdata\"", text)), 1)


if __name__ == "__main__":
    unittest.main()
