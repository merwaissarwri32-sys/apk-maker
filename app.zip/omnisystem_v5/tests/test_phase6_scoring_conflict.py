import unittest
from datetime import datetime, timezone

from omnisystem_v5.decision.contracts import NormalizedCandidate, ScoreComponents
from omnisystem_v5.decision.conflict import resolve_directional_conflicts, resolve_duplicates
from omnisystem_v5.decision.enums import ConflictResolution, ConflictType, QualityLevel
from omnisystem_v5.decision.policy import ConflictPolicy, ScoringPolicy
from omnisystem_v5.decision.scoring import explain_rank_key, rank_candidates, rank_key
from omnisystem_v5.risk.enums import Direction

UTC = timezone.utc
NOW = datetime.now(UTC)


def _cand(source="ScalpEngine", direction=Direction.LONG, entry=100.0, quality_level=QualityLevel.MODERATE, symbol="BTCUSDT"):
    q = ScoreComponents(structural_quality=quality_level, confirmation_quality=quality_level,
                         risk_quality=quality_level, reward_quality=quality_level,
                         timeframe_alignment=quality_level, data_quality=quality_level)
    cid = NormalizedCandidate.make_id(source, symbol, direction, entry, entry - 5, (entry + 10,), "SCALP", NOW)
    return NormalizedCandidate(candidate_id=cid, source_engine=source, horizon="SCALP", symbol=symbol,
                                direction=direction, entry=entry, stop_loss=entry - 5, take_profits=(entry + 10,),
                                generated_at=NOW, quality=q)


class TestRankKey(unittest.TestCase):
    def test_strong_ranks_above_moderate(self):
        strong = _cand(quality_level=QualityLevel.STRONG)
        moderate = _cand(quality_level=QualityLevel.MODERATE)
        self.assertGreater(rank_key(strong.quality, ScoringPolicy()), rank_key(moderate.quality, ScoringPolicy()))

    def test_priority_order_decides_ties_on_first_component(self):
        policy = ScoringPolicy(component_priority_order=("risk_quality", "structural_quality"))
        a = ScoreComponents(risk_quality=QualityLevel.STRONG, structural_quality=QualityLevel.NONE)
        b = ScoreComponents(risk_quality=QualityLevel.WEAK, structural_quality=QualityLevel.STRONG)
        self.assertGreater(rank_key(a, policy), rank_key(b, policy))  # risk_quality decides first, structural irrelevant here

    def test_explain_rank_key_is_traceable(self):
        c = _cand(quality_level=QualityLevel.STRONG)
        explanation = explain_rank_key(c.quality, ScoringPolicy())
        self.assertEqual(explanation[0], ("risk_quality", "STRONG"))

    def test_rank_candidates_is_stable_and_deterministic(self):
        a = _cand(quality_level=QualityLevel.WEAK)
        b = _cand(quality_level=QualityLevel.STRONG)
        c = _cand(quality_level=QualityLevel.MODERATE)
        ranked1 = rank_candidates([a, b, c], ScoringPolicy())
        ranked2 = rank_candidates([a, b, c], ScoringPolicy())
        self.assertEqual([x.candidate_id for x in ranked1], [b.candidate_id, c.candidate_id, a.candidate_id])
        self.assertEqual(ranked1, ranked2)


class TestDuplicateResolution(unittest.TestCase):
    def test_same_engine_same_direction_close_price_is_duplicate(self):
        a = _cand(entry=100.0, quality_level=QualityLevel.WEAK)
        b = _cand(entry=100.02, quality_level=QualityLevel.STRONG)  # within default 0.05% tolerance
        survivors, records = resolve_duplicates([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 1)
        self.assertEqual(survivors[0].candidate_id, b.candidate_id)
        self.assertEqual(records[0].conflict_type, ConflictType.SAME_ENGINE_DUPLICATE)
        self.assertEqual(records[0].resolution, ConflictResolution.KEPT_HIGHER_RANKED)

    def test_different_engines_same_price_not_duplicate(self):
        a = _cand(source="ScalpEngine", entry=100.0)
        b = _cand(source="IntradayEngine", entry=100.0)
        survivors, records = resolve_duplicates([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 2)
        self.assertEqual(records, [])

    def test_far_apart_prices_same_engine_not_duplicate(self):
        a = _cand(entry=100.0)
        b = _cand(entry=150.0)
        survivors, records = resolve_duplicates([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 2)

    def test_opposite_direction_same_engine_not_duplicate(self):
        a = _cand(direction=Direction.LONG, entry=100.0)
        b = _cand(direction=Direction.SHORT, entry=100.0)
        survivors, records = resolve_duplicates([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 2)

    def test_three_way_duplicate_keeps_single_best(self):
        a = _cand(entry=100.0, quality_level=QualityLevel.WEAK)
        b = _cand(entry=100.01, quality_level=QualityLevel.MODERATE)
        c = _cand(entry=100.02, quality_level=QualityLevel.STRONG)
        survivors, records = resolve_duplicates([a, b, c], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 1)
        self.assertEqual(survivors[0].candidate_id, c.candidate_id)


class TestDirectionalConflictResolution(unittest.TestCase):
    def test_decisive_winner_kept(self):
        strong = _cand(direction=Direction.LONG, quality_level=QualityLevel.STRONG)
        weak = _cand(direction=Direction.SHORT, quality_level=QualityLevel.NONE)
        survivors, records, unresolved = resolve_directional_conflicts([strong, weak], ConflictPolicy(), ScoringPolicy())
        self.assertFalse(unresolved)
        self.assertEqual(len(survivors), 1)
        self.assertEqual(survivors[0].candidate_id, strong.candidate_id)
        self.assertEqual(records[0].resolution, ConflictResolution.KEPT_HIGHER_RANKED)

    def test_close_conflict_drops_both(self):
        a = _cand(direction=Direction.LONG, quality_level=QualityLevel.MODERATE)
        b = _cand(direction=Direction.SHORT, quality_level=QualityLevel.MODERATE)
        survivors, records, unresolved = resolve_directional_conflicts([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertTrue(unresolved)
        self.assertEqual(len(survivors), 0)
        self.assertEqual(records[0].resolution, ConflictResolution.DROPPED_UNRESOLVED)
        self.assertIsNone(records[0].surviving_candidate_id)

    def test_same_direction_never_flagged_as_conflict(self):
        a = _cand(direction=Direction.LONG, quality_level=QualityLevel.STRONG)
        b = _cand(direction=Direction.LONG, entry=200.0, quality_level=QualityLevel.WEAK)
        survivors, records, unresolved = resolve_directional_conflicts([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 2)
        self.assertEqual(records, [])
        self.assertFalse(unresolved)

    def test_different_symbols_never_conflict(self):
        a = _cand(direction=Direction.LONG, symbol="BTCUSDT")
        b = _cand(direction=Direction.SHORT, symbol="ETHUSDT")
        survivors, records, unresolved = resolve_directional_conflicts([a, b], ConflictPolicy(), ScoringPolicy())
        self.assertEqual(len(survivors), 2)

    def test_margin_threshold_is_configurable(self):
        a = _cand(direction=Direction.LONG, quality_level=QualityLevel.STRONG)
        b = _cand(direction=Direction.SHORT, quality_level=QualityLevel.MODERATE)
        # with a very high required margin, even STRONG vs MODERATE might not be decisive
        strict_policy = ConflictPolicy(min_decisive_component_margin=10)
        survivors, records, unresolved = resolve_directional_conflicts([a, b], strict_policy, ScoringPolicy())
        self.assertTrue(unresolved)


if __name__ == "__main__":
    unittest.main()
