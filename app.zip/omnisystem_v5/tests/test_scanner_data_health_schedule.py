import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.intelligence.enums import Horizon
from omnisystem_v5.scanner.clock import FixedClock, ManualClock
from omnisystem_v5.scanner.config import ScannerConfig, ScannerConfigError
from omnisystem_v5.scanner.dedup import DedupPolicy
from omnisystem_v5.scanner.enums import CycleHealth, SymbolScanStatus
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError, classify_fetch_exception
from omnisystem_v5.scanner.health import FailureLedger, HealthPolicy, assess_health
from omnisystem_v5.scanner.market_data import fetch_timeframe, gate_envelope, scanner_quality_config
from omnisystem_v5.scanner.report import SymbolScanResult
from omnisystem_v5.scanner.scheduler import SchedulePolicy, delay_after, is_due, next_due_at
from omnisystem_v5.scanner.timeframes import (check_synchronization, horizon_timeframes, plan_horizons,
                                              required_timeframes)
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.tests.scanner_fixtures import END, StubSource, bars_ending_at, envelope

SYM = "BTC/USDT"


def gate(env, tf=Timeframe.M15, now=END, min_bars=40, stale=2.0):
    return gate_envelope(env, SYM, tf, now, min_bars, stale)


def good(tf=Timeframe.M15, n=60, end=END):
    return envelope(SYM, tf, bars_ending_at(tf, n, end))


class TestGate(unittest.TestCase):
    def test_good_envelope_passes(self):
        self.assertIsNone(gate(good()))

    def test_malformed_and_mismatch(self):
        self.assertEqual(gate("nope")[0], FailureClass.MALFORMED_RESPONSE)
        self.assertEqual(gate(good(Timeframe.M5))[0], FailureClass.MALFORMED_RESPONSE)
        self.assertEqual(gate_envelope(good(), "ETH/USDT", Timeframe.M15, END, 40, 2)[0], FailureClass.MALFORMED_RESPONSE)

    def test_quality_status_mapping(self):
        bars = bars_ending_at(Timeframe.M15, 60, END)
        for status, cls in ((QualityStatus.STALE, FailureClass.STALE_DATA),
                            (QualityStatus.INSUFFICIENT_DATA, FailureClass.INSUFFICIENT_DATA),
                            (QualityStatus.INVALID, FailureClass.INVALID_DATA),
                            (QualityStatus.ERROR, FailureClass.PROVIDER_UNAVAILABLE)):
            self.assertEqual(gate(envelope(SYM, Timeframe.M15, bars, status=status, reasons=("r",)))[0], cls)

    def test_simulated_origin_refused(self):
        env = envelope(SYM, Timeframe.M15, bars_ending_at(Timeframe.M15, 60, END), origin=DataOrigin.SIMULATED)
        self.assertEqual(gate(env)[0], FailureClass.UNUSABLE_ORIGIN)

    def test_insufficient_bars(self):
        self.assertEqual(gate(good(n=39))[0], FailureClass.INSUFFICIENT_DATA)
        self.assertIsNone(gate(good(n=40)))

    def test_source_that_bypassed_the_gate_is_caught_by_sequence_revalidation(self):
        bars = list(bars_ending_at(Timeframe.M15, 60, END))
        dup = list(bars[:30]) + [bars[29]] + list(bars[30:])           # duplicate bar
        self.assertEqual(gate(envelope(SYM, Timeframe.M15, dup))[0], FailureClass.INVALID_DATA)
        shuffled = bars[:10] + [bars[11], bars[10]] + bars[12:]        # broken order
        self.assertEqual(gate(envelope(SYM, Timeframe.M15, shuffled))[0], FailureClass.INVALID_DATA)
        gap = bars[:30] + bars[45:]                                    # missing bars -> broken sequence
        self.assertEqual(gate(envelope(SYM, Timeframe.M15, gap), min_bars=40)[0], FailureClass.INVALID_DATA)

    def test_freshness_uses_injected_clock_with_strict_boundary(self):
        env = good()
        limit = 2 * 900
        self.assertIsNone(gate(env, now=END + timedelta(seconds=limit)))                    # exactly at limit: fresh
        cls, _ = gate(env, now=END + timedelta(seconds=limit + 1))
        self.assertEqual(cls, FailureClass.STALE_DATA)

    def test_forming_or_future_bar_rejected(self):
        cls, detail = gate(good(), now=END - timedelta(seconds=1))
        self.assertEqual(cls, FailureClass.INVALID_DATA)
        self.assertIn("forming", detail)

    def test_higher_timeframes_are_not_stale_under_scanner_quality_config(self):
        cfg = scanner_quality_config()
        self.assertEqual(cfg.max_staleness_seconds, float("inf"))
        self.assertIsNone(gate(good(Timeframe.D1, n=60), tf=Timeframe.D1, now=END + timedelta(hours=20)))


class TestFetch(unittest.TestCase):
    def call(self, source, attempts=2):
        return fetch_timeframe(source, SYM, Timeframe.M15, 200, END, 40, 2.0, attempts)

    def test_timeout_is_retried_then_succeeds(self):
        src = StubSource([Timeframe.M15]); src.errors[(SYM, Timeframe.M15)] = [TimeoutError("t"), None]
        env, problem = self.call(src)
        self.assertIsNotNone(env); self.assertIsNone(problem)
        self.assertEqual(len(src.calls), 2)

    def test_timeout_retries_are_bounded(self):
        src = StubSource([Timeframe.M15]); src.errors[(SYM, Timeframe.M15)] = TimeoutError("t")
        env, problem = self.call(src, attempts=3)
        self.assertEqual((env, problem[0]), (None, FailureClass.PROVIDER_TIMEOUT))
        self.assertEqual(len(src.calls), 3)

    def test_rate_limit_and_unavailable_are_not_retried(self):
        for exc, cls in ((ProviderRateLimitedError("slow", 5), FailureClass.PROVIDER_RATE_LIMITED),
                         (DataUnavailableError("down"), FailureClass.PROVIDER_UNAVAILABLE)):
            src = StubSource([Timeframe.M15]); src.errors[(SYM, Timeframe.M15)] = exc
            _, problem = self.call(src, attempts=5)
            self.assertEqual(problem[0], cls)
            self.assertEqual(len(src.calls), 1)

    def test_exception_classification(self):
        self.assertEqual(classify_fetch_exception(ValueError("x")), FailureClass.MALFORMED_RESPONSE)
        self.assertEqual(classify_fetch_exception(ConnectionError()), FailureClass.PROVIDER_UNAVAILABLE)
        self.assertEqual(classify_fetch_exception(RuntimeError("bug")), FailureClass.INTERNAL_ERROR)


class TestTimeframes(unittest.TestCase):
    def setUp(self):
        self.cfg = ScannerConfig()

    def test_relationships_are_read_from_existing_engine_configs(self):
        self.assertEqual(horizon_timeframes(self.cfg, Horizon.INTRADAY), (Timeframe.M15, Timeframe.H1))
        self.assertEqual(horizon_timeframes(self.cfg, Horizon.SHORT_SWING), (Timeframe.H4, Timeframe.D1))
        self.assertEqual(required_timeframes(self.cfg),
                         (Timeframe.M5, Timeframe.M15, Timeframe.H1, Timeframe.H4, Timeframe.D1))

    def test_required_timeframes_follow_enabled_horizons_and_dedupe(self):
        c = ScannerConfig(horizons=(Horizon.INTRADAY,), scalp_timeframe=Timeframe.M15)
        self.assertEqual(required_timeframes(c), (Timeframe.M15, Timeframe.H1))
        c = ScannerConfig(horizons=(Horizon.SCALP, Horizon.INTRADAY), scalp_timeframe=Timeframe.M15)
        self.assertEqual(required_timeframes(c), (Timeframe.M15, Timeframe.H1))

    def test_sync_ok_and_lagging_lower_timeframe_detected(self):
        ok = {Timeframe.M15: good(), Timeframe.H1: good(Timeframe.H1)}
        self.assertIsNone(check_synchronization(ok, (Timeframe.M15, Timeframe.H1)))
        lag = {Timeframe.M15: good(end=END - timedelta(minutes=15)), Timeframe.H1: good(Timeframe.H1)}
        self.assertEqual(check_synchronization(lag, (Timeframe.M15, Timeframe.H1))[0],
                         FailureClass.UNSYNCHRONIZED_TIMEFRAMES)

    def test_plan_blocks_only_the_horizons_that_lack_data(self):
        envs = {Timeframe.M5: good(Timeframe.M5), Timeframe.M15: good(), Timeframe.H1: good(Timeframe.H1)}
        fails = {Timeframe.H4: (FailureClass.PROVIDER_UNAVAILABLE, "down"), Timeframe.D1: (FailureClass.PROVIDER_UNAVAILABLE, "down")}
        plan = plan_horizons(self.cfg, envs, fails)
        self.assertEqual(plan.runnable, (Horizon.SCALP, Horizon.INTRADAY))
        self.assertEqual([b.horizon for b in plan.blocked], [Horizon.SHORT_SWING])
        self.assertEqual(plan.blocked[0].failure_class, FailureClass.PROVIDER_UNAVAILABLE)

    def test_plan_blocks_unsynchronized_horizon(self):
        envs = {Timeframe.M15: good(end=END - timedelta(minutes=15)), Timeframe.H1: good(Timeframe.H1)}
        plan = plan_horizons(ScannerConfig(horizons=(Horizon.INTRADAY,)), envs, {})
        self.assertEqual((plan.runnable, plan.blocked[0].failure_class), ((), FailureClass.UNSYNCHRONIZED_TIMEFRAMES))


class TestConfig(unittest.TestCase):
    def test_validation(self):
        bad = [dict(horizons=()), dict(horizons=(Horizon.SCALP, Horizon.SCALP)), dict(horizons=("SCALP",)),
               dict(fetch_limit=10), dict(staleness_bars=0), dict(max_symbols_per_cycle=0),
               dict(max_fetch_attempts=0),
               dict(dedup=DedupPolicy(expiry_seconds=30), schedule=SchedulePolicy(interval_seconds=60))]
        for kw in bad:
            with self.assertRaises(ScannerConfigError, msg=str(kw)):
                ScannerConfig(**kw)
        ScannerConfig()   # defaults are valid


def R(symbol, status=SymbolScanStatus.EVALUATED, cls=None):
    return SymbolScanResult(symbol, status, cls)


def failed(symbol, cls=FailureClass.INSUFFICIENT_DATA):
    return R(symbol, SymbolScanStatus.REJECTED, cls)


HP = HealthPolicy(min_sample=5, systemic_ratio=0.8, degraded_ratio=0.3, quarantine_after=3, quarantine_seconds=900)


class TestHealth(unittest.TestCase):
    def universe(self, n_ok, n_bad, cls=FailureClass.INSUFFICIENT_DATA):
        return [R(f"OK{i}") for i in range(n_ok)] + [failed(f"BAD{i}", cls) for i in range(n_bad)]

    def test_isolated_bad_symbol_is_healthy(self):
        self.assertEqual(assess_health(self.universe(49, 1), False, HP)[0], CycleHealth.HEALTHY)
        self.assertEqual(assess_health(self.universe(49, 1, FailureClass.PROVIDER_UNAVAILABLE), False, HP)[0], CycleHealth.HEALTHY)

    def test_provider_wide_outage_is_systemic(self):
        h, why = assess_health(self.universe(0, 10, FailureClass.PROVIDER_UNAVAILABLE), False, HP)
        self.assertEqual(h, CycleHealth.SYSTEMIC_FAILURE)
        self.assertIn("attempted=10", why[-1])

    def test_partial_outage_is_degraded_not_systemic(self):
        self.assertEqual(assess_health(self.universe(6, 4, FailureClass.PROVIDER_TIMEOUT), False, HP)[0], CycleHealth.DEGRADED)

    def test_threshold_boundaries_are_inclusive(self):
        self.assertEqual(assess_health(self.universe(2, 8, FailureClass.PROVIDER_UNAVAILABLE), False, HP)[0], CycleHealth.SYSTEMIC_FAILURE)   # 0.8
        self.assertEqual(assess_health(self.universe(3, 7, FailureClass.PROVIDER_UNAVAILABLE), False, HP)[0], CycleHealth.DEGRADED)           # 0.7
        self.assertEqual(assess_health(self.universe(7, 3), False, HP)[0], CycleHealth.DEGRADED)                                             # 0.3
        self.assertEqual(assess_health(self.universe(8, 2), False, HP)[0], CycleHealth.HEALTHY)                                               # 0.2

    def test_symbol_level_data_defects_alone_do_not_look_like_a_feed_outage_unless_nothing_works(self):
        self.assertEqual(assess_health(self.universe(3, 7), False, HP)[0], CycleHealth.DEGRADED)
        self.assertEqual(assess_health(self.universe(0, 10), False, HP)[0], CycleHealth.SYSTEMIC_FAILURE)   # nothing usable at all

    def test_small_sample_never_systemic(self):
        h, why = assess_health(self.universe(0, 2, FailureClass.PROVIDER_UNAVAILABLE), False, HP)
        self.assertEqual(h, CycleHealth.DEGRADED)
        self.assertTrue(any("not declared systemic" in w for w in why))
        self.assertEqual(assess_health(self.universe(0, 2), False, HP)[0], CycleHealth.HEALTHY)

    def test_empty_universe_and_all_skipped_are_no_work(self):
        self.assertEqual(assess_health([], False, HP)[0], CycleHealth.NO_WORK)
        skipped = [R("A", SymbolScanStatus.SKIPPED_QUARANTINE), R("B", SymbolScanStatus.SKIPPED_BUDGET)]
        self.assertEqual(assess_health(skipped, False, HP)[0], CycleHealth.NO_WORK)

    def test_quarantined_symbols_do_not_dilute_or_inflate_ratios(self):
        results = self.universe(9, 1) + [R(f"Q{i}", SymbolScanStatus.SKIPPED_QUARANTINE) for i in range(50)]
        self.assertEqual(assess_health(results, False, HP)[0], CycleHealth.HEALTHY)

    def test_rate_limit_and_internal_error_force_at_least_degraded(self):
        self.assertEqual(assess_health(self.universe(9, 1), True, HP)[0], CycleHealth.DEGRADED)
        self.assertEqual(assess_health(self.universe(9, 0) + [failed("BUG", FailureClass.INTERNAL_ERROR)], False, HP)[0],
                         CycleHealth.DEGRADED)
        self.assertEqual(assess_health([R("A"), failed("B", FailureClass.INTERNAL_ERROR)], False, HP)[0], CycleHealth.DEGRADED)


class TestLedger(unittest.TestCase):
    def test_repeated_bad_symbol_gets_quarantined_then_probed(self):
        L, now = FailureLedger(), END
        for i in range(2):
            L = L.update([failed("BAD")], CycleHealth.HEALTHY, now, HP)
            self.assertFalse(L.is_quarantined("BAD", now))
        L = L.update([failed("BAD")], CycleHealth.HEALTHY, now, HP)
        self.assertTrue(L.is_quarantined("BAD", now))
        self.assertTrue(L.is_quarantined("BAD", now + timedelta(seconds=899)))
        self.assertFalse(L.is_quarantined("BAD", now + timedelta(seconds=900)))         # probe allowed
        L = L.update([failed("BAD")], CycleHealth.HEALTHY, now + timedelta(seconds=900), HP)   # probe fails: back in
        self.assertTrue(L.is_quarantined("BAD", now + timedelta(seconds=901)))

    def test_success_resets_the_counter(self):
        L = FailureLedger().update([failed("X")], CycleHealth.HEALTHY, END, HP).update([failed("X")], CycleHealth.HEALTHY, END, HP)
        L = L.update([R("X")], CycleHealth.HEALTHY, END, HP)
        self.assertIsNone(L.entry("X"))

    def test_failures_do_not_count_in_degraded_or_systemic_cycles(self):
        L = FailureLedger()
        for h in (CycleHealth.DEGRADED, CycleHealth.SYSTEMIC_FAILURE) * 5:
            L = L.update([failed("X", FailureClass.PROVIDER_UNAVAILABLE)], h, END, HP)
        self.assertIsNone(L.entry("X"))
        self.assertFalse(L.is_quarantined("X", END))

    def test_policy_validation(self):
        with self.assertRaises(ValueError):
            HealthPolicy(degraded_ratio=0.9, systemic_ratio=0.5)


class TestScheduler(unittest.TestCase):
    P = SchedulePolicy(interval_seconds=60, backoff_factor=2, max_backoff_seconds=500)

    def test_first_run_is_due_immediately(self):
        self.assertTrue(is_due(END, None, None, 0, self.P))

    def test_due_boundary_inclusive(self):
        self.assertFalse(is_due(END + timedelta(seconds=59.9), END, CycleHealth.HEALTHY, 0, self.P))
        self.assertTrue(is_due(END + timedelta(seconds=60), END, CycleHealth.HEALTHY, 0, self.P))

    def test_exponential_backoff_capped_and_recovery_resets(self):
        delays = [delay_after(CycleHealth.SYSTEMIC_FAILURE, n, self.P) for n in (1, 2, 3, 4, 10)]
        self.assertEqual(delays, [120, 240, 480, 500, 500])
        self.assertEqual(delay_after(CycleHealth.HEALTHY, 0, self.P), 60)
        self.assertEqual(delay_after(CycleHealth.DEGRADED, 3, self.P), 60)
        self.assertEqual(next_due_at(END, CycleHealth.SYSTEMIC_FAILURE, 2, END, self.P), END + timedelta(seconds=240))

    def test_clock_cannot_go_backwards_and_requires_tz(self):
        c = ManualClock(END)
        with self.assertRaises(ValueError):
            c.advance(-1)
        with self.assertRaises(ValueError):
            FixedClock(datetime(2024, 1, 1))
        with self.assertRaises(ValueError):
            c.set(END - timedelta(seconds=1))

    def test_policy_validation(self):
        with self.assertRaises(ValueError):
            SchedulePolicy(interval_seconds=0)


if __name__ == "__main__":
    unittest.main()
