import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _envelope(bars, timeframe=Timeframe.H1):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))


def _uptrend_bars(n, t0):
    bars = []
    price = 100.0
    for i in range(n):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price + 0.2))
    return bars


def _downtrend_bars(n, t0):
    bars = []
    price = 200.0
    for i in range(n):
        price -= 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price - 0.2))
    return bars


def _flat_bars(n, t0):
    return [_bar(t0 + timedelta(hours=i), 100.0, 100.5, 99.5, 100.0) for i in range(n)]


def _build_contexts(bars, timeframe=Timeframe.H1):
    env = _envelope(bars, timeframe)
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


class TestBullEngine(unittest.TestCase):
    def test_uptrend_produces_bullish_scenario(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_uptrend_bars(100, t0))
        self.assertEqual(mctx.status, ContextStatus.OK)
        self.assertEqual(qctx.status, QuantStatus.OK)
        case = build_bull_case("BTCUSDT", mctx, qctx)
        self.assertTrue(case.has_scenario)
        self.assertEqual(case.direction, DirectionBias.BULLISH)
        self.assertIn(case.structure_alignment, (AlignmentLevel.STRONG, AlignmentLevel.MODERATE))

    def test_downtrend_produces_no_bullish_scenario(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_downtrend_bars(100, t0))
        case = build_bull_case("BTCUSDT", mctx, qctx)
        self.assertFalse(case.has_scenario)
        self.assertEqual(case.structure_alignment, AlignmentLevel.NONE)

    def test_non_ok_market_context_yields_no_scenario(self):
        t0 = datetime.now(UTC)
        from omnisystem_v5.context.schema import MarketContext
        mctx = MarketContext(symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.DATA_UNAVAILABLE,
                              calculated_at=t0, provenance=None)
        from omnisystem_v5.quant.schema import QuantContext
        qctx = QuantContext(symbol="BTCUSDT", timeframe=Timeframe.H1, status=QuantStatus.DATA_UNAVAILABLE,
                             calculated_at=t0, provenance=None)
        case = build_bull_case("BTCUSDT", mctx, qctx)
        self.assertFalse(case.has_scenario)


class TestBearEngine(unittest.TestCase):
    def test_downtrend_produces_bearish_scenario(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_downtrend_bars(100, t0))
        case = build_bear_case("BTCUSDT", mctx, qctx)
        self.assertTrue(case.has_scenario)
        self.assertEqual(case.direction, DirectionBias.BEARISH)

    def test_uptrend_produces_no_bearish_scenario(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_uptrend_bars(100, t0))
        case = build_bear_case("BTCUSDT", mctx, qctx)
        self.assertFalse(case.has_scenario)


class TestBullBearIndependence(unittest.TestCase):
    def test_engines_can_both_report_no_scenario_on_flat_market(self):
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_flat_bars(100, t0))
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        self.assertFalse(bull.has_scenario)
        self.assertFalse(bear.has_scenario)

    def test_engines_disagree_on_trending_market_without_contradiction_error(self):
        """The point of independence: on a clear uptrend, Bull says yes and
        Bear says no, without either engine needing to consult the other."""
        t0 = datetime.now(UTC) - timedelta(hours=100)
        mctx, qctx = _build_contexts(_uptrend_bars(100, t0))
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        self.assertNotEqual(bull.has_scenario, bear.has_scenario)


if __name__ == "__main__":
    unittest.main()
