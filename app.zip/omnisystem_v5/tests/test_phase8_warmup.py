"""
Phase 8, Priority 2 - Short-Swing Warmup / Lookback Architecture.

Test-first: these tests encode the REAL dependency chain extracted
from context/builder.py (MarketContextConfig.min_bars_required),
quant/engine.py (QuantEngineConfig.min_bars_required), and each
horizon's execution/higher timeframe configuration - never a
hand-picked constant like 2880. If any of those engines' own defaults
change, these expected numbers are recomputed from the same formulas,
not re-guessed.
"""
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.intelligence.intraday_engine import IntradayEngineConfig
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar
from omnisystem_v5.validation.resampling import resample_bars
from omnisystem_v5.validation.warmup import (
    compute_required_lookback_bars,
    context_bar_requirement,
    intraday_warmup_requirement,
    required_base_bars_for_timeframe,
    scalp_warmup_requirement,
    short_swing_warmup_requirement,
)

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)


def _m15_bar(i, base=100.0):
    return OHLCVBar(open=base, high=base + 0.5, low=base - 0.5, close=base,
                     volume=10.0, open_time=T0 + timedelta(minutes=15 * i),
                     close_time=T0 + timedelta(minutes=15 * (i + 1)))


class TestRequiredBaseBarsForTimeframe(unittest.TestCase):
    def test_same_timeframe_no_resampling_needed(self):
        self.assertEqual(required_base_bars_for_timeframe(Timeframe.M15, Timeframe.M15, 40), 40)

    def test_m15_to_h1_includes_boundary_alignment_margin(self):
        # ratio 4: naive ratio*N=160, but a sliding window can start
        # mid-bucket, so the guaranteed-safe number is 160 + (4-1) = 163.
        self.assertEqual(required_base_bars_for_timeframe(Timeframe.M15, Timeframe.H1, 40), 163)

    def test_m15_to_h4_includes_boundary_alignment_margin(self):
        # ratio 16: 16*40 + 15 = 655
        self.assertEqual(required_base_bars_for_timeframe(Timeframe.M15, Timeframe.H4, 40), 655)

    def test_m15_to_d1_includes_boundary_alignment_margin(self):
        # ratio 96: 96*40 + 95 = 3935
        self.assertEqual(required_base_bars_for_timeframe(Timeframe.M15, Timeframe.D1, 40), 3935)

    def test_zero_target_bars_needs_zero(self):
        self.assertEqual(required_base_bars_for_timeframe(Timeframe.M15, Timeframe.D1, 0), 0)


class TestContextBarRequirement(unittest.TestCase):
    def test_uses_the_larger_of_context_and_quant_minimums(self):
        # Default MarketContextConfig.min_bars_required=30,
        # QuantEngineConfig.min_bars_required=40 -> bottleneck is 40,
        # not 30 (quant runs on the SAME bars, not a re-sliced subset).
        self.assertEqual(context_bar_requirement(MarketContextConfig(), QuantEngineConfig()), 40)

    def test_reflects_custom_config_values(self):
        mcc = MarketContextConfig(min_bars_required=100)
        qec = QuantEngineConfig(min_bars_required=25)
        self.assertEqual(context_bar_requirement(mcc, qec), 100)


class TestPerHorizonWarmupRequirement(unittest.TestCase):
    def setUp(self):
        self.mcc = MarketContextConfig()
        self.qec = QuantEngineConfig()

    def test_scalp_requirement_equals_context_bar_requirement_on_base_timeframe(self):
        self.assertEqual(scalp_warmup_requirement(Timeframe.M15, self.mcc, self.qec), 40)

    def test_intraday_requirement_driven_by_its_higher_timeframe(self):
        # default Intraday: execution=M15(==base)->40, higher=H1->163
        self.assertEqual(
            intraday_warmup_requirement(Timeframe.M15, IntradayEngineConfig(), self.mcc, self.qec), 163
        )

    def test_short_swing_requirement_driven_by_its_higher_timeframe_D1(self):
        # default Short-Swing: execution=H4->655, higher=D1->3935
        self.assertEqual(
            short_swing_warmup_requirement(Timeframe.M15, ShortSwingEngineConfig(), self.mcc, self.qec), 3935
        )

    def test_short_swing_needs_far_more_than_the_old_fixed_400_default(self):
        req = short_swing_warmup_requirement(Timeframe.M15, ShortSwingEngineConfig(), self.mcc, self.qec)
        self.assertGreater(req, 400)


class TestComputeRequiredLookbackBars(unittest.TestCase):
    def setUp(self):
        self.mcc = MarketContextConfig()
        self.qec = QuantEngineConfig()
        self.itf = IntradayEngineConfig()
        self.ssf = ShortSwingEngineConfig()

    def test_all_horizons_enabled_takes_the_max_across_all_of_them(self):
        result = compute_required_lookback_bars(
            Timeframe.M15, True, True, True, self.mcc, self.qec, self.itf, self.ssf, floor_bars=60,
        )
        self.assertEqual(result, 3935)  # Short-Swing's D1 requirement dominates

    def test_only_scalp_enabled_does_not_pay_short_swing_cost(self):
        result = compute_required_lookback_bars(
            Timeframe.M15, True, False, False, self.mcc, self.qec, self.itf, self.ssf, floor_bars=60,
        )
        self.assertEqual(result, 60)  # floor_bars dominates 40

    def test_only_short_swing_enabled_isolates_its_own_requirement(self):
        result = compute_required_lookback_bars(
            Timeframe.M15, False, False, True, self.mcc, self.qec, self.itf, self.ssf, floor_bars=60,
        )
        self.assertEqual(result, 3935)

    def test_floor_bars_is_always_respected_as_a_lower_bound(self):
        result = compute_required_lookback_bars(
            Timeframe.M15, True, False, False, self.mcc, self.qec, self.itf, self.ssf, floor_bars=999999,
        )
        self.assertEqual(result, 999999)


class TestShortSwingWarmupIsGenuinelySufficientEndToEnd(unittest.TestCase):
    """Not just a formula check: actually build the D1 MarketContext +
    QuantContext for Short-Swing from a real resampled M15 window sized
    exactly to compute_required_lookback_bars()'s answer, and prove it
    reaches OK status - i.e. the number this module computes is not
    merely a guess, it is a genuine, sufficient warmup."""

    def test_computed_lookback_is_sufficient_for_short_swing_D1_context(self):
        mcc, qec = MarketContextConfig(), QuantEngineConfig()
        req = short_swing_warmup_requirement(Timeframe.M15, ShortSwingEngineConfig(), mcc, qec)
        bars = [_m15_bar(i, base=100 + (i % 7) * 0.1) for i in range(req)]

        d1_bars = resample_bars(bars, Timeframe.M15, Timeframe.D1)
        provenance = DataProvenance(source="test", origin=DataOrigin.HISTORICAL,
                                     fetched_at=datetime.now(UTC), data_timestamp=d1_bars[-1].close_time)
        envelope = MarketDataEnvelope(market="TEST", timeframe=Timeframe.D1, provenance=provenance,
                                       quality_status=QualityStatus.OK, bars=tuple(d1_bars))
        mctx = build_market_context("TEST", envelope, mcc)
        self.assertEqual(mctx.status, ContextStatus.OK)
        qctx = build_quant_context("TEST", mctx, qec)
        self.assertEqual(qctx.status, QuantStatus.OK)

    def test_one_bar_short_of_requirement_is_insufficient_at_worst_case_alignment(self):
        # Proves the margin term is TIGHT, not an arbitrary safety
        # buffer: at the worst-case window start (one source interval
        # past a D1 calendar boundary, wasting the maximum possible
        # ratio-1 leading bars on an incomplete first bucket), `req`
        # bars are exactly enough and `req - 1` are not.
        mcc, qec = MarketContextConfig(), QuantEngineConfig()
        ssf = ShortSwingEngineConfig()
        req = short_swing_warmup_requirement(Timeframe.M15, ssf, mcc, qec)
        worst_case_start = T0 + timedelta(minutes=15)  # 1 M15 interval past the D1 boundary

        def _bars_from(start, n):
            return [OHLCVBar(open=100.0, high=100.5, low=99.5, close=100.0, volume=10.0,
                              open_time=start + timedelta(minutes=15 * i),
                              close_time=start + timedelta(minutes=15 * (i + 1))) for i in range(n)]

        sufficient = resample_bars(_bars_from(worst_case_start, req), Timeframe.M15, Timeframe.D1)
        insufficient = resample_bars(_bars_from(worst_case_start, req - 1), Timeframe.M15, Timeframe.D1)
        self.assertGreaterEqual(len(sufficient), 40)
        self.assertLess(len(insufficient), 40)


class TestMultiHorizonReplayConfigLookbackArchitecture(unittest.TestCase):
    """Priority 2, architecture-level: max_lookback_bars must not stay a
    single fixed value shared across all horizons. If the caller doesn't
    pin it explicitly, the config must auto-compute a genuinely
    sufficient window from the real per-horizon requirements above; if
    the caller DOES pin an explicit value that isn't enough for the
    horizons they enabled, construction must fail closed (raise) rather
    than silently running with starved higher-timeframe horizons."""

    def test_default_config_with_short_swing_enabled_auto_computes_sufficient_lookback(self):
        from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0)
        self.assertGreaterEqual(config.max_lookback_bars, 3935)

    def test_scalp_only_config_does_not_pay_for_short_swings_D1_requirement(self):
        from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_intraday=False, enable_short_swing=False,
        )
        self.assertLess(config.max_lookback_bars, 400)

    def test_explicit_insufficient_lookback_for_enabled_horizons_raises(self):
        from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
        with self.assertRaises(ValueError):
            MultiHorizonReplayConfig(
                symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                max_lookback_bars=400,  # old fixed default - not enough for Short-Swing's D1 leg
            )

    def test_explicit_sufficient_lookback_is_accepted_unchanged(self):
        from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            max_lookback_bars=4000,
        )
        self.assertEqual(config.max_lookback_bars, 4000)

    def test_explicit_lookback_sufficient_for_reduced_horizon_set_is_accepted(self):
        from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_intraday=False, enable_short_swing=False, max_lookback_bars=60,
        )
        self.assertEqual(config.max_lookback_bars, 60)


if __name__ == "__main__":
    unittest.main()
