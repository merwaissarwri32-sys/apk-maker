"""Phase 11 end-to-end scenarios A-N through the REAL, unmodified ScanEngine (scripted providers, SYNTHETIC data).
Each scenario checks what the scanner reports AND what Phase 11 recorded, so failures are attributable to the right layer."""
import unittest
from datetime import timedelta

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.catalog import InstrumentCatalog
from omnisystem_v5.marketdata.freshness import FreshnessState
from omnisystem_v5.marketdata.health import InstrumentState, ObsKind, ProviderObservation, ProviderState
from omnisystem_v5.marketdata.provider import RawBars
from omnisystem_v5.marketdata.source import LiveMarketDataSource
from omnisystem_v5.scanner import ScanEngine, StaticUniverse, SymbolSpec
from omnisystem_v5.scanner.enums import CycleHealth, SymbolScanStatus
from omnisystem_v5.scanner.failures import FailureClass
from omnisystem_v5.scanner.timeframes import required_timeframes
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.tests.marketdata_fixtures import (END, LONG_SEED, VENUE, Stack, crypto_instrument, raw_rows)
from omnisystem_v5.tests.scanner_fixtures import account, bars_ending_at

M5 = Timeframe.M5
BTC = "BTC/USDT"


def res(rep, symbol):
    return next(r for r in rep.results if r.symbol == symbol)


class TestScenarios(unittest.TestCase):
    def test_C_unknown_symbol_reaches_the_scanner_as_invalid_data_not_a_crash(self):
        st = Stack()
        eng = ScanEngine(st.source, StaticUniverse([SymbolSpec("NOPE/USDT"), SymbolSpec(BTC)]), st.scfg, st.clock)
        rep = eng.run_cycle(st.state, account()).report
        self.assertEqual((res(rep, "NOPE/USDT").status, res(rep, "NOPE/USDT").failure_class), (SymbolScanStatus.REJECTED, FailureClass.INVALID_DATA))
        self.assertEqual(res(rep, BTC).status, SymbolScanStatus.EVALUATED)

    def test_E_persistent_timeout_uses_exactly_the_scanners_retry_budget(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", 8)))
        first = required_timeframes(st.scfg)[0]
        st.crypto_provider.script("BTCUSDT", first, [TimeoutError(), TimeoutError()])
        rep = st.cycle()
        r = res(rep, BTC)
        self.assertEqual(r.status, SymbolScanStatus.EVALUATED)                             # scanner semantics: only the SCALP horizon is lost
        self.assertEqual(r.horizons_run, ("INTRADAY", "SHORT_SWING"))
        self.assertTrue(any(n.startswith("SCALP:PROVIDER_TIMEOUT") for n in r.notes))
        self.assertEqual(len([c for c in st.crypto_provider.calls if c.provider_symbol == "BTCUSDT" and c.timeframe == first]),
                         st.scfg.max_fetch_attempts * st.md.retry.max_attempts)            # 2 x 1: no multiplication
        self.assertEqual(res(rep, "ETH/USDT").status, SymbolScanStatus.EVALUATED)
        self.assertEqual(st.sleep.calls, [])                                               # Phase 11 added no hidden waiting

    def test_E3_timeouts_on_every_timeframe_trip_only_that_providers_breaker(self):
        """Timeouts are PROVIDER-scope faults (a timeout cannot be attributed to a symbol). Ten consecutive ones (5 timeframes x 2
        scanner attempts) cross unavailable_after=5, so the provider fails fast for its cooldown. Other providers are unaffected."""
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", 8)), forex=(("EUR", "USD"),))
        for tf in required_timeframes(st.scfg):
            st.crypto_provider.script("BTCUSDT", tf, [TimeoutError()] * 2)
        rep = st.cycle()
        self.assertEqual((res(rep, BTC).status, res(rep, BTC).failure_class), (SymbolScanStatus.REJECTED, FailureClass.PROVIDER_TIMEOUT))
        self.assertEqual(st.book.provider("cryptofeed", st.clock.now()).state, ProviderState.UNAVAILABLE)
        self.assertEqual(res(rep, "ETH/USDT").failure_class, FailureClass.PROVIDER_UNAVAILABLE)    # same provider: known, documented trade-off
        self.assertEqual(res(rep, "EUR/USD").status, SymbolScanStatus.EVALUATED)                   # different provider: untouched
        self.assertEqual(st.book.provider("fxfeed", st.clock.now()).state, ProviderState.HEALTHY)
        rep2 = st.cycle(advance=300)                                                               # cooldown over: probe, then recovery
        self.assertEqual(res(rep2, BTC).status, SymbolScanStatus.EVALUATED)

    def test_E2_a_single_timeout_is_absorbed_by_the_scanners_retry(self):
        st = Stack()
        st.crypto_provider.script("BTCUSDT", required_timeframes(st.scfg)[0], [TimeoutError()])
        self.assertEqual(res(st.cycle(), BTC).status, SymbolScanStatus.EVALUATED)

    def test_H_malformed_payload_is_classified_malformed_response(self):
        st = Stack()
        tfs = required_timeframes(st.scfg)
        st.crypto_provider.script("BTCUSDT", tfs[0], [RawBars("cryptofeed", "WRONG", raw_rows(bars_ending_at(tfs[0], 60, END)), tfs[0])])
        r = res(st.cycle(), BTC)
        self.assertEqual(r.status, SymbolScanStatus.EVALUATED)
        self.assertTrue(any(n.startswith("SCALP:MALFORMED_RESPONSE") for n in r.notes))
        h = st.book.provider("cryptofeed", END)                                                    # later successes reset the streak
        self.assertEqual((h.state, h.consecutive_failures, h.last_failure_class), (ProviderState.HEALTHY, 0, FailureClass.MALFORMED_RESPONSE))
        st2 = Stack()
        for tf in tfs:
            st2.crypto_provider.script("BTCUSDT", tf, [RawBars("cryptofeed", "WRONG", raw_rows(bars_ending_at(tf, 60, END)), tf)])
        r2 = res(st2.cycle(), BTC)
        self.assertEqual((r2.status, r2.failure_class), (SymbolScanStatus.REJECTED, FailureClass.MALFORMED_RESPONSE))

    def test_I_stale_data_is_stale_in_both_layers(self):
        st = Stack()
        st.clock.advance(5000)                                                              # provider keeps serving the old bars
        r = res(st.cycle(), BTC)
        self.assertEqual(r.status, SymbolScanStatus.EVALUATED)                              # 1h/4h/1d bars are still inside their own limits
        self.assertNotIn("SCALP", r.horizons_run)
        self.assertTrue(any(n.startswith("SCALP:STALE_DATA") for n in r.notes))
        st = Stack()
        st.clock.advance(10 * 86400)                                                        # now every required timeframe is stale
        rep = st.cycle()
        r = res(rep, BTC)
        self.assertEqual((r.status, r.failure_class), (SymbolScanStatus.REJECTED, FailureClass.STALE_DATA))
        self.assertTrue(all(s.freshness in (FreshnessState.STALE, FreshnessState.EXPIRED) for s in st.book.streams()))
        self.assertEqual(rep.emitted, ())

    def test_J_insufficient_data(self):
        st = Stack(n=30)
        r = res(st.cycle(), BTC)
        self.assertEqual((r.status, r.failure_class), (SymbolScanStatus.REJECTED, FailureClass.INSUFFICIENT_DATA))

    def test_G_provider_unavailable_then_recovery_through_the_scanner(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),))
        tfs = required_timeframes(st.scfg)
        for tf in tfs:
            st.crypto_provider.script("BTCUSDT", tf, [DataUnavailableError("down")] * 6)
        for i in range(6):
            rep = st.cycle(advance=1 if i else 0)
            if rep.universe_size == 0:
                break
        self.assertEqual(st.book.provider("cryptofeed", st.clock.now()).state, ProviderState.UNAVAILABLE)
        rep = st.cycle(advance=1)
        self.assertEqual(rep.universe_size, 0)                                              # nothing is scanned while it cools down
        for tf in tfs:
            st.crypto_provider.script("BTCUSDT", tf, [])
        for _ in range(4):
            rep = st.cycle(advance=300)
        self.assertEqual(st.book.provider("cryptofeed", st.clock.now()).state, ProviderState.HEALTHY)
        self.assertEqual(res(rep, BTC).status, SymbolScanStatus.EVALUATED)


class TestSourceResolution(unittest.TestCase):
    def test_unmapped_provider_symbol(self):
        st = Stack()
        cat = InstrumentCatalog([*st.catalog.listings_for(BTC), Listing(crypto_instrument("XRP"), VENUE)])
        src = LiveMarketDataSource(st.md, cat, st.router, st.book, st.clock, st.sink)
        env = src.get_market_data("XRP/USDT", M5, 200)
        self.assertEqual((env.quality_status, env.bars), (QualityStatus.INVALID, ()))
        self.assertIn("data.unmapped_instrument", env.reasons[0])
        self.assertEqual(st.crypto_provider.calls, [])
        self.assertEqual(st.book.provider("cryptofeed", END).state, ProviderState.HEALTHY)   # an instrument defect, not a provider fault

    def test_degraded_provider_data_is_delivered_but_marked_degraded(self):
        st = Stack()
        for _ in range(2):
            st.book.observe_provider("cryptofeed", ProviderObservation(ObsKind.FAILURE, FailureClass.PROVIDER_TIMEOUT), END)
        env = st.source.get_market_data(BTC, M5, 200)
        self.assertEqual(env.quality_status, QualityStatus.OK)
        s = st.book.streams()[0]
        self.assertEqual((s.freshness, s.provider_state), (FreshnessState.DEGRADED, "DEGRADED"))
        self.assertEqual(st.book.provider("cryptofeed", END).state, ProviderState.RECOVERING)   # the success started recovery

    def test_origin_follows_the_adapter_declaration_never_the_source(self):
        for origin in (DataOrigin.HISTORICAL, DataOrigin.SIMULATED):
            st = Stack(origin=origin)
            self.assertEqual(st.source.get_market_data(BTC, M5, 200).provenance.origin, origin)

    def test_timestamps_come_only_from_the_injected_clock(self):
        a, b = Stack(), Stack()
        a.clock.advance(120)
        b.clock.advance(120)
        ea, eb = a.source.get_market_data(BTC, M5, 200), b.source.get_market_data(BTC, M5, 200)
        self.assertEqual(ea.provenance.fetched_at, END + timedelta(seconds=120))
        self.assertEqual(ea, eb)
        self.assertEqual(a.book.streams()[0].evaluated_at, END + timedelta(seconds=120))


if __name__ == "__main__":
    unittest.main()
