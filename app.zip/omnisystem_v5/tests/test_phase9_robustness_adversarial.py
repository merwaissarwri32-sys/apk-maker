"""
Phase 9 - Robustness layer (validation/robustness.py) and additive
adversarial-validation enhancements.

Same policy as test_phase9_walk_forward_robust_validation.py: real
engines, SYNTHETIC fixtures, no vacuous passes, wall-clock ids excluded
from cross-run comparison. Scenario/stress results describe pipeline
behaviour on synthetic inputs - never market evidence.
"""
import unittest
from dataclasses import replace
from functools import lru_cache
from unittest.mock import patch

from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.tests.phase9_fixtures import (
    closed_trades, flat_bars, loose_risk_policy, oscillating_bars, scalp_template,
    with_duplicate_timestamp, with_removed_bars, scaled_volatility, wf_config,
)
from omnisystem_v5.validation.adversarial_validation import (
    check_look_ahead_leakage, check_structural_robustness, check_walk_forward_future_mutation,
    check_window_robustness,
)
from omnisystem_v5.validation.contracts import BacktestResult
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig, run_multi_horizon_replay
from omnisystem_v5.validation.robustness import (
    ROBUSTNESS_LIMITATIONS, RejectedVariant, RobustnessScenario, ScenarioKind, ScenarioOutcome,
    ScenarioStatus, compare_outcomes, generate_horizon_variants, generate_window_variants,
    run_robustness_suite,
)
from omnisystem_v5.validation.walk_forward_runner import (
    FoldResult, WalkForwardMode, build_fold_audit, run_walk_forward,
)

BARS = oscillating_bars(700, seed=1)  # SYNTHETIC


def _outcome(label="x", **kw):
    base = dict(label=label, kind=ScenarioKind.WINDOW, evidence_class="BASE_DATASET", mode="ROLLING",
                train_bars=100, test_bars=100, step_bars=100, horizons_enabled=("SCALP",),
                status=ScenarioStatus.COMPLETED, fold_count=6, valid_fold_count=6, blocked_fold_count=0,
                empty_fold_count=0, closed_trade_count=10, total_pnl=100.0, win_rate=0.5,
                profitable_fold_ratio=0.5, fold_pnls=(), trades_by_horizon={}, warning_issue_counts={},
                forced_close_trade_count=0, dataset_hash="h")
    base.update(kw)
    return ScenarioOutcome(**base)


class TestCompareOutcomes(unittest.TestCase):
    def test_hand_computed_delta_relative_change_and_sign_flip(self):
        b = _outcome("b", kind=ScenarioKind.BASELINE, total_pnl=100.0)
        c = compare_outcomes(b, _outcome("v", total_pnl=40.0, closed_trade_count=7))
        self.assertEqual((c.pnl_delta, c.closed_trade_delta, c.pnl_sign_flipped), (-60.0, -3, False))
        self.assertAlmostEqual(c.pnl_relative_change, -0.6)
        self.assertTrue(compare_outcomes(b, _outcome("v", total_pnl=-20.0)).pnl_sign_flipped)

    def test_undefined_comparisons_are_none_never_fabricated(self):
        zero = compare_outcomes(_outcome("b", total_pnl=0.0), _outcome("v", total_pnl=50.0))
        self.assertIsNone(zero.pnl_relative_change)
        self.assertIsNone(zero.pnl_sign_flipped)
        none_base = compare_outcomes(_outcome("b", total_pnl=None), _outcome("v", total_pnl=50.0))
        self.assertEqual((none_base.pnl_delta, none_base.pnl_relative_change, none_base.pnl_sign_flipped),
                         (None, None, None))


class TestScenarioContract(unittest.TestCase):
    def test_bars_override_requires_an_explicit_evidence_class(self):
        with self.assertRaises(ValueError):
            RobustnessScenario("s", ScenarioKind.STRESS_FIXTURE, wf_config(), bars=tuple(BARS))
        s = RobustnessScenario("s", ScenarioKind.STRESS_FIXTURE, wf_config(), bars=tuple(BARS),
                               evidence_class="SYNTHETIC_STRESS_FIXTURE")
        self.assertEqual(s.evidence_class, "SYNTHETIC_STRESS_FIXTURE")

    def test_empty_label_rejected(self):
        with self.assertRaises(ValueError):
            RobustnessScenario("", ScenarioKind.WINDOW, wf_config())

    def test_suite_requires_a_baseline_and_unique_labels(self):
        base = RobustnessScenario("b", ScenarioKind.BASELINE, wf_config())
        with self.assertRaises(ValueError):
            run_robustness_suite(BARS, RobustnessScenario("b", ScenarioKind.WINDOW, wf_config()), ())
        with self.assertRaises(ValueError):
            run_robustness_suite(BARS, base, (RobustnessScenario("b", ScenarioKind.WINDOW, wf_config()),))
        with self.assertRaises(ValueError):
            run_robustness_suite(BARS, base, (RobustnessScenario("v", ScenarioKind.BASELINE, wf_config()),))


@lru_cache(maxsize=None)
def _window_report():
    base = wf_config(train=100, test=100)
    scenarios, rejected = generate_window_variants(base, train_options=(80, 100), test_options=(50, 100),
                                                   step_options=(50, 100))
    baseline = RobustnessScenario("baseline", ScenarioKind.BASELINE, base)
    return scenarios, rejected, run_robustness_suite(BARS, baseline, scenarios, rejected_variants=rejected,
                                                      flag_relative_change_threshold=0.05)


class TestWindowStepProportionRobustness(unittest.TestCase):
    def test_generator_records_invalid_variants_instead_of_silently_dropping_them(self):
        scenarios, rejected, _ = _window_report()
        self.assertEqual(len(scenarios) + len(rejected), 2 * 2 * 2 - 1)            # every combo except the baseline
        self.assertEqual(len(rejected), 2)                                          # (train 80|100, test 100, step 50)
        self.assertTrue(all(isinstance(r, RejectedVariant) and "overlap" in r.reason.lower() for r in rejected))
        labels = [s.label for s in scenarios] + [r.label for r in rejected]
        self.assertEqual(len(labels), len(set(labels)))

    def test_suite_outcomes_match_independent_walk_forward_runs_and_show_measurable_change(self):
        scenarios, rejected, report = _window_report()
        self.assertGreaterEqual(report.baseline.closed_trade_count, 3)              # real baseline trades
        self.assertEqual(report.baseline.status, ScenarioStatus.COMPLETED)
        self.assertEqual(len(report.outcomes), len(scenarios))
        self.assertEqual(report.rejected_variants, rejected)
        for scen, out in zip(scenarios, report.outcomes):
            self.assertEqual(out.label, scen.label)
            direct = run_walk_forward(BARS, scen.run_config)
            self.assertEqual(out.fold_count, direct.aggregate.fold_count)
            self.assertEqual(out.closed_trade_count, direct.aggregate.total_closed_trades)
            self.assertAlmostEqual(out.total_pnl, direct.aggregate.total_pnl)
        self.assertTrue(any(c.pnl_delta != 0 or c.closed_trade_delta != 0 for c in report.comparisons))

    def test_flags_follow_the_stated_rule_exactly(self):
        _, _, report = _window_report()
        expected = []
        for c in report.comparisons:
            if c.pnl_sign_flipped:
                expected.append((c.label, "PNL_SIGN_FLIPPED"))
            elif c.pnl_relative_change is not None and abs(c.pnl_relative_change) > report.flag_relative_change_threshold:
                expected.append((c.label, "RELATIVE_PNL_CHANGE_EXCEEDS_THRESHOLD"))
        self.assertEqual(list(report.flagged), expected)
        self.assertGreaterEqual(len(report.flagged), 1)                             # threshold 0.05 really flags something
        self.assertEqual(report.sign_flip_count, sum(1 for c in report.comparisons if c.pnl_sign_flipped))

    def test_baseline_is_preserved_and_unflagged_variants_are_not_removed(self):
        _, _, report = _window_report()
        self.assertEqual(report.baseline.kind, ScenarioKind.BASELINE)
        self.assertEqual(len(report.comparisons), len(report.outcomes))

    def test_repeat_suite_run_is_deterministic(self):
        base = wf_config()
        scen = (RobustnessScenario("v", ScenarioKind.WINDOW, wf_config(train=80, test=100)),)
        baseline = RobustnessScenario("b", ScenarioKind.BASELINE, base)
        a = run_robustness_suite(BARS, baseline, scen)
        b = run_robustness_suite(BARS, baseline, scen)
        self.assertGreaterEqual(a.baseline.closed_trade_count, 3)
        self.assertEqual(a, b)

    def test_report_states_its_limitations(self):
        _, _, report = _window_report()
        self.assertEqual(report.limitations, ROBUSTNESS_LIMITATIONS)
        self.assertIn("not market evidence", " ".join(ROBUSTNESS_LIMITATIONS).lower())


def _two_horizon_template():
    return MultiHorizonReplayConfig(symbol="X", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                    enable_scalp=True, enable_intraday=True, enable_short_swing=False,
                                    risk_policy=loose_risk_policy())


class TestHorizonRobustness(unittest.TestCase):
    def test_horizon_variants_isolate_each_horizon_using_real_engines(self):
        template = _two_horizon_template()
        L = template.max_lookback_bars
        data = oscillating_bars(L + 300, seed=1)
        base = wf_config(train=L, test=100, template=template)
        scenarios, rejected = generate_horizon_variants(base)
        self.assertEqual(rejected, ())
        self.assertEqual(sorted(s.label for s in scenarios), ["horizons=INTRADAY", "horizons=SCALP"])
        report = run_robustness_suite(data, RobustnessScenario("baseline", ScenarioKind.BASELINE, base), scenarios)
        self.assertEqual(set(report.baseline.trades_by_horizon), {"SCALP", "INTRADAY"})  # both really fired
        self.assertGreaterEqual(report.baseline.closed_trade_count, 3)
        by_label = {o.label: o for o in report.outcomes}
        self.assertEqual(set(by_label["horizons=SCALP"].trades_by_horizon), {"SCALP"})
        self.assertEqual(set(by_label["horizons=INTRADAY"].trades_by_horizon), {"INTRADAY"})
        self.assertEqual(by_label["horizons=SCALP"].horizons_enabled, ("SCALP",))
        self.assertGreaterEqual(by_label["horizons=SCALP"].closed_trade_count, 1)
        self.assertGreaterEqual(by_label["horizons=INTRADAY"].closed_trade_count, 1)

    def test_single_horizon_base_has_no_proper_subsets_and_says_so(self):
        scenarios, rejected = generate_horizon_variants(wf_config())
        self.assertEqual((scenarios, rejected), ((), ()))


class TestConfigurationVariants(unittest.TestCase):
    def test_reward_risk_variant_changes_real_outcomes_and_is_compared_to_baseline(self):
        base = wf_config()
        variant = wf_config(template=scalp_template(risk_policy=loose_risk_policy(min_reward_risk_ratio=3.0)))
        report = run_robustness_suite(
            BARS, RobustnessScenario("baseline", ScenarioKind.BASELINE, base),
            (RobustnessScenario("min_rr=3.0", ScenarioKind.CONFIG_VARIANT, variant),))
        self.assertGreaterEqual(report.baseline.closed_trade_count, 3)
        self.assertGreaterEqual(report.outcomes[0].closed_trade_count, 3)
        self.assertNotEqual(report.comparisons[0].closed_trade_delta, 0)             # measurable, real change


class TestStressFixtureScenarios(unittest.TestCase):
    def test_stress_scenarios_are_labelled_synthetic_and_behave_fail_closed(self):
        vol = RobustnessScenario("vol x3", ScenarioKind.STRESS_FIXTURE, wf_config(),
                                 bars=tuple(scaled_volatility(BARS, 3.0)), evidence_class="SYNTHETIC_STRESS_FIXTURE")
        dup = RobustnessScenario("dup ts", ScenarioKind.STRESS_FIXTURE, wf_config(),
                                 bars=tuple(with_duplicate_timestamp(BARS, 250)),
                                 evidence_class="SYNTHETIC_STRESS_FIXTURE")
        gap = RobustnessScenario("gap", ScenarioKind.STRESS_FIXTURE, wf_config(),
                                 bars=tuple(with_removed_bars(BARS, range(250, 255))),
                                 evidence_class="SYNTHETIC_STRESS_FIXTURE")
        report = run_robustness_suite(BARS, RobustnessScenario("baseline", ScenarioKind.BASELINE, wf_config()),
                                      (vol, dup, gap))
        v, d, g = report.outcomes
        self.assertGreaterEqual(report.baseline.closed_trade_count, 3)
        self.assertTrue(all(o.evidence_class == "SYNTHETIC_STRESS_FIXTURE" for o in (v, d, g)))
        self.assertEqual(report.baseline.evidence_class, "BASE_DATASET")
        self.assertNotEqual(report.comparisons[0].pnl_delta, 0)                      # volatility stress really moved results
        self.assertEqual((d.blocked_fold_count, d.status), (2, ScenarioStatus.COMPLETED))
        self.assertEqual(g.blocked_fold_count, 0)                                    # gap: non-blocking by contract
        self.assertGreaterEqual(g.warning_issue_counts.get("ABNORMAL_GAP", 0), 1)

    def test_all_folds_blocked_is_reported_with_undefined_metrics(self):
        cfg = wf_config(mode=WalkForwardMode.EXPANDING)
        early_dup = RobustnessScenario("early dup", ScenarioKind.STRESS_FIXTURE, cfg,
                                       bars=tuple(with_duplicate_timestamp(BARS, 5)),
                                       evidence_class="SYNTHETIC_STRESS_FIXTURE")
        report = run_robustness_suite(BARS, RobustnessScenario("baseline", ScenarioKind.BASELINE, cfg), (early_dup,))
        out = report.outcomes[0]
        self.assertEqual(out.status, ScenarioStatus.ALL_FOLDS_BLOCKED)
        self.assertEqual((out.valid_fold_count, out.blocked_fold_count), (0, out.fold_count))
        self.assertGreater(out.fold_count, 0)
        self.assertIsNone(out.total_pnl)
        self.assertIsNone(report.comparisons[0].pnl_delta)
        self.assertGreaterEqual(report.baseline.closed_trade_count, 3)

    def test_internal_exception_inside_a_scenario_propagates(self):
        base = RobustnessScenario("baseline", ScenarioKind.BASELINE, wf_config())
        with patch("omnisystem_v5.validation.walk_forward_runner.run_multi_horizon_replay",
                   side_effect=RuntimeError("boom")) as stub:
            with self.assertRaises(RuntimeError):
                run_robustness_suite(BARS, base, ())
        self.assertGreaterEqual(stub.call_count, 1)


class TestLookAheadLeakageCheckOnRealEngines(unittest.TestCase):
    def test_zero_trade_comparison_is_flagged_vacuous_not_a_clean_pass(self):
        data = flat_bars(160)
        r = check_look_ahead_leakage(data[:120], scalp_template(), end_index=119, extra_future_bars=tuple(data[120:]),
                                     exclude_wall_clock_ids=True)
        self.assertEqual(len(run_multi_horizon_replay(data[:120], replace(scalp_template(), end_index=119)).trades), 0)
        self.assertTrue(r.vacuous)
        self.assertEqual(r.checked_trade_count, 0)

    def test_real_engine_clean_result_is_non_vacuous_when_wall_clock_ids_are_excluded(self):
        r = check_look_ahead_leakage(BARS[:400], scalp_template(), end_index=399,
                                     extra_future_bars=tuple(BARS[400:500]), exclude_wall_clock_ids=True)
        self.assertGreaterEqual(r.checked_trade_count, 3)
        self.assertFalse(r.vacuous)
        self.assertFalse(r.leak_detected)
        self.assertEqual(set(r.excluded_fields), {"candidate_id", "decision_id"})

    def test_default_behaviour_is_unchanged_and_flags_wall_clock_ids_on_real_engines(self):
        # Reproduces the pre-existing Phase 8 behaviour that motivated the flag: with real engines
        # candidate_id/decision_id embed the wall clock, so comparing them reports a false positive.
        r = check_look_ahead_leakage(BARS[:400], scalp_template(), end_index=399, extra_future_bars=tuple(BARS[400:500]))
        self.assertGreaterEqual(r.checked_trade_count, 3)
        self.assertTrue(r.leak_detected)
        self.assertEqual(r.excluded_fields, ())


class TestWindowRobustnessSeesBlockedFolds(unittest.TestCase):
    def test_blocked_folds_are_visible_not_disguised_as_zero_pnl_folds(self):
        result = run_walk_forward(with_duplicate_timestamp(BARS, 250), wf_config())
        self.assertGreaterEqual(sum(len(closed_trades(fr.backtest.trades)) for fr in result.fold_results), 3)
        r = check_window_robustness(result)
        self.assertEqual(r.per_fold_valid, (True, False, False, True, True, True))
        self.assertEqual(r.blocked_fold_count, 2)


class TestWalkForwardFutureMutationCheck(unittest.TestCase):
    def test_clean_pipeline_is_reported_clean_and_non_vacuous(self):
        r = check_walk_forward_future_mutation(BARS, wf_config(), 400, lambda tail: scaled_volatility(tail, 3.0))
        self.assertFalse(r.leak_detected)
        self.assertFalse(r.vacuous)
        self.assertGreaterEqual(r.compared_closed_trade_count, 3)
        self.assertGreaterEqual(r.mutated_fold_changed_count, 1)
        self.assertEqual(r.differing_fold_indices, ())

    def test_a_mutation_that_changes_nothing_is_flagged_vacuous(self):
        r = check_walk_forward_future_mutation(BARS, wf_config(), 400, lambda tail: list(tail))
        self.assertFalse(r.leak_detected)
        self.assertTrue(r.vacuous)
        self.assertEqual(r.mutated_fold_changed_count, 0)

    def test_engineered_leak_is_detected(self):
        import omnisystem_v5.validation.walk_forward_runner as wfr

        def leaky_single_fold(bars, fold, config):
            bars_slice = bars[fold.warmup_start_index:]                          # LEAK: everything after test_end
            local_start = fold.test_start_index - fold.warmup_start_index
            local_end = fold.test_end_index - fold.warmup_start_index
            fold_config = replace(config.replay_config_template, start_index=local_start, end_index=local_end)
            backtest = wfr.run_multi_horizon_replay(bars_slice, fold_config, run_id=f"leaky-{fold.fold_index}")
            return FoldResult(fold=fold, backtest=backtest, audit=build_fold_audit(fold, backtest))

        with patch.object(wfr, "_run_single_fold", side_effect=leaky_single_fold) as stub:
            r = check_walk_forward_future_mutation(BARS, wf_config(), 400,
                                                   lambda tail: with_duplicate_timestamp(tail, 10))
        self.assertGreaterEqual(stub.call_count, 1)                              # the leaky stub really ran
        self.assertTrue(r.leak_detected)
        self.assertGreaterEqual(len(r.differing_fold_indices), 1)


class TestAdversarialStructuralCases(unittest.TestCase):
    def test_insufficient_warmup_is_observable_and_deterministic(self):
        bt = run_multi_horizon_replay(BARS[:30], scalp_template())
        self.assertFalse(bt.data_quality.warmup_sufficient)
        self.assertEqual(len(bt.trades), 0)
        again = run_multi_horizon_replay(BARS[:30], scalp_template())
        self.assertEqual(bt.data_quality, again.data_quality)

    def test_unexpected_internal_exception_is_recorded_with_type_and_never_silent(self):
        with patch("omnisystem_v5.validation.adversarial_validation.run_multi_horizon_replay",
                   side_effect=RuntimeError("engine exploded")) as stub:
            r = check_structural_robustness(scalp_template(), [("case", BARS[:100])])
        self.assertEqual(stub.call_count, 1)
        self.assertFalse(r.all_cases_handled_without_unhandled_crash)
        self.assertEqual(r.case_results[0].raised_exception_type, "RuntimeError")
        self.assertIn("engine exploded", r.case_results[0].raised_exception_message)

    def test_duplicate_and_out_of_order_inputs_are_blocked_not_crashed(self):
        from omnisystem_v5.tests.phase9_fixtures import with_swapped_adjacent
        r = check_structural_robustness(scalp_template(), [
            ("dup", with_duplicate_timestamp(BARS[:200], 100)),
            ("swap", with_swapped_adjacent(BARS[:200], 100)),
        ])
        self.assertTrue(r.all_cases_handled_without_unhandled_crash)
        self.assertEqual([c.data_quality_blocked for c in r.case_results], [True, True])
        self.assertEqual([c.trade_count for c in r.case_results], [0, 0])


if __name__ == "__main__":
    unittest.main()
