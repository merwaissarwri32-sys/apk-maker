"""Shared fixtures for the Phase 10 scanner tests.

EVIDENCE CLASS: every bar series here is SYNTHETIC. It exercises the real,
unmocked context/quant/engine/decision/risk pipeline; it is not market evidence.
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone

from omnisystem_v5.risk.contracts import AccountState, RiskPolicy
from omnisystem_v5.scanner.failures import ProviderRateLimitedError
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar
from omnisystem_v5.validation.resampling import seconds_for_timeframe

UTC = timezone.utc
END = datetime(2024, 3, 1, 0, 0, tzinfo=UTC)        # aligned to every timeframe boundary up to D1
FIXTURE_EVIDENCE_CLASS = "SYNTHETIC_FIXTURE"


def account():
    return AccountState(equity=10000.0)


def loose_risk_policy():
    return RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50, max_exposure_pct=100000,
                      max_total_open_risk_pct=100)


def bars_ending_at(tf, n, end, seed=1, amp=3.0, period=40, drift=0.02, noise=0.4):
    """Deterministic drifting sine + seeded noise; the last bar CLOSES exactly at `end`."""
    step = timedelta(seconds=seconds_for_timeframe(tf))
    rnd = random.Random(seed)
    out, prev = [], 100.0
    for i in range(n):
        c = 100 + drift * i + amp * math.sin(2 * math.pi * i / period) + rnd.uniform(-noise, noise)
        o, h_pad, l_pad, vol = prev, abs(rnd.uniform(0, 0.3)), abs(rnd.uniform(0, 0.3)), 100 + rnd.random() * 10
        close_time = end - step * (n - 1 - i)
        out.append(OHLCVBar(o, max(o, c) + h_pad, min(o, c) - l_pad, c, vol, close_time - step, close_time))
        prev = c
    return tuple(out)


def envelope(symbol, tf, bars, origin=DataOrigin.HISTORICAL, status=QualityStatus.OK, reasons=()):
    last = bars[-1].close_time if bars else END
    prov = DataProvenance("fixture", origin, last, last)
    return MarketDataEnvelope(symbol, tf, prov, status, tuple(bars), tuple(reasons))


class StubSource:
    """Serves synthetic envelopes; failures can be injected per (symbol, tf) or per symbol."""

    def __init__(self, tfs, n=220, end=END, seed_for=lambda s: 1, amp=3.0):
        self.tfs, self.n, self.end, self.seed_for, self.amp = tfs, n, end, seed_for, amp
        self.overrides, self.errors, self.calls = {}, {}, []

    def get_market_data(self, market, timeframe, limit=200):
        self.calls.append((market, timeframe))
        err = self.errors.get((market, timeframe)) or self.errors.get(market)
        if err is not None:
            if isinstance(err, list):                     # sequence of outcomes, consumed per call
                item = err.pop(0) if err else None
                if isinstance(item, Exception):
                    raise item
                if item is None:
                    return self._default(market, timeframe)
                return item
            raise err
        if (market, timeframe) in self.overrides:
            return self.overrides[(market, timeframe)]
        return self._default(market, timeframe)

    def _default(self, market, timeframe):
        bars = bars_ending_at(timeframe, self.n, self.end, seed=self.seed_for(market), amp=self.amp)
        return envelope(market, timeframe, bars)
