import unittest

from omnisystem_v5.risk.contracts import AccountState, RiskPolicy
from omnisystem_v5.risk.enums import RejectionReasonCode, WarningCode
from omnisystem_v5.risk.validators import validate_account_limits


class TestMaxRiskPerTrade(unittest.TestCase):
    def test_within_limit_passes(self):
        out = validate_account_limits(risk_amount=90, notional=1000, policy=RiskPolicy(max_risk_per_trade_pct=1.0),
                                       account=AccountState(equity=10000))
        self.assertTrue(out.ok)

    def test_exceeding_limit_rejected(self):
        out = validate_account_limits(risk_amount=150, notional=1000, policy=RiskPolicy(max_risk_per_trade_pct=1.0),
                                       account=AccountState(equity=10000))
        self.assertIn(RejectionReasonCode.MAX_RISK_PER_TRADE_EXCEEDED, out.rejections)

    def test_exactly_at_limit_passes(self):
        out = validate_account_limits(risk_amount=100, notional=1000, policy=RiskPolicy(max_risk_per_trade_pct=1.0),
                                       account=AccountState(equity=10000))
        self.assertTrue(out.ok)


class TestMaxTotalOpenRisk(unittest.TestCase):
    def test_existing_open_risk_included_in_check(self):
        policy = RiskPolicy(max_risk_per_trade_pct=10.0, max_total_open_risk_pct=5.0, max_exposure_pct=100.0)
        account = AccountState(equity=10000, existing_open_risk_amount=400)  # 4% already open
        out = validate_account_limits(risk_amount=200, notional=1000, policy=policy, account=account)  # +2% -> 6% total
        self.assertIn(RejectionReasonCode.MAX_TOTAL_OPEN_RISK_EXCEEDED, out.rejections)

    def test_near_limit_warns(self):
        policy = RiskPolicy(max_risk_per_trade_pct=10.0, max_total_open_risk_pct=5.0, max_exposure_pct=100.0)
        account = AccountState(equity=10000, existing_open_risk_amount=400)
        out = validate_account_limits(risk_amount=60, notional=1000, policy=policy, account=account)  # 4.6% -> within 10% of 5%
        self.assertTrue(out.ok)
        self.assertIn(WarningCode.OPEN_RISK_NEAR_LIMIT, out.warnings)


class TestMaxExposure(unittest.TestCase):
    def test_existing_exposure_included_in_check(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=20.0)
        account = AccountState(equity=10000, existing_exposure_amount=1500)  # 15%
        out = validate_account_limits(risk_amount=10, notional=1000, policy=policy, account=account)  # +10% -> 25%
        self.assertIn(RejectionReasonCode.MAX_EXPOSURE_EXCEEDED, out.rejections)

    def test_exposure_within_limit_passes(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=20.0)
        account = AccountState(equity=10000)
        out = validate_account_limits(risk_amount=10, notional=1000, policy=policy, account=account)  # 10%
        self.assertTrue(out.ok)


class TestMaxConcurrentRisk(unittest.TestCase):
    def test_concurrent_limit_enforced(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             max_concurrent_risk_count=3)
        account = AccountState(equity=10000, existing_open_positions_count=3)
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertIn(RejectionReasonCode.MAX_CONCURRENT_RISK_EXCEEDED, out.rejections)

    def test_concurrent_limit_not_yet_reached_passes(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             max_concurrent_risk_count=3)
        account = AccountState(equity=10000, existing_open_positions_count=2)
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertTrue(out.ok)

    def test_none_means_unlimited(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             max_concurrent_risk_count=None)
        account = AccountState(equity=10000, existing_open_positions_count=999)
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertTrue(out.ok)


class TestDailyLossLimit(unittest.TestCase):
    def test_daily_loss_limit_triggers_block(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             daily_loss_limit_pct=3.0)
        account = AccountState(equity=10000, daily_loss_amount=350)  # 3.5% already lost today
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertIn(RejectionReasonCode.DAILY_LOSS_LIMIT_EXCEEDED, out.rejections)

    def test_daily_loss_under_limit_passes(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             daily_loss_limit_pct=3.0)
        account = AccountState(equity=10000, daily_loss_amount=100)  # 1%
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertTrue(out.ok)

    def test_none_disables_daily_loss_check(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             daily_loss_limit_pct=None)
        account = AccountState(equity=10000, daily_loss_amount=9000)  # 90% lost, but check disabled
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertTrue(out.ok)


class TestConsecutiveLossGuard(unittest.TestCase):
    def test_guard_triggers_block(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             consecutive_loss_guard=3)
        account = AccountState(equity=10000, consecutive_losses=3)
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertIn(RejectionReasonCode.CONSECUTIVE_LOSS_GUARD_TRIGGERED, out.rejections)

    def test_below_guard_threshold_passes(self):
        policy = RiskPolicy(max_risk_per_trade_pct=100.0, max_total_open_risk_pct=100.0, max_exposure_pct=100.0,
                             consecutive_loss_guard=3)
        account = AccountState(equity=10000, consecutive_losses=2)
        out = validate_account_limits(risk_amount=10, notional=100, policy=policy, account=account)
        self.assertTrue(out.ok)


class TestMultipleLimitsSimultaneously(unittest.TestCase):
    def test_all_violated_limits_are_reported_together(self):
        """Unlike the stage-level short-circuit in engine.py, this single
        function call should surface every violated account-level limit
        at once — useful for a caller inspecting why a candidate failed."""
        policy = RiskPolicy(max_risk_per_trade_pct=0.01, max_total_open_risk_pct=0.01, max_exposure_pct=0.01,
                             max_concurrent_risk_count=0, daily_loss_limit_pct=0.001, consecutive_loss_guard=0)
        account = AccountState(equity=10000, existing_open_positions_count=0, daily_loss_amount=100, consecutive_losses=1)
        out = validate_account_limits(risk_amount=100, notional=1000, policy=policy, account=account)
        self.assertGreaterEqual(len(out.rejections), 4)


if __name__ == "__main__":
    unittest.main()
