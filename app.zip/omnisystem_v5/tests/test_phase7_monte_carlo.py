import unittest

from omnisystem_v5.validation.monte_carlo import (
    MonteCarloConfig,
    MonteCarloMethod,
    MonteCarloResult,
    MonteCarloSampler,
    make_seeded_rng,
)


class TestMonteCarloConfig(unittest.TestCase):
    def test_valid_config_constructs(self):
        config = MonteCarloConfig(method=MonteCarloMethod.TRADE_ORDER_SHUFFLE, num_simulations=100, random_seed=42)
        self.assertEqual(config.random_seed, 42)

    def test_zero_simulations_rejected(self):
        with self.assertRaises(ValueError):
            MonteCarloConfig(method=MonteCarloMethod.BOOTSTRAP_RESAMPLE, num_simulations=0, random_seed=1)

    def test_negative_simulations_rejected(self):
        with self.assertRaises(ValueError):
            MonteCarloConfig(method=MonteCarloMethod.BOOTSTRAP_RESAMPLE, num_simulations=-5, random_seed=1)

    def test_non_int_seed_rejected(self):
        with self.assertRaises(ValueError):
            MonteCarloConfig(method=MonteCarloMethod.SLIPPAGE_STRESS, num_simulations=10, random_seed=3.14)

    def test_seed_is_mandatory_positional_or_keyword(self):
        with self.assertRaises(TypeError):
            MonteCarloConfig(method=MonteCarloMethod.FEE_STRESS, num_simulations=10)

    def test_all_methods_are_valid_enum_values(self):
        for method in MonteCarloMethod:
            config = MonteCarloConfig(method=method, num_simulations=1, random_seed=0)
            self.assertEqual(config.method, method)


class TestSeededRngDeterminism(unittest.TestCase):
    def test_same_seed_produces_same_sequence(self):
        rng1 = make_seeded_rng(42)
        rng2 = make_seeded_rng(42)
        seq1 = [rng1.random() for _ in range(10)]
        seq2 = [rng2.random() for _ in range(10)]
        self.assertEqual(seq1, seq2)

    def test_different_seeds_produce_different_sequences(self):
        rng1 = make_seeded_rng(1)
        rng2 = make_seeded_rng(2)
        seq1 = [rng1.random() for _ in range(10)]
        seq2 = [rng2.random() for _ in range(10)]
        self.assertNotEqual(seq1, seq2)

    def test_independent_of_global_random_module_state(self):
        import random
        random.seed(999)
        random.random()
        random.random()
        rng1 = make_seeded_rng(7)
        seq1 = [rng1.random() for _ in range(5)]

        random.seed(111)
        random.random()
        rng2 = make_seeded_rng(7)
        seq2 = [rng2.random() for _ in range(5)]

        self.assertEqual(seq1, seq2)


class TestMonteCarloResultIsHonestlyUnimplemented(unittest.TestCase):
    def test_implemented_flag_defaults_false(self):
        config = MonteCarloConfig(method=MonteCarloMethod.TRADE_ORDER_SHUFFLE, num_simulations=10, random_seed=1)
        result = MonteCarloResult(config=config)
        self.assertFalse(result.implemented)
        self.assertEqual(result.simulated_outcomes, ())

    def test_notes_explicitly_state_foundation_only(self):
        config = MonteCarloConfig(method=MonteCarloMethod.PARAMETER_SENSITIVITY, num_simulations=5, random_seed=2)
        result = MonteCarloResult(config=config)
        self.assertTrue(any("foundation" in n.lower() for n in result.notes))


class TestMonteCarloSamplerIsAbstractFoundationOnly(unittest.TestCase):
    def test_cannot_instantiate_directly(self):
        with self.assertRaises(TypeError):
            MonteCarloSampler()

    def test_subclass_stub_raises_not_implemented(self):
        class Incomplete(MonteCarloSampler):
            def generate_samples(self, trades, config):
                return super().generate_samples(trades, config)

            def summarize(self, samples, config):
                return super().summarize(samples, config)

        instance = Incomplete()
        config = MonteCarloConfig(method=MonteCarloMethod.DRAWDOWN_STRESS, num_simulations=1, random_seed=0)
        with self.assertRaises(NotImplementedError):
            instance.generate_samples([], config)
        with self.assertRaises(NotImplementedError):
            instance.summarize([], config)


if __name__ == "__main__":
    unittest.main()
