"""Phase 11: reusable provider CONTRACT suite + adapter tests. No network, no credentials, SYNTHETIC fixtures.

The REST adapter is 'IMPLEMENTED — NOT LIVE-VERIFIED': its tests use a scripted fake transport and hand-authored
payloads. Passing them is not evidence about any real endpoint.
"""
import json
import unittest
from datetime import timedelta

from omnisystem_v5.data.providers.base import DataProvider, DataUnavailableError, RawFetchResult
from omnisystem_v5.marketdata import validation as V
from omnisystem_v5.marketdata.adapters import klines_rest
from omnisystem_v5.marketdata.adapters.klines_rest import KlinesRestAdapter
from omnisystem_v5.marketdata.adapters.legacy import LegacyDataProviderAdapter
from omnisystem_v5.marketdata.adapters.scripted import ScriptedProvider, scripted_capabilities
from omnisystem_v5.marketdata.assets import AssetClass, Listing
from omnisystem_v5.marketdata.config import SharedLimits, ValidationPolicy
from omnisystem_v5.marketdata.provider import (LIVE_CLAIMS, BarRequest, EvidenceLevel, ProviderAuthError, ProviderCapabilities,
                                               ProviderPayloadError, RawBarRow, RawBars, TransportRequest, TransportResponse)
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError, classify_fetch_exception
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe
from omnisystem_v5.tests.marketdata_fixtures import END, VENUE, crypto_instrument, raw_rows
from omnisystem_v5.tests.scanner_fixtures import bars_ending_at
from omnisystem_v5.validation.resampling import seconds_for_timeframe

TF = Timeframe.M5
SYM = "BTCUSDT"
LIMITS = SharedLimits(2.0, 40, 200, 2)


class ProviderContract:
    """Mixin (NOT a TestCase, so it is not collected by itself). A provider passes if every scenario behaves per contract.
    Subclasses implement build(scenario) -> provider serving SYM at TF."""
    SCENARIOS = ("valid", "timeout", "rate_limit", "auth", "malformed", "unavailable", "unknown_symbol")
    REQ = BarRequest(SYM, TF, 200)

    def build(self, scenario):
        raise NotImplementedError

    def test_valid_response_shape(self):
        p = self.build("valid")
        raw = p.fetch_bars(self.REQ)
        self.assertIsInstance(raw, RawBars)
        self.assertEqual(raw.provider_symbol, SYM)
        self.assertIn(raw.timeframe, (None, TF))
        self.assertEqual(raw.provider_name, p.name)
        self.assertIsInstance(raw.rows, tuple)
        self.assertGreater(len(raw.rows), 0)
        self.assertTrue(all(isinstance(r, RawBarRow) for r in raw.rows))

    def test_valid_output_passes_the_strict_validator(self):
        raw = self.build("valid").fetch_bars(self.REQ)
        out = V.validate_series(raw, self.REQ, Listing(crypto_instrument(), VENUE), END, ValidationPolicy(), LIMITS)
        self.assertEqual(out.kind, V.OK, out.issues)

    def test_valid_response_is_reproducible(self):
        a = self.build("valid").fetch_bars(self.REQ)
        b = self.build("valid").fetch_bars(self.REQ)
        self.assertEqual(a, b)

    def test_timeout_maps_to_timeout(self):
        with self.assertRaises(TimeoutError) as cm:
            self.build("timeout").fetch_bars(self.REQ)
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.PROVIDER_TIMEOUT)

    def test_rate_limit_maps_to_rate_limited_and_keeps_retry_after(self):
        with self.assertRaises(ProviderRateLimitedError) as cm:
            self.build("rate_limit").fetch_bars(self.REQ)
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.PROVIDER_RATE_LIMITED)
        self.assertEqual(cm.exception.retry_after_seconds, 12.0)

    def test_auth_failure_is_distinguishable_and_classified_unavailable(self):
        with self.assertRaises(ProviderAuthError) as cm:
            self.build("auth").fetch_bars(self.REQ)
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.PROVIDER_UNAVAILABLE)

    def test_malformed_payload_maps_to_malformed_response(self):
        with self.assertRaises(ProviderPayloadError) as cm:
            self.build("malformed").fetch_bars(self.REQ)
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.MALFORMED_RESPONSE)

    def test_outage_maps_to_provider_unavailable(self):
        with self.assertRaises(Exception) as cm:
            self.build("unavailable").fetch_bars(self.REQ)
        self.assertEqual(classify_fetch_exception(cm.exception), FailureClass.PROVIDER_UNAVAILABLE)

    def test_unknown_symbol_never_fabricates_data(self):
        with self.assertRaises(Exception) as cm:
            self.build("unknown_symbol").fetch_bars(BarRequest("NOPE", TF, 10))
        self.assertIn(classify_fetch_exception(cm.exception), (FailureClass.PROVIDER_UNAVAILABLE, FailureClass.MALFORMED_RESPONSE))

    def test_capabilities_are_honest(self):
        p = self.build("valid")
        c = p.capabilities
        self.assertIsInstance(c, ProviderCapabilities)
        self.assertTrue(p.name)
        self.assertIn(TF, c.timeframes)
        self.assertNotEqual(c.declared_origin, DataOrigin.UNAVAILABLE)
        if c.declared_origin == DataOrigin.LIVE:
            self.assertTrue(c.live_capable)
        self.assertNotIn(c.evidence, LIVE_CLAIMS)          # nothing here may claim live-connected / observed / production


# ---- concrete providers under the same contract -------------------------------------------------

def _series():
    return {(SYM, TF): raw_rows(bars_ending_at(TF, 60, END))}


class TestScriptedProviderContract(ProviderContract, unittest.TestCase):
    def build(self, scenario):
        outcomes = {"timeout": TimeoutError("t"), "rate_limit": ProviderRateLimitedError("rl", 12.0), "auth": ProviderAuthError("401"),
                    "malformed": ProviderPayloadError("bad"), "unavailable": DataUnavailableError("down")}
        out = {(SYM, TF): [outcomes[scenario]]} if scenario in outcomes else {}
        return ScriptedProvider("scripted", scripted_capabilities({AssetClass.CRYPTO}, {TF}), _series(), out)


class FakeTransport:
    def __init__(self, *responses):
        self.responses, self.requests = list(responses), []

    def request(self, request: TransportRequest) -> TransportResponse:
        self.requests.append(request)
        item = self.responses[0] if len(self.responses) == 1 else self.responses.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item


def klines_body(bars):
    return json.dumps([[int(b.open_time.timestamp() * 1000), str(b.open), str(b.high), str(b.low), str(b.close), str(b.volume),
                        int(b.close_time.timestamp() * 1000) - 1, "0", 0, "0", "0", "0"] for b in bars])


def ok_response(n=60, end=END):
    return TransportResponse(200, klines_body(bars_ending_at(TF, n, end)))


class TestKlinesAdapterContract(ProviderContract, unittest.TestCase):
    def build(self, scenario):
        resp = {"valid": ok_response(), "timeout": TimeoutError("socket timed out"),
                "rate_limit": TransportResponse(429, "", (("Retry-After", "12"),)), "auth": TransportResponse(401, "denied"),
                "malformed": TransportResponse(200, "<html>oops</html>"), "unavailable": TransportResponse(503, ""),
                "unknown_symbol": TransportResponse(400, '{"code":-1121,"msg":"Invalid symbol."}')}[scenario]
        return KlinesRestAdapter("klines", FakeTransport(resp))


class _InnerProvider(DataProvider):
    declared_origin = DataOrigin.HISTORICAL

    def __init__(self, scenario):
        self.scenario = scenario

    @property
    def name(self):
        return "legacy_inner"

    def fetch_ohlcv(self, market, timeframe, limit=200):
        s = self.scenario
        if s == "timeout":
            raise TimeoutError("t")
        if s == "rate_limit":
            raise ProviderRateLimitedError("rl", 12.0)
        if s == "auth":
            raise ProviderAuthError("401")
        if s in ("unavailable", "unknown_symbol") or market != SYM:
            raise DataUnavailableError("nope")
        bars = bars_ending_at(timeframe, 60, END)
        rows = [dict(open=b.open, high=b.high, low=b.low, close=b.close, volume=b.volume, open_time=b.open_time.isoformat(),
                     close_time=b.close_time.isoformat()) for b in bars]
        if s == "malformed":
            rows[3].pop("close")
        return RawFetchResult(self.declared_origin, self.name, rows)


class TestLegacyAdapterContract(ProviderContract, unittest.TestCase):
    def build(self, scenario):
        caps = scripted_capabilities({AssetClass.CRYPTO}, {TF})
        return LegacyDataProviderAdapter(_InnerProvider(scenario), caps)


# ---- adapter-specific behavior -----------------------------------------------------------------

class TestKlinesAdapter(unittest.TestCase):
    def test_status_is_explicit_and_never_overclaims(self):
        a = KlinesRestAdapter("k", FakeTransport(ok_response()))
        self.assertEqual(klines_rest.STATUS, "IMPLEMENTED — NOT LIVE-VERIFIED")
        self.assertEqual(a.status, klines_rest.STATUS)
        self.assertEqual(a.capabilities.evidence, EvidenceLevel.IMPLEMENTED)
        self.assertIn("NOT LIVE-VERIFIED", klines_rest.__doc__)
        self.assertNotIn(a.capabilities.evidence, LIVE_CLAIMS)

    def test_request_is_explicit_about_symbol_interval_and_limit(self):
        t = FakeTransport(ok_response())
        KlinesRestAdapter("k", t, path="/api/x").fetch_bars(BarRequest(SYM, Timeframe.H4, 50))
        (req,) = t.requests
        self.assertEqual((req.method, req.path), ("GET", "/api/x"))
        self.assertEqual(dict(req.params), {"symbol": SYM, "interval": "4h", "limit": "50"})

    def test_all_supported_timeframes_have_an_interval_code(self):
        a = KlinesRestAdapter("k", FakeTransport(ok_response()))
        for tf in (Timeframe.M1, Timeframe.M5, Timeframe.M15, Timeframe.H1, Timeframe.H4, Timeframe.D1):
            self.assertIn(tf, a.capabilities.timeframes)

    def test_close_time_is_derived_from_the_requested_timeframe_not_the_provider(self):
        raw = KlinesRestAdapter("k", FakeTransport(ok_response())).fetch_bars(BarRequest(SYM, TF, 60))
        for r in raw.rows:
            self.assertEqual(r.close_time - r.open_time, timedelta(seconds=seconds_for_timeframe(TF)))

    def test_http_status_mapping(self):
        cases = [(429, ProviderRateLimitedError), (418, ProviderRateLimitedError), (401, ProviderAuthError), (403, ProviderAuthError),
                 (408, TimeoutError), (504, TimeoutError), (500, DataUnavailableError), (503, DataUnavailableError),
                 (400, DataUnavailableError), (404, DataUnavailableError), (301, DataUnavailableError)]
        for status, exc in cases:
            with self.assertRaises(exc, msg=str(status)):
                KlinesRestAdapter("k", FakeTransport(TransportResponse(status, ""))).fetch_bars(BarRequest(SYM, TF, 10))

    def test_retry_after_header_parsing(self):
        for header, expected in ((("retry-after", "7"), 7.0), (("RETRY-AFTER", "2.5"), 2.5), (("Retry-After", "soon"), None)):
            with self.assertRaises(ProviderRateLimitedError) as cm:
                KlinesRestAdapter("k", FakeTransport(TransportResponse(429, "", (header,)))).fetch_bars(BarRequest(SYM, TF, 10))
            self.assertEqual(cm.exception.retry_after_seconds, expected)
        with self.assertRaises(ProviderRateLimitedError) as cm:
            KlinesRestAdapter("k", FakeTransport(TransportResponse(429, ""))).fetch_bars(BarRequest(SYM, TF, 10))
        self.assertIsNone(cm.exception.retry_after_seconds)

    def test_malformed_bodies_fail_closed(self):
        row = [1709250000000, "1", "2", "0.5", "1.5", "10"]
        bad = ["", "not json", "{}", "null", "[1,2]", json.dumps([row[:5]]), json.dumps([[True] + row[1:]]),
               json.dumps([[1709250000000.5] + row[1:]]), json.dumps([["1709250000000"] + row[1:]]), json.dumps([[10 ** 30] + row[1:]])]
        for body in bad:
            with self.assertRaises(ProviderPayloadError, msg=body):
                KlinesRestAdapter("k", FakeTransport(TransportResponse(200, body))).fetch_bars(BarRequest(SYM, TF, 10))

    def test_transport_errors_propagate_unchanged(self):
        for exc in (TimeoutError("t"), ConnectionError("reset")):
            with self.assertRaises(type(exc)):
                KlinesRestAdapter("k", FakeTransport(exc)).fetch_bars(BarRequest(SYM, TF, 10))

    def test_bad_values_inside_rows_are_passed_through_for_the_core_to_reject(self):
        body = json.dumps([[1709250000000, "NaN", "2", "0.5", "1.5", "10"]])
        raw = KlinesRestAdapter("k", FakeTransport(TransportResponse(200, body))).fetch_bars(BarRequest(SYM, TF, 10))
        out = V.validate_series(raw, BarRequest(SYM, TF, 10), Listing(crypto_instrument(), VENUE), END, ValidationPolicy(), LIMITS)
        self.assertEqual(out.kind, V.INVALID)              # the adapter never "fixes" values

    def test_response_with_a_forming_last_bar_is_handled_by_the_core_policy(self):
        raw = KlinesRestAdapter("k", FakeTransport(ok_response(61, END + timedelta(minutes=5)))).fetch_bars(BarRequest(SYM, TF, 61))
        out = V.validate_series(raw, BarRequest(SYM, TF, 61), Listing(crypto_instrument(), VENUE), END, ValidationPolicy(), LIMITS)
        self.assertEqual((out.kind, len(out.bars)), (V.OK, 60))

    def test_no_credentials_are_used_or_stored(self):
        t = FakeTransport(ok_response())
        KlinesRestAdapter("k", t).fetch_bars(BarRequest(SYM, TF, 10))
        names = {k.lower() for k, _ in t.requests[0].params}
        self.assertFalse(names & {"apikey", "api_key", "token", "secret", "signature", "key"})


class TestCapabilityRules(unittest.TestCase):
    def test_only_live_capable_adapters_may_declare_live(self):
        with self.assertRaises(ValueError):
            ProviderCapabilities(frozenset({AssetClass.CRYPTO}), frozenset({TF}), DataOrigin.LIVE, live_capable=False)
        with self.assertRaises(ValueError):
            ProviderCapabilities(frozenset({AssetClass.CRYPTO}), frozenset({TF}), DataOrigin.UNAVAILABLE)
        with self.assertRaises(ValueError):
            ProviderCapabilities(frozenset(), frozenset({TF}), DataOrigin.HISTORICAL)
        with self.assertRaises(ValueError):
            ProviderCapabilities(frozenset({AssetClass.CRYPTO}), frozenset(), DataOrigin.HISTORICAL)

    def test_scripted_fixtures_never_pose_as_live(self):
        c = scripted_capabilities({AssetClass.CRYPTO}, {TF})
        self.assertEqual((c.declared_origin, c.live_capable, c.evidence), (DataOrigin.HISTORICAL, False, EvidenceLevel.TESTED))

    def test_bar_request_validation(self):
        for args in (("", TF, 1), (SYM, "5m", 1), (SYM, TF, 0), (SYM, TF, True)):
            with self.assertRaises(ValueError):
                BarRequest(*args)

    def test_scripted_provider_records_calls_and_serves_last_n(self):
        p = ScriptedProvider("s", scripted_capabilities({AssetClass.CRYPTO}, {TF}), _series())
        raw = p.fetch_bars(BarRequest(SYM, TF, 10))
        self.assertEqual((len(raw.rows), len(p.calls)), (10, 1))
        self.assertEqual(raw.rows[-1].close_time, END)


if __name__ == "__main__":
    unittest.main()
