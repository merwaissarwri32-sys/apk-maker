import statistics
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.atr import calculate_atr, calculate_true_range, latest_atr
from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.calculations.returns import calculate_returns, calculate_volatility
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


class TestTrueRange(unittest.TestCase):
    def test_true_range_uses_correct_max_component(self):
        t0 = datetime.now(UTC)
        bars = [
            _bar(t0, 100, 105, 95, 102),
            _bar(t0 + timedelta(hours=1), 102, 110, 101, 108),  # gap up: high-prevclose = 8
        ]
        tr = calculate_true_range(bars)
        # TR = max(110-101=9, |110-102|=8, |101-102|=1) = 9
        self.assertEqual(len(tr), 1)
        self.assertAlmostEqual(tr[0], 9.0)

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        with self.assertRaises(InsufficientDataError):
            calculate_true_range([_bar(t0, 1, 2, 0.5, 1.5)])


class TestATR(unittest.TestCase):
    def _make_bars(self, n, t0):
        # simple oscillating bars with constant range so ATR is easy to reason about
        bars = []
        price = 100.0
        for i in range(n):
            o = price
            h = o + 2
            l = o - 2
            c = o + 0.5
            bars.append(_bar(t0 + timedelta(hours=i), o, h, l, c))
            price = c
        return bars

    def test_atr_requires_period_plus_one_bars(self):
        t0 = datetime.now(UTC)
        bars = self._make_bars(10, t0)
        with self.assertRaises(InsufficientDataError):
            calculate_atr(bars, period=14)

    def test_atr_seed_is_simple_average_of_first_period_tr(self):
        t0 = datetime.now(UTC)
        bars = self._make_bars(20, t0)
        tr_values = calculate_true_range(bars)
        expected_seed = sum(tr_values[:14]) / 14
        series = calculate_atr(bars, period=14)
        self.assertAlmostEqual(series[0].value, expected_seed, places=8)

    def test_atr_wilder_smoothing_step(self):
        t0 = datetime.now(UTC)
        bars = self._make_bars(20, t0)
        tr_values = calculate_true_range(bars)
        series = calculate_atr(bars, period=14)
        expected_next = (series[0].value * 13 + tr_values[14]) / 14
        self.assertAlmostEqual(series[1].value, expected_next, places=8)

    def test_latest_atr_matches_series_end(self):
        t0 = datetime.now(UTC)
        bars = self._make_bars(25, t0)
        series = calculate_atr(bars, period=14)
        self.assertAlmostEqual(latest_atr(bars, period=14).value, series[-1].value)

    def test_atr_always_positive_for_nonzero_ranges(self):
        t0 = datetime.now(UTC)
        bars = self._make_bars(30, t0)
        series = calculate_atr(bars, period=14)
        self.assertTrue(all(p.value > 0 for p in series))


class TestReturnsAndVolatility(unittest.TestCase):
    def test_returns_basic_calculation(self):
        t0 = datetime.now(UTC)
        bars = [
            _bar(t0, 100, 101, 99, 100, v=1),
            _bar(t0 + timedelta(hours=1), 100, 106, 99, 105, v=1),
            _bar(t0 + timedelta(hours=2), 105, 108, 100, 100, v=1),
        ]
        returns = calculate_returns(bars)
        self.assertAlmostEqual(returns[0], 0.05)
        self.assertAlmostEqual(returns[1], (100 - 105) / 105)

    def test_returns_insufficient_bars(self):
        t0 = datetime.now(UTC)
        with self.assertRaises(InsufficientDataError):
            calculate_returns([_bar(t0, 1, 2, 0.5, 1.5)])

    def test_volatility_matches_stdev_of_returns(self):
        t0 = datetime.now(UTC)
        closes = [100, 102, 101, 105, 103, 107]
        bars = [_bar(t0 + timedelta(hours=i), c, c + 1, c - 1, c) for i, c in enumerate(closes)]
        returns = calculate_returns(bars)
        expected = statistics.stdev(returns)
        self.assertAlmostEqual(calculate_volatility(bars), expected, places=10)

    def test_volatility_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 100, 101, 99, 100), _bar(t0 + timedelta(hours=1), 100, 102, 99, 101)]
        with self.assertRaises(InsufficientDataError):
            calculate_volatility(bars)  # only 1 return, stdev needs >= 2


if __name__ == "__main__":
    unittest.main()
