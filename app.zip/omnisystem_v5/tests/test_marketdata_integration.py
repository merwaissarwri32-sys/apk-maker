"""Phase 11 <-> Phase 10 integration: the REAL, unmodified ScanEngine consuming Phase 11 through its existing protocols.
All data is SYNTHETIC. This proves wiring and failure handling; it is not evidence about live markets."""
import json
import unittest
from datetime import timedelta

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.config import ValidationPolicy
from omnisystem_v5.marketdata.health import ProviderState
from omnisystem_v5.marketdata.state import build_snapshot
from omnisystem_v5.scanner.enums import CycleHealth, SymbolScanStatus
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.tests.marketdata_fixtures import END, LONG_SEED, QUIET_SEED, SHORT_SEED, Stack
from omnisystem_v5.tests.test_scanner_engine import World

M5 = Timeframe.M5
SEEDS = {"BTC/USDT": LONG_SEED, "ETH/USDT": SHORT_SEED, "DOGE/USDT": QUIET_SEED}


def crypto_args(seeds=SEEDS):
    return tuple((k.split("/")[0], k.split("/")[1], v) for k, v in seeds.items())


def result(rep, symbol):
    return next(r for r in rep.results if r.symbol == symbol)


class TestPhase10BehaviorThroughPhase11(unittest.TestCase):
    def test_scan_report_is_identical_to_the_phase10_stub_path(self):
        """GATE G: same data through Phase 11's boundary gives a byte-identical canonical scan report."""
        a = World(SEEDS).cycle()
        b = Stack(crypto=crypto_args()).cycle()
        self.assertEqual(a.canonical_dict(), b.canonical_dict())
        self.assertEqual({s.descriptor.symbol: s.descriptor.direction for s in b.emitted}, {"BTC/USDT": "LONG", "ETH/USDT": "SHORT"})

    def test_parity_holds_over_several_cycles_with_a_moving_clock(self):
        w, st = World(SEEDS), Stack(crypto=crypto_args())
        for advance in (0, 300, 900, 3600):
            self.assertEqual(w.cycle(advance).canonical_dict(), st.cycle(advance).canonical_dict(), advance)

    def test_no_hidden_extra_provider_calls(self):
        st = Stack(crypto=crypto_args())
        st.cycle()
        from omnisystem_v5.scanner.timeframes import required_timeframes
        self.assertEqual(len(st.crypto_provider.calls), len(SEEDS) * len(required_timeframes(st.scfg)))     # one fetch per (symbol, tf)


class TestMultiAsset(unittest.TestCase):
    def test_crypto_and_forex_are_served_side_by_side(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        rep = st.cycle()
        self.assertEqual((rep.health, rep.universe_size), (CycleHealth.HEALTHY, 2))
        self.assertEqual({r.symbol: r.status for r in rep.results}, {"BTC/USDT": SymbolScanStatus.EVALUATED, "EUR/USD": SymbolScanStatus.EVALUATED})
        sources = {env_source for env_source in (st.source.get_market_data(s, M5, 200).provenance.source for s in ("BTC/USDT", "EUR/USD"))}
        self.assertEqual(sources, {"cryptofeed", "fxfeed"})

    def test_forex_closed_market_is_not_scanned_and_not_a_failure(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        st.advance(86400 + 12 * 3600)                                            # Saturday 12:00 UTC
        rep = st.cycle()
        self.assertEqual(rep.universe_size, 1)
        self.assertEqual([r.symbol for r in rep.results], ["BTC/USDT"])
        self.assertEqual(rep.health, CycleHealth.HEALTHY)


class TestD2SessionGapLimitationIsPinned(unittest.TestCase):
    """D2 (accepted): the frozen gate re-validates sequences and rejects session gaps. Phase 11 never fills, compresses or
    fabricates bars to get around it. SHORT_SWING (4h + 1d) stays unavailable for session-based markets."""

    def forex(self, **md):
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),), md_kwargs=md or None)
        return st, st.cycle()

    def test_default_forex_runs_only_horizons_whose_windows_contain_no_session_gap(self):
        st, rep = self.forex()
        r = result(rep, "EUR/USD")
        self.assertEqual((r.status, r.horizons_run), (SymbolScanStatus.EVALUATED, ("SCALP",)))
        joined = " ".join(r.notes)
        self.assertIn("INTRADAY:INVALID_DATA", joined)
        self.assertIn("SHORT_SWING:INVALID_DATA", joined)
        self.assertIn("data.session_gap", joined)
        self.assertEqual(result(rep, "BTC/USDT").horizons_run, ("SCALP", "INTRADAY", "SHORT_SWING"))       # crypto is unaffected

    def test_opt_in_truncation_recovers_intraday_but_never_short_swing(self):
        st, rep = self.forex(validation=ValidationPolicy(truncate_at_session_gap=True))
        r = result(rep, "EUR/USD")
        self.assertEqual(r.horizons_run, ("SCALP", "INTRADAY"))
        joined = " ".join(r.notes)
        self.assertIn("SHORT_SWING:INSUFFICIENT_DATA", joined)
        self.assertIn("data.session_gap_truncated", joined)

    def test_no_bars_are_ever_fabricated_to_bridge_a_gap(self):
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),), md_kwargs={"validation": ValidationPolicy(truncate_at_session_gap=True)})
        st.cycle()
        delivered = st.source.get_market_data("EUR/USD", Timeframe.H4, 200)
        served = {r.open_time for r in st.forex_provider.fetch_bars(__import__("omnisystem_v5.marketdata.provider", fromlist=["x"]).BarRequest("EUR_USD", Timeframe.H4, 200)).rows}
        self.assertTrue({b.open_time for b in delivered.bars} <= served)
        opens = [b.open_time for b in delivered.bars]
        self.assertEqual(opens, sorted(set(opens)))

    def test_session_gaps_never_quarantine_the_instrument(self):
        """Regression: each of 1h/4h/1d used to count as an instrument failure, quarantining EUR/USD after one cycle
        and silently removing even its SCALP horizon from cycle two onward."""
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),))
        for i in range(4):
            rep = st.cycle(advance=300 if i else 0)
            r = result(rep, "EUR/USD")
            self.assertEqual((r.status, r.horizons_run), (SymbolScanStatus.EVALUATED, ("SCALP",)), i)
        h = st.book.instrument("EUR/USD")                                          # recorded by the successful SCALP stream
        self.assertEqual((h.state.value, h.consecutive_failures), ("AVAILABLE", 0))
        self.assertTrue(any(e.symbol == "EUR/USD" and e.scannable for e in st.universe.evaluate(st.clock.now()).entries))

    def test_reopen_window_fails_closed_no_data_no_signal(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        st.advance(2 * 86400 + 22 * 3600 + 30 * 60)                              # Sunday 22:30 UTC, 30 minutes after the FX open
        rep = st.cycle()
        r = result(rep, "EUR/USD")
        self.assertEqual((r.status, r.failure_class, r.horizons_run), (SymbolScanStatus.REJECTED, FailureClass.INVALID_DATA, ()))
        self.assertNotIn("EUR/USD", [s.descriptor.symbol for s in rep.emitted])
        self.assertEqual(result(rep, "BTC/USDT").status, SymbolScanStatus.EVALUATED)


class TestFailureIsolationThroughTheScanner(unittest.TestCase):
    def test_one_bad_symbol_does_not_poison_the_scan(self):
        st = Stack(crypto=crypto_args())
        import dataclasses
        from omnisystem_v5.tests.marketdata_fixtures import raw_rows
        from omnisystem_v5.tests.scanner_fixtures import bars_ending_at
        from omnisystem_v5.scanner.timeframes import required_timeframes
        for tf in required_timeframes(st.scfg):
            rows = list(raw_rows(bars_ending_at(tf, 220, END, seed=SHORT_SEED)))
            rows[60] = dataclasses.replace(rows[60], close=float("nan"))
            st.crypto_provider.set_series("ETHUSDT", tf, rows)
        rep = st.cycle()
        self.assertEqual(result(rep, "ETH/USDT").status, SymbolScanStatus.REJECTED)
        self.assertEqual(result(rep, "ETH/USDT").failure_class, FailureClass.INVALID_DATA)
        self.assertEqual(result(rep, "BTC/USDT").status, SymbolScanStatus.EVALUATED)
        self.assertEqual(result(rep, "DOGE/USDT").status, SymbolScanStatus.EVALUATED)
        self.assertEqual({s.descriptor.symbol for s in rep.emitted}, {"BTC/USDT"})
        self.assertEqual(rep.health, CycleHealth.HEALTHY)
        self.assertEqual(st.book.provider("cryptofeed", END).state, ProviderState.HEALTHY)

    def test_rate_limit_aborts_the_cycle_using_the_scanners_own_semantics(self):
        st = Stack(crypto=crypto_args())
        from omnisystem_v5.scanner.timeframes import required_timeframes
        first = required_timeframes(st.scfg)[0]
        st.crypto_provider.script("BTCUSDT", first, [ProviderRateLimitedError("rl", 30.0)])
        rep = st.cycle()
        self.assertTrue(rep.rate_limited)
        self.assertEqual(rep.emitted, ())
        self.assertGreaterEqual(rep.count(SymbolScanStatus.SKIPPED_RATE_LIMIT), 1)
        calls = len(st.crypto_provider.calls)
        rep2 = st.cycle(advance=300)                                              # still inside the 30 s? no: 300 s later -> probe allowed
        self.assertEqual(rep2.health, CycleHealth.HEALTHY)
        self.assertGreater(len(st.crypto_provider.calls), calls)

    def test_a_provider_outage_isolates_its_market_and_is_visible_in_state(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        from omnisystem_v5.scanner.timeframes import required_timeframes
        for tf in required_timeframes(st.scfg):
            st.crypto_provider.script("BTCUSDT", tf, [DataUnavailableError("down")] * 10)
        for _ in range(3):
            rep = st.cycle(advance=300)
            self.assertEqual(result(rep, "EUR/USD").status, SymbolScanStatus.EVALUATED)
        self.assertEqual(st.book.provider("cryptofeed", st.clock.now()).state, ProviderState.UNAVAILABLE)
        snap = build_snapshot(st.clock.now(), st.book, st.router, st.universe, st.metrics)
        self.assertEqual({p.provider: p.state.value for p in snap.providers}, {"cryptofeed": "UNAVAILABLE", "fxfeed": "HEALTHY"})
        rep = st.cycle(advance=1)                                                  # still inside the 30 s cooldown: no probe yet
        self.assertEqual(rep.universe_size, 1)                                     # the down provider's markets are not scanned
        self.assertEqual([r.symbol for r in rep.results], ["EUR/USD"])
        self.assertEqual(result(rep, "EUR/USD").status, SymbolScanStatus.EVALUATED)

    def test_everything_down_is_reported_as_systemic_by_the_scanner_not_hidden(self):
        names = ("BTC", "ETH", "DOGE", "SOL", "ADA", "XRP")                         # >= the scanner's min_sample (5) attempted symbols
        st = Stack(crypto=tuple((n, "USDT", 1) for n in names))
        from omnisystem_v5.scanner.timeframes import required_timeframes
        for n in names:
            for tf in required_timeframes(st.scfg):
                st.crypto_provider.script(f"{n}USDT", tf, [DataUnavailableError("down")] * 5)
        rep = st.cycle()
        self.assertEqual(rep.health, CycleHealth.SYSTEMIC_FAILURE)
        self.assertEqual(rep.emitted, ())


class TestDeterminism(unittest.TestCase):
    def run_scenario(self):
        st = Stack(crypto=crypto_args(), forex=(("EUR", "USD"),))
        reports = [st.cycle(a).canonical_dict() for a in (0, 300, 900)]
        snap = build_snapshot(st.clock.now(), st.book, st.router, st.universe, st.metrics).to_json()
        return json.dumps(reports, sort_keys=True), snap

    def test_same_inputs_same_clock_same_config_give_identical_output(self):
        runs = [self.run_scenario() for _ in range(3)]
        self.assertEqual(runs[0], runs[1])
        self.assertEqual(runs[1], runs[2])

    def test_no_wall_clock_leaks_into_content_identity(self):
        a, b = Stack(), Stack()
        ea, eb = a.source.get_market_data("BTC/USDT", M5, 200), b.source.get_market_data("BTC/USDT", M5, 200)
        self.assertEqual(ea, eb)
        self.assertEqual(a.book.streams()[0].digest, b.book.streams()[0].digest)


if __name__ == "__main__":
    unittest.main()
