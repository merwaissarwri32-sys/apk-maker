"""
Phase 9 - Walk-Forward & Robust Validation (walk-forward layer).

Written BEFORE the production changes. Policy:
  * Real, unmocked engines on SYNTHETIC fixtures (phase9_fixtures.py) -
    never presented as market evidence.
  * No vacuous tests: every test first proves the behaviour it checks
    really occurred (real closed trades, real blocked folds, ...).
  * Wall-clock-derived ids (candidate_id / decision_id) are excluded from
    cross-run comparisons; trade_id and every other field must match.
"""
import statistics
import unittest
from collections import Counter
from dataclasses import replace
from functools import lru_cache
from unittest.mock import patch

from omnisystem_v5.schemas.market_data import OHLCVBar, SchemaValidationError
from omnisystem_v5.tests.phase9_fixtures import (
    T0, UTC, closed_trades, comparable_trades, flat_bars, oscillating_bars, scalp_template,
    with_duplicate_timestamp, with_removed_bars, with_swapped_adjacent, wf_config,
)
from omnisystem_v5.validation.contracts import DataQualityIssue, DataQualityReport
from omnisystem_v5.validation.enums import (
    DataQualityIssueType, ExitReason, TradeLifecycleState, ValidationPeriodType,
)
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig, run_multi_horizon_replay
from omnisystem_v5.validation.performance import calculate_performance_metrics
from omnisystem_v5.validation.walk_forward_runner import (
    WALK_FORWARD_LIMITATIONS, Fold, FoldResult, FoldStatus, WalkForwardMode, WalkForwardRunConfig,
    _aggregate, build_fold_audit, compute_folds, required_warmup_bars, run_walk_forward,
)
from omnisystem_v5.validation.warmup import compute_required_lookback_bars

BARS = oscillating_bars(700, seed=1)  # SYNTHETIC
# Second SYNTHETIC dataset for metric hand-calculations: seed 1's closed trades are all wins or exactly
# breakeven (profit factor / expectancy would be trivially undefined). Seed 11 yields real wins AND losses.
METRICS_BARS = oscillating_bars(700, seed=11)


@lru_cache(maxsize=None)
def _metrics_result():
    return run_walk_forward(METRICS_BARS, wf_config())


@lru_cache(maxsize=None)
def _base(mode):
    return run_walk_forward(BARS, wf_config(mode=mode))


def _all_closed(result):
    return [t for fr in result.fold_results for t in closed_trades(fr.backtest.trades)]


class TestConfigContract(unittest.TestCase):
    def test_required_warmup_bars_is_derived_from_warmup_module_not_hard_coded(self):
        t = MultiHorizonReplayConfig(symbol="X", base_timeframe=scalp_template().base_timeframe, initial_capital=1.0)
        expected = compute_required_lookback_bars(
            t.base_timeframe, t.enable_scalp, t.enable_intraday, t.enable_short_swing,
            t.market_context_config, t.quant_engine_config, t.intraday_engine_config,
            t.short_swing_engine_config, floor_bars=t.min_bars_required)
        self.assertEqual(required_warmup_bars(t), expected)
        self.assertGreater(expected, required_warmup_bars(scalp_template()))  # depends on enabled horizons

    def test_non_positive_train_test_step_rejected_fail_closed(self):
        for kw in ({"train": -1}, {"test": -5}, {"step": -3}, {"step": 0}):
            with self.subTest(kw=kw), self.assertRaises(ValueError):
                wf_config(**kw)

    def test_both_modes_reject_train_bars_below_required_warmup_with_the_exact_number(self):
        full = MultiHorizonReplayConfig(symbol="X", base_timeframe=scalp_template().base_timeframe, initial_capital=1.0)
        required = required_warmup_bars(full)
        for mode in (WalkForwardMode.ROLLING, WalkForwardMode.EXPANDING):
            with self.subTest(mode=mode), self.assertRaises(ValueError) as cm:
                WalkForwardRunConfig(mode=mode, train_bars=required - 1, test_bars=50, replay_config_template=full)
            self.assertIn(str(required), str(cm.exception))

    def test_expanding_with_train_bars_exactly_required_is_accepted_and_every_fold_has_enough_warmup(self):
        t = scalp_template()
        required = required_warmup_bars(t)
        for mode in (WalkForwardMode.ROLLING, WalkForwardMode.EXPANDING):
            cfg = WalkForwardRunConfig(mode=mode, train_bars=required, test_bars=50, replay_config_template=t)
            folds = compute_folds(400, cfg)
            self.assertGreaterEqual(len(folds), 3)
            for f in folds:
                self.assertGreaterEqual(f.warmup_end_index - f.warmup_start_index + 1, required)

    def test_overlapping_test_windows_are_rejected_fail_closed_in_both_modes(self):
        for mode in (WalkForwardMode.ROLLING, WalkForwardMode.EXPANDING):
            with self.subTest(mode=mode), self.assertRaises(ValueError) as cm:
                wf_config(mode=mode, train=100, test=100, step=50)
            self.assertIn("overlap", str(cm.exception).lower())

    def test_step_equal_to_test_is_accepted_and_step_greater_leaves_visible_untested_bars(self):
        wf_config(train=100, test=100, step=100)
        cfg = wf_config(train=100, test=100, step=150)
        folds = compute_folds(len(BARS), cfg)
        self.assertGreaterEqual(len(folds), 3)
        self.assertTrue(all(b.test_start_index - a.test_end_index > 1 for a, b in zip(folds, folds[1:])))
        result = run_walk_forward(BARS, cfg)
        self.assertEqual(result.aggregate.total_test_bars, 100 * len(folds))
        self.assertLess(result.aggregate.total_test_bars, folds[-1].test_end_index - folds[0].test_start_index + 1)


class TestFoldBoundaryAudit(unittest.TestCase):
    def _check(self, mode):
        result = _base(mode)
        self.assertGreaterEqual(len(result.fold_results), 4)
        prev = None
        for fr in result.fold_results:
            a, f = fr.audit, fr.fold
            self.assertIsNotNone(a)
            self.assertEqual((a.fold_index, a.warmup_start_index, a.warmup_end_index, a.test_start_index, a.test_end_index),
                             (f.fold_index, f.warmup_start_index, f.warmup_end_index, f.test_start_index, f.test_end_index))
            self.assertEqual(a.warmup_end_index + 1, a.test_start_index)          # train -> test boundary
            self.assertLess(a.warmup_end_index, a.test_start_index)                # no train/test overlap
            self.assertEqual(a.train_bar_count, a.warmup_end_index - a.warmup_start_index + 1)
            self.assertEqual(a.test_bar_count, a.test_end_index - a.test_start_index + 1)
            splits = {s.period_type: s for s in fr.backtest.period_splits}
            local = a.test_start_index - a.warmup_start_index
            self.assertEqual((splits[ValidationPeriodType.TRAINING].start_index, splits[ValidationPeriodType.TRAINING].end_index),
                             (0, local - 1))
            self.assertEqual(splits[ValidationPeriodType.OUT_OF_SAMPLE].start_index, local)
            if prev is not None:
                self.assertEqual(prev.test_end_index + 1, a.test_start_index)      # contiguous, disjoint tests
            prev = a
        return result

    def test_rolling_boundaries_are_consistent_and_train_window_slides(self):
        result = self._check(WalkForwardMode.ROLLING)
        starts = [fr.audit.warmup_start_index for fr in result.fold_results]
        self.assertEqual(starts, [i * 100 for i in range(len(starts))])
        self.assertTrue(all(fr.audit.train_bar_count == 100 for fr in result.fold_results))

    def test_expanding_boundaries_are_consistent_and_train_window_grows(self):
        result = self._check(WalkForwardMode.EXPANDING)
        counts = [fr.audit.train_bar_count for fr in result.fold_results]
        self.assertTrue(all(fr.audit.warmup_start_index == 0 for fr in result.fold_results))
        self.assertEqual(counts, [100 + 100 * i for i in range(len(counts))])


class TestFutureDataIsolation(unittest.TestCase):
    def test_bars_after_a_folds_test_end_never_influence_that_fold(self):
        from omnisystem_v5.tests.phase9_fixtures import mutate_from, scaled_volatility
        cut = 400
        mutated = mutate_from(BARS, cut, lambda tail: scaled_volatility(tail, 3.0))
        a = run_walk_forward(BARS, wf_config())
        b = run_walk_forward(mutated, wf_config())
        safe = [i for i, fr in enumerate(a.fold_results) if fr.fold.test_end_index < cut]
        touched = [i for i, fr in enumerate(a.fold_results) if fr.fold.test_end_index >= cut]
        # non-vacuity: enough real closed trades in the safe folds, and the
        # mutation really changes the folds it is supposed to reach.
        self.assertGreaterEqual(sum(len(closed_trades(a.fold_results[i].backtest.trades)) for i in safe), 3)
        self.assertTrue(any(comparable_trades(a.fold_results[i].backtest.trades) !=
                            comparable_trades(b.fold_results[i].backtest.trades) for i in touched))
        for i in safe:
            self.assertEqual(comparable_trades(a.fold_results[i].backtest.trades),
                             comparable_trades(b.fold_results[i].backtest.trades))


class TestFoldIndependence(unittest.TestCase):
    def test_each_fold_equals_a_standalone_run_of_only_its_own_slice(self):
        result = _base(WalkForwardMode.ROLLING)
        self.assertGreaterEqual(len(result.fold_results), 4)
        for fr in result.fold_results:
            self.assertGreaterEqual(len(closed_trades(fr.backtest.trades)), 3)     # 3+ real trades fired per fold
            f = fr.fold
            solo = run_walk_forward(BARS[f.warmup_start_index: f.test_end_index + 1], wf_config())
            self.assertEqual(len(solo.fold_results), 1)
            self.assertEqual(comparable_trades(solo.fold_results[0].backtest.trades), comparable_trades(fr.backtest.trades))

    def test_expanding_fold_equals_standalone_run_ending_at_its_test_end(self):
        result = _base(WalkForwardMode.EXPANDING)
        last = result.fold_results[-1]
        self.assertGreaterEqual(len(closed_trades(last.backtest.trades)), 3)
        solo = run_walk_forward(BARS[: last.fold.test_end_index + 1], wf_config(mode=WalkForwardMode.EXPANDING))
        self.assertEqual(comparable_trades(solo.fold_results[-1].backtest.trades), comparable_trades(last.backtest.trades))

    def test_capital_is_fresh_and_trade_ids_do_not_bleed_across_folds(self):
        result = _base(WalkForwardMode.ROLLING)
        ids = [t.trade_id for fr in result.fold_results for t in fr.backtest.trades]
        self.assertGreaterEqual(len(closed_trades([t for fr in result.fold_results for t in fr.backtest.trades])), 12)
        self.assertEqual(len(ids), len(set(ids)))
        for fr in result.fold_results:
            self.assertEqual(fr.backtest.reproducibility.replay_config_summary["initial_capital"], "10000.0")

    def test_running_twice_in_one_process_leaves_no_hidden_state_behind(self):
        first = run_walk_forward(BARS, wf_config())
        second = run_walk_forward(BARS, wf_config())
        self.assertEqual([comparable_trades(f.backtest.trades) for f in first.fold_results],
                         [comparable_trades(f.backtest.trades) for f in second.fold_results])


class TestDeterminism(unittest.TestCase):
    def test_run_a_equals_run_b_except_wall_clock_derived_ids(self):
        a, b = run_walk_forward(BARS, wf_config()), run_walk_forward(BARS, wf_config())
        self.assertGreaterEqual(len(_all_closed(a)), 3)
        self.assertEqual(a.dataset_hash, b.dataset_hash)
        self.assertEqual([fr.fold for fr in a.fold_results], [fr.fold for fr in b.fold_results])
        self.assertEqual([fr.audit for fr in a.fold_results], [fr.audit for fr in b.fold_results])
        self.assertEqual(a.aggregate, b.aggregate)
        for fa, fb in zip(a.fold_results, b.fold_results):
            self.assertEqual([t.trade_id for t in fa.backtest.trades], [t.trade_id for t in fb.backtest.trades])
            self.assertEqual(comparable_trades(fa.backtest.trades), comparable_trades(fb.backtest.trades))
            self.assertEqual([t.rejection_detail for t in fa.backtest.trades], [t.rejection_detail for t in fb.backtest.trades])

    def test_the_wall_clock_id_limitation_is_documented_in_the_result(self):
        result = _base(WalkForwardMode.ROLLING)
        text = " ".join(result.limitations)
        for token in ("candidate_id", "decision_id", "calculated_at"):
            self.assertIn(token, text)
        self.assertEqual(result.limitations[:len(WALK_FORWARD_LIMITATIONS)], WALK_FORWARD_LIMITATIONS)


class TestBlockedAndEmptyFolds(unittest.TestCase):
    def test_duplicate_timestamp_blocks_exactly_the_folds_whose_slice_contains_it(self):
        data = with_duplicate_timestamp(BARS, 250)
        result = run_walk_forward(data, wf_config())
        statuses = [fr.audit.status for fr in result.fold_results]
        self.assertEqual([s == FoldStatus.BLOCKED for s in statuses], [False, True, True, False, False, False])
        for i in (1, 2):
            a = result.fold_results[i].audit
            self.assertEqual(a.blocking_issue_types, ("DUPLICATE_TIMESTAMP",))
            self.assertEqual((a.trade_record_count, a.is_valid), (0, False))
        valid = [fr for fr in result.fold_results if fr.audit.status != FoldStatus.BLOCKED]
        self.assertGreaterEqual(sum(len(closed_trades(fr.backtest.trades)) for fr in valid), 3)
        agg = result.aggregate
        self.assertEqual((agg.fold_count, agg.valid_fold_count, agg.blocked_fold_count), (6, 4, 2))
        self.assertEqual(agg.blocked_fold_reasons, ((1, ("DUPLICATE_TIMESTAMP",)), (2, ("DUPLICATE_TIMESTAMP",))))
        self.assertEqual(agg.total_candidates_traced, sum(len(fr.backtest.trades) for fr in valid))
        self.assertAlmostEqual(agg.total_pnl, sum(t.pnl for fr in valid for t in closed_trades(fr.backtest.trades)))

    def test_out_of_order_data_is_blocked_and_reported_not_silently_dropped(self):
        result = run_walk_forward(with_swapped_adjacent(BARS, 250), wf_config())
        blocked = [fr for fr in result.fold_results if fr.audit.status == FoldStatus.BLOCKED]
        self.assertEqual([fr.fold.fold_index for fr in blocked], [1, 2])
        self.assertTrue(all("OUT_OF_ORDER" in fr.audit.blocking_issue_types for fr in blocked))
        self.assertEqual(result.aggregate.blocked_fold_count, 2)
        self.assertEqual(result.aggregate.fold_count, len(result.fold_results))  # nothing removed from the trace

    def test_aggregate_excludes_trades_of_a_blocked_fold_even_if_a_result_carries_them(self):
        good = run_walk_forward(BARS, wf_config()).fold_results[0]
        self.assertGreaterEqual(len(closed_trades(good.backtest.trades)), 3)
        bad_dq = DataQualityReport(
            issues=(DataQualityIssue(DataQualityIssueType.DUPLICATE_TIMESTAMP, 5, T0, "x"),), is_valid=False)
        forged = FoldResult(fold=good.fold, backtest=replace(good.backtest, data_quality=bad_dq))
        agg = _aggregate((forged,))
        self.assertEqual((agg.blocked_fold_count, agg.valid_fold_count), (1, 0))
        self.assertEqual((agg.total_candidates_traced, agg.total_closed_trades), (0, 0))

    def test_warmup_insufficient_fold_is_blocked_at_the_walk_forward_layer(self):
        good = run_walk_forward(BARS, wf_config()).fold_results[0]
        dq = DataQualityReport(
            issues=(DataQualityIssue(DataQualityIssueType.INSUFFICIENT_WARMUP, None, None, "w"),),
            is_valid=True, warmup_sufficient=False)
        audit = build_fold_audit(good.fold, replace(good.backtest, data_quality=dq))
        self.assertEqual(audit.status, FoldStatus.BLOCKED)
        self.assertEqual(audit.blocking_issue_types, ("INSUFFICIENT_WARMUP",))

    def test_empty_folds_are_valid_traced_and_never_get_fabricated_metrics(self):
        result = run_walk_forward(flat_bars(700), wf_config())
        self.assertGreaterEqual(len(result.fold_results), 4)
        self.assertTrue(all(len(fr.backtest.trades) == 0 for fr in result.fold_results))   # emptiness is real
        agg = result.aggregate
        self.assertEqual((agg.empty_fold_count, agg.blocked_fold_count, agg.valid_fold_count),
                         (agg.fold_count, 0, agg.fold_count))
        self.assertTrue(all(fr.audit.status == FoldStatus.VALID_NO_TRADES for fr in result.fold_results))
        for value in (agg.win_rate, agg.average_r_multiple, agg.profitable_fold_ratio, agg.fold_pnl_stdev):
            self.assertIsNone(value)
        pooled = agg.pooled_performance
        self.assertEqual(pooled.closed_trades, 0)
        for value in (pooled.win_rate, pooled.profit_factor, pooled.expectancy, pooled.total_pnl):
            self.assertIsNone(value)
        self.assertTrue(pooled.reasons)

    def test_mixed_dataset_reports_both_fold_statuses(self):
        data = BARS[:400] + flat_bars(300, start_index=400)
        result = run_walk_forward(data, wf_config())
        statuses = [fr.audit.status for fr in result.fold_results]
        self.assertIn(FoldStatus.VALID_WITH_CLOSED_TRADES, statuses)
        self.assertIn(FoldStatus.VALID_NO_TRADES, statuses)
        agg = result.aggregate
        self.assertEqual(agg.empty_fold_count, statuses.count(FoldStatus.VALID_NO_TRADES))
        self.assertEqual(agg.valid_fold_count, len(statuses))

    def test_abnormal_gap_stays_non_blocking_and_is_reflected_in_the_trace(self):
        data = with_removed_bars(BARS, range(250, 255))
        result = run_walk_forward(data, wf_config())
        affected = [fr for fr in result.fold_results if fr.fold.warmup_start_index <= 250 <= fr.fold.test_end_index]
        self.assertGreaterEqual(len(affected), 1)
        for fr in affected:
            self.assertIn(("ABNORMAL_GAP", 1), fr.audit.warning_issue_counts)
            self.assertNotEqual(fr.audit.status, FoldStatus.BLOCKED)          # data-quality contract unchanged
        agg = result.aggregate
        self.assertEqual(agg.blocked_fold_count, 0)
        self.assertEqual(agg.warning_issue_counts.get("ABNORMAL_GAP"), len(affected))

    def test_dataset_too_short_for_one_fold_is_explicit_not_silent(self):
        for data in ([], BARS[:150]):
            result = run_walk_forward(data, wf_config())
            self.assertEqual((result.aggregate.fold_count, result.aggregate.valid_fold_count), (0, 0))
            self.assertTrue(any("no fold" in s.lower() for s in result.limitations))
            self.assertIsNone(result.aggregate.profitable_fold_ratio)


class TestEndOfReplayWindowTrace(unittest.TestCase):
    def test_forced_close_is_traced_separately_and_contract_is_unchanged(self):
        result = run_walk_forward(BARS, wf_config(train=100, test=60))
        forced = [t for fr in result.fold_results for t in fr.backtest.trades
                  if t.exit_reason == ExitReason.END_OF_REPLAY_WINDOW]
        self.assertGreaterEqual(len(forced), 1)                                   # a real forced close happened
        self.assertTrue(all(t.state == TradeLifecycleState.FINAL_EXIT for t in forced))  # Phase 7/8 contract kept
        self.assertEqual(result.aggregate.forced_close_trade_count, len(forced))
        traced = [tid for fr in result.fold_results for tid in fr.audit.forced_close_trade_ids]
        self.assertEqual(sorted(traced), sorted(t.trade_id for t in forced))
        self.assertTrue(any("END_OF_REPLAY_WINDOW" in s for s in result.limitations))


class TestFoldMetrics(unittest.TestCase):
    def setUp(self):
        self.result = _metrics_result()
        self.closed = _all_closed(self.result)
        self.assertGreaterEqual(len(self.closed), 12)                              # real trades, not vacuous
        self.assertTrue(any(t.pnl > 0 for t in self.closed) and any(t.pnl < 0 for t in self.closed))

    def test_pooled_performance_is_exactly_performance_py_over_usable_fold_trades(self):
        expected = calculate_performance_metrics(self.closed, 10000.0)
        self.assertEqual(self.result.aggregate.pooled_performance, expected)

    def test_headline_metrics_match_independent_hand_calculation(self):
        pnls = [t.pnl for t in self.closed]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]
        pooled = self.result.aggregate.pooled_performance
        agg = self.result.aggregate
        self.assertAlmostEqual(pooled.total_pnl, sum(pnls))
        self.assertAlmostEqual(agg.total_pnl, sum(pnls))
        self.assertAlmostEqual(agg.win_rate, len(wins) / len(pnls))
        self.assertTrue(wins and losses)
        self.assertAlmostEqual(pooled.profit_factor, sum(wins) / abs(sum(losses)))
        exp = (len(wins) / len(pnls)) * statistics.mean(wins) + (len(losses) / len(pnls)) * statistics.mean(losses)
        self.assertAlmostEqual(pooled.expectancy, exp)
        peak = equity = 10000.0
        worst = 0.0
        for p in pnls:
            equity += p
            peak = max(peak, equity)
            worst = max(worst, peak - equity)
        self.assertAlmostEqual(pooled.drawdown.max_drawdown_abs, worst)

    def test_fold_consistency_matches_hand_calculation(self):
        per_fold = [(fr.fold.fold_index, sum(t.pnl for t in closed_trades(fr.backtest.trades)))
                    for fr in self.result.fold_results if closed_trades(fr.backtest.trades)]
        agg = self.result.aggregate
        self.assertEqual(tuple(agg.fold_pnls), tuple((i, p) for i, p in per_fold))
        prof = sum(1 for _, p in per_fold if p > 0)
        self.assertEqual((agg.profitable_fold_count, agg.losing_fold_count), (prof, sum(1 for _, p in per_fold if p < 0)))
        self.assertAlmostEqual(agg.profitable_fold_ratio, prof / len(per_fold))
        self.assertAlmostEqual(agg.fold_pnl_stdev, statistics.stdev(p for _, p in per_fold))

    def test_rejection_counts_and_horizon_distribution_match_the_trace(self):
        all_trades = [t for fr in self.result.fold_results for t in fr.backtest.trades]
        agg = self.result.aggregate
        rejected = [t for t in all_trades if t.state in (TradeLifecycleState.REJECTED_BY_RISK,
                                                          TradeLifecycleState.INVALIDATED, TradeLifecycleState.EXPIRED)]
        self.assertGreaterEqual(len(rejected), 3)                                  # real rejections exist
        self.assertEqual(dict(agg.rejection_state_counts), dict(Counter(t.state.value for t in rejected)))
        self.assertEqual(dict(agg.rejection_reason_counts), dict(Counter(t.rejection_detail for t in rejected)))
        self.assertEqual(sum(agg.trades_by_horizon.values()), len(all_trades))
        self.assertEqual(agg.total_candidates_traced, len(all_trades))


class TestRollingVersusExpandingLimitation(unittest.TestCase):
    def test_documented_expanding_equals_rolling_decisions_when_train_covers_lookback(self):
        r, e = _base(WalkForwardMode.ROLLING), _base(WalkForwardMode.EXPANDING)
        self.assertGreaterEqual(len(_all_closed(r)), 12)
        self.assertEqual([comparable_trades(f.backtest.trades) for f in r.fold_results],
                         [comparable_trades(f.backtest.trades) for f in e.fold_results])
        self.assertTrue(any("EXPANDING" in s for s in e.limitations))


class TestErrorsAreNeverSwallowed(unittest.TestCase):
    def test_unexpected_internal_exception_propagates_and_the_stub_really_ran(self):
        with patch("omnisystem_v5.validation.walk_forward_runner.run_multi_horizon_replay",
                   side_effect=RuntimeError("boom")) as stub:
            with self.assertRaises(RuntimeError):
                run_walk_forward(BARS, wf_config())
        self.assertGreaterEqual(stub.call_count, 1)


class TestMalformedTimestampContract(unittest.TestCase):
    """Priority 7: malformed bars cannot exist as OHLCVBar objects - the Phase 1
    schema fails closed at construction (before any validation layer), with a
    named, deterministic exception. Not a traceability gap; no schema change."""

    def test_naive_timestamp_bar_cannot_be_constructed(self):
        with self.assertRaises(SchemaValidationError) as cm:
            OHLCVBar(100, 100.5, 99.5, 100, 1, T0.replace(tzinfo=None), T0)
        self.assertIn("timezone-aware", str(cm.exception))

    def test_close_before_open_bar_cannot_be_constructed(self):
        from datetime import timedelta
        with self.assertRaises(SchemaValidationError):
            OHLCVBar(100, 100.5, 99.5, 100, 1, T0 + timedelta(minutes=15), T0)


if __name__ == "__main__":
    unittest.main()
