import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.validation.contracts import (
    DataQualityReport,
    ExecutionConfig,
    HistoricalDatasetDescriptor,
    ReproducibilityRecord,
    SimulatedFill,
    TradeRecord,
)
from omnisystem_v5.validation.enums import ExitReason, TradeLifecycleState
from omnisystem_v5.validation.performance import calculate_performance_metrics
from omnisystem_v5.validation.report import build_validation_report, render_markdown

UTC = timezone.utc
T0 = datetime.now(UTC) - timedelta(hours=1000)


def _trade(i, pnl, regime="TREND", rejection_detail=""):
    signal_time = T0 + timedelta(hours=i)
    fill = SimulatedFill(price=100.0, timestamp=signal_time, fee_amount=0.0, slippage_amount=0.0)
    return TradeRecord(
        trade_id=f"t{i}", symbol="BTCUSDT", direction="LONG", signal_time=signal_time,
        state=TradeLifecycleState.FINAL_EXIT if pnl is not None else TradeLifecycleState.REJECTED_BY_RISK,
        entry_zone_bottom=99.0, entry_zone_top=100.0, stop_loss=95.0, take_profits=(110.0,),
        entry_fill=fill if pnl is not None else None, exit_fill=fill if pnl is not None else None,
        exit_reason=ExitReason.TAKE_PROFIT if pnl else None,
        quantity=10.0, risk_amount=100.0, pnl=pnl, r_multiple=(pnl / 100.0) if pnl is not None else None,
        duration_bars=5, market_regime=regime, rejection_detail=rejection_detail,
    )


def _fake_result(trades):
    dataset = HistoricalDatasetDescriptor(
        symbol="BTCUSDT", timeframe=Timeframe.H1, bar_count=200,
        start_timestamp=T0, end_timestamp=T0 + timedelta(hours=200),
        source_description="test", dataset_hash="abc123",
    )
    dq = DataQualityReport(issues=(), is_valid=True, warmup_sufficient=True)
    repro = ReproducibilityRecord(run_id="run1", dataset=dataset, replay_config_summary={"symbol": "BTCUSDT"})

    class _FakeResult:
        pass

    r = _FakeResult()
    r.trades = tuple(trades)
    r.data_quality = dq
    r.dataset = dataset
    r.reproducibility = repro
    return r


class TestBuildValidationReport(unittest.TestCase):
    def test_basic_report_structure(self):
        trades = [_trade(0, 50.0), _trade(1, -20.0), _trade(2, None, rejection_detail="no candidate passed the Risk Engine's actionability gate")]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {"max_risk_per_trade_pct": 1.0, "min_reward_risk_ratio": 2.0})

        self.assertEqual(report.signal_statistics.total_signals, 3)
        self.assertEqual(report.signal_statistics.final_exit_count, 2)
        self.assertEqual(report.signal_statistics.rejected_by_risk_count, 1)
        self.assertAlmostEqual(report.signal_statistics.candidate_to_trade_conversion_rate, 2 / 3)
        self.assertTrue(report.data_quality_is_valid)
        self.assertEqual(report.reproducibility_run_id, "run1")
        self.assertEqual(report.reproducibility_dataset_hash, "abc123")

    def test_failure_modes_aggregated_and_sorted(self):
        trades = [
            _trade(0, None, rejection_detail="reason A"),
            _trade(1, None, rejection_detail="reason A"),
            _trade(2, None, rejection_detail="reason B"),
        ]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {})
        self.assertEqual(report.failure_modes[0].detail, "reason A")
        self.assertEqual(report.failure_modes[0].count, 2)

    def test_regime_analysis_reflects_performance_breakdown(self):
        trades = [_trade(0, 10.0, regime="TREND"), _trade(1, -5.0, regime="RANGE")]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {})
        self.assertIn("TREND", report.regime_analysis)
        self.assertIn("RANGE", report.regime_analysis)

    def test_limitations_always_present_and_honest(self):
        result = _fake_result([])
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {})
        self.assertTrue(any("Monte Carlo" in lim for lim in report.limitations))
        self.assertTrue(any("Walk-Forward" in lim for lim in report.limitations))

    def test_naive_datetime_rejected(self):
        from omnisystem_v5.validation.report import ValidationReport, SignalStatistics, RiskStatistics
        with self.assertRaises(ValueError):
            ValidationReport(
                generated_at=datetime.now(), determinism_confirmed=True, pipeline_description="x",
                data_quality_is_valid=True, data_quality_issue_count=0, data_quality_warmup_sufficient=True,
                execution_assumptions=ExecutionConfig(), signal_statistics=SignalStatistics(),
                performance=calculate_performance_metrics([], 10000.0), risk_statistics=RiskStatistics(),
                regime_analysis={}, failure_modes=(), limitations=(),
                reproducibility_run_id="", reproducibility_dataset_hash="", reproducibility_config_summary={},
            )


class TestToDictAndMarkdown(unittest.TestCase):
    def test_to_dict_is_serializable_shape(self):
        trades = [_trade(0, 50.0)]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {"max_risk_per_trade_pct": 1.0, "min_reward_risk_ratio": 2.0})
        d = report.to_dict()
        self.assertIsInstance(d, dict)
        self.assertIn("performance", d)
        self.assertIn("signal_statistics", d)

    def test_markdown_contains_all_ten_sections(self):
        trades = [_trade(0, 50.0), _trade(1, -20.0)]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {"max_risk_per_trade_pct": 1.0, "min_reward_risk_ratio": 2.0})
        md = render_markdown(report)
        for section in ["A. System Validation", "B. Data Quality", "C. Execution Assumptions",
                         "D. Signal Statistics", "E. Trading Performance", "F. Risk Statistics",
                         "G. Regime Analysis", "H. Failure Modes", "I. Limitations", "J. Reproducibility"]:
            self.assertIn(section, md)

    def test_markdown_warns_on_small_sample(self):
        trades = [_trade(0, 50.0)]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        report = build_validation_report(result, metrics, ExecutionConfig(), {})
        md = render_markdown(report)
        self.assertIn("WARNING", md)


class TestDeterminism(unittest.TestCase):
    def test_repeated_report_generation_is_structurally_identical(self):
        trades = [_trade(0, 50.0), _trade(1, -20.0)]
        result = _fake_result(trades)
        metrics = calculate_performance_metrics(result.trades, initial_capital=10000.0)
        r1 = build_validation_report(result, metrics, ExecutionConfig(), {"max_risk_per_trade_pct": 1.0, "min_reward_risk_ratio": 2.0})
        r2 = build_validation_report(result, metrics, ExecutionConfig(), {"max_risk_per_trade_pct": 1.0, "min_reward_risk_ratio": 2.0})
        d1, d2 = r1.to_dict(), r2.to_dict()
        d1.pop("generated_at"); d2.pop("generated_at")
        self.assertEqual(d1, d2)


if __name__ == "__main__":
    unittest.main()
