import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.enums import NoTradeReason, ScalpStatus
from omnisystem_v5.intelligence.event_risk import EventRiskContext, EventRiskStatus
from omnisystem_v5.intelligence.intraday_engine import IntradayEngineConfig, detect_intraday_candidate
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig, detect_short_swing_candidate
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0, delta_minutes=15):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(minutes=delta_minutes))


def _build(tf, bars):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    env = MarketDataEnvelope(market="BTCUSDT", timeframe=tf, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _range_then_breakout(t0, delta_minutes):
    bars = []
    price = 100.0
    for i in range(60):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(minutes=delta_minutes * i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5, delta_minutes=delta_minutes))
    for i in range(60, 65):
        price += 3.0
        bars.append(_bar(t0 + timedelta(minutes=delta_minutes * i), price, price + 2, price - 1, price + 1, v=30, delta_minutes=delta_minutes))
    for i in range(65, 80):
        price -= 0.8
        bars.append(_bar(t0 + timedelta(minutes=delta_minutes * i), price, price + 1.0, price - 1.0, price - 0.3, v=15, delta_minutes=delta_minutes))
    for i in range(80, 100):
        price += 1.0 if i % 2 == 0 else -1.0
        bars.append(_bar(t0 + timedelta(minutes=delta_minutes * i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2, delta_minutes=delta_minutes))
    return bars


class TestStaleDataAcrossHorizons(unittest.TestCase):
    def test_stale_market_data_blocks_intraday_via_status_mapping(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_bars = _range_then_breakout(t0, 15)
        h1_bars = _range_then_breakout(t0, 60)
        prov_now = datetime.now(UTC)
        stale_prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=prov_now,
                                     data_timestamp=prov_now - timedelta(days=10))
        env = MarketDataEnvelope(market="BTCUSDT", timeframe=Timeframe.M15, provenance=stale_prov,
                                  quality_status=QualityStatus.STALE, bars=tuple(m15_bars))
        m15_ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        self.assertEqual(m15_ctx.status, ContextStatus.DATA_UNAVAILABLE)
        m15_q = build_quant_context("BTCUSDT", m15_ctx, QuantEngineConfig(min_bars_required=40))
        h1_ctx, h1_q = _build(Timeframe.H1, h1_bars)

        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                           contexts={Timeframe.M15: m15_ctx, Timeframe.H1: h1_ctx})
        result = detect_intraday_candidate("BTCUSDT", mtf, {Timeframe.M15: m15_q, Timeframe.H1: h1_q}, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, result.rejection_reasons)


class TestEventRiskNeverFabricatesSafety(unittest.TestCase):
    def test_unavailable_event_data_never_produces_available_status_on_candidate(self):
        t0 = datetime.now(UTC) - timedelta(minutes=240 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 240))
        d1_ctx, d1_q = _build(Timeframe.D1, _range_then_breakout(t0, 1440))
        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                           contexts={Timeframe.H4: h4_ctx, Timeframe.D1: d1_ctx})
        result = detect_short_swing_candidate("BTCUSDT", mtf, {Timeframe.H4: h4_q, Timeframe.D1: d1_q}, ShortSwingEngineConfig())
        if result.candidates:
            self.assertNotEqual(result.candidates[0].event_risk_status, EventRiskStatus.EVENT_DATA_AVAILABLE)

    def test_event_risk_context_cannot_lie_about_availability(self):
        """Even if a caller tries to construct a 'confirmed safe' verdict
        from unavailable data, the schema itself refuses."""
        with self.assertRaises(ValueError):
            EventRiskContext(
                symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_UNAVAILABLE, checked_at=datetime.now(UTC),
                high_impact_event_near=False,
            )


class TestInvalidStructureAcrossEngines(unittest.TestCase):
    def test_invalid_market_context_status_rejected_by_intraday(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_bars = _range_then_breakout(t0, 15)
        h1_bars = _range_then_breakout(t0, 60)
        prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=datetime.now(UTC), data_timestamp=m15_bars[-1].close_time)
        env = MarketDataEnvelope(market="BTCUSDT", timeframe=Timeframe.M15, provenance=prov, quality_status=QualityStatus.INVALID, bars=tuple(m15_bars))
        m15_ctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
        self.assertEqual(m15_ctx.status, ContextStatus.INVALID_CONTEXT)
        m15_q = build_quant_context("BTCUSDT", m15_ctx, QuantEngineConfig(min_bars_required=40))
        h1_ctx, h1_q = _build(Timeframe.H1, h1_bars)
        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                           contexts={Timeframe.M15: m15_ctx, Timeframe.H1: h1_ctx})
        result = detect_intraday_candidate("BTCUSDT", mtf, {Timeframe.M15: m15_q, Timeframe.H1: h1_q}, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)


class TestNeverCrashesUnderAdversarialInput(unittest.TestCase):
    def test_short_swing_survives_zero_volume_extreme_series(self):
        t0 = datetime.now(UTC) - timedelta(minutes=240 * 100)
        bars = []
        price = 500.0
        for i in range(100):
            price += 80 if i % 2 == 0 else -75
            price = max(price, 10)
            bars.append(OHLCVBar(open=price, high=price + 20, low=max(price - 20, 1), close=price + 2, volume=0,
                                  open_time=t0 + timedelta(minutes=240 * i), close_time=t0 + timedelta(minutes=240 * i + 240)))
        h4_ctx, h4_q = _build(Timeframe.H4, bars)
        d1_bars = []
        price = 500.0
        for i in range(100):
            price += 80 if i % 2 == 0 else -75
            price = max(price, 10)
            d1_bars.append(OHLCVBar(open=price, high=price + 20, low=max(price - 20, 1), close=price + 2, volume=0,
                                     open_time=t0 + timedelta(minutes=1440 * i), close_time=t0 + timedelta(minutes=1440 * i + 1440)))
        d1_ctx, d1_q = _build(Timeframe.D1, d1_bars)
        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                           contexts={Timeframe.H4: h4_ctx, Timeframe.D1: d1_ctx})
        result = detect_short_swing_candidate("BTCUSDT", mtf, {Timeframe.H4: h4_q, Timeframe.D1: d1_q}, ShortSwingEngineConfig())
        self.assertIn(result.status, (ScalpStatus.ZONE_IDENTIFIED, ScalpStatus.NO_VALID_SCALP))


if __name__ == "__main__":
    unittest.main()
