import math
import unittest
from datetime import datetime, timezone

from omnisystem_v5.decision.contracts import NormalizedCandidate, ScoreComponents, FinalDecision
from omnisystem_v5.decision.enums import CandidateStatus, DecisionOutcome, DecisionReasonCode, QualityLevel
from omnisystem_v5.decision.engine import decide
from omnisystem_v5.decision.policy import ConflictPolicy, DecisionPolicy, QualityGatePolicy, ScoringPolicy
from omnisystem_v5.risk.contracts import AccountState
from omnisystem_v5.risk.enums import Direction

UTC = timezone.utc
NOW = datetime.now(UTC)


def _cand(source="ScalpEngine", direction=Direction.LONG, entry=100.0, sl=None, tps=None,
          quality_level=QualityLevel.STRONG, symbol="BTCUSDT", generated_at=None):
    generated_at = generated_at or NOW
    if sl is None:
        sl = entry - 8 if direction == Direction.LONG else entry + 8
    if tps is None:
        tps = (entry + 24,) if direction == Direction.LONG else (entry - 24,)
    q = ScoreComponents(structural_quality=quality_level, confirmation_quality=quality_level,
                         risk_quality=quality_level, reward_quality=quality_level,
                         timeframe_alignment=quality_level, data_quality=quality_level)
    cid = NormalizedCandidate.make_id(source, symbol, direction, entry, sl, tps, "SCALP", generated_at)
    return NormalizedCandidate(candidate_id=cid, source_engine=source, horizon="SCALP", symbol=symbol,
                                direction=direction, entry=entry, stop_loss=sl, take_profits=tps,
                                generated_at=generated_at, quality=q)


def _account(**kwargs):
    defaults = dict(equity=10000.0)
    defaults.update(kwargs)
    return AccountState(**defaults)


class TestNoCandidates(unittest.TestCase):
    def test_empty_list_is_no_trade(self):
        d = decide([], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.NO_CANDIDATES_PROVIDED)
        self.assertIsNone(d.selected_candidate)
        self.assertIsNone(d.risk_result)


class TestSingleCandidateHappyPath(unittest.TestCase):
    def test_valid_candidate_produces_long(self):
        c = _cand(direction=Direction.LONG)
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.LONG)
        self.assertEqual(d.selected_candidate.candidate_id, c.candidate_id)
        self.assertTrue(d.risk_result.is_actionable)
        self.assertEqual(len(d.candidate_trace), 1)
        self.assertEqual(d.candidate_trace[0].status, CandidateStatus.ACCEPTED)

    def test_valid_short_candidate(self):
        c = _cand(direction=Direction.SHORT, entry=100.0)
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.SHORT)


class TestMultiSymbolRejected(unittest.TestCase):
    def test_mixed_symbols_rejected(self):
        a = _cand(symbol="BTCUSDT")
        b = _cand(symbol="ETHUSDT")
        d = decide([a, b], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.MULTI_SYMBOL_INPUT_NOT_SUPPORTED)
        self.assertEqual(len(d.candidate_trace), 2)
        self.assertTrue(all(r.status == CandidateStatus.REJECTED_DATA_INVALID for r in d.candidate_trace))


class TestDataIntegrity(unittest.TestCase):
    def test_nan_entry_rejected_others_survive(self):
        good = _cand(entry=100.0)
        bad = _cand(source="IntradayEngine", entry=math.nan)
        d = decide([good, bad], _account())
        self.assertEqual(d.outcome, DecisionOutcome.LONG)
        statuses = {r.candidate_id: r.status for r in d.candidate_trace}
        self.assertEqual(statuses[bad.candidate_id], CandidateStatus.REJECTED_DATA_INVALID)
        self.assertEqual(statuses[good.candidate_id], CandidateStatus.ACCEPTED)

    def test_all_invalid_is_no_trade(self):
        bad1 = _cand(entry=math.nan)
        bad2 = _cand(source="IntradayEngine", entry=-1.0)
        d = decide([bad1, bad2], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.ALL_CANDIDATES_DATA_INVALID)

    def test_infinite_stop_loss_rejected(self):
        bad = _cand(sl=math.inf)
        d = decide([bad], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)

    def test_missing_take_profits_rejected(self):
        bad = _cand(tps=())
        d = decide([bad], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.ALL_CANDIDATES_DATA_INVALID)


class TestDuplicateHandling(unittest.TestCase):
    def test_same_engine_duplicates_collapse_to_one_decision(self):
        a = _cand(entry=100.0, quality_level=QualityLevel.WEAK)
        b = _cand(entry=100.01, quality_level=QualityLevel.STRONG)
        d = decide([a, b], _account())
        self.assertEqual(d.outcome, DecisionOutcome.LONG)
        self.assertEqual(d.selected_candidate.candidate_id, b.candidate_id)
        statuses = {r.candidate_id: r.status for r in d.candidate_trace}
        self.assertEqual(statuses[a.candidate_id], CandidateStatus.REJECTED_DUPLICATE)


class TestBullBearConflict(unittest.TestCase):
    def test_close_conflict_is_no_trade(self):
        bull = _cand(source="BullEngine", direction=Direction.LONG, quality_level=QualityLevel.MODERATE)
        bear = _cand(source="BearEngine", direction=Direction.SHORT, quality_level=QualityLevel.MODERATE)
        d = decide([bull, bear], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.UNRESOLVED_DIRECTIONAL_CONFLICT)
        self.assertTrue(len(d.conflict_records) >= 1)

    def test_decisive_conflict_picks_winner(self):
        bull = _cand(source="BullEngine", direction=Direction.LONG, quality_level=QualityLevel.STRONG)
        bear = _cand(source="BearEngine", direction=Direction.SHORT, quality_level=QualityLevel.NONE)
        d = decide([bull, bear], _account())
        self.assertEqual(d.outcome, DecisionOutcome.LONG)
        statuses = {r.candidate_id: r.status for r in d.candidate_trace}
        self.assertEqual(statuses[bear.candidate_id], CandidateStatus.REJECTED_CONFLICT)


class TestScalpIntradayConflict(unittest.TestCase):
    def test_scalp_long_intraday_short_conflict(self):
        scalp = _cand(source="ScalpEngine", direction=Direction.LONG, quality_level=QualityLevel.MODERATE)
        intraday = _cand(source="IntradayEngine", direction=Direction.SHORT, quality_level=QualityLevel.MODERATE)
        d = decide([scalp, intraday], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)


class TestQualityGateInPipeline(unittest.TestCase):
    def test_low_quality_candidate_rejected_before_risk(self):
        c = _cand(quality_level=QualityLevel.NONE)
        policy = DecisionPolicy(quality_gate=QualityGatePolicy(min_moderate_plus_components=3))
        d = decide([c], _account(), decision_policy=policy)
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.NO_CANDIDATE_PASSED_QUALITY_GATE)
        self.assertEqual(d.candidate_trace[0].status, CandidateStatus.REJECTED_QUALITY)


class TestRiskVeto(unittest.TestCase):
    def test_poor_rr_candidate_vetoed_by_risk(self):
        c = _cand(entry=100.0, sl=92.0, tps=(101.0,))
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)
        self.assertEqual(d.reason_code, DecisionReasonCode.NO_CANDIDATE_PASSED_RISK_GATE)
        self.assertEqual(d.candidate_trace[0].status, CandidateStatus.REJECTED_RISK)

    def test_risk_cannot_be_bypassed_even_with_perfect_quality(self):
        c = _cand(quality_level=QualityLevel.STRONG, entry=100.0, sl=100.0, tps=(120.0,))
        d = decide([c], _account())
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)

    def test_second_ranked_candidate_tried_after_first_fails_risk(self):
        poor_rr = _cand(source="ScalpEngine", entry=100.0, sl=92.0, tps=(101.0,), quality_level=QualityLevel.STRONG)
        good_rr = _cand(source="IntradayEngine", entry=100.5, sl=95.0, tps=(120.0,), quality_level=QualityLevel.WEAK)
        d = decide([poor_rr, good_rr], _account(), decision_policy=DecisionPolicy(max_risk_attempts=3))
        self.assertIn(d.outcome, (DecisionOutcome.LONG, DecisionOutcome.NO_TRADE))


class TestMultipleEngineCandidatesNoConsensus(unittest.TestCase):
    def test_no_candidate_reaches_threshold_is_no_trade(self):
        c1 = _cand(source="ScalpEngine", quality_level=QualityLevel.NONE)
        c2 = _cand(source="IntradayEngine", entry=105.0, quality_level=QualityLevel.NONE)
        policy = DecisionPolicy(quality_gate=QualityGatePolicy(min_moderate_plus_components=5))
        d = decide([c1, c2], _account(), decision_policy=policy)
        self.assertEqual(d.outcome, DecisionOutcome.NO_TRADE)


class TestPolicyVersioning(unittest.TestCase):
    def test_policy_version_recorded_on_decision(self):
        c = _cand()
        policy = DecisionPolicy(policy_version="2.3.1")
        d = decide([c], _account(), decision_policy=policy)
        self.assertEqual(d.policy_version, "2.3.1")

    def test_changing_scoring_policy_changes_outcome(self):
        a = _cand(source="ScalpEngine", entry=100.0)
        object.__setattr__(a, "quality", ScoreComponents(risk_quality=QualityLevel.STRONG, structural_quality=QualityLevel.NONE,
                                                           confirmation_quality=QualityLevel.NONE, reward_quality=QualityLevel.NONE,
                                                           timeframe_alignment=QualityLevel.NONE, data_quality=QualityLevel.NONE))
        b = _cand(source="IntradayEngine", entry=100.5)
        object.__setattr__(b, "quality", ScoreComponents(risk_quality=QualityLevel.NONE, structural_quality=QualityLevel.MODERATE,
                                                           confirmation_quality=QualityLevel.MODERATE, reward_quality=QualityLevel.MODERATE,
                                                           timeframe_alignment=QualityLevel.MODERATE, data_quality=QualityLevel.MODERATE))
        policy_risk_first = DecisionPolicy(
            scoring=ScoringPolicy(component_priority_order=("risk_quality", "structural_quality", "confirmation_quality",
                                                              "reward_quality", "timeframe_alignment", "data_quality",
                                                              "regime_compatibility", "conflict_penalty")),
            quality_gate=QualityGatePolicy(min_moderate_plus_components=1),
            conflict=ConflictPolicy(min_decisive_component_margin=1),
        )
        d1 = decide([a, b], _account(), decision_policy=policy_risk_first)
        self.assertEqual(d1.selected_candidate.candidate_id, a.candidate_id)

        policy_structure_first = DecisionPolicy(
            scoring=ScoringPolicy(component_priority_order=("structural_quality", "risk_quality", "confirmation_quality",
                                                              "reward_quality", "timeframe_alignment", "data_quality",
                                                              "regime_compatibility", "conflict_penalty")),
            quality_gate=QualityGatePolicy(min_moderate_plus_components=1),
            conflict=ConflictPolicy(min_decisive_component_margin=1),
        )
        d2 = decide([a, b], _account(), decision_policy=policy_structure_first)
        self.assertEqual(d2.selected_candidate.candidate_id, b.candidate_id)


class TestDeterminism(unittest.TestCase):
    def test_identical_input_identical_output(self):
        c = _cand()
        fixed_time = NOW
        d1 = decide([c], _account(), now=fixed_time)
        d2 = decide([c], _account(), now=fixed_time)
        self.assertEqual(d1.decision_id, d2.decision_id)
        self.assertEqual(d1.outcome, d2.outcome)
        self.assertEqual(d1.reason_code, d2.reason_code)

    def test_no_hidden_state_across_repeated_calls(self):
        c = _cand()
        outcomes = {decide([c], _account()).outcome for _ in range(5)}
        self.assertEqual(len(outcomes), 1)


class TestDecisionTraceCompleteness(unittest.TestCase):
    def test_every_input_candidate_appears_exactly_once_in_trace(self):
        candidates = [_cand(source=f"Engine{i}", entry=100.0 + i * 2) for i in range(4)]
        d = decide(candidates, _account())
        trace_ids = [r.candidate_id for r in d.candidate_trace]
        self.assertEqual(sorted(trace_ids), sorted(c.candidate_id for c in candidates))
        self.assertEqual(len(trace_ids), len(set(trace_ids)))


class TestContractValidation(unittest.TestCase):
    def test_no_trade_cannot_carry_selected_candidate(self):
        with self.assertRaises(ValueError):
            FinalDecision(
                decision_id="x", decision_version="1.0", policy_version="1.0", generated_at=NOW,
                outcome=DecisionOutcome.NO_TRADE, symbol="BTCUSDT",
                selected_candidate=_cand(), risk_result=None,
            )

    def test_long_decision_requires_actionable_risk_result(self):
        with self.assertRaises(ValueError):
            FinalDecision(
                decision_id="x", decision_version="1.0", policy_version="1.0", generated_at=NOW,
                outcome=DecisionOutcome.LONG, symbol="BTCUSDT",
                selected_candidate=_cand(), risk_result=None,
            )


if __name__ == "__main__":
    unittest.main()
