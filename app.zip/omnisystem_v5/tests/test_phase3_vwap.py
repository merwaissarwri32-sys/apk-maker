import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.quant.vwap import calculate_rolling_vwap, calculate_session_vwap, calculate_vwap
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bar(t, h, l, c, v, o=None):
    return OHLCVBar(open=o if o is not None else c, high=h, low=l, close=c, volume=v,
                     open_time=t, close_time=t + timedelta(hours=1))


class TestVwap(unittest.TestCase):
    def test_vwap_matches_hand_calculation(self):
        t0 = datetime.now(UTC)
        bars = [
            _bar(t0, h=10, l=8, c=9, v=100),     # typical=9,  weighted=900
            _bar(t0 + timedelta(hours=1), h=12, l=10, c=11, v=200),  # typical=11, weighted=2200
        ]
        # VWAP = (900+2200)/(100+200) = 3100/300 = 10.3333...
        vwap = calculate_vwap(bars)
        self.assertAlmostEqual(vwap, 3100 / 300, places=8)

    def test_zero_total_volume_returns_none(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 10, 8, 9, v=0), _bar(t0 + timedelta(hours=1), 12, 10, 11, v=0)]
        self.assertIsNone(calculate_vwap(bars))

    def test_empty_bars_raises(self):
        with self.assertRaises(InsufficientDataError):
            calculate_vwap([])

    def test_session_vwap_uses_full_series(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0 + timedelta(hours=i), 10, 8, 9, v=10) for i in range(5)]
        self.assertAlmostEqual(calculate_session_vwap(bars), 9.0)

    def test_rolling_vwap_uses_only_recent_period(self):
        t0 = datetime.now(UTC)
        # first 3 bars have very different price than the last 2
        bars = [_bar(t0 + timedelta(hours=i), 100, 98, 99, v=10) for i in range(3)]
        bars += [_bar(t0 + timedelta(hours=3 + i), 10, 8, 9, v=10) for i in range(2)]
        rolling = calculate_rolling_vwap(bars, period=2)
        self.assertAlmostEqual(rolling, 9.0)  # only last 2 bars considered
        full = calculate_session_vwap(bars)
        self.assertNotAlmostEqual(full, rolling)

    def test_rolling_vwap_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 10, 8, 9, v=10)]
        with self.assertRaises(InsufficientDataError):
            calculate_rolling_vwap(bars, period=5)

    def test_rolling_vwap_invalid_period_raises(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0, 10, 8, 9, v=10)]
        with self.assertRaises(ValueError):
            calculate_rolling_vwap(bars, period=0)

    def test_mixed_zero_and_nonzero_volume_still_computes(self):
        t0 = datetime.now(UTC)
        bars = [
            _bar(t0, 10, 8, 9, v=0),
            _bar(t0 + timedelta(hours=1), 12, 10, 11, v=100),
        ]
        vwap = calculate_vwap(bars)
        self.assertAlmostEqual(vwap, 11.0)  # only the nonzero-volume bar contributes weight


if __name__ == "__main__":
    unittest.main()
