import unittest
from datetime import datetime, timezone

from omnisystem_v5.intelligence.event_risk import (
    EventRiskContext,
    EventRiskStatus,
    NullEventRiskProvider,
)

UTC = timezone.utc


class TestEventRiskContext(unittest.TestCase):
    def test_null_provider_always_reports_unavailable(self):
        ctx = NullEventRiskProvider().get_event_risk("BTCUSDT")
        self.assertEqual(ctx.status, EventRiskStatus.EVENT_DATA_UNAVAILABLE)
        self.assertIsNone(ctx.high_impact_event_near)
        self.assertTrue(len(ctx.reasons) > 0)

    def test_unavailable_never_blocks_trading_by_itself(self):
        ctx = NullEventRiskProvider().get_event_risk("BTCUSDT")
        self.assertFalse(ctx.blocks_trading(), "unavailable data must never be treated as confirmed risk")

    def test_stale_never_blocks_trading_by_itself(self):
        ctx = EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_STALE, checked_at=datetime.now(UTC))
        self.assertFalse(ctx.blocks_trading())

    def test_available_with_confirmed_event_blocks_trading(self):
        ctx = EventRiskContext(
            symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_AVAILABLE, checked_at=datetime.now(UTC),
            high_impact_event_near=True, window_minutes=60,
        )
        self.assertTrue(ctx.blocks_trading())

    def test_available_with_no_event_does_not_block(self):
        ctx = EventRiskContext(
            symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_AVAILABLE, checked_at=datetime.now(UTC),
            high_impact_event_near=False,
        )
        self.assertFalse(ctx.blocks_trading())

    def test_naive_datetime_rejected(self):
        with self.assertRaises(ValueError):
            EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_UNAVAILABLE, checked_at=datetime.now())

    def test_cannot_report_verdict_without_available_status(self):
        """This is the core anti-fabrication rule: you cannot set
        high_impact_event_near unless status says the data is actually
        available."""
        with self.assertRaises(ValueError):
            EventRiskContext(
                symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_UNAVAILABLE, checked_at=datetime.now(UTC),
                high_impact_event_near=False,
            )
        with self.assertRaises(ValueError):
            EventRiskContext(
                symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_STALE, checked_at=datetime.now(UTC),
                high_impact_event_near=True,
            )


if __name__ == "__main__":
    unittest.main()
