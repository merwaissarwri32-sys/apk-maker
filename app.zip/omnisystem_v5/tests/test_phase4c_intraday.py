import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.enums import NoTradeReason, ScalpStatus
from omnisystem_v5.intelligence.event_risk import EventRiskContext, EventRiskStatus
from omnisystem_v5.intelligence.intraday_engine import IntradayEngineConfig, detect_intraday_candidate
from omnisystem_v5.intelligence.intraday_schema import IntradaySchemaError, IntradayScenarioType
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0, minutes=15):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(minutes=minutes))


def _range_then_breakout(t0, step_minutes=15):
    bars = []
    price = 100.0
    for i in range(60):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(minutes=step_minutes * i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5, minutes=step_minutes))
    for i in range(60, 65):
        price += 3.0
        bars.append(_bar(t0 + timedelta(minutes=step_minutes * i), price, price + 2, price - 1, price + 1, v=30, minutes=step_minutes))
    for i in range(65, 80):
        price -= 0.8
        bars.append(_bar(t0 + timedelta(minutes=step_minutes * i), price, price + 1.0, price - 1.0, price - 0.3, v=15, minutes=step_minutes))
    for i in range(80, 100):
        price += 1.0 if i % 2 == 0 else -1.0
        bars.append(_bar(t0 + timedelta(minutes=step_minutes * i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2, minutes=step_minutes))
    return bars


def _flat_bars(n, t0, step_minutes=15):
    return [_bar(t0 + timedelta(minutes=step_minutes * i), 100.0, 100.3, 99.7, 100.0, minutes=step_minutes) for i in range(n)]


def _build(tf, bars):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    env = MarketDataEnvelope(market="BTCUSDT", timeframe=tf, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q):
    mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                       contexts={Timeframe.M15: m15_ctx, Timeframe.H1: h1_ctx})
    return mtf, {Timeframe.M15: m15_q, Timeframe.H1: h1_q}


class TestIntradayPositive(unittest.TestCase):
    def test_hand_verified_aligned_uptrend_produces_trend_continuation(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _range_then_breakout(t0, 15))
        h1_ctx, h1_q = _build(Timeframe.H1, _range_then_breakout(t0, 60))
        mtf, quant_by_tf = _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q)

        result = detect_intraday_candidate("BTCUSDT", mtf, quant_by_tf, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        c = result.candidates[0]
        self.assertEqual(c.scenario_type, IntradayScenarioType.TREND_CONTINUATION)
        self.assertEqual(c.direction.value, "BULLISH")
        self.assertGreaterEqual(c.risk_reward.reward_risk_ratio, IntradayEngineConfig().min_reward_risk_ratio)
        self.assertEqual(c.timeframe, Timeframe.M15)
        self.assertEqual(c.higher_timeframe, Timeframe.H1)


class TestIntradayRejections(unittest.TestCase):
    def test_missing_higher_timeframe_context(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _range_then_breakout(t0, 15))
        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC), contexts={Timeframe.M15: m15_ctx})
        result = detect_intraday_candidate("BTCUSDT", mtf, {Timeframe.M15: m15_q}, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, result.rejection_reasons)

    def test_conflicting_higher_and_execution_timeframe_rejected(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _range_then_breakout(t0, 15))
        # opposite direction on 1H (downtrend construction)
        down_bars = []
        price = 200.0
        for i in range(100):
            price -= 0.5 if (i % 6 < 4) else -0.3
            down_bars.append(_bar(t0 + timedelta(minutes=60 * i), price, price + 1.2, price - 1.2, price - 0.2, minutes=60))
        h1_ctx, h1_q = _build(Timeframe.H1, down_bars)
        mtf, quant_by_tf = _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q)
        result = detect_intraday_candidate("BTCUSDT", mtf, quant_by_tf, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_CONFLICTING_STRUCTURE, result.rejection_reasons)

    def test_flat_market_rejected_as_unstable_regime(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _flat_bars(100, t0, 15))
        h1_ctx, h1_q = _build(Timeframe.H1, _flat_bars(100, t0, 60))
        mtf, quant_by_tf = _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q)
        result = detect_intraday_candidate("BTCUSDT", mtf, quant_by_tf, IntradayEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, result.rejection_reasons)

    def test_poor_rr_rejected_with_high_minimum(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _range_then_breakout(t0, 15))
        h1_ctx, h1_q = _build(Timeframe.H1, _range_then_breakout(t0, 60))
        mtf, quant_by_tf = _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q)
        result = detect_intraday_candidate("BTCUSDT", mtf, quant_by_tf, IntradayEngineConfig(min_reward_risk_ratio=100.0))
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)

    def test_confirmed_event_risk_blocks_intraday(self):
        t0 = datetime.now(UTC) - timedelta(minutes=15 * 100)
        m15_ctx, m15_q = _build(Timeframe.M15, _range_then_breakout(t0, 15))
        h1_ctx, h1_q = _build(Timeframe.H1, _range_then_breakout(t0, 60))
        mtf, quant_by_tf = _mtf_and_quant(m15_ctx, m15_q, h1_ctx, h1_q)
        event_risk = EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_AVAILABLE,
                                       checked_at=datetime.now(UTC), high_impact_event_near=True, window_minutes=30)
        result = detect_intraday_candidate("BTCUSDT", mtf, quant_by_tf, IntradayEngineConfig(), event_risk=event_risk)
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_HIGH_EVENT_RISK, result.rejection_reasons)


class TestIntradayDistinctFromScalp(unittest.TestCase):
    def test_schema_rejects_wrong_horizon(self):
        from omnisystem_v5.intelligence.intraday_schema import IntradayCandidate, IntradayCandidateEvidence
        from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias, ExpectedHoldingPeriod, Horizon, MarketRegime
        from omnisystem_v5.intelligence.scalp_schema import PriceZone
        now = datetime.now(UTC)
        ev = IntradayCandidateEvidence(*(AlignmentLevel.NONE,) * 8)
        with self.assertRaises(IntradaySchemaError):
            IntradayCandidate(
                symbol="BTCUSDT", horizon=Horizon.SCALP, scenario_type=IntradayScenarioType.TREND_CONTINUATION,
                direction=DirectionBias.BULLISH, timeframe=Timeframe.M15, higher_timeframe=Timeframe.H1,
                calculated_at=now, expected_holding_period=ExpectedHoldingPeriod.HOURS,
                preferred_entry_zone=PriceZone(100, 100), invalidation_zone=PriceZone(95, 95),
                target_zones=(PriceZone(110, 110),), risk_reward=None, evidence=ev,
                supporting_evidence=(), contradicting_evidence=(), market_regime=MarketRegime.TREND,
                data_quality="OK", confirmation_required=True, status=ScalpStatus.ZONE_IDENTIFIED,
            )

    def test_evidence_has_no_volume_or_rr_quality_components(self):
        """Distinctness check: Intraday evidence explicitly does NOT carry
        Scalp's volume_alignment/risk_reward_quality fields."""
        from omnisystem_v5.intelligence.intraday_schema import IntradayCandidateEvidence
        fields = IntradayCandidateEvidence.__dataclass_fields__.keys()
        self.assertNotIn("volume_alignment", fields)
        self.assertNotIn("risk_reward_quality", fields)
        self.assertIn("higher_timeframe_alignment", fields)
        self.assertIn("execution_timeframe_alignment", fields)


if __name__ == "__main__":
    unittest.main()
