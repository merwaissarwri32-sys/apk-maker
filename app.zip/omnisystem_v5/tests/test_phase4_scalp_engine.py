import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.enums import NoTradeReason, ScalpStatus
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig, detect_scalp_candidate
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _envelope(bars, timeframe=Timeframe.H1):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))


def _build_contexts(bars, timeframe=Timeframe.H1):
    env = _envelope(bars, timeframe)
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _range_then_breakout_bars(t0):
    """Uptrend -> sharp spike (leaves an untouched swing-high resistance
    far above) -> pullback -> consolidation with a nearby swing low and
    rising volume. Hand-verified to produce: TrendState.UPTREND, a valid
    invalidation just below price, a valid target at the old spike high
    far above price (healthy R:R), and enough confluence (volume, FVG,
    VWAP, volatility) to pass the default quality filter."""
    bars = []
    price = 100.0
    for i in range(60):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5))
    for i in range(60, 65):
        price += 3.0
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 2, price - 1, price + 1, v=30))
    for i in range(65, 80):
        price -= 0.8
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price - 0.3, v=15))
    for i in range(80, 100):
        price += 1.0 if i % 2 == 0 else -1.0
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2))
    return bars


class TestScalpEngineAcceptance(unittest.TestCase):
    def test_hand_verified_uptrend_with_untouched_resistance_produces_candidate(self):
        """Hand-verified construction (see _range_then_breakout_bars docstring)
        that is known to produce a valid bullish ZONE_IDENTIFIED candidate
        with a healthy R:R — this is the positive-path proof that the full
        Bull Engine -> Scalp Engine pipeline can actually accept a setup,
        not just reject everything."""
        t0 = datetime.now(UTC) - timedelta(hours=100)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())

        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        c = result.candidates[0]
        self.assertEqual(c.direction.value, "BULLISH")
        self.assertGreaterEqual(c.risk_reward.reward_risk_ratio, ScalpEngineConfig().min_reward_risk_ratio)
        self.assertTrue(c.confirmation_required)
        self.assertEqual(c.status, ScalpStatus.ZONE_IDENTIFIED)
        self.assertLess(c.invalidation_zone.bottom, mctx.current_price)
        self.assertGreater(c.target_zones[0].bottom, mctx.current_price)


class TestScalpEngineRejections(unittest.TestCase):
    def test_unstable_regime_rejected(self):
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = [_bar(t0 + timedelta(hours=i), 100.0, 100.5, 99.5, 100.0) for i in range(90)]  # perfectly flat -> undefined trend, normal vol -> unstable
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, result.rejection_reasons)

    def test_no_scenario_either_side_rejected(self):
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = [_bar(t0 + timedelta(hours=i), 100.0, 100.5, 99.5, 100.0) for i in range(90)]
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        # flat market -> unstable regime caught first, or conflicting structure — either is a valid NO_TRADE
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)

    def test_insufficient_data_rejected(self):
        from omnisystem_v5.context.schema import MarketContext
        from omnisystem_v5.quant.schema import QuantContext
        from omnisystem_v5.context.enums import ContextStatus
        from omnisystem_v5.quant.enums import QuantStatus
        t0 = datetime.now(UTC)
        mctx = MarketContext(symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.INSUFFICIENT_CONTEXT,
                              calculated_at=t0, provenance=None)
        qctx = QuantContext(symbol="BTCUSDT", timeframe=Timeframe.H1, status=QuantStatus.INSUFFICIENT_DATA,
                             calculated_at=t0, provenance=None)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_INSUFFICIENT_DATA, result.rejection_reasons)

    def test_poor_rr_rejected_with_high_minimum(self):
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = _range_then_breakout_bars(t0)
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        # an absurdly high min R:R should force rejection regardless of setup quality
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig(min_reward_risk_ratio=100.0))
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)


class TestScalpEngineNeverCrashes(unittest.TestCase):
    def test_zero_volume_series_does_not_crash(self):
        t0 = datetime.now(UTC) - timedelta(hours=90)
        bars = _range_then_breakout_bars(t0)
        bars = [OHLCVBar(open=b.open, high=b.high, low=b.low, close=b.close, volume=0,
                          open_time=b.open_time, close_time=b.close_time) for b in bars]
        mctx, qctx = _build_contexts(bars)
        bull = build_bull_case("BTCUSDT", mctx, qctx)
        bear = build_bear_case("BTCUSDT", mctx, qctx)
        result = detect_scalp_candidate("BTCUSDT", mctx, qctx, bull, bear, ScalpEngineConfig())
        self.assertIn(result.status, (ScalpStatus.ZONE_IDENTIFIED, ScalpStatus.NO_VALID_SCALP))


if __name__ == "__main__":
    unittest.main()
