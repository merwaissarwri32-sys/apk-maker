import unittest

from omnisystem_v5.risk.contracts import InstrumentSpec
from omnisystem_v5.risk.enums import RejectionReasonCode, WarningCode
from omnisystem_v5.risk.position_sizing import calculate_position_size


class TestPositionSizingBasic(unittest.TestCase):
    def test_hand_calculation(self):
        # equity=10000, risk=1% -> $100 risk; entry=100, sl=98 -> per-unit risk=2 -> qty=50
        r = calculate_position_size(equity=10000, risk_pct=1.0, entry=100.0, stop_loss=98.0)
        self.assertAlmostEqual(r.quantity, 50.0)
        self.assertAlmostEqual(r.actual_risk_amount, 100.0)
        self.assertAlmostEqual(r.notional, 5000.0)
        self.assertTrue(r.ok)

    def test_short_direction_uses_absolute_distance(self):
        r = calculate_position_size(equity=10000, risk_pct=1.0, entry=100.0, stop_loss=105.0)
        self.assertAlmostEqual(r.quantity, 20.0)  # per-unit risk=5 -> 100/5=20


class TestPositionSizingBoundary(unittest.TestCase):
    def test_zero_risk_distance_is_impossible(self):
        r = calculate_position_size(equity=10000, risk_pct=1.0, entry=100.0, stop_loss=100.0)
        self.assertFalse(r.ok)
        self.assertIn(RejectionReasonCode.POSITION_SIZE_IMPOSSIBLE, r.rejection_reasons)

    def test_zero_risk_pct_yields_zero_quantity(self):
        r = calculate_position_size(equity=10000, risk_pct=0.0, entry=100.0, stop_loss=98.0)
        self.assertFalse(r.ok)
        self.assertIn(RejectionReasonCode.POSITION_SIZE_ZERO, r.rejection_reasons)

    def test_negative_risk_pct_yields_zero_quantity(self):
        r = calculate_position_size(equity=10000, risk_pct=-1.0, entry=100.0, stop_loss=98.0)
        self.assertFalse(r.ok)
        self.assertIn(RejectionReasonCode.POSITION_SIZE_ZERO, r.rejection_reasons)


class TestPositionSizingWithInstrument(unittest.TestCase):
    def test_position_step_rounds_down_never_up(self):
        instr = InstrumentSpec(symbol="BTCUSDT", position_step=1.0)
        # raw quantity would be 50.7 -> must floor to 50, never ceil to 51
        r = calculate_position_size(equity=10140, risk_pct=1.0, entry=100.0, stop_loss=98.0, instrument=instr)
        self.assertAlmostEqual(r.quantity, 50.0)
        self.assertIn(WarningCode.POSITION_SIZE_ROUNDED_DOWN, r.warnings)
        # actual risk taken must never exceed target risk due to rounding
        target_risk = 10140 * 0.01
        self.assertLessEqual(r.actual_risk_amount, target_risk + 1e-9)

    def test_below_min_position_size_is_impossible_never_bumped_up(self):
        instr = InstrumentSpec(symbol="BTCUSDT", min_position_size=100.0)
        r = calculate_position_size(equity=10000, risk_pct=1.0, entry=100.0, stop_loss=98.0, instrument=instr)
        self.assertFalse(r.ok)
        self.assertIn(RejectionReasonCode.POSITION_SIZE_IMPOSSIBLE, r.rejection_reasons)
        self.assertIsNone(r.quantity)

    def test_contract_size_scales_per_unit_risk(self):
        instr = InstrumentSpec(symbol="XAUUSD", contract_size=100.0)
        # per-unit risk = 2 * 100 = 200 -> qty = 100/200 = 0.5
        r = calculate_position_size(equity=10000, risk_pct=1.0, entry=100.0, stop_loss=98.0, instrument=instr)
        self.assertAlmostEqual(r.quantity, 0.5)

    def test_never_inflates_size_to_reach_a_reward_target(self):
        """There is no reward/target parameter in calculate_position_size
        at all — this test documents that fact structurally."""
        import inspect
        sig = inspect.signature(calculate_position_size)
        self.assertNotIn("target", sig.parameters)
        self.assertNotIn("reward", sig.parameters)
        self.assertNotIn("take_profit", sig.parameters)


if __name__ == "__main__":
    unittest.main()
