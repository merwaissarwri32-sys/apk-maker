"""Phase 12 - deduplication, lifecycle, cooldown, expiry, re-notification, redelivery and the persistence seam. SYNTHETIC."""
import dataclasses
import json
import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.alerts.construction import build_alert
from omnisystem_v5.alerts.dedup import (AlertDedupPolicy, AlertDedupState, InMemoryAlertStateStore, expire, observe, record_delivery)
from omnisystem_v5.alerts.enums import AlertDedupVerdict as V
from omnisystem_v5.alerts.enums import AlertSeverity, AlertState
from omnisystem_v5.alerts.errors import AlertConfigError, AlertValidationError
from omnisystem_v5.tests.test_alerts_domain import cand

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
POL = AlertDedupPolicy(cooldown_seconds=900, expiry_seconds=300, max_redeliveries=2, observation_memory=32, retention_seconds=86400)


def at(sec):
    return T0 + timedelta(seconds=sec)


def alert_at(sec, key, state="UNAVAILABLE", provider="p1"):
    c = cand(state=state, key=key, family=(("provider", provider),), observed_at=at(sec))
    return build_alert(c, AlertSeverity.CRITICAL, at(sec))


def feed(steps, policy=POL, state=None):
    """steps: (seconds, observation_key[, state[, provider]]) -> (final_state, [verdicts])"""
    state, out = state or AlertDedupState(), []
    for s in steps:
        state, v = observe(state, alert_at(*s), at(s[0]), policy)
        out.append(v)
    return state, out


class TestVerdicts(unittest.TestCase):
    def test_first_sighting_is_new(self):
        st, v = feed([(0, "a")])
        self.assertEqual(v, [V.NEW])
        self.assertEqual((st.records[0].state, st.records[0].seen_count), (AlertState.ACTIVE, 1))

    def test_same_observation_again_is_an_exact_duplicate_and_changes_nothing(self):
        st1, _ = feed([(0, "a")])
        st2, v = feed([(10, "a")], state=st1)
        self.assertEqual(v, [V.EXACT_DUPLICATE])
        self.assertEqual(st1, st2)

    def test_newer_sighting_of_the_same_alert_is_still_active(self):
        st, v = feed([(0, "a"), (100, "b"), (200, "c")])
        self.assertEqual(v, [V.NEW, V.STILL_ACTIVE, V.STILL_ACTIVE])
        r = st.records[0]
        self.assertEqual((r.seen_count, r.last_seen_at, r.last_notified_at), (3, at(200), at(0)))

    def test_material_change_notifies_and_replaces_the_fingerprint(self):
        st, v = feed([(0, "a", "UNAVAILABLE"), (10, "b", "DEGRADED")])
        self.assertEqual(v, [V.NEW, V.MATERIAL_CHANGE])
        self.assertEqual(len(st.records), 1)
        self.assertEqual(st.records[0].last_notified_at, at(10))

    def test_material_change_bypasses_cooldown_after_expiry(self):
        _, v = feed([(0, "a", "UNAVAILABLE"), (400, "b", "DEGRADED")])
        self.assertEqual(v, [V.NEW, V.MATERIAL_CHANGE])

    def test_expiry_boundary_is_strict(self):
        _, v = feed([(0, "a"), (300, "b")])          # now - last_seen == expiry  -> still active
        self.assertEqual(v, [V.NEW, V.STILL_ACTIVE])
        st, v = feed([(0, "a"), (301, "b")])         # > expiry -> expired; re-appearance inside cooldown
        self.assertEqual(v, [V.NEW, V.COOLDOWN])
        self.assertEqual(st.records[0].state, AlertState.EXPIRED)

    def test_cooldown_boundary_is_strict_then_renotify(self):
        _, v = feed([(0, "a"), (301, "b"), (899, "c")])
        self.assertEqual(v, [V.NEW, V.COOLDOWN, V.COOLDOWN])
        st, v = feed([(0, "a"), (301, "b"), (900, "c")])
        self.assertEqual(v, [V.NEW, V.COOLDOWN, V.RENOTIFY])
        self.assertEqual((st.records[0].state, st.records[0].last_notified_at), (AlertState.ACTIVE, at(900)))

    def test_expired_records_are_forgotten_after_retention_then_new_again(self):
        _, v = feed([(0, "a"), (86399, "b")])
        self.assertEqual(v, [V.NEW, V.RENOTIFY])
        _, v = feed([(0, "a"), (86400, "b")])
        self.assertEqual(v, [V.NEW, V.NEW])

    def test_families_do_not_interfere_and_state_order_is_deterministic(self):
        st, v = feed([(0, "a", "UNAVAILABLE", "p2"), (1, "b", "UNAVAILABLE", "p1"), (2, "c", "UNAVAILABLE", "p2")])
        self.assertEqual(v, [V.NEW, V.NEW, V.STILL_ACTIVE])
        self.assertEqual([r.family for r in st.records], sorted(r.family for r in st.records))

    def test_observation_memory_is_bounded(self):
        pol = dataclasses.replace(POL, observation_memory=2)
        st, v = feed([(0, "a"), (1, "b"), (2, "c"), (3, "a")], policy=pol)
        self.assertEqual(v[-1], V.STILL_ACTIVE)            # "a" was evicted from the bounded memory (documented trade-off)
        self.assertLessEqual(len(st.records[0].observations), 2)

    def test_same_inputs_give_identical_states(self):
        steps = [(0, "a"), (50, "b"), (400, "c"), (950, "d")]
        self.assertEqual(feed(steps), feed(steps))


class TestExpiryFunction(unittest.TestCase):
    def test_expire_reports_newly_expired_records_once(self):
        st, _ = feed([(0, "a")])
        st2, gone = expire(st, at(301), POL)
        self.assertEqual([r.state for r in gone], [AlertState.EXPIRED])
        st3, gone2 = expire(st2, at(302), POL)
        self.assertEqual(gone2, ())
        self.assertEqual(st3, st2)

    def test_active_alerts_are_not_expired_early(self):
        st, _ = feed([(0, "a")])
        self.assertEqual(expire(st, at(300), POL)[1], ())


class TestRedelivery(unittest.TestCase):
    def setUp(self):
        self.st, _ = feed([(0, "a")])
        self.fam = self.st.records[0].family

    def test_undelivered_notification_is_redelivered_on_a_newer_sighting_and_is_bounded(self):
        st = record_delivery(self.st, self.fam, deliverable=True, delivered=False)
        st, v = feed([(10, "b"), (20, "c"), (30, "d")], state=st)
        self.assertEqual(v, [V.REDELIVER, V.REDELIVER, V.STILL_ACTIVE])            # max_redeliveries = 2
        self.assertTrue(st.records[0].pending_delivery)

    def test_delivery_success_or_nothing_deliverable_clears_the_flag(self):
        pend = record_delivery(self.st, self.fam, deliverable=True, delivered=False)
        self.assertFalse(record_delivery(pend, self.fam, deliverable=True, delivered=True).records[0].pending_delivery)
        self.assertFalse(record_delivery(pend, self.fam, deliverable=False, delivered=False).records[0].pending_delivery)

    def test_replayed_observation_never_redelivers(self):
        st = record_delivery(self.st, self.fam, deliverable=True, delivered=False)
        _, v = feed([(10, "a")], state=st)
        self.assertEqual(v, [V.EXACT_DUPLICATE])

    def test_unknown_family_is_ignored(self):
        self.assertEqual(record_delivery(self.st, "f" * 20, deliverable=True, delivered=False), self.st)


class TestPolicyValidation(unittest.TestCase):
    def test_invalid_policies_fail_closed(self):
        for kw in (dict(cooldown_seconds=-1), dict(expiry_seconds=0), dict(expiry_seconds=float("nan")), dict(max_redeliveries=-1),
                   dict(observation_memory=0), dict(retention_seconds=10, cooldown_seconds=900), dict(cooldown_seconds=True), dict(expiry_seconds="5")):
            with self.subTest(kw=kw):
                with self.assertRaises(AlertConfigError):
                    AlertDedupPolicy(**kw)


class TestPersistenceSeam(unittest.TestCase):
    def test_state_round_trips_through_plain_json(self):
        st, _ = feed([(0, "a", "UNAVAILABLE", "p1"), (5, "b", "DEGRADED", "p2"), (301, "c", "UNAVAILABLE", "p1")])
        wire = json.dumps(st.to_dict(), sort_keys=True)
        self.assertEqual(AlertDedupState.from_dict(json.loads(wire)), st)

    def test_restart_keeps_idempotency_when_state_is_restored(self):
        st, _ = feed([(0, "a"), (301, "b")])
        restored = InMemoryAlertStateStore(AlertDedupState.from_dict(json.loads(json.dumps(st.to_dict()))))
        _, v = feed([(302, "b"), (303, "c")], state=restored.load())
        self.assertEqual(v, [V.EXACT_DUPLICATE, V.COOLDOWN])
        _, lost = feed([(302, "b")])                                   # WITHOUT restored state the process would re-notify
        self.assertEqual(lost, [V.NEW])

    def test_malformed_stored_state_fails_closed(self):
        st, _ = feed([(0, "a")])
        good = st.to_dict()
        bad = []
        bad.append({"records": [{**good["records"][0], "state": "DEAD"}]})
        bad.append({"records": [{k: v for k, v in good["records"][0].items() if k != "family"}]})
        bad.append({"records": [{**good["records"][0], "first_seen_at": "2026-01-01T00:00:00"}]})
        bad.append({"records": [{**good["records"][0], "last_seen_at": "garbage"}]})
        bad.append({})
        for b in bad:
            with self.subTest(b=str(b)[:40]):
                with self.assertRaises(AlertValidationError):
                    AlertDedupState.from_dict(b)

    def test_in_memory_store_is_a_plain_load_save_seam(self):
        s = InMemoryAlertStateStore()
        self.assertEqual(s.load(), AlertDedupState())
        st, _ = feed([(0, "a")])
        s.save(st)
        self.assertIs(s.load(), st)


if __name__ == "__main__":
    unittest.main()
