import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.calculations.swings import find_swing_points, label_hh_hl_lh_ll
from omnisystem_v5.calculations.trend import classify_trend
from omnisystem_v5.context.enums import StructureEventType, SwingType, TrendState
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_highs_lows(values, t0):
    """values: list of (high, low) tuples. open/close kept inside the range."""
    bars = []
    for i, (h, l) in enumerate(values):
        mid = (h + l) / 2
        bars.append(
            OHLCVBar(
                open=mid, high=h, low=l, close=mid,
                volume=10.0,
                open_time=t0 + timedelta(hours=i),
                close_time=t0 + timedelta(hours=i, minutes=59),
            )
        )
    return bars


class TestFindSwingPoints(unittest.TestCase):
    def test_simple_single_swing_high(self):
        t0 = datetime.now(UTC)
        # index 2 is a clean local max with window=2
        hl = [(10, 5), (11, 6), (15, 12), (11, 6), (10, 5)]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        highs = [s for s in swings if s.swing_type == SwingType.HIGH]
        self.assertEqual(len(highs), 1)
        self.assertEqual(highs[0].bar_index, 2)
        self.assertEqual(highs[0].price, 15)
        self.assertEqual(highs[0].confirmed_at_index, 4)

    def test_simple_single_swing_low(self):
        t0 = datetime.now(UTC)
        hl = [(20, 15), (19, 14), (18, 5), (19, 14), (20, 15)]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        lows = [s for s in swings if s.swing_type == SwingType.LOW]
        self.assertEqual(len(lows), 1)
        self.assertEqual(lows[0].price, 5)

    def test_tie_is_not_a_swing(self):
        t0 = datetime.now(UTC)
        # index 2 ties with index 1 on high -> neither strictly greater than the other side fully
        hl = [(10, 5), (15, 6), (15, 6), (10, 5), (9, 4)]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        highs_at_1_or_2 = [s for s in swings if s.swing_type == SwingType.HIGH and s.bar_index in (1, 2)]
        self.assertEqual(len(highs_at_1_or_2), 0, "equal adjacent highs must not both register as swings")

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_highs_lows([(10, 5), (11, 6)], t0)
        with self.assertRaises(InsufficientDataError):
            find_swing_points(bars, Timeframe.H1, window=2)

    def test_invalid_window_raises_value_error(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_highs_lows([(10, 5)] * 10, t0)
        with self.assertRaises(ValueError):
            find_swing_points(bars, Timeframe.H1, window=0)


class TestLabelHhHlLhLl(unittest.TestCase):
    def test_higher_high_and_higher_low(self):
        t0 = datetime.now(UTC)
        hl = [
            (10, 5), (11, 6), (15, 12), (11, 6), (10, 8),   # swing high @2 (15)
            (11, 9), (18, 14), (11, 9), (10, 10),           # swing low @4 (8), swing high @6 (18)
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = label_hh_hl_lh_ll(swings, Timeframe.H1)
        types = [e.event_type for e in events]
        # second swing high (18) > first swing high (15) => HIGHER_HIGH
        self.assertIn(StructureEventType.HIGHER_HIGH, types)

    def test_first_swing_of_each_type_produces_no_event(self):
        t0 = datetime.now(UTC)
        hl = [(10, 5), (11, 6), (15, 12), (11, 6), (10, 5)]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)  # only 1 swing high, 0 lows
        events = label_hh_hl_lh_ll(swings, Timeframe.H1)
        self.assertEqual(len(events), 0)

    def test_equal_high_labeled_correctly(self):
        t0 = datetime.now(UTC)
        # two separated swing highs at the exact same price
        hl = [
            (10, 5), (11, 6), (15, 12), (11, 6), (10, 5),
            (11, 6), (15, 12), (11, 6), (10, 5),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = label_hh_hl_lh_ll(swings, Timeframe.H1)
        self.assertTrue(any(e.event_type == StructureEventType.EQUAL_HIGH for e in events))


class TestClassifyTrend(unittest.TestCase):
    def test_undefined_when_no_events(self):
        result = classify_trend([], Timeframe.H1, as_of=datetime.now(UTC))
        self.assertEqual(result.state, TrendState.UNDEFINED)

    def test_uptrend_requires_both_higher_high_and_higher_low(self):
        t0 = datetime.now(UTC)
        # Hand-verified: swing high @2 (14), swing low @4 (7), swing high @6 (16, HH),
        # swing low @8 (9, HL) -> last high=HH, last low=HL => UPTREND
        hl = [
            (10, 8), (12, 9), (14, 12), (11, 9), (10, 7),
            (12, 9), (16, 13), (13, 11), (12, 9), (13, 10), (11, 10),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = label_hh_hl_lh_ll(swings, Timeframe.H1)
        result = classify_trend(events, Timeframe.H1, as_of=datetime.now(UTC))
        self.assertEqual(result.state, TrendState.UPTREND)

    def test_mixed_signals_produce_range(self):
        # Hand-verified: swing high @2 (14), swing low @4 (7), swing high @6 (16, HH),
        # swing low @8 (3, LOWER_LOW) -> last high=HH but last low=LL => RANGE (divergent)
        t0 = datetime.now(UTC)
        hl = [
            (10, 8), (12, 9), (14, 12), (11, 9), (10, 7),
            (12, 9), (16, 13), (13, 11), (12, 3), (13, 10), (11, 10),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = label_hh_hl_lh_ll(swings, Timeframe.H1)
        result = classify_trend(events, Timeframe.H1, as_of=datetime.now(UTC))
        self.assertEqual(result.state, TrendState.RANGE)


if __name__ == "__main__":
    unittest.main()
