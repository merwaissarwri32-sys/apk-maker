"""Phase 11: LiveMarketDataSource, InstrumentUniverse, telemetry/metrics, state snapshot. SYNTHETIC, no network."""
import dataclasses
import json
import unittest
from datetime import timedelta

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.adapters.scripted import ScriptedProvider, raw_row_from_bar, scripted_capabilities
from omnisystem_v5.marketdata.assets import AssetClass, Listing
from omnisystem_v5.marketdata.config import RetryPolicy, ThrottlePolicy
from omnisystem_v5.marketdata.events import DataEventKind
from omnisystem_v5.marketdata.feed import PollingFeed
from omnisystem_v5.marketdata.freshness import FreshnessState
from omnisystem_v5.marketdata.health import InstrumentState, ProviderState
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.provider import BarRequest, ProviderAuthError, ProviderPayloadError, RawBarRow, RawBars
from omnisystem_v5.marketdata.router import ProviderRouter
from omnisystem_v5.marketdata.sessions import MarketStatus, WeeklySession
from omnisystem_v5.marketdata.state import DataStateReader, RollupState, build_snapshot
from omnisystem_v5.marketdata.stream import BarStore, StreamingFeed
from omnisystem_v5.marketdata.symbol_map import SymbolMap
from omnisystem_v5.marketdata.universe import InstrumentUniverse
from omnisystem_v5.marketdata.issues import FaultScope
from omnisystem_v5.scanner.enums import MarketType
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError
from omnisystem_v5.scanner.market_data import gate_envelope
from omnisystem_v5.scanner.universe import UniverseFilter, resolve_universe
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import MarketDataEnvelope
from omnisystem_v5.tests.marketdata_fixtures import (END, LONG_SEED, QUIET_SEED, SHORT_SEED, VENUE, Stack, crypto_instrument, raw_rows)
from omnisystem_v5.tests.scanner_fixtures import bars_ending_at

M5 = Timeframe.M5
BTC = "BTC/USDT"
STEP5 = timedelta(seconds=300)


def get(st, symbol=BTC, tf=M5, limit=200):
    return st.source.get_market_data(symbol, tf, limit)


def prov(st, name="cryptofeed"):
    return st.book.provider(name, st.clock.now())


class TestSourceHappyPath(unittest.TestCase):
    def test_envelope_ok_and_contract_unchanged(self):
        st = Stack()
        env = get(st)
        self.assertIsInstance(env, MarketDataEnvelope)
        self.assertEqual((env.market, env.timeframe, env.quality_status), (BTC, M5, QualityStatus.OK))
        self.assertEqual(len(env.bars), 200)
        self.assertEqual((env.provenance.source, env.provenance.origin), ("cryptofeed", DataOrigin.HISTORICAL))
        self.assertEqual((env.provenance.fetched_at, env.provenance.data_timestamp), (END, END))
        self.assertTrue(env.is_usable())
        self.assertEqual([f.name for f in dataclasses.fields(MarketDataEnvelope)],
                         ["market", "timeframe", "provenance", "quality_status", "bars", "reasons", "schema_version"])

    def test_scanner_gate_accepts_what_phase11_marks_ok(self):
        st = Stack()
        env = get(st)
        self.assertIsNone(gate_envelope(env, BTC, M5, END, st.md.limits.min_bars, st.md.limits.staleness_bars))

    def test_stream_health_is_recorded_beside_the_envelope(self):
        st = Stack()
        get(st)
        (s,) = st.book.streams()
        self.assertEqual((s.symbol, s.timeframe, s.freshness, s.status, s.bars, s.provider), (BTC, M5, FreshnessState.FRESH, QualityStatus.OK, 200, "cryptofeed"))
        self.assertEqual(s.age_seconds, 0.0)
        self.assertEqual(len(s.digest), 64)

    def test_uses_injected_clock_for_provenance(self):
        st = Stack()
        st.advance(300)
        self.assertEqual(get(st).provenance.fetched_at, END + STEP5)


class TestSourceRefusals(unittest.TestCase):
    def test_unknown_instrument_is_refused_without_calling_any_provider(self):
        st = Stack()
        for bad in ("NOPE/USDT", "btc/usdt", "BTCUSDT", None, 5):
            env = get(st, bad)
            self.assertEqual(env.quality_status, QualityStatus.INVALID)
            self.assertFalse(env.is_usable())
            self.assertEqual(env.bars, ())
            self.assertIn("data.unknown_instrument", env.reasons[0])
        self.assertEqual(st.crypto_provider.calls, [])

    def test_unsupported_timeframe_is_invalid_not_a_provider_fault(self):
        st = Stack(provider_tfs=(M5,))
        env = get(st, tf=Timeframe.H1)
        self.assertEqual(env.quality_status, QualityStatus.INVALID)
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)
        self.assertEqual(st.crypto_provider.calls, [])

    def test_simulated_origin_is_never_usable(self):
        st = Stack(origin=DataOrigin.SIMULATED)
        env = get(st)
        self.assertEqual(env.provenance.origin, DataOrigin.SIMULATED)
        self.assertFalse(env.is_usable())
        self.assertIsNotNone(gate_envelope(env, BTC, M5, END, 40, 2.0))


class TestSourceDataDefects(unittest.TestCase):
    def script_rows(self, st, mutate, tf=M5):
        rows = list(raw_rows(bars_ending_at(tf, 220, END, seed=LONG_SEED)))
        mutate(rows)
        st.crypto_provider.set_series("BTCUSDT", tf, rows)

    def test_nan_bar_is_invalid_and_provider_stays_healthy(self):
        st = Stack()
        self.script_rows(st, lambda r: r.__setitem__(100, dataclasses.replace(r[100], close=float("nan"))))
        env = get(st)
        self.assertEqual((env.quality_status, env.bars), (QualityStatus.INVALID, ()))
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)             # bad data for one symbol is not a provider fault
        self.assertEqual(prov(st).consecutive_failures, 0)

    def test_repeated_invalid_data_quarantines_only_that_instrument(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", SHORT_SEED)))
        self.script_rows(st, lambda r: r.__setitem__(100, dataclasses.replace(r[100], close=float("inf"))))
        for _ in range(3):
            get(st)
        self.assertEqual(st.book.instrument(BTC).state, InstrumentState.QUARANTINED)
        self.assertEqual(get(st, "ETH/USDT").quality_status, QualityStatus.OK)
        self.assertEqual(st.book.instrument("ETH/USDT").state, InstrumentState.AVAILABLE)
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)
        excluded = {e.symbol: e for e in st.universe.evaluate(END).excluded}
        self.assertEqual(excluded[BTC].state, InstrumentState.QUARANTINED)
        self.assertEqual([s.symbol for s in st.universe.symbols(END)], ["ETH/USDT"])

    def test_good_data_after_bad_recovers_the_instrument(self):
        st = Stack()
        self.script_rows(st, lambda r: r.__setitem__(100, dataclasses.replace(r[100], close=float("nan"))))
        get(st)
        self.assertEqual(st.book.instrument(BTC).state, InstrumentState.DEGRADED)
        st.refresh()
        self.assertEqual(get(st).quality_status, QualityStatus.OK)
        self.assertEqual(st.book.instrument(BTC).state, InstrumentState.AVAILABLE)

    def test_stale_data_is_reported_stale_and_expired_is_visible_in_stream_health(self):
        st = Stack()
        st.clock.advance(2 * 300 + 1)                                        # just past staleness_bars(2.0) x 5m
        env = get(st)
        self.assertEqual(env.quality_status, QualityStatus.STALE)
        self.assertFalse(env.is_usable())
        self.assertEqual(st.book.streams()[0].freshness, FreshnessState.STALE)
        st.clock.advance(10 * 300)
        self.assertEqual(get(st).quality_status, QualityStatus.STALE)         # the frozen envelope has no EXPIRED status
        self.assertEqual(st.book.streams()[0].freshness, FreshnessState.EXPIRED)
        self.assertIsNone(st.book.instrument(BTC))                              # staleness never counts against the instrument
        self.assertIn(DataEventKind.DATA_STALE, [e.kind for e in st.memory.events])

    def test_stale_data_is_not_an_instrument_or_provider_failure(self):
        st = Stack()
        st.clock.advance(5000)
        for _ in range(6):
            get(st)
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)
        self.assertIsNone(st.book.instrument(BTC))

    def test_insufficient_data(self):
        st = Stack(n=30)
        env = get(st)
        self.assertEqual(env.quality_status, QualityStatus.INSUFFICIENT_DATA)
        self.assertFalse(env.is_usable())

    def test_forming_bar_is_dropped_and_recorded(self):
        st = Stack()
        st.crypto_provider.set_series("BTCUSDT", M5, raw_rows(bars_ending_at(M5, 201, END + STEP5, seed=LONG_SEED)))
        env = get(st)
        self.assertEqual((env.quality_status, len(env.bars), env.bars[-1].close_time), (QualityStatus.OK, 199, END))
        self.assertTrue(any("data.forming_bar_dropped" in r for r in env.reasons))
        self.assertEqual(st.book.streams()[0].dropped, ((K.DATA_FORMING_BAR_DROPPED.value, 1),))

    def test_future_bar_and_empty_response_are_invalid(self):
        st = Stack()
        st.crypto_provider.set_series("BTCUSDT", M5, raw_rows(bars_ending_at(M5, 220, END + STEP5 * 4)))
        self.assertEqual(get(st).quality_status, QualityStatus.INVALID)
        st.crypto_provider.set_series("BTCUSDT", M5, ())
        env = get(st)
        self.assertEqual((env.quality_status, env.bars), (QualityStatus.INVALID, ()))
        self.assertEqual(st.book.streams()[0].freshness, FreshnessState.MISSING)


class TestSourceProviderFaults(unittest.TestCase):
    def test_timeout_is_raised_with_the_existing_type_and_counted(self):
        st = Stack()
        st.crypto_provider.script("BTCUSDT", M5, [TimeoutError("t")])
        with self.assertRaises(TimeoutError):
            get(st)
        self.assertEqual(prov(st).consecutive_failures, 1)
        self.assertEqual(prov(st).last_failure_class, FailureClass.PROVIDER_TIMEOUT)
        self.assertEqual(get(st).quality_status, QualityStatus.OK)             # next call succeeds; streak resets
        self.assertEqual(prov(st).consecutive_failures, 0)

    def test_bounded_retry_inside_the_source(self):
        from omnisystem_v5.marketdata.config import RetryPolicy
        st = Stack(cfg_kwargs={"max_fetch_attempts": 1}, md_kwargs={"retry": RetryPolicy(max_attempts=3, jitter_fraction=0.0)})
        st.crypto_provider.script("BTCUSDT", M5, [TimeoutError(), TimeoutError(), None])
        self.assertEqual(get(st).quality_status, QualityStatus.OK)
        self.assertEqual((len(st.crypto_provider.calls), st.sleep.calls), (3, [0.5, 1.0]))
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)                # the retried timeouts recovered within one request
        self.assertEqual(len([e for e in st.memory.events if e.kind == DataEventKind.RETRY_ATTEMPT]), 2)
        st.crypto_provider.script("BTCUSDT", M5, [TimeoutError()] * 9)
        with self.assertRaises(TimeoutError):
            get(st)
        self.assertEqual(len(st.crypto_provider.calls), 6)                     # exactly 3 more, never more

    def test_rate_limit_throttles_the_provider_and_fails_fast_without_hammering(self):
        st = Stack()
        st.crypto_provider.script("BTCUSDT", M5, [ProviderRateLimitedError("rl", 30.0)])
        with self.assertRaises(ProviderRateLimitedError):
            get(st)
        self.assertEqual(prov(st).state, ProviderState.THROTTLED)
        n = len(st.crypto_provider.calls)
        st.clock.advance(10)
        with self.assertRaises(ProviderRateLimitedError) as cm:
            get(st)
        self.assertEqual(len(st.crypto_provider.calls), n)                     # not called again while throttled
        self.assertEqual(cm.exception.retry_after_seconds, 20.0)
        st.advance(20)                                                         # window over: one probe is allowed
        self.assertEqual(get(st).quality_status, QualityStatus.OK)
        self.assertEqual(prov(st).state, ProviderState.RECOVERING)
        kinds = [e.kind for e in st.memory.events]
        self.assertIn(DataEventKind.RATE_LIMITED, kinds)
        self.assertIn(DataEventKind.RECONNECT_ATTEMPT, kinds)

    def test_outage_then_fail_fast_then_probe_and_full_recovery(self):
        st = Stack()
        st.crypto_provider.script("BTCUSDT", M5, [DataUnavailableError("down")] * 5)
        for _ in range(5):
            with self.assertRaises(DataUnavailableError):
                get(st)
        self.assertEqual(prov(st).state, ProviderState.UNAVAILABLE)
        n = len(st.crypto_provider.calls)
        env = get(st)                                                          # cooling down: refused without a call
        self.assertEqual((env.quality_status, env.provenance.origin), (QualityStatus.DATA_UNAVAILABLE, DataOrigin.UNAVAILABLE))
        self.assertEqual(len(st.crypto_provider.calls), n)
        st.advance(30)
        for i in range(3):
            self.assertEqual(get(st).quality_status, QualityStatus.OK)
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)
        kinds = [e.kind for e in st.memory.events]
        self.assertIn(DataEventKind.RECOVERY, kinds)
        self.assertIn(DataEventKind.RECONNECT_ATTEMPT, kinds)

    def test_auth_failure_is_not_retried_and_needs_an_operator(self):
        st = Stack(cfg_kwargs={"max_fetch_attempts": 1}, md_kwargs={"retry": RetryPolicy(max_attempts=3, retry_on=frozenset(FailureClass))})
        st.crypto_provider.script("BTCUSDT", M5, [ProviderAuthError("401")])
        with self.assertRaises(ProviderAuthError):
            get(st)
        self.assertEqual(len(st.crypto_provider.calls), 1)
        h = prov(st)
        self.assertEqual((h.state, h.requires_operator), (ProviderState.UNAVAILABLE, True))
        st.advance(10 ** 6)
        self.assertEqual(get(st).quality_status, QualityStatus.DATA_UNAVAILABLE)   # never auto-probed
        st.book.reset_provider("cryptofeed", st.clock.now())
        self.assertEqual(get(st).quality_status, QualityStatus.OK)

    def test_structurally_bad_payload_is_a_provider_scope_fault(self):
        st = Stack()
        bad = RawBars("cryptofeed", "OTHERSYMBOL", raw_rows(bars_ending_at(M5, 60, END)), M5)
        st.crypto_provider.script("BTCUSDT", M5, [bad])
        with self.assertRaises(ProviderPayloadError):
            get(st)
        self.assertEqual(prov(st).consecutive_failures, 1)
        wrong_tf = RawBars("cryptofeed", "BTCUSDT", raw_rows(bars_ending_at(M5, 60, END)), Timeframe.M15)
        st.crypto_provider.script("BTCUSDT", M5, [wrong_tf])
        with self.assertRaises(ProviderPayloadError):
            get(st)

    def test_unknown_exception_types_are_still_recorded_and_re_raised(self):
        st = Stack()
        st.crypto_provider.script("BTCUSDT", M5, [RuntimeError("bug")])
        with self.assertRaises(RuntimeError):
            get(st)
        self.assertEqual(prov(st).consecutive_failures, 1)

    def test_local_throttle_protects_the_provider_without_blaming_it(self):
        st = Stack(md_kwargs={"throttle": ThrottlePolicy(max_requests=2, per_seconds=60.0)})
        get(st); get(st)
        n = len(st.crypto_provider.calls)
        with self.assertRaises(ProviderRateLimitedError) as cm:
            get(st)
        self.assertEqual(len(st.crypto_provider.calls), n)
        self.assertEqual(cm.exception.retry_after_seconds, 60.0)
        self.assertEqual(prov(st).state, ProviderState.HEALTHY)
        self.assertIn(DataEventKind.LOCAL_THROTTLED, [e.kind for e in st.memory.events])
        st.advance(61)
        self.assertEqual(get(st).quality_status, QualityStatus.OK)


class TestIsolation(unittest.TestCase):
    def test_one_bad_symbol_does_not_poison_healthy_symbols(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", SHORT_SEED), ("DOGE", "USDT", QUIET_SEED)))
        rows = list(raw_rows(bars_ending_at(M5, 220, END, seed=SHORT_SEED)))
        rows[50] = dataclasses.replace(rows[50], high=-5.0)
        st.crypto_provider.set_series("ETHUSDT", M5, rows)
        self.assertEqual(get(st, "ETH/USDT").quality_status, QualityStatus.INVALID)
        self.assertEqual(get(st, BTC).quality_status, QualityStatus.OK)
        self.assertEqual(get(st, "DOGE/USDT").quality_status, QualityStatus.OK)

    def test_one_failing_provider_does_not_destroy_other_markets(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        st.crypto_provider.script("BTCUSDT", M5, [DataUnavailableError("down")] * 5)
        for _ in range(5):
            with self.assertRaises(DataUnavailableError):
                get(st)
        self.assertEqual(prov(st).state, ProviderState.UNAVAILABLE)
        self.assertEqual(prov(st, "fxfeed").state, ProviderState.HEALTHY)
        env = get(st, "EUR/USD")
        self.assertEqual(env.quality_status, QualityStatus.OK)
        self.assertEqual(env.provenance.source, "fxfeed")
        self.assertEqual([s.symbol for s in st.universe.symbols(END)], ["EUR/USD"])

    def test_sink_failure_never_breaks_ingestion(self):
        class Boom:
            def emit(self, event):
                raise RuntimeError("sink down")
        st = Stack()
        st.source._sink = Boom()
        self.assertEqual(get(st).quality_status, QualityStatus.OK)


class TestFeedNeutrality(unittest.TestCase):
    def test_polling_and_streaming_produce_identical_canonical_envelopes(self):
        poll = Stack()
        rows = raw_rows(bars_ending_at(M5, 220, END, seed=LONG_SEED))
        store = BarStore(max_bars=500)
        store.seed("BTCUSDT", M5, rows)
        stream_stack = Stack()
        feed = StreamingFeed("cryptofeed", scripted_capabilities({AssetClass.CRYPTO}, (M5,)), store)
        router = ProviderRouter([feed], [SymbolMap("cryptofeed", [("BTCUSDT", crypto_instrument())])])
        stream_stack.source._router = router
        a, b = get(poll), stream_stack.source.get_market_data(BTC, M5, 200)
        self.assertEqual(a, b)
        self.assertEqual(a.bars, b.bars)


class TestMetricsAndEvents(unittest.TestCase):
    def test_counters_and_latency(self):
        st = Stack()
        st.timer.step = 0.25
        get(st); get(st)
        st.clock.advance(5000)
        get(st)                                                                # stale
        get(st, "NOPE/USDT")                                                   # rejected: unknown
        st.crypto_provider.script("BTCUSDT", M5, [TimeoutError()])
        st.refresh()
        with self.assertRaises(TimeoutError):
            get(st)
        m = st.metrics.snapshot()
        self.assertEqual((m.ingested, m.accepted, m.stale, m.rejected), (3, 2, 1, 1))
        self.assertEqual(dict(m.provider_errors), {"PROVIDER_TIMEOUT": 1})
        self.assertEqual(dict(m.rejected_by_reason), {"data.unknown_instrument": 1})
        self.assertEqual((m.latency_count, m.latency_total_seconds, m.latency_max_seconds), (3, 0.75, 0.25))

    def test_events_are_structured_and_time_stamped_from_the_injected_clock(self):
        st = Stack()
        get(st)
        e = next(x for x in st.memory.events if x.kind == DataEventKind.DATA_INGESTED)
        self.assertEqual((e.at, e.symbol), (END, BTC))
        self.assertEqual(dict(e.detail)["status"], "OK")


class TestUniverse(unittest.TestCase):
    def test_yields_symbolspecs_that_satisfy_the_scanner_contract(self):
        st = Stack(crypto=(("ETH", "USDT", 1), ("BTC", "USDT", 1)), forex=(("EUR", "USD"),))
        specs = st.universe.symbols(END)
        self.assertEqual({s.symbol: s.market_type for s in specs}, {"BTC/USDT": MarketType.SPOT, "ETH/USDT": MarketType.SPOT, "EUR/USD": MarketType.FX})
        self.assertEqual(dict(next(s for s in specs if s.symbol == "EUR/USD").metadata), {"asset_class": "FOREX", "venue": "TESTX"})
        resolved = resolve_universe(specs, UniverseFilter())                    # the scanner's own resolver accepts it unchanged
        self.assertEqual((len(resolved.specs), resolved.excluded), (3, ()))
        self.assertEqual([s.symbol for s in specs], sorted(s.symbol for s in specs))

    def test_forex_session_closed_on_weekend_is_excluded_with_next_open_crypto_stays(self):
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),))
        sat = END + timedelta(days=1, hours=12)                                # Saturday 2024-03-02 12:00 UTC
        snap = st.universe.evaluate(sat)
        by = {e.symbol: e for e in snap.entries}
        self.assertTrue(by[BTC].scannable)
        eu = by["EUR/USD"]
        self.assertEqual((eu.scannable, eu.state), (False, InstrumentState.UNAVAILABLE))
        self.assertEqual(eu.reasons[0].key, K.INSTRUMENT_SESSION_CLOSED)
        self.assertEqual(dict(eu.reasons[0].params)["status"], MarketStatus.CLOSED.value)
        self.assertEqual(eu.next_open.isoformat(), "2024-03-03T22:00:00+00:00")
        self.assertEqual([s.symbol for s in st.universe.symbols(sat)], [BTC])

    def test_disabled_and_unmapped_instruments(self):
        st = Stack()
        extra = [Listing(crypto_instrument("ETH"), VENUE, enabled=False), Listing(crypto_instrument("XRP"), VENUE)]
        cat = type(st.catalog)([*(st.catalog.listings_for(BTC)), *extra])
        uni = InstrumentUniverse(cat, st.router, st.book, st.tfs)
        by = {e.symbol: e for e in uni.evaluate(END).entries}
        self.assertEqual(by["ETH/USDT"].state, InstrumentState.DISABLED)
        self.assertEqual(by["XRP/USDT"].state, InstrumentState.UNAVAILABLE)
        self.assertEqual(by["XRP/USDT"].reasons[0].key, K.DATA_UNMAPPED_INSTRUMENT)
        self.assertEqual([s.symbol for s in uni.symbols(END)], [BTC])

    def test_provider_outage_excludes_only_its_instruments(self):
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),))
        for _ in range(5):
            st.book.observe_provider("fxfeed", __import__("omnisystem_v5.marketdata.health", fromlist=["x"]).ProviderObservation(
                __import__("omnisystem_v5.marketdata.health", fromlist=["x"]).ObsKind.FAILURE, FailureClass.PROVIDER_TIMEOUT), END)
        by = {e.symbol: e for e in st.universe.evaluate(END).entries}
        self.assertEqual(by["EUR/USD"].reasons[0].key, K.INSTRUMENT_PROVIDER_UNAVAILABLE)
        self.assertTrue(by[BTC].scannable)

    def test_degraded_provider_or_instrument_stays_scannable_but_is_marked_degraded(self):
        st = Stack()
        from omnisystem_v5.marketdata.health import ObsKind, ProviderObservation
        for _ in range(2):
            st.book.observe_provider("cryptofeed", ProviderObservation(ObsKind.FAILURE, FailureClass.PROVIDER_TIMEOUT), END)
        (e,) = st.universe.evaluate(END).entries
        self.assertEqual((e.scannable, e.state), (True, InstrumentState.DEGRADED))

    def test_quarantine_window_then_probe(self):
        st = Stack()
        for _ in range(3):
            st.book.observe_instrument(BTC, False, END)
        self.assertEqual(st.universe.symbols(END), ())
        self.assertEqual(st.universe.symbols(END + timedelta(seconds=899)), ())
        self.assertEqual(len(st.universe.symbols(END + timedelta(seconds=900))), 1)

    def test_required_timeframe_not_served_excludes_instrument(self):
        st = Stack(provider_tfs=(M5,))
        (e,) = st.universe.evaluate(END).entries
        self.assertEqual((e.scannable, e.reasons[0].key), (False, K.INSTRUMENT_NO_PROVIDER))

    def test_one_broken_listing_cannot_break_the_universe(self):
        class BadSession:
            def status(self, at):
                raise RuntimeError("calendar down")

            def next_open(self, at):
                return None
        st = Stack()
        bad = Listing(crypto_instrument("ETH"), VENUE, session=BadSession())
        cat = type(st.catalog)([*(st.catalog.listings_for(BTC)), bad])
        router = ProviderRouter(st.router.feeds, [SymbolMap("cryptofeed", [("BTCUSDT", crypto_instrument()), ("ETHUSDT", crypto_instrument("ETH"))])])
        snap = InstrumentUniverse(cat, router, st.book, st.tfs).evaluate(END)
        by = {e.symbol: e for e in snap.entries}
        self.assertTrue(by[BTC].scannable)
        self.assertEqual(by["ETH/USDT"].reasons[0].key, K.INSTRUMENT_INTERNAL_ERROR)

    def test_requires_timeframes(self):
        st = Stack()
        with self.assertRaises(ValueError):
            InstrumentUniverse(st.catalog, st.router, st.book, ())


class TestSnapshot(unittest.TestCase):
    def make(self):
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", SHORT_SEED)), forex=(("EUR", "USD"),))
        for s in ("BTC/USDT", "ETH/USDT", "EUR/USD"):
            get(st, s)
        return st

    def test_snapshot_is_canonical_json_and_language_neutral(self):
        st = self.make()
        snap = build_snapshot(END, st.book, st.router, st.universe, st.metrics)
        data = json.loads(snap.to_json())
        self.assertEqual(data["schema_version"], "1.0")
        self.assertEqual(set(data), {"at", "providers", "instruments", "streams", "universe", "metrics", "evidence", "rollups", "schema_version"})
        self.assertEqual({e[0]: e[1] for e in data["evidence"]}, {"cryptofeed": "TESTED", "fxfeed": "TESTED"})
        for p in data["providers"]:
            self.assertEqual(set(p["reason"]), {"key", "params"})           # structured reason, never prose
        self.assertEqual(snap.to_json(), json.dumps(json.loads(snap.to_json()), sort_keys=True, separators=(",", ":")))

    def test_identical_stacks_produce_byte_identical_snapshots(self):
        a, b = self.make(), self.make()
        ja = build_snapshot(END, a.book, a.router, a.universe, a.metrics).to_json()
        jb = build_snapshot(END, b.book, b.router, b.universe, b.metrics).to_json()
        self.assertEqual(ja, jb)
        self.assertEqual(ja, build_snapshot(END, a.book, a.router, a.universe, a.metrics).to_json())     # and repeatable

    def test_reader_facade_matches_builder(self):
        st = self.make()
        self.assertEqual(DataStateReader(st.book, st.router, st.universe, st.metrics).snapshot(END),
                         build_snapshot(END, st.book, st.router, st.universe, st.metrics))

    def test_rollups_distinguish_asset_class_from_systemic_faults(self):
        st = self.make()
        from omnisystem_v5.marketdata.health import ObsKind, ProviderObservation
        fail = ProviderObservation(ObsKind.FAILURE, FailureClass.PROVIDER_UNAVAILABLE)
        roll = lambda: {(r.scope, r.subject): r.state for r in build_snapshot(END, st.book, st.router, st.universe).rollups}
        r0 = roll()
        self.assertEqual(r0[(FaultScope.SYSTEMIC, "providers")], RollupState.HEALTHY)
        for _ in range(5):
            st.book.observe_provider("cryptofeed", fail, END)
        r1 = roll()
        self.assertEqual(r1[(FaultScope.ASSET_CLASS, "CRYPTO")], RollupState.UNAVAILABLE)
        self.assertEqual(r1[(FaultScope.ASSET_CLASS, "FOREX")], RollupState.HEALTHY)
        self.assertEqual(r1[(FaultScope.SYSTEMIC, "providers")], RollupState.DEGRADED)      # one provider down is NOT systemic
        for _ in range(5):
            st.book.observe_provider("fxfeed", fail, END)
        self.assertEqual(roll()[(FaultScope.SYSTEMIC, "providers")], RollupState.UNAVAILABLE)

    def test_every_configured_provider_is_represented_even_before_first_use(self):
        st = Stack(crypto=(("BTC", "USDT", 1),), forex=(("EUR", "USD"),))
        snap = build_snapshot(END, st.book, st.router)
        self.assertEqual([p.provider for p in snap.providers], ["cryptofeed", "fxfeed"])


if __name__ == "__main__":
    unittest.main()
