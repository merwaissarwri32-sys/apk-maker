"""Shared fixtures for the Phase 12 tests.

EVIDENCE CLASS: SYNTHETIC and deterministic. Real Phase 10 scanner / Phase 11 marketdata objects are produced by the real
(unmodified) stack over scripted providers; transports are in-memory fakes; nothing touches a network or a real clock.
"""
from __future__ import annotations

import hashlib
import json
from datetime import timedelta

from omnisystem_v5.alerts.audit import InMemoryAuditLog
from omnisystem_v5.alerts.dedup import InMemoryAlertStateStore
from omnisystem_v5.alerts.delivery import DeliveryExecutor, DeliveryPolicy
from omnisystem_v5.alerts.enums import AlertSeverity, NotificationChannel
from omnisystem_v5.alerts.i18n import alert_catalog
from omnisystem_v5.alerts.pipeline import AlertPipeline
from omnisystem_v5.alerts.policy import AlertPolicy
from omnisystem_v5.alerts.routing import AlertRouter, NotificationTarget, RoutingPolicy, RoutingRule
from omnisystem_v5.alerts.transport import RecordingTransport, TransportRegistry
from omnisystem_v5.marketdata.events import InMemorySink
from omnisystem_v5.marketdata.i18n import EN, FA
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.tests.scanner_fixtures import END


class AdvancingSleep:
    """Injected sleep: records the requested wait and moves the ManualClock (so deadlines are testable without real time)."""

    def __init__(self, clock):
        self.clock, self.waits = clock, []

    def __call__(self, seconds):
        self.waits.append(seconds)
        self.clock.advance(seconds)


def default_routing(min_severity=AlertSeverity.INFO, **rule_kw) -> RoutingPolicy:
    targets = (NotificationTarget("ops-en", NotificationChannel.INTERNAL, EN), NotificationTarget("ops-fa", NotificationChannel.INTERNAL, FA))
    return RoutingPolicy(targets, (RoutingRule("all", ("ops-en", "ops-fa"), min_severity=min_severity, **rule_kw),))


class Harness:
    def __init__(self, routing=None, policy=None, transports=None, delivery=None, sink=None, audit=None, clock=None, store=None):
        self.clock = clock or ManualClock(END)
        self.sleep = AdvancingSleep(self.clock)
        self.sink = sink if sink is not None else InMemorySink()
        self.audit = audit if audit is not None else InMemoryAuditLog()
        self.store = store or InMemoryAlertStateStore()
        self.recording = RecordingTransport()
        self.registry = TransportRegistry(transports if transports is not None else (self.recording,))
        self.router = AlertRouter(routing or default_routing())
        self.policy = policy or AlertPolicy()
        self.executor = DeliveryExecutor(delivery or DeliveryPolicy(), self.clock, self.sleep, self.sink)
        self.pipeline = AlertPipeline(clock=self.clock, policy=self.policy, router=self.router, transports=self.registry,
                                      executor=self.executor, catalog=alert_catalog(), store=self.store, audit=self.audit, sink=self.sink)

    def kinds(self):
        return [getattr(e.kind, "value", e.kind) for e in self.sink.events]


_CACHE: dict = {}


def real_scan_world():
    """One real ScanReport (2 emitted signals, BTC LONG + ETH SHORT) plus the catalog/snapshot/events of the real Phase 11 stack.
    Built once per process (the objects are immutable)."""
    if "w" not in _CACHE:
        from omnisystem_v5.marketdata.state import build_snapshot
        from omnisystem_v5.tests.marketdata_fixtures import LONG_SEED, SHORT_SEED, Stack
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", SHORT_SEED)))
        report = st.cycle()
        snap = build_snapshot(st.clock.now(), st.book, st.router, st.universe, st.metrics)
        _CACHE["w"] = (report, st.catalog, snap, tuple(st.memory.events))
    return _CACHE["w"]


def real_suppressed_report():
    """A REAL second scan cycle over unchanged data: the scanner itself suppresses the repeated setups (ScanReport.suppressed)."""
    if "s" not in _CACHE:
        from omnisystem_v5.tests.marketdata_fixtures import LONG_SEED, SHORT_SEED, Stack
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED), ("ETH", "USDT", SHORT_SEED)))
        st.cycle()
        _CACHE["s"] = st.cycle()
    return _CACHE["s"]


def real_outage_world():
    """Real Phase 11 stack with one provider driven to UNAVAILABLE through scripted outages: (snapshot, events)."""
    if "o" not in _CACHE:
        from omnisystem_v5.data.providers.base import DataUnavailableError
        from omnisystem_v5.marketdata.state import build_snapshot
        from omnisystem_v5.scanner.timeframes import required_timeframes
        from omnisystem_v5.tests.marketdata_fixtures import LONG_SEED, Stack
        st = Stack(crypto=(("BTC", "USDT", LONG_SEED),), forex=(("EUR", "USD"),))
        for tf in required_timeframes(st.scfg):
            st.crypto_provider.script("BTCUSDT", tf, [DataUnavailableError("down")] * 10)
        for _ in range(3):
            st.cycle(advance=300)
        snap = build_snapshot(st.clock.now(), st.book, st.router, st.universe, st.metrics)
        _CACHE["o"] = (snap, tuple(st.memory.events))
    return _CACHE["o"]


def scenario_digest() -> str:
    """A whole end-to-end run over REAL scanner/marketdata objects, reduced to one sha256 of canonical output.
    Used by the PYTHONHASHSEED determinism test (run in subprocesses)."""
    report, catalog, snap, events = real_scan_world()
    osnap, oevents = real_outage_world()
    from omnisystem_v5.alerts.sources import CatalogContextResolver
    h = Harness()
    out = []
    for step in range(2):                                   # second pass = pure replay -> duplicates
        out += h.pipeline.process_report(report, CatalogContextResolver(catalog))
        out += h.pipeline.process_snapshot(osnap)
        out += h.pipeline.process_events(oevents, strict=False)
        h.clock.advance(1)
    blob = json.dumps([r.to_dict() for r in out], sort_keys=True) + json.dumps([e.envelope_id for e in h.recording.sent])
    return hashlib.sha256(blob.encode()).hexdigest()
