import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.enums import FVGType, LiquidityType, SRLevelType
from omnisystem_v5.context.schema import FairValueGap, LiquidityZone, MarketContext, SupportResistanceLevel, VolatilityMetrics
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.intelligence.entry_zone import EntryZoneConfig, build_structural_entry_zone
from omnisystem_v5.intelligence.enums import AlignmentLevel, DirectionBias
from omnisystem_v5.schemas.enums import Timeframe

UTC = timezone.utc


def _mctx(price, atr=1.0, fvgs=(), sr=(), liquidity=()):
    now = datetime.now(UTC)
    vol = VolatilityMetrics(timeframe=Timeframe.H1, calculated_at=now, atr=atr, atr_period=14, returns_volatility=0.01) if atr else None
    return MarketContext(
        symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.OK, calculated_at=now, provenance=None,
        current_price=price, volatility=vol, fair_value_gaps=fvgs, support_resistance=sr, liquidity_zones=liquidity,
    )


class TestFallback(unittest.TestCase):
    def test_no_structure_falls_back_to_narrow_band_reported_as_none_quality(self):
        mctx = _mctx(price=100.0)
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.NONE)
        self.assertIn("weak/insufficient", source)
        self.assertTrue(zone.contains(100.0))

    def test_unavailable_price_reported_explicitly(self):
        mctx = _mctx(price=None)
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.NONE)
        self.assertIn("price unavailable", source)


class TestSingleStructuralSource(unittest.TestCase):
    def test_fvg_alone_gives_moderate_quality(self):
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BULLISH, top=99.0, bottom=97.0, timeframe=Timeframe.H1, formed_at=now, filled=False)
        mctx = _mctx(price=100.0, fvgs=(fvg,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.MODERATE)
        self.assertEqual((zone.bottom, zone.top), (97.0, 99.0))

    def test_support_level_alone_gives_weak_quality(self):
        now = datetime.now(UTC)
        sr = SupportResistanceLevel(level_type=SRLevelType.SUPPORT, price=98.0, timeframe=Timeframe.H1,
                                     touch_count=2, first_formed_at=now, last_touched_at=now)
        mctx = _mctx(price=100.0, sr=(sr,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.WEAK)

    def test_liquidity_zone_alone_gives_weak_quality(self):
        now = datetime.now(UTC)
        liq = LiquidityZone(liquidity_type=LiquidityType.EQUAL_LOWS, price_level=98.0, timeframe=Timeframe.H1,
                             touch_count=2, formed_at=now)
        mctx = _mctx(price=100.0, liquidity=(liq,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.WEAK)

    def test_wrong_side_structure_is_ignored(self):
        """A bearish FVG must never be used to build a BULLISH entry zone."""
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BEARISH, top=103.0, bottom=101.0, timeframe=Timeframe.H1, formed_at=now, filled=False)
        mctx = _mctx(price=100.0, fvgs=(fvg,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.NONE)

    def test_filled_fvg_is_ignored(self):
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BULLISH, top=99.0, bottom=97.0, timeframe=Timeframe.H1, formed_at=now, filled=True, filled_at=now)
        mctx = _mctx(price=100.0, fvgs=(fvg,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.NONE)

    def test_too_far_structure_excluded_by_distance_config(self):
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BULLISH, top=50.0, bottom=48.0, timeframe=Timeframe.H1, formed_at=now, filled=False)
        mctx = _mctx(price=100.0, atr=1.0, fvgs=(fvg,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx, config=EntryZoneConfig(max_distance_atr=2.0))
        self.assertEqual(quality, AlignmentLevel.NONE)  # 50 bars price by 50, way beyond 2 ATR


class TestConfluence(unittest.TestCase):
    def test_overlapping_fvg_and_sr_gives_strong_confluence(self):
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BULLISH, top=99.0, bottom=97.0, timeframe=Timeframe.H1, formed_at=now, filled=False)
        sr = SupportResistanceLevel(level_type=SRLevelType.SUPPORT, price=98.0, timeframe=Timeframe.H1,
                                     touch_count=3, first_formed_at=now, last_touched_at=now)
        mctx = _mctx(price=100.0, fvgs=(fvg,), sr=(sr,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        self.assertEqual(quality, AlignmentLevel.STRONG)
        self.assertIn("confluence", source)

    def test_non_overlapping_zones_do_not_falsely_confluence(self):
        now = datetime.now(UTC)
        fvg = FairValueGap(fvg_type=FVGType.BULLISH, top=99.0, bottom=98.5, timeframe=Timeframe.H1, formed_at=now, filled=False)
        sr = SupportResistanceLevel(level_type=SRLevelType.SUPPORT, price=90.0, timeframe=Timeframe.H1,
                                     touch_count=3, first_formed_at=now, last_touched_at=now)
        mctx = _mctx(price=100.0, atr=5.0, fvgs=(fvg,), sr=(sr,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx)
        # nearest is the FVG; SR is far away and doesn't overlap it -> MODERATE not STRONG
        self.assertEqual(quality, AlignmentLevel.MODERATE)


class TestBearishSide(unittest.TestCase):
    def test_bearish_direction_uses_resistance_and_equal_highs(self):
        now = datetime.now(UTC)
        sr = SupportResistanceLevel(level_type=SRLevelType.RESISTANCE, price=102.0, timeframe=Timeframe.H1,
                                     touch_count=2, first_formed_at=now, last_touched_at=now)
        mctx = _mctx(price=100.0, sr=(sr,))
        zone, quality, source = build_structural_entry_zone(DirectionBias.BEARISH, mctx)
        self.assertEqual(quality, AlignmentLevel.WEAK)


class TestVwapReactionArea(unittest.TestCase):
    def test_vwap_used_when_no_other_structure_and_quant_context_supplied(self):
        class _FakeVwap:
            def __init__(self, value):
                self.value = value

        class _FakeQuantContext:
            def __init__(self, session_vwap):
                self.vwap_session = _FakeVwap(session_vwap)
                self.vwap_rolling = None

        mctx = _mctx(price=100.2, atr=1.0)
        qctx = _FakeQuantContext(session_vwap=100.0)
        zone, quality, source = build_structural_entry_zone(DirectionBias.BULLISH, mctx, quant_context=qctx)
        self.assertEqual(quality, AlignmentLevel.WEAK)
        self.assertIn("VWAP", source)


if __name__ == "__main__":
    unittest.main()
