"""
Phase 8 - Multi-Horizon Replay orchestration, production-grade
completion tests.

Per the Phase 8 engineering directive: Determinism, Look-Ahead
Protection, Cross-Horizon Conflict, Data-Quality Blocking, Per-Horizon
Enable/Disable, Max Concurrent Positions, Metadata Propagation,
Rejected-Candidate Traceability, Error Semantics (see
test_phase8_exception_handling.py for the dedicated silent-exception
tests), and Deterministic Ordering.

MOCK POLICY: only detect_scalp_candidate / detect_intraday_candidate /
detect_short_swing_candidate are patched (exactly Phase 7's own
established pattern for detect_scalp_candidate) - never
build_market_context, build_quant_context, resample_bars, decide(), or
the Risk Engine. Every context/quant/decision/risk/conflict outcome in
these tests is produced by the REAL, unmodified production code,
running against real (if synthetic) OHLCV data that genuinely
satisfies each horizon's warmup requirement from validation/warmup.py.
"""
import math
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from omnisystem_v5.decision.enums import CandidateStatus, ConflictResolution, ConflictType
from omnisystem_v5.intelligence.enums import (
    AlignmentLevel,
    DirectionBias,
    ExpectedHoldingPeriod,
    Horizon,
    MarketRegime,
    ScalpStatus,
)
from omnisystem_v5.intelligence.event_risk import EventRiskStatus
from omnisystem_v5.intelligence.intraday_schema import (
    IntradayCandidate,
    IntradayCandidateEvidence,
    IntradayDetectionResult,
    IntradayScenarioType,
)
from omnisystem_v5.intelligence.scalp_schema import PriceZone, ScalpCandidate, ScalpCandidateEvidence, ScalpDetectionResult
from omnisystem_v5.intelligence.short_swing_schema import (
    ShortSwingCandidate,
    ShortSwingCandidateEvidence,
    ShortSwingDetectionResult,
    ShortSwingScenarioType,
)
from omnisystem_v5.quant.risk_reward import calculate_risk_reward
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.contracts import ExecutionConfig
from omnisystem_v5.validation.enums import TradeLifecycleState
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig, run_multi_horizon_replay
from omnisystem_v5.validation.warmup import short_swing_warmup_requirement
from omnisystem_v5.context.builder import MarketContextConfig
from omnisystem_v5.quant.engine import QuantEngineConfig
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)

# Real number, computed from the actual dependency chain (never
# hardcoded) - see validation/warmup.py / test_phase8_warmup.py.
SHORT_SWING_REQ = short_swing_warmup_requirement(
    Timeframe.M15, ShortSwingEngineConfig(), MarketContextConfig(), QuantEngineConfig()
)


def _m15_bar(i, base=100.0, amp=3.0):
    p = base + amp * math.sin(i / 15.0)
    return OHLCVBar(open=p, high=p + 1.5, low=p - 1.5, close=p + 0.1, volume=50.0,
                     open_time=T0 + timedelta(minutes=15 * i), close_time=T0 + timedelta(minutes=15 * (i + 1)))


def _all_horizon_bars(n):
    return [_m15_bar(i) for i in range(n)]


def _scalp_evidence(level=AlignmentLevel.STRONG):
    return ScalpCandidateEvidence(
        structure_alignment=level, liquidity_alignment=level, momentum_alignment=level,
        volume_alignment=level, volatility_alignment=level, vwap_alignment=level,
        fvg_alignment=level, risk_reward_quality=level, multi_timeframe_alignment=level,
    )


def _intraday_evidence(level=AlignmentLevel.STRONG):
    return IntradayCandidateEvidence(
        structure_alignment=level, liquidity_alignment=level, momentum_alignment=level,
        volatility_alignment=level, vwap_alignment=level, fvg_alignment=level,
        higher_timeframe_alignment=level, execution_timeframe_alignment=level,
    )


def _short_swing_evidence(level=AlignmentLevel.STRONG):
    return ShortSwingCandidateEvidence(
        higher_timeframe_structure_alignment=level, execution_timeframe_structure_alignment=level,
        liquidity_alignment=level, momentum_alignment=level, volatility_alignment=level,
        higher_timeframe_fvg_alignment=level,
    )


def _scalp_candidate(direction, calculated_at, current_price=100.0, entry=(99.0, 100.0), sl=95.0, tp=115.0):
    rr = calculate_risk_reward(entry=current_price, invalidation=sl, target=tp)
    return ScalpCandidate(
        symbol="BTCUSDT", horizon=Horizon.SCALP, direction=direction, timeframe=Timeframe.M15,
        calculated_at=calculated_at, expected_holding_period=ExpectedHoldingPeriod.MINUTES_TO_HOURS,
        preferred_entry_zone=PriceZone(bottom=entry[0], top=entry[1]),
        invalidation_zone=PriceZone(bottom=sl, top=sl), target_zones=(PriceZone(bottom=tp, top=tp),),
        risk_reward=rr, evidence=_scalp_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, data_quality="OK", confirmation_required=True,
        status=ScalpStatus.ZONE_IDENTIFIED, current_price=current_price,
    )


def _intraday_candidate(direction, calculated_at, current_price=100.0, entry=(99.0, 100.0), sl=105.0, tp=85.0):
    rr = calculate_risk_reward(entry=current_price, invalidation=sl, target=tp)
    return IntradayCandidate(
        symbol="BTCUSDT", horizon=Horizon.INTRADAY, scenario_type=IntradayScenarioType.TREND_CONTINUATION,
        direction=direction, timeframe=Timeframe.M15, higher_timeframe=Timeframe.H1, calculated_at=calculated_at,
        expected_holding_period=ExpectedHoldingPeriod.HOURS,
        preferred_entry_zone=PriceZone(bottom=entry[0], top=entry[1]),
        invalidation_zone=PriceZone(bottom=sl, top=sl), target_zones=(PriceZone(bottom=tp, top=tp),),
        risk_reward=rr, evidence=_intraday_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, data_quality="OK", confirmation_required=True,
        status=ScalpStatus.ZONE_IDENTIFIED, current_price=current_price,
    )


def _short_swing_candidate(direction, calculated_at, current_price=100.0, entry=(99.0, 100.0), sl=90.0, tp=130.0):
    rr = calculate_risk_reward(entry=current_price, invalidation=sl, target=tp)
    return ShortSwingCandidate(
        symbol="BTCUSDT", horizon=Horizon.SHORT_SWING, scenario_type=ShortSwingScenarioType.HTF_TREND_CONTINUATION,
        direction=direction, timeframe=Timeframe.H4, higher_timeframe=Timeframe.D1, calculated_at=calculated_at,
        expected_holding_period=ExpectedHoldingPeriod.ONE_TO_THREE_DAYS,
        preferred_entry_zone=PriceZone(bottom=entry[0], top=entry[1]),
        invalidation_zone=PriceZone(bottom=sl, top=sl), target_zones=(PriceZone(bottom=tp, top=tp),),
        risk_reward=rr, evidence=_short_swing_evidence(), supporting_evidence=(), contradicting_evidence=(),
        market_regime=MarketRegime.TREND, event_risk_status=EventRiskStatus.EVENT_DATA_AVAILABLE,
        data_quality="OK", confirmation_required=True, status=ScalpStatus.ZONE_IDENTIFIED, current_price=current_price,
    )


def _scalp_result(candidate=None):
    if candidate is None:
        return ScalpDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.M15, calculated_at=datetime.now(UTC),
                                     status=ScalpStatus.NO_VALID_SCALP)
    return ScalpDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.M15, calculated_at=candidate.calculated_at,
                                 status=ScalpStatus.ZONE_IDENTIFIED, candidates=(candidate,))


def _intraday_result(candidate=None):
    if candidate is None:
        return IntradayDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.M15, calculated_at=datetime.now(UTC),
                                        status=ScalpStatus.NO_VALID_SCALP)
    return IntradayDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.M15, calculated_at=candidate.calculated_at,
                                    status=ScalpStatus.ZONE_IDENTIFIED, candidates=(candidate,))


def _short_swing_result(candidate=None):
    if candidate is None:
        return ShortSwingDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.H4, calculated_at=datetime.now(UTC),
                                          status=ScalpStatus.NO_VALID_SCALP)
    return ShortSwingDetectionResult(symbol="BTCUSDT", timeframe=Timeframe.H4, calculated_at=candidate.calculated_at,
                                      status=ScalpStatus.ZONE_IDENTIFIED, candidates=(candidate,))


_PATCH_SCALP = "omnisystem_v5.validation.multi_horizon_replay.detect_scalp_candidate"
_PATCH_INTRADAY = "omnisystem_v5.validation.multi_horizon_replay.detect_intraday_candidate"
_PATCH_SHORT_SWING = "omnisystem_v5.validation.multi_horizon_replay.detect_short_swing_candidate"


class TestDeterminism(unittest.TestCase):
    """1. Determinism - same input, run N times, byte-identical trades,
    ordering, IDs, and metadata every time."""

    def test_all_three_horizons_conflicting_directions_is_fully_deterministic_across_runs(self):
        n = SHORT_SWING_REQ + 3
        bars = _all_horizon_bars(n)
        signal_time = bars[SHORT_SWING_REQ - 1].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        ss_c = _short_swing_candidate(DirectionBias.BULLISH, signal_time)

        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            start_index=SHORT_SWING_REQ - 1, end_index=SHORT_SWING_REQ - 1,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )

        def run_once():
            with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
                 patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)), \
                 patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(ss_c)):
                return run_multi_horizon_replay(bars, config, run_id="det-1")

        r1 = run_once()
        r2 = run_once()
        r3 = run_once()

        def _fingerprint(result):
            return [
                (t.trade_id, t.horizon, t.source_engine, t.direction, t.state.value,
                 t.candidate_id, t.decision_id, t.rejection_detail, t.stop_loss, t.take_profits)
                for t in result.trades
            ]

        f1, f2, f3 = _fingerprint(r1), _fingerprint(r2), _fingerprint(r3)
        self.assertEqual(f1, f2)
        self.assertEqual(f2, f3)
        self.assertGreaterEqual(len(f1), 3)  # winner + 2 rejected, at minimum
        self.assertEqual(r1.reproducibility.dataset.dataset_hash, r2.reproducibility.dataset.dataset_hash)


class TestLookAheadProtection(unittest.TestCase):
    """2. Look-Ahead Protection - decision-time fields for every step up
    to end_index must be byte-identical whether or not MORE bars exist
    beyond end_index. This directly exercises the sliding-window
    construction in run_multi_horizon_replay, not just resample_bars in
    isolation (already covered in test_phase8_resampling.py)."""

    def test_extra_future_bars_beyond_end_index_never_change_decision_time_fields(self):
        n_a = 250
        bars_a = _all_horizon_bars(n_a)
        # dataset B: identical prefix, PLUS extra bars appended after
        # end_index that are wildly different (a price spike) - if any
        # context/candidate builder ever peeked past idx, this would
        # change the outcome.
        bars_b = list(bars_a) + [
            OHLCVBar(open=9999.0, high=10050.0, low=9950.0, close=10000.0, volume=999.0,
                     open_time=bars_a[-1].close_time + timedelta(minutes=15 * i),
                     close_time=bars_a[-1].close_time + timedelta(minutes=15 * (i + 1)))
            for i in range(1, 40)
        ]
        end_index = n_a - 1
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, end_index=end_index,
        )

        result_a = run_multi_horizon_replay(bars_a, config)
        result_b = run_multi_horizon_replay(bars_b, config)

        def _decision_time_fields(t):
            return (t.symbol, t.direction, t.signal_time, t.entry_zone_bottom, t.entry_zone_top,
                    t.stop_loss, t.take_profits, t.decision_id, t.candidate_id,
                    t.market_regime, t.horizon, t.source_engine, t.rejection_detail, t.trade_id)

        trades_a = [_decision_time_fields(t) for t in result_a.trades]
        trades_b = [_decision_time_fields(t) for t in result_b.trades]
        # Only the LAST trade's execution-outcome fields (entry_fill,
        # exit_fill, state, pnl...) are allowed to differ, since those
        # legitimately depend on forward price data past end_index -
        # that is correct backtesting, not a leak. Every DECISION-time
        # field, for EVERY trade including the last one, must match.
        self.assertEqual(trades_a, trades_b)

    def test_short_swing_context_built_at_a_step_is_unaffected_by_bars_beyond_that_step(self):
        n_a = SHORT_SWING_REQ
        bars_a = _all_horizon_bars(n_a)
        bars_b = list(bars_a) + [_m15_bar(i, base=99999.0, amp=0.0) for i in range(n_a, n_a + 500)]
        end_index = n_a - 1
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_scalp=False, enable_intraday=False, start_index=end_index, end_index=end_index,
        )
        signal_time = bars_a[end_index].close_time
        ss_c = _short_swing_candidate(DirectionBias.BULLISH, signal_time)

        with patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(ss_c)) as mock_detect:
            run_multi_horizon_replay(bars_a, config)
            call_args_a = mock_detect.call_args

        with patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(ss_c)) as mock_detect:
            run_multi_horizon_replay(bars_b, config)
            call_args_b = mock_detect.call_args

        # The MultiTimeframeMarketContext/quant_by_tf passed into the
        # engine at the SAME step must be identical regardless of the
        # 500 extra (wildly different) future bars appended to bars_b.
        mtf_a, quant_a = call_args_a.args[1], call_args_a.args[2]
        mtf_b, quant_b = call_args_b.args[1], call_args_b.args[2]
        self.assertEqual(mtf_a.contexts.keys(), mtf_b.contexts.keys())
        for tf in mtf_a.contexts:
            self.assertEqual(mtf_a.contexts[tf].bars, mtf_b.contexts[tf].bars)
            self.assertEqual(quant_a[tf].status, quant_b[tf].status)


class TestCrossHorizonConflict(unittest.TestCase):
    """3. Cross-Horizon Conflict - uses the REAL, existing Phase 6
    conflict contract (decision/conflict.py) - no new ranking invented.
    Scalp(LONG) vs Intraday(SHORT) vs Short-Swing(LONG) with the
    candidate evidence above produces a deterministic, hand-verified
    outcome from rank_key()'s own lexicographic ordering."""

    def test_scalp_wins_intraday_loses_to_conflict_short_swing_loses_to_ranking(self):
        n = SHORT_SWING_REQ + 1
        bars = _all_horizon_bars(n)
        idx = SHORT_SWING_REQ - 1
        signal_time = bars[idx].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        ss_c = _short_swing_candidate(DirectionBias.BULLISH, signal_time)

        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            start_index=idx, end_index=idx,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )
        with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
             patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)), \
             patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(ss_c)):
            result = run_multi_horizon_replay(bars, config)

        by_engine = {t.source_engine: t for t in result.trades}
        self.assertEqual(len(result.trades), 3)
        self.assertIn(by_engine["ScalpEngine"].state, (TradeLifecycleState.FINAL_EXIT, TradeLifecycleState.EXPIRED))
        self.assertEqual(by_engine["IntradayEngine"].state, TradeLifecycleState.INVALIDATED)
        self.assertIn("conflict", by_engine["IntradayEngine"].rejection_detail.lower())
        self.assertEqual(by_engine["ShortSwingEngine"].state, TradeLifecycleState.INVALIDATED)
        self.assertIn("higher-ranked", by_engine["ShortSwingEngine"].rejection_detail.lower())

    def test_conflict_resolution_result_is_stable_across_repeated_runs(self):
        n = SHORT_SWING_REQ + 1
        bars = _all_horizon_bars(n)
        idx = SHORT_SWING_REQ - 1
        signal_time = bars[idx].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, start_index=idx, end_index=idx,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )
        outcomes = []
        for _ in range(3):
            with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
                 patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)):
                result = run_multi_horizon_replay(bars, config)
            outcomes.append(tuple((t.source_engine, t.state.value, t.rejection_detail) for t in result.trades))
        self.assertEqual(len(set(outcomes)), 1)  # every run produced the identical outcome tuple


class TestDataQualityBlocking(unittest.TestCase):
    """4. Data Quality Blocking - real (not mocked) validate_historical_dataset
    gate; a blocking issue must prevent EVERY horizon engine from ever
    being invoked, with zero trades produced."""

    def test_duplicate_timestamp_blocks_the_entire_replay_before_any_horizon_runs(self):
        bars = _all_horizon_bars(80)
        corrupt = list(bars)
        corrupt[40] = OHLCVBar(open=100, high=100.5, low=99.5, close=100, volume=10,
                                open_time=corrupt[39].open_time, close_time=corrupt[39].close_time)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80)
        with patch(_PATCH_SCALP) as mock_detect:
            result = run_multi_horizon_replay(corrupt, config)
        self.assertFalse(result.data_quality.is_valid)
        self.assertEqual(result.trades, ())
        mock_detect.assert_not_called()  # blocked BEFORE any horizon engine is reached

    def test_valid_dataset_is_not_blocked(self):
        bars = _all_horizon_bars(80)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80)
        result = run_multi_horizon_replay(bars, config)
        self.assertTrue(result.data_quality.is_valid)


class TestPerHorizonEnableDisable(unittest.TestCase):
    """5. Per-Horizon Enable/Disable - enabling/disabling one horizon
    must not unpredictably change another's behavior, and warmup is
    only enforced for horizons actually enabled."""

    def _config(self, **kw):
        return MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                         risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50), **kw)

    def test_scalp_only(self):
        n = 80
        bars = _all_horizon_bars(n)
        idx = 60
        signal_time = bars[idx].close_time
        c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        config = self._config(enable_intraday=False, enable_short_swing=False, max_lookback_bars=80,
                               start_index=idx, end_index=idx)
        with patch(_PATCH_SCALP, return_value=_scalp_result(c)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual([t.source_engine for t in result.trades], ["ScalpEngine"])

    def test_intraday_only(self):
        n = 250
        bars = _all_horizon_bars(n)
        idx = 200
        signal_time = bars[idx].close_time
        c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        config = self._config(enable_scalp=False, enable_short_swing=False, start_index=idx, end_index=idx)
        with patch(_PATCH_INTRADAY, return_value=_intraday_result(c)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual([t.source_engine for t in result.trades], ["IntradayEngine"])

    def test_short_swing_only(self):
        n = SHORT_SWING_REQ + 1
        bars = _all_horizon_bars(n)
        idx = SHORT_SWING_REQ - 1
        signal_time = bars[idx].close_time
        c = _short_swing_candidate(DirectionBias.BULLISH, signal_time)
        config = self._config(enable_scalp=False, enable_intraday=False, start_index=idx, end_index=idx)
        with patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(c)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual([t.source_engine for t in result.trades], ["ShortSwingEngine"])

    def test_disabling_short_swing_does_not_change_scalp_plus_intraday_outcome(self):
        n = 250
        bars = _all_horizon_bars(n)
        idx = 200
        signal_time = bars[idx].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        config_without = self._config(enable_short_swing=False, start_index=idx, end_index=idx)
        with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
             patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)):
            result = run_multi_horizon_replay(bars, config_without)
        engines = sorted(t.source_engine for t in result.trades)
        self.assertEqual(engines, ["IntradayEngine", "ScalpEngine"])

    def test_warmup_floor_only_applies_to_enabled_horizons(self):
        # Scalp-only config accepts a small max_lookback_bars that would
        # be rejected outright if short_swing were enabled (see
        # test_phase8_warmup.py) - proving warmup enforcement is
        # per-enabled-horizon, not a blanket constant.
        config = self._config(enable_intraday=False, enable_short_swing=False, max_lookback_bars=60)
        self.assertEqual(config.max_lookback_bars, 60)


class TestMaxConcurrentPositions(unittest.TestCase):
    """6. Max Concurrent Positions - the real, existing architectural
    contract: this replay engine is fundamentally single-position
    (sequential, non-overlapping trades across ALL horizons combined),
    enforced by an explicit, fail-closed config check, and structurally
    guaranteed by the idx-advances-past-exit loop design - not by an
    ad-hoc counter bolted on afterward."""

    def test_max_concurrent_positions_other_than_one_is_rejected_fail_closed(self):
        bars = _all_horizon_bars(80)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80,
                                           execution=ExecutionConfig(max_concurrent_positions=2))
        with self.assertRaises(ValueError):
            run_multi_horizon_replay(bars, config)

    def test_default_max_concurrent_positions_of_one_is_accepted(self):
        bars = _all_horizon_bars(80)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80)
        result = run_multi_horizon_replay(bars, config)  # must not raise
        self.assertTrue(result.data_quality.is_valid)

    def test_no_two_closed_trades_ever_overlap_in_time_across_horizons(self):
        n = 300
        bars = [OHLCVBar(open=100.0, high=100.5, low=99.5, close=100.0, volume=10.0,
                          open_time=T0 + timedelta(minutes=15 * i), close_time=T0 + timedelta(minutes=15 * (i + 1)))
                for i in range(n)]
        signals = [80, 150, 220]
        for s_ in signals:  # each signal's trade fills on flat bars, then hits TP=115 three bars later
            b = bars[s_ + 3]
            bars[s_ + 3] = OHLCVBar(open=100.0, high=116.0, low=99.5, close=115.5, volume=10.0,
                                     open_time=b.open_time, close_time=b.close_time)
        candidates_by_time = {
            bars[s_].close_time: _scalp_candidate(DirectionBias.BULLISH, bars[s_].close_time, current_price=100.0,
                                                   entry=(99.0, 100.0), sl=95.0, tp=115.0)
            for s_ in signals
        }

        def side_effect(*args, **kwargs):
            base_mctx = args[1]
            calculated_at = base_mctx.bars[-1].close_time
            c = candidates_by_time.get(calculated_at)
            return _scalp_result(c)

        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=n,
                                           risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50))
        with patch(_PATCH_SCALP, side_effect=side_effect):
            result = run_multi_horizon_replay(bars, config)

        self.assertEqual(len(result.trades), 3)  # non-vacuous: all 3 signals really fired
        self.assertTrue(all(t.state == TradeLifecycleState.FINAL_EXIT for t in result.trades))
        closed = sorted(
            (t for t in result.trades if t.entry_fill is not None and t.exit_fill is not None),
            key=lambda t: t.entry_fill.timestamp,
        )
        for a, b in zip(closed, closed[1:]):
            self.assertLessEqual(a.exit_fill.timestamp, b.entry_fill.timestamp)


class TestMetadataPropagation(unittest.TestCase):
    """7. Metadata Propagation - horizon/source_engine must survive
    Candidate -> NormalizedCandidate -> FinalDecision -> TradeRecord
    without being lost or overwritten, for BOTH the winner and every
    rejected candidate."""

    def test_horizon_and_source_engine_correct_for_winner_and_rejected(self):
        n = 250
        bars = _all_horizon_bars(n)
        idx = 200
        signal_time = bars[idx].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, start_index=idx, end_index=idx,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )
        with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
             patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)):
            result = run_multi_horizon_replay(bars, config)

        by_engine = {t.source_engine: t for t in result.trades}
        self.assertEqual(by_engine["ScalpEngine"].horizon, "SCALP")
        self.assertEqual(by_engine["IntradayEngine"].horizon, "INTRADAY")
        for t in result.trades:
            self.assertNotEqual(t.horizon, "")
            self.assertNotEqual(t.source_engine, "")

    def test_metadata_survives_all_the_way_to_a_fully_filled_final_exit_trade(self):
        bars = [OHLCVBar(open=100.0, high=100.5, low=99.5, close=100.0, volume=10.0,
                          open_time=T0 + timedelta(minutes=15 * i), close_time=T0 + timedelta(minutes=15 * (i + 1)))
                for i in range(60)]
        signal_time = bars[-1].close_time
        c = _scalp_candidate(DirectionBias.BULLISH, signal_time, current_price=100.0,
                              entry=(99.0, 100.0), sl=95.0, tp=115.0)
        future = [
            OHLCVBar(open=99.5, high=100.2, low=98.8, close=99.8, volume=10.0,
                     open_time=bars[-1].close_time, close_time=bars[-1].close_time + timedelta(minutes=15)),
            OHLCVBar(open=100.0, high=116.0, low=99.5, close=115.5, volume=10.0,
                     open_time=bars[-1].close_time + timedelta(minutes=15), close_time=bars[-1].close_time + timedelta(minutes=30)),
        ]
        full_bars = bars + future
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_intraday=False, enable_short_swing=False, max_lookback_bars=60,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )
        with patch(_PATCH_SCALP) as mock_detect:
            mock_detect.side_effect = lambda *a, **k: (_scalp_result(c) if mock_detect.call_count == 1 else _scalp_result())
            result = run_multi_horizon_replay(full_bars, config)

        closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT]
        self.assertEqual(len(closed), 1)
        self.assertEqual(closed[0].horizon, "SCALP")
        self.assertEqual(closed[0].source_engine, "ScalpEngine")


class TestRejectedCandidateTraceability(unittest.TestCase):
    """8. Rejected Candidate Traceability - no rejected candidate
    disappears silently; each carries a distinguishable reason."""

    def test_quality_gate_rejection_is_traced_with_a_quality_specific_reason(self):
        n = 80
        bars = _all_horizon_bars(n)
        idx = 60
        signal_time = bars[idx].close_time
        weak_candidate = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        weak_candidate = ScalpCandidate(
            **{**weak_candidate.__dict__, "evidence": _scalp_evidence(AlignmentLevel.WEAK), "data_quality": "DEGRADED"}
        )
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80,
                                           start_index=idx, end_index=idx)
        with patch(_PATCH_SCALP, return_value=_scalp_result(weak_candidate)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual(len(result.trades), 1)
        self.assertEqual(result.trades[0].state, TradeLifecycleState.INVALIDATED)
        self.assertTrue(result.trades[0].rejection_detail)  # non-empty, real reason recorded

    def test_risk_rejection_is_traced_as_rejected_by_risk_not_invalidated(self):
        n = 80
        bars = _all_horizon_bars(n)
        idx = 60
        signal_time = bars[idx].close_time
        # SL far tighter than min_sl_distance_pct allows is rejected by
        # the risk gate specifically (RiskPolicy default min 0.05%).
        c = _scalp_candidate(DirectionBias.BULLISH, signal_time, current_price=100.0,
                              entry=(99.9, 100.0), sl=99.999, tp=115.0)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80,
                                           start_index=idx, end_index=idx)
        with patch(_PATCH_SCALP, return_value=_scalp_result(c)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual(len(result.trades), 1)
        self.assertEqual(result.trades[0].state, TradeLifecycleState.REJECTED_BY_RISK)
        self.assertTrue(result.trades[0].rejection_detail)

    def test_no_candidate_step_produces_no_trade_record_at_all_not_a_hidden_rejection(self):
        bars = _all_horizon_bars(80)
        config = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
                                           enable_intraday=False, enable_short_swing=False, max_lookback_bars=80)
        with patch(_PATCH_SCALP, return_value=_scalp_result(None)):
            result = run_multi_horizon_replay(bars, config)
        self.assertEqual(result.trades, ())  # correctly distinguishable from "rejected": nothing to reject


class TestDeterministicOrdering(unittest.TestCase):
    """10. Deterministic Ordering - candidate/trade ordering must never
    depend on dict/set iteration or timing; only on the fixed
    Scalp -> Intraday -> Short-Swing collection order and each stage's
    explicit, documented tie-break rules."""

    def test_trade_trace_order_is_stable_across_repeated_runs_with_all_three_horizons(self):
        n = SHORT_SWING_REQ + 1
        bars = _all_horizon_bars(n)
        idx = SHORT_SWING_REQ - 1
        signal_time = bars[idx].close_time
        scalp_c = _scalp_candidate(DirectionBias.BULLISH, signal_time)
        intraday_c = _intraday_candidate(DirectionBias.BEARISH, signal_time)
        ss_c = _short_swing_candidate(DirectionBias.BULLISH, signal_time)
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            start_index=idx, end_index=idx,
            risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50),
        )
        orderings = []
        for _ in range(4):
            with patch(_PATCH_SCALP, return_value=_scalp_result(scalp_c)), \
                 patch(_PATCH_INTRADAY, return_value=_intraday_result(intraday_c)), \
                 patch(_PATCH_SHORT_SWING, return_value=_short_swing_result(ss_c)):
                result = run_multi_horizon_replay(bars, config)
            orderings.append(tuple(t.source_engine for t in result.trades))
        self.assertEqual(len(set(orderings)), 1)
        # Real, explainable order (not an arbitrary expectation): decide()'s
        # candidate_trace records Intraday (dropped in the conflict stage)
        # first, then Short-Swing (REJECTED_RANKED_LOWER, assigned after
        # the winner is found), and the replay engine appends the winner's
        # own TradeRecord (Scalp) last, after the rejected-candidate loop.
        self.assertEqual(orderings[0], ("IntradayEngine", "ShortSwingEngine", "ScalpEngine"))


if __name__ == "__main__":
    unittest.main()
