import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.enums import FVGType, LiquidityType, SRLevelType, SwingType
from omnisystem_v5.context.schema import FairValueGap, LiquidityZone, SupportResistanceLevel, SwingPoint
from omnisystem_v5.quant.enums import InvalidationDirection, InvalidationSource
from omnisystem_v5.quant.invalidation import (
    candidates_from_fvgs,
    candidates_from_liquidity_zones,
    candidates_from_support_resistance,
    candidates_from_swings,
    gather_invalidation_candidates,
)
from omnisystem_v5.schemas.enums import Timeframe

UTC = timezone.utc


def _swing(price, t, swing_type=SwingType.HIGH, idx=0):
    return SwingPoint(swing_type=swing_type, price=price, timestamp=t, bar_index=idx, confirmed_at_index=idx + 2, timeframe=Timeframe.H1)


class TestCandidatesFromSwings(unittest.TestCase):
    def test_most_recent_high_and_low_selected_by_default(self):
        t0 = datetime.now(UTC)
        swings = (
            _swing(110, t0, SwingType.HIGH, 0),
            _swing(115, t0 + timedelta(hours=5), SwingType.HIGH, 5),  # more recent high
            _swing(90, t0 + timedelta(hours=2), SwingType.LOW, 2),
            _swing(85, t0 + timedelta(hours=7), SwingType.LOW, 7),    # more recent low
        )
        candidates = candidates_from_swings(swings, current_price=100.0, timeframe=Timeframe.H1)
        prices = {c.price for c in candidates}
        self.assertEqual(prices, {115, 85})

    def test_direction_and_distance_correct(self):
        t0 = datetime.now(UTC)
        swings = (_swing(110, t0, SwingType.HIGH, 0),)
        candidates = candidates_from_swings(swings, current_price=100.0, timeframe=Timeframe.H1)
        self.assertEqual(len(candidates), 1)
        c = candidates[0]
        self.assertEqual(c.direction, InvalidationDirection.ABOVE_PRICE)
        self.assertAlmostEqual(c.distance_abs, 10.0)
        self.assertAlmostEqual(c.distance_pct, 10.0)
        self.assertTrue(c.valid)

    def test_already_breached_swing_high_marked_invalid(self):
        t0 = datetime.now(UTC)
        # a swing HIGH's intrinsic side is ABOVE_PRICE; price has since closed
        # above it (price=100 > swing price=90), so geometrically it is now
        # BELOW_PRICE -> mismatch with its intrinsic side -> broken/invalid.
        swings = (_swing(90, t0, SwingType.HIGH, 0),)
        candidates = candidates_from_swings(swings, current_price=100.0, timeframe=Timeframe.H1)
        c = candidates[0]
        self.assertEqual(c.direction, InvalidationDirection.BELOW_PRICE)
        self.assertFalse(c.valid, "a swing high that price has already closed above is a broken level")

    def test_intact_swing_low_marked_valid(self):
        t0 = datetime.now(UTC)
        # swing LOW's intrinsic side is BELOW_PRICE; price (100) is indeed
        # above it (80) -> geometric direction matches intrinsic side -> valid.
        swings = (_swing(80, t0, SwingType.LOW, 0),)
        candidates = candidates_from_swings(swings, current_price=100.0, timeframe=Timeframe.H1)
        c = candidates[0]
        self.assertEqual(c.direction, InvalidationDirection.BELOW_PRICE)
        self.assertTrue(c.valid)


class TestCandidatesFromSupportResistance(unittest.TestCase):
    def test_basic_mapping(self):
        t0 = datetime.now(UTC)
        levels = (
            SupportResistanceLevel(
                level_type=SRLevelType.SUPPORT, price=95.0, timeframe=Timeframe.H1,
                touch_count=2, first_formed_at=t0, last_touched_at=t0 + timedelta(hours=3),
            ),
        )
        candidates = candidates_from_support_resistance(levels, current_price=100.0, timeframe=Timeframe.H1)
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0].source, InvalidationSource.SUPPORT_RESISTANCE)
        self.assertEqual(candidates[0].direction, InvalidationDirection.BELOW_PRICE)
        self.assertTrue(candidates[0].valid)

    def test_broken_resistance_marked_invalid(self):
        t0 = datetime.now(UTC)
        # resistance's intrinsic side is ABOVE_PRICE; price has since traded
        # above the level -> geometrically BELOW_PRICE -> broken -> invalid.
        levels = (
            SupportResistanceLevel(
                level_type=SRLevelType.RESISTANCE, price=90.0, timeframe=Timeframe.H1,
                touch_count=2, first_formed_at=t0, last_touched_at=t0,
            ),
        )
        candidates = candidates_from_support_resistance(levels, current_price=100.0, timeframe=Timeframe.H1)
        self.assertFalse(candidates[0].valid)


class TestCandidatesFromLiquidityZones(unittest.TestCase):
    def test_basic_mapping(self):
        t0 = datetime.now(UTC)
        zones = (
            LiquidityZone(
                liquidity_type=LiquidityType.EQUAL_HIGHS, price_level=110.0,
                timeframe=Timeframe.H1, touch_count=2, formed_at=t0,
            ),
        )
        candidates = candidates_from_liquidity_zones(zones, current_price=100.0, timeframe=Timeframe.H1)
        self.assertEqual(candidates[0].source, InvalidationSource.LIQUIDITY_ZONE)
        self.assertEqual(candidates[0].direction, InvalidationDirection.ABOVE_PRICE)


class TestCandidatesFromFvgs(unittest.TestCase):
    def test_unfilled_fvg_produces_two_boundary_candidates(self):
        t0 = datetime.now(UTC)
        gap = FairValueGap(
            fvg_type=FVGType.BULLISH, top=105.0, bottom=102.0,
            timeframe=Timeframe.H1, formed_at=t0, filled=False,
        )
        candidates = candidates_from_fvgs((gap,), current_price=100.0, timeframe=Timeframe.H1)
        self.assertEqual(len(candidates), 2)
        self.assertTrue(all(c.source == InvalidationSource.FVG_BOUNDARY for c in candidates))

    def test_filled_fvg_excluded(self):
        t0 = datetime.now(UTC)
        gap = FairValueGap(
            fvg_type=FVGType.BULLISH, top=105.0, bottom=102.0,
            timeframe=Timeframe.H1, formed_at=t0, filled=True, filled_at=t0 + timedelta(hours=1),
        )
        candidates = candidates_from_fvgs((gap,), current_price=100.0, timeframe=Timeframe.H1)
        self.assertEqual(len(candidates), 0)


class TestGatherAll(unittest.TestCase):
    def test_sorted_by_distance_ascending(self):
        t0 = datetime.now(UTC)
        swings = (_swing(150, t0, SwingType.HIGH, 0), _swing(50, t0, SwingType.LOW, 1))
        sr = (SupportResistanceLevel(level_type=SRLevelType.RESISTANCE, price=101.0, timeframe=Timeframe.H1,
                                      touch_count=2, first_formed_at=t0, last_touched_at=t0),)
        candidates = gather_invalidation_candidates(
            swings=swings, support_resistance=sr, liquidity_zones=(), fair_value_gaps=(),
            current_price=100.0, timeframe=Timeframe.H1,
        )
        distances = [c.distance_abs for c in candidates]
        self.assertEqual(distances, sorted(distances))
        self.assertAlmostEqual(distances[0], 1.0)  # the 101 resistance is closest

    def test_timeframe_integrity_across_all_sources(self):
        t0 = datetime.now(UTC)
        swings = (_swing(150, t0, SwingType.HIGH, 0),)
        candidates = gather_invalidation_candidates(
            swings=swings, support_resistance=(), liquidity_zones=(), fair_value_gaps=(),
            current_price=100.0, timeframe=Timeframe.H4,
        )
        self.assertTrue(all(c.timeframe == Timeframe.H4 for c in candidates))


if __name__ == "__main__":
    unittest.main()
