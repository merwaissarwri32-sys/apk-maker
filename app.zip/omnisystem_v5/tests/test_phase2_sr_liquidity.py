import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.liquidity import detect_liquidity_zones
from omnisystem_v5.calculations.support_resistance import detect_support_resistance
from omnisystem_v5.calculations.swings import find_swing_points
from omnisystem_v5.context.enums import LiquidityType, SRLevelType
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_highs_lows(values, t0):
    bars = []
    for i, (h, l) in enumerate(values):
        mid = (h + l) / 2
        bars.append(
            OHLCVBar(
                open=mid, high=h, low=l, close=mid, volume=10.0,
                open_time=t0 + timedelta(hours=i),
                close_time=t0 + timedelta(hours=i, minutes=59),
            )
        )
    return bars


class TestSupportResistance(unittest.TestCase):
    def test_two_equal_swing_highs_form_resistance(self):
        t0 = datetime.now(UTC)
        # Two swing highs at ~100 (within tolerance), separated in time.
        hl = [
            (90, 80), (95, 85), (100, 92), (95, 85), (90, 80),
            (91, 81), (100.05, 92), (91, 81), (90, 80),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        levels = detect_support_resistance(swings, Timeframe.H1, tolerance_pct=0.01, min_touches=2)
        resistance = [lv for lv in levels if lv.level_type == SRLevelType.RESISTANCE]
        self.assertEqual(len(resistance), 1)
        self.assertEqual(resistance[0].touch_count, 2)

    def test_single_swing_is_not_reported_as_level(self):
        t0 = datetime.now(UTC)
        hl = [(90, 80), (95, 85), (100, 92), (95, 85), (90, 80)]  # only 1 swing high
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        levels = detect_support_resistance(swings, Timeframe.H1, tolerance_pct=0.01, min_touches=2)
        self.assertEqual(len(levels), 0)

    def test_dissimilar_swings_do_not_cluster(self):
        t0 = datetime.now(UTC)
        # swing highs far apart in price: 100 and 200 -> should not cluster together
        hl = [
            (90, 80), (95, 85), (100, 92), (95, 85), (90, 80),
            (150, 130), (200, 180), (150, 130), (140, 120),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        levels = detect_support_resistance(swings, Timeframe.H1, tolerance_pct=0.01, min_touches=2)
        resistance = [lv for lv in levels if lv.level_type == SRLevelType.RESISTANCE]
        self.assertEqual(len(resistance), 0, "100 and 200 are far outside 1% tolerance, must not cluster")


class TestLiquidityZones(unittest.TestCase):
    def test_equal_highs_detected_as_liquidity(self):
        t0 = datetime.now(UTC)
        hl = [
            (90, 80), (95, 85), (100.0, 92), (95, 85), (90, 80),
            (91, 81), (100.02, 92), (91, 81), (90, 80),
        ]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        zones = detect_liquidity_zones(swings, Timeframe.H1, tolerance_pct=0.001)
        equal_highs = [z for z in zones if z.liquidity_type == LiquidityType.EQUAL_HIGHS]
        self.assertEqual(len(equal_highs), 1)
        self.assertEqual(equal_highs[0].touch_count, 2)

    def test_no_liquidity_zone_from_single_swing(self):
        t0 = datetime.now(UTC)
        hl = [(90, 80), (95, 85), (100, 92), (95, 85), (90, 80)]
        bars = _bars_from_highs_lows(hl, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        zones = detect_liquidity_zones(swings, Timeframe.H1, tolerance_pct=0.001)
        self.assertEqual(len(zones), 0)


if __name__ == "__main__":
    unittest.main()
