import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.structure_events import detect_structure_breaks
from omnisystem_v5.calculations.swings import find_swing_points
from omnisystem_v5.context.enums import StructureEventType
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_ohlc(values, t0):
    """values: list of (open, high, low, close)."""
    bars = []
    for i, (o, h, l, c) in enumerate(values):
        bars.append(
            OHLCVBar(
                open=o, high=h, low=l, close=c, volume=10.0,
                open_time=t0 + timedelta(hours=i),
                close_time=t0 + timedelta(hours=i, minutes=59),
            )
        )
    return bars


class TestStructureBreaks(unittest.TestCase):
    def test_bullish_break_with_no_prior_trend_is_choch(self):
        """First-ever break, with UNDEFINED trend context, must be
        classified conservatively as CHOCH_BULLISH per the documented rule."""
        t0 = datetime.now(UTC)
        # Build: a single swing high at idx2 (14), then a bar that closes above it.
        values = [
            (10, 10, 8, 9), (12, 12, 9, 11), (14, 14, 12, 13), (11, 11, 9, 10), (10, 10, 7, 9),
            # idx4 confirms swing high(14) at idx4 (window=2). Now bar idx5 closes above 14.
            (15, 20, 14, 18),
        ]
        bars = _bars_from_ohlc(values, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = detect_structure_breaks(bars, swings, Timeframe.H1)
        bullish_breaks = [e for e in events if e.event_type in (StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH)]
        self.assertEqual(len(bullish_breaks), 1)
        self.assertEqual(bullish_breaks[0].event_type, StructureEventType.CHOCH_BULLISH)

    def test_bearish_break_with_no_prior_trend_is_choch(self):
        t0 = datetime.now(UTC)
        values = [
            (10, 12, 10, 11), (9, 11, 9, 10), (8, 10, 6, 7), (9, 11, 9, 10), (10, 12, 10, 11),
            # idx2 confirms swing low(6) at idx4. bar idx5 closes below 6.
            (5, 6, 2, 3),
        ]
        bars = _bars_from_ohlc(values, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = detect_structure_breaks(bars, swings, Timeframe.H1)
        bearish_breaks = [e for e in events if e.event_type in (StructureEventType.BOS_BEARISH, StructureEventType.CHOCH_BEARISH)]
        self.assertEqual(len(bearish_breaks), 1)
        self.assertEqual(bearish_breaks[0].event_type, StructureEventType.CHOCH_BEARISH)

    def test_broken_swing_is_retired_and_not_rebroken(self):
        t0 = datetime.now(UTC)
        values = [
            (10, 10, 8, 9), (12, 12, 9, 11), (14, 14, 12, 13), (11, 11, 9, 10), (10, 10, 7, 9),
            (15, 20, 14, 18),   # break above 14 once
            (17, 17, 15, 16), (16, 16, 14, 15), (18, 19, 15, 18),  # closes near/above 14 again but shouldn't re-trigger old level
        ]
        bars = _bars_from_ohlc(values, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = detect_structure_breaks(bars, swings, Timeframe.H1)
        bullish_breaks = [e for e in events if e.event_type in (StructureEventType.BOS_BULLISH, StructureEventType.CHOCH_BULLISH)]
        # Only one break of the original 14-level should be recorded, even though
        # later closes also sit above 14 (no active_high exists anymore for that level).
        self.assertEqual(len(bullish_breaks), 1)

    def test_no_break_when_close_does_not_exceed_active_swing(self):
        t0 = datetime.now(UTC)
        values = [
            (10, 10, 8, 9), (12, 12, 9, 11), (14, 14, 12, 13), (11, 11, 9, 10), (10, 10, 7, 9),
            (12, 13, 11, 12),  # closes below 14, no break
        ]
        bars = _bars_from_ohlc(values, t0)
        swings = find_swing_points(bars, Timeframe.H1, window=2)
        events = detect_structure_breaks(bars, swings, Timeframe.H1)
        self.assertEqual(len(events), 0)

    def test_events_retain_correct_timeframe(self):
        t0 = datetime.now(UTC)
        values = [
            (10, 10, 8, 9), (12, 12, 9, 11), (14, 14, 12, 13), (11, 11, 9, 10), (10, 10, 7, 9),
            (15, 20, 14, 18),
        ]
        bars = _bars_from_ohlc(values, t0)
        swings = find_swing_points(bars, Timeframe.H4, window=2)
        events = detect_structure_breaks(bars, swings, Timeframe.H4)
        self.assertTrue(all(e.timeframe == Timeframe.H4 for e in events))


if __name__ == "__main__":
    unittest.main()
