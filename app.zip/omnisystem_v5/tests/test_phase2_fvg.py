import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.calculations.fvg import detect_fair_value_gaps
from omnisystem_v5.context.enums import FVGType
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_ohlc(values, t0):
    """values: list of (open, high, low, close)."""
    bars = []
    for i, (o, h, l, c) in enumerate(values):
        bars.append(
            OHLCVBar(
                open=o, high=h, low=l, close=c, volume=10.0,
                open_time=t0 + timedelta(hours=i),
                close_time=t0 + timedelta(hours=i, minutes=59),
            )
        )
    return bars


class TestFairValueGaps(unittest.TestCase):
    def test_bullish_fvg_detected(self):
        t0 = datetime.now(UTC)
        # A: high=10, B: middle candle, C: low=15 -> gap [10, 15], A.high < C.low
        values = [
            (9, 10, 8, 9.5),     # A
            (12, 16, 11, 15),    # B (middle, drives the gap)
            (15, 18, 15, 17),    # C: low=15 > A.high=10
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.H1)
        self.assertEqual(len(gaps), 1)
        gap = gaps[0]
        self.assertEqual(gap.fvg_type, FVGType.BULLISH)
        self.assertEqual(gap.bottom, 10)
        self.assertEqual(gap.top, 15)
        self.assertEqual(gap.formed_at, bars[1].open_time)

    def test_bearish_fvg_detected(self):
        t0 = datetime.now(UTC)
        # A: low=15, C: high=10 -> A.low > C.high -> gap [10, 15]
        values = [
            (16, 17, 15, 16.5),   # A
            (13, 14, 11, 12),     # B
            (10, 10, 8, 9),       # C: high=10 < A.low=15
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.H1)
        self.assertEqual(len(gaps), 1)
        gap = gaps[0]
        self.assertEqual(gap.fvg_type, FVGType.BEARISH)
        self.assertEqual(gap.bottom, 10)
        self.assertEqual(gap.top, 15)

    def test_no_gap_when_candles_overlap(self):
        t0 = datetime.now(UTC)
        values = [
            (10, 12, 9, 11),
            (11, 13, 10, 12),
            (12, 13, 10, 11),   # overlaps with A's range, no imbalance
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.H1)
        self.assertEqual(len(gaps), 0)

    def test_gap_marked_filled_when_price_returns(self):
        t0 = datetime.now(UTC)
        values = [
            (9, 10, 8, 9.5),     # A
            (12, 16, 11, 15),    # B
            (15, 18, 15, 17),    # C -> bullish gap [10,15]
            (16, 17, 15.5, 16),  # still above gap
            (14, 15, 9, 12),     # dips back into [10,15] -> fills the gap
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.H1)
        self.assertEqual(len(gaps), 1)
        self.assertTrue(gaps[0].filled)
        self.assertEqual(gaps[0].filled_at, bars[4].close_time)

    def test_gap_not_marked_filled_without_forward_data(self):
        t0 = datetime.now(UTC)
        values = [
            (9, 10, 8, 9.5),
            (12, 16, 11, 15),
            (15, 18, 15, 17),   # bullish gap, no bars after this
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.H1)
        self.assertEqual(len(gaps), 1)
        self.assertFalse(gaps[0].filled)
        self.assertIsNone(gaps[0].filled_at)

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_ohlc([(1, 2, 0.5, 1.5), (1, 2, 0.5, 1.5)], t0)
        with self.assertRaises(InsufficientDataError):
            detect_fair_value_gaps(bars, Timeframe.H1)

    def test_events_retain_correct_timeframe(self):
        t0 = datetime.now(UTC)
        values = [
            (9, 10, 8, 9.5),
            (12, 16, 11, 15),
            (15, 18, 15, 17),
        ]
        bars = _bars_from_ohlc(values, t0)
        gaps = detect_fair_value_gaps(bars, Timeframe.M15)
        self.assertTrue(all(g.timeframe == Timeframe.M15 for g in gaps))


if __name__ == "__main__":
    unittest.main()
