"""
Shared fixtures for the Phase 9 test suites.

EVIDENCE CLASS: every bar series built here is SYNTHETIC
(`FIXTURE_EVIDENCE_CLASS`). It exists to exercise the real, unmocked
Scalp -> Decision -> Risk -> Execution pipeline on inputs that reliably
produce closed trades. It is NOT market evidence and no result derived
from it may be presented as market performance.

The real engines stamp `calculated_at` with the wall clock, so
`candidate_id` / `decision_id` are NOT reproducible across runs with
real engines (`trade_id` is). `comparable_trade` therefore excludes
exactly those two fields; everything else must match.
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone

from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.enums import TradeLifecycleState
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
from omnisystem_v5.validation.walk_forward_runner import WalkForwardMode, WalkForwardRunConfig

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)
FIXTURE_EVIDENCE_CLASS = "SYNTHETIC_FIXTURE"
_WALL_CLOCK_DERIVED_FIELDS = ("candidate_id", "decision_id")


def oscillating_bars(n, seed=1, amp=3.0, period=40, drift=0.02, noise=0.4, minutes=15):
    """Deterministic drifting sine + seeded noise (SYNTHETIC)."""
    rnd = random.Random(seed)
    out, prev = [], 100.0
    for i in range(n):
        c = 100 + drift * i + amp * math.sin(2 * math.pi * i / period) + rnd.uniform(-noise, noise)
        o = prev
        h = max(o, c) + abs(rnd.uniform(0, 0.3))
        lo = min(o, c) - abs(rnd.uniform(0, 0.3))
        out.append(OHLCVBar(o, h, lo, c, 100 + rnd.random() * 10,
                            T0 + timedelta(minutes=minutes * i), T0 + timedelta(minutes=minutes * (i + 1))))
        prev = c
    return out


def loose_risk_policy(**kw):
    params = dict(min_reward_risk_ratio=1.0, max_sl_distance_pct=50,
                  max_exposure_pct=100000, max_total_open_risk_pct=100)
    params.update(kw)
    return RiskPolicy(**params)


def scalp_template(**kw):
    """Scalp-only template; risk policy loosened only so real candidates can
    execute in the synthetic fixture (a stated fixture choice, not a tuned one)."""
    kw.setdefault("risk_policy", loose_risk_policy())
    return MultiHorizonReplayConfig(
        symbol="X", base_timeframe=Timeframe.M15, initial_capital=10000.0,
        enable_intraday=False, enable_short_swing=False, **kw)


def wf_config(mode=WalkForwardMode.ROLLING, train=100, test=100, step=None, template=None):
    return WalkForwardRunConfig(mode=mode, train_bars=train, test_bars=test,
                                replay_config_template=template or scalp_template(), step_bars=step)


# ---- stress / adversarial builders (all return NEW lists; inputs untouched) ----
def with_duplicate_timestamp(bars, index):
    out = list(bars)
    out.insert(index + 1, bars[index])
    return out


def with_removed_bars(bars, indices):
    drop = set(indices)
    return [b for i, b in enumerate(bars) if i not in drop]


def with_swapped_adjacent(bars, index):
    out = list(bars)
    out[index], out[index + 1] = out[index + 1], out[index]
    return out


def scaled_volatility(bars, factor):
    """Scale each bar's body and wicks around its own open (SYNTHETIC stress)."""
    out = []
    for x in bars:
        o = x.open
        c = o + (x.close - o) * factor
        hi = max(o, c) + (x.high - max(o, x.close)) * factor
        lo = min(o, c) - (min(o, x.close) - x.low) * factor
        out.append(OHLCVBar(o, hi, lo, c, x.volume, x.open_time, x.close_time))
    return out


def mutate_from(bars, start_index, mutation):
    return list(bars[:start_index]) + mutation(list(bars[start_index:]))


# ---- comparison helpers ----
def comparable_trade(t):
    """All TradeRecord fields except the two wall-clock-derived ids."""
    return tuple((k, getattr(t, k)) for k in t.__dataclass_fields__ if k not in _WALL_CLOCK_DERIVED_FIELDS)


def comparable_trades(trades):
    return tuple(comparable_trade(t) for t in trades)


def closed_trades(trades):
    return [t for t in trades if t.state == TradeLifecycleState.FINAL_EXIT]


def flat_bars(n, start_index=0, base=100.0, minutes=15):
    """Featureless series on which the real engines find no candidate (SYNTHETIC)."""
    return [OHLCVBar(base, base + 0.5, base - 0.5, base, 10.0,
                     T0 + timedelta(minutes=minutes * (start_index + i)),
                     T0 + timedelta(minutes=minutes * (start_index + i + 1))) for i in range(n)]
