import unittest
from datetime import datetime, timezone

from omnisystem_v5.decision.contracts import NormalizedCandidate, ScoreComponents
from omnisystem_v5.decision.enums import QualityLevel
from omnisystem_v5.decision.quality_gate import apply_quality_gate, passes_quality_gate
from omnisystem_v5.decision.policy import QualityGatePolicy
from omnisystem_v5.risk.enums import Direction

UTC = timezone.utc
NOW = datetime.now(UTC)


def _cand(**quality_kwargs):
    q = ScoreComponents(**quality_kwargs)
    cid = NormalizedCandidate.make_id("ScalpEngine", "BTCUSDT", Direction.LONG, 100.0, 95.0, (110.0,), "SCALP", NOW)
    return NormalizedCandidate(candidate_id=cid, source_engine="ScalpEngine", horizon="SCALP", symbol="BTCUSDT",
                                direction=Direction.LONG, entry=100.0, stop_loss=95.0, take_profits=(110.0,),
                                generated_at=NOW, quality=q)


class TestQualityGate(unittest.TestCase):
    def test_enough_moderate_components_passes(self):
        c = _cand(structural_quality=QualityLevel.STRONG, risk_quality=QualityLevel.MODERATE, reward_quality=QualityLevel.MODERATE)
        ok, detail = passes_quality_gate(c, QualityGatePolicy(min_moderate_plus_components=3))
        self.assertTrue(ok)

    def test_too_few_moderate_components_fails(self):
        c = _cand(structural_quality=QualityLevel.WEAK, risk_quality=QualityLevel.NONE)
        ok, detail = passes_quality_gate(c, QualityGatePolicy(min_moderate_plus_components=3))
        self.assertFalse(ok)
        self.assertIn("0/8", detail)

    def test_exactly_at_threshold_passes(self):
        c = _cand(structural_quality=QualityLevel.MODERATE, risk_quality=QualityLevel.MODERATE, reward_quality=QualityLevel.MODERATE)
        ok, detail = passes_quality_gate(c, QualityGatePolicy(min_moderate_plus_components=3))
        self.assertTrue(ok)

    def test_apply_quality_gate_splits_passed_and_failed(self):
        good = _cand(structural_quality=QualityLevel.STRONG, risk_quality=QualityLevel.STRONG, reward_quality=QualityLevel.STRONG)
        bad = _cand(structural_quality=QualityLevel.NONE)
        passed, failures = apply_quality_gate([good, bad], QualityGatePolicy(min_moderate_plus_components=3))
        self.assertEqual(passed, [good])
        self.assertIn(bad.candidate_id, failures)

    def test_all_none_fails(self):
        c = _cand()
        ok, _ = passes_quality_gate(c, QualityGatePolicy(min_moderate_plus_components=1))
        self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
