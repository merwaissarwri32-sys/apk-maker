"""
Phase 8 - Real Walk-Forward Runner.

Test-first, mirroring test_phase8_multi_horizon_replay.py's mock
policy exactly: only detect_scalp_candidate is patched (test boundary
only); every context/quant/decision/risk/period-split outcome is
produced by real, unmodified production code.
"""
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from omnisystem_v5.intelligence.enums import DirectionBias
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.tests.test_phase8_multi_horizon_replay import _scalp_candidate, _scalp_result
from omnisystem_v5.validation.enums import TradeLifecycleState, ValidationPeriodType
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig
from omnisystem_v5.validation.walk_forward_runner import (
    Fold,
    WalkForwardMode,
    WalkForwardRunConfig,
    compute_folds,
    run_walk_forward,
)

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)

_PATCH_SCALP = "omnisystem_v5.validation.multi_horizon_replay.detect_scalp_candidate"


def _flat_bars(n, base=100.0):
    return [OHLCVBar(open=base, high=base + 0.5, low=base - 0.5, close=base, volume=10.0,
                      open_time=T0 + timedelta(minutes=15 * i), close_time=T0 + timedelta(minutes=15 * (i + 1)))
            for i in range(n)]


def _scalp_only_template(**kw):
    if "max_lookback_bars" in kw and "min_bars_required" not in kw:
        kw["min_bars_required"] = kw["max_lookback_bars"]
    return MultiHorizonReplayConfig(
        symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
        enable_intraday=False, enable_short_swing=False,
        risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50), **kw,
    )


def _rapid_fire_template():
    """Phase 9 retrofit: a scalp-only template whose risk policy does not
    reject the mock candidate below, so trades genuinely close."""
    return MultiHorizonReplayConfig(
        symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
        enable_intraday=False, enable_short_swing=False,
        risk_policy=RiskPolicy(min_reward_risk_ratio=1.0, max_sl_distance_pct=50,
                                max_exposure_pct=100000, max_total_open_risk_pct=100),
        max_lookback_bars=40, min_bars_required=40,
    )


def _rapid_fire_result():
    """A fixed-clock candidate (entry zone brackets the flat price, SL/TP
    inside one bar's range) that opens and closes trades on nearly every
    replay step - so retrofitted tests provably exercise real trades."""
    cand = _scalp_candidate(DirectionBias.BULLISH, T0, current_price=100.0,
                             entry=(99.5, 100.5), sl=99.6, tp=100.4)
    return _scalp_result(cand)


def _closed_count(result):
    return sum(1 for fr in result.fold_results for t in fr.backtest.trades
               if t.state == TradeLifecycleState.FINAL_EXIT)


class TestWalkForwardRunConfigValidation(unittest.TestCase):
    def test_non_positive_train_bars_rejected(self):
        with self.assertRaises(ValueError):
            WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=0, test_bars=10,
                                  replay_config_template=_scalp_only_template(max_lookback_bars=40))

    def test_non_positive_test_bars_rejected(self):
        with self.assertRaises(ValueError):
            WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=0,
                                  replay_config_template=_scalp_only_template(max_lookback_bars=40))

    def test_non_positive_step_bars_rejected(self):
        with self.assertRaises(ValueError):
            WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=10, step_bars=0,
                                  replay_config_template=_scalp_only_template(max_lookback_bars=40))

    def test_step_bars_defaults_to_test_bars(self):
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=15,
                                       replay_config_template=_scalp_only_template(max_lookback_bars=40))
        self.assertEqual(config.step_bars, 15)

    def test_rolling_train_bars_smaller_than_required_lookback_is_rejected_fail_closed(self):
        # Template requires 3935 bars for Short-Swing if enabled - use
        # the default (all horizons) template so the real requirement
        # from validation/warmup.py is enforced, not a scalp-only floor.
        full_template = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0)
        with self.assertRaises(ValueError):
            WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=400, test_bars=50,
                                  replay_config_template=full_template)

    def test_expanding_mode_rejects_train_bars_below_required_warmup_fail_closed(self):
        # PHASE 9 CONTRACT CHANGE (directive Priority 2). This test used to assert the opposite
        # (EXPANDING accepted train_bars=400 although the enabled horizons need 3935): the first fold(s)
        # would then start without enough history for the higher-timeframe contexts. EXPANDING now
        # fails closed exactly like ROLLING; see test_phase9_walk_forward_robust_validation.py.
        full_template = MultiHorizonReplayConfig(symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0)
        with self.assertRaises(ValueError):
            WalkForwardRunConfig(mode=WalkForwardMode.EXPANDING, train_bars=400, test_bars=50,
                                  replay_config_template=full_template)


class TestComputeFoldsBoundaryMath(unittest.TestCase):
    def test_rolling_folds_are_hand_verifiable_and_non_overlapping(self):
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=10, step_bars=10,
                                       replay_config_template=template)
        folds = compute_folds(100, config)
        expected = (
            Fold(0, 0, 39, 40, 49),
            Fold(1, 10, 49, 50, 59),
            Fold(2, 20, 59, 60, 69),
            Fold(3, 30, 69, 70, 79),
            Fold(4, 40, 79, 80, 89),
            Fold(5, 50, 89, 90, 99),
        )
        self.assertEqual(folds, expected)

    def test_expanding_folds_always_start_warmup_at_zero(self):
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.EXPANDING, train_bars=40, test_bars=10, step_bars=10,
                                       replay_config_template=template)
        folds = compute_folds(70, config)
        expected = (
            Fold(0, 0, 39, 40, 49),
            Fold(1, 0, 49, 50, 59),
            Fold(2, 0, 59, 60, 69),
        )
        self.assertEqual(folds, expected)

    def test_test_windows_never_overlap_when_step_equals_test_bars(self):
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=10,
                                       replay_config_template=template)
        folds = compute_folds(200, config)
        for a, b in zip(folds, folds[1:]):
            self.assertLess(a.test_end_index, b.test_start_index)
            self.assertEqual(a.test_end_index + 1, b.test_start_index)  # contiguous, no gap, no overlap

    def test_dataset_too_short_for_even_one_fold_yields_zero_folds(self):
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=10,
                                       replay_config_template=template)
        folds = compute_folds(45, config)
        self.assertEqual(folds, ())


class TestRunWalkForwardZeroFoldCase(unittest.TestCase):
    def test_too_short_dataset_returns_explicit_empty_result_not_a_crash(self):
        bars = _flat_bars(45)
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=10,
                                       replay_config_template=template)
        result = run_walk_forward(bars, config)
        self.assertEqual(result.fold_results, ())
        self.assertEqual(result.aggregate.fold_count, 0)
        self.assertIsNone(result.aggregate.win_rate)


class TestDeterminism(unittest.TestCase):
    def test_repeated_full_run_is_byte_identical(self):
        bars = _flat_bars(150)
        template = _rapid_fire_template()
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)

        def run_once():
            with patch(_PATCH_SCALP, return_value=_rapid_fire_result()):
                return run_walk_forward(bars, config)

        r1, r2 = run_once(), run_once()
        # Phase 9 retrofit: prove the comparison is not vacuous.
        self.assertGreaterEqual(_closed_count(r1), 3)

        def fingerprint(r):
            return (
                r.dataset_hash, r.aggregate,
                tuple((fr.fold, fr.backtest.trades, fr.backtest.period_splits) for fr in r.fold_results),
            )

        self.assertEqual(fingerprint(r1), fingerprint(r2))


class TestLookAheadProtection(unittest.TestCase):
    def test_extra_trailing_bars_never_change_earlier_folds_results(self):
        bars_a = _flat_bars(120)  # exactly 2 folds worth (40 train + 20 test) * 2 = 120
        bars_b = bars_a + [
            OHLCVBar(open=99999, high=100050, low=99950, close=100000, volume=1,
                     open_time=bars_a[-1].close_time + timedelta(minutes=15 * i),
                     close_time=bars_a[-1].close_time + timedelta(minutes=15 * (i + 1)))
            for i in range(1, 60)
        ]
        template = _rapid_fire_template()
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)

        with patch(_PATCH_SCALP, return_value=_rapid_fire_result()):
            result_a = run_walk_forward(bars_a, config)
            result_b = run_walk_forward(bars_b, config)
        # Phase 9 retrofit: the compared folds must really contain closed trades.
        self.assertGreaterEqual(_closed_count(result_a), 3)

        # bars_b has enough extra bars for additional folds, bars_a does
        # not - but every fold that exists in BOTH datasets must be
        # identical regardless of what comes after it.
        self.assertGreater(len(result_b.fold_results), len(result_a.fold_results))
        for fr_a, fr_b in zip(result_a.fold_results, result_b.fold_results):
            self.assertEqual(fr_a.fold, fr_b.fold)
            self.assertEqual(fr_a.backtest.trades, fr_b.backtest.trades)


class TestFoldIndependence(unittest.TestCase):
    def test_every_fold_uses_the_templates_initial_capital_fresh_not_compounded(self):
        n = 40 + 20 + 20  # 2 folds
        bars = _flat_bars(n)
        template = _rapid_fire_template()
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)
        with patch(_PATCH_SCALP, return_value=_rapid_fire_result()):
            result = run_walk_forward(bars, config)
        # Phase 9 retrofit: every fold must really have executed trades, so
        # "fresh capital" is asserted against folds that could have compounded.
        for fr in result.fold_results:
            self.assertGreaterEqual(sum(1 for t in fr.backtest.trades
                                        if t.state == TradeLifecycleState.FINAL_EXIT), 3)
        for fr in result.fold_results:
            self.assertEqual(fr.backtest.reproducibility.replay_config_summary["initial_capital"], "10000.0")

    def test_a_losing_fold_does_not_change_the_next_folds_position_sizing_inputs(self):
        n = 40 + 20 + 20
        bars = _flat_bars(n)
        signal_time_0 = bars[40].close_time  # first replay step of fold 0's test window
        signal_time_1 = bars[60].close_time  # first replay step of fold 1's test window
        c0 = _scalp_candidate(DirectionBias.BULLISH, signal_time_0, current_price=100.0,
                               entry=(99.0, 100.0), sl=95.0, tp=115.0)
        c1 = _scalp_candidate(DirectionBias.BULLISH, signal_time_1, current_price=100.0,
                               entry=(99.0, 100.0), sl=95.0, tp=115.0)
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)

        def side_effect(*args, **kwargs):
            base_mctx = args[1]
            t = base_mctx.bars[-1].close_time
            if t == signal_time_0:
                return _scalp_result(c0)
            if t == signal_time_1:
                return _scalp_result(c1)
            return _scalp_result(None)

        with patch(_PATCH_SCALP, side_effect=side_effect):
            result = run_walk_forward(bars, config)

        rejected_by_risk_or_invalidated = [
            t for fr in result.fold_results for t in fr.backtest.trades
            if t.state in (TradeLifecycleState.REJECTED_BY_RISK, TradeLifecycleState.INVALIDATED)
        ]
        # identical candidate, identical (fresh) account equity each
        # fold -> if any candidate was rejected/invalidated in fold 0 it
        # must be rejected/invalidated for the SAME reason in fold 1 -
        # proving fold 1 was not affected by fold 0's outcome.
        details = {t.rejection_detail for t in rejected_by_risk_or_invalidated}
        self.assertLessEqual(len(details), 1)
        # non-vacuous: BOTH folds must actually have traced the candidate
        self.assertTrue(all(len(fr.backtest.trades) >= 1 for fr in result.fold_results))
        by_fold = [tuple((t.state, t.exit_reason, t.pnl) for t in fr.backtest.trades) for fr in result.fold_results]
        self.assertEqual(by_fold[0], by_fold[1])


class TestFailureSemantics(unittest.TestCase):
    def test_a_genuine_internal_error_in_one_fold_propagates_and_is_never_swallowed(self):
        bars = _flat_bars(120)
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)
        with patch("omnisystem_v5.validation.walk_forward_runner.run_multi_horizon_replay",
                   side_effect=RuntimeError("simulated genuine bug")):
            with self.assertRaises(RuntimeError):
                run_walk_forward(bars, config)


class TestPeriodSplitsPopulated(unittest.TestCase):
    def test_each_fold_backtest_carries_training_and_out_of_sample_period_splits(self):
        bars = _flat_bars(80)
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)
        with patch(_PATCH_SCALP, return_value=_scalp_result(None)):
            result = run_walk_forward(bars, config)
        fr = result.fold_results[0]
        types = [p.period_type for p in fr.backtest.period_splits]
        self.assertEqual(types, [ValidationPeriodType.TRAINING, ValidationPeriodType.OUT_OF_SAMPLE])
        training, oos = fr.backtest.period_splits
        self.assertEqual(training.start_index, 0)
        self.assertEqual(training.end_index, 39)
        self.assertEqual(oos.start_index, 40)
        self.assertEqual(oos.end_index, 59)


class TestAggregateMetricsCorrectness(unittest.TestCase):
    def test_aggregate_counts_and_pnl_match_hand_calculation_across_two_folds(self):
        n = 40 + 20 + 20
        bars = _flat_bars(n)
        signal_time_0 = bars[40].close_time
        signal_time_1 = bars[60].close_time
        # fold 0: a candidate that will win (TP hit) - future bars appended below
        c0 = _scalp_candidate(DirectionBias.BULLISH, signal_time_0, current_price=100.0,
                               entry=(99.0, 100.0), sl=95.0, tp=115.0)
        # fold 1: no candidate at all -> zero trades from fold 1
        template = _scalp_only_template(max_lookback_bars=40)
        config = WalkForwardRunConfig(mode=WalkForwardMode.ROLLING, train_bars=40, test_bars=20,
                                       replay_config_template=template)

        def side_effect(*args, **kwargs):
            base_mctx = args[1]
            if base_mctx.bars[-1].close_time == signal_time_0:
                return _scalp_result(c0)
            return _scalp_result(None)

        with patch(_PATCH_SCALP, side_effect=side_effect):
            result = run_walk_forward(bars, config)

        self.assertEqual(result.aggregate.fold_count, 2)
        # only fold 0 ever proposes a candidate; whatever its outcome
        # (fill/no-fill within its own test window), fold 1 contributes
        # exactly zero trade records.
        fold1_trades = result.fold_results[1].backtest.trades
        self.assertEqual(fold1_trades, ())
        # non-vacuous: fold 0 really did trace the candidate
        self.assertGreaterEqual(len(result.fold_results[0].backtest.trades), 1)
        self.assertEqual(result.aggregate.total_candidates_traced, len(result.fold_results[0].backtest.trades))
        total_from_folds = sum(len(fr.backtest.trades) for fr in result.fold_results)
        self.assertEqual(result.aggregate.total_candidates_traced, total_from_folds)


if __name__ == "__main__":
    unittest.main()
