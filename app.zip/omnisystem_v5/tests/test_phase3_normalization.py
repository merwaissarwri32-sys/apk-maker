import unittest
from datetime import datetime, timedelta, timezone

import statistics

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.quant.normalization import calculate_atr_normalized_momentum, calculate_return_zscore
from omnisystem_v5.schemas.market_data import OHLCVBar

UTC = timezone.utc


def _bars_from_closes(closes, t0):
    bars = []
    for i, c in enumerate(closes):
        bars.append(
            OHLCVBar(open=c, high=c + 1, low=c - 1, close=c, volume=10.0,
                     open_time=t0 + timedelta(hours=i), close_time=t0 + timedelta(hours=i, minutes=59))
        )
    return bars


class TestReturnZscore(unittest.TestCase):
    def test_matches_manual_calculation(self):
        t0 = datetime.now(UTC)
        closes = [100, 102, 101, 105, 103, 107, 104]
        bars = _bars_from_closes(closes, t0)
        returns = [(closes[i] - closes[i - 1]) / closes[i - 1] for i in range(1, len(closes))]
        mean_r = statistics.mean(returns)
        stdev_r = statistics.stdev(returns)
        expected = (returns[-1] - mean_r) / stdev_r
        result = calculate_return_zscore(bars, window=len(returns))
        self.assertAlmostEqual(result, expected, places=10)

    def test_insufficient_bars_raises(self):
        t0 = datetime.now(UTC)
        bars = _bars_from_closes([100, 101], t0)
        with self.assertRaises(InsufficientDataError):
            calculate_return_zscore(bars, window=10)

    def test_zero_variance_raises(self):
        t0 = datetime.now(UTC)
        # constant returns of exactly 0 -> stdev is 0
        bars = _bars_from_closes([100, 100, 100, 100, 100], t0)
        with self.assertRaises(ValueError):
            calculate_return_zscore(bars, window=4)


class TestAtrNormalizedMomentum(unittest.TestCase):
    def test_hand_calculation(self):
        self.assertAlmostEqual(calculate_atr_normalized_momentum(momentum=6.0, atr=2.0), 3.0)

    def test_negative_momentum_preserves_sign(self):
        self.assertAlmostEqual(calculate_atr_normalized_momentum(momentum=-4.0, atr=2.0), -2.0)

    def test_zero_atr_raises(self):
        with self.assertRaises(ValueError):
            calculate_atr_normalized_momentum(momentum=5.0, atr=0.0)


if __name__ == "__main__":
    unittest.main()
