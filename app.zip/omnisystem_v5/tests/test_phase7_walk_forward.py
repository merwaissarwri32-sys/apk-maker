import unittest

from omnisystem_v5.validation.enums import ValidationPeriodType
from omnisystem_v5.validation.walk_forward import (
    WalkForwardConfig,
    WalkForwardEngine,
    split_walk_forward_periods,
)


class TestWalkForwardConfig(unittest.TestCase):
    def test_default_fractions_sum_to_one(self):
        config = WalkForwardConfig()
        self.assertAlmostEqual(config.training_fraction + config.validation_fraction + config.out_of_sample_fraction, 1.0)

    def test_invalid_fractions_rejected(self):
        with self.assertRaises(ValueError):
            WalkForwardConfig(training_fraction=0.5, validation_fraction=0.3, out_of_sample_fraction=0.3)

    def test_negative_fraction_rejected(self):
        with self.assertRaises(ValueError):
            WalkForwardConfig(training_fraction=-0.1, validation_fraction=0.6, out_of_sample_fraction=0.5)


class TestSplitDeterminism(unittest.TestCase):
    def test_same_input_same_output(self):
        s1 = split_walk_forward_periods(1000)
        s2 = split_walk_forward_periods(1000)
        self.assertEqual(s1, s2)

    def test_split_covers_correct_period_types_in_order(self):
        splits = split_walk_forward_periods(1000)
        self.assertEqual([s.period_type for s in splits],
                          [ValidationPeriodType.TRAINING, ValidationPeriodType.VALIDATION, ValidationPeriodType.OUT_OF_SAMPLE])

    def test_split_respects_configured_fractions_approximately(self):
        config = WalkForwardConfig(training_fraction=0.5, validation_fraction=0.3, out_of_sample_fraction=0.2)
        splits = split_walk_forward_periods(1000, config)
        train, val, oos = splits
        train_len = train.end_index - train.start_index + 1
        val_len = val.end_index - val.start_index + 1
        self.assertAlmostEqual(train_len / 1000, 0.5, delta=0.01)
        self.assertAlmostEqual(val_len / 1000, 0.3, delta=0.01)


class TestNoOverlapNoLeakage(unittest.TestCase):
    def test_periods_are_strictly_chronological_and_non_overlapping(self):
        splits = split_walk_forward_periods(500)
        train, val, oos = splits
        self.assertLess(train.end_index, val.start_index)
        self.assertLess(val.end_index, oos.start_index)

    def test_periods_are_contiguous_no_gaps(self):
        splits = split_walk_forward_periods(500)
        train, val, oos = splits
        self.assertEqual(train.end_index + 1, val.start_index)
        self.assertEqual(val.end_index + 1, oos.start_index)

    def test_out_of_sample_covers_end_of_dataset(self):
        splits = split_walk_forward_periods(500)
        self.assertEqual(splits[-1].end_index, 499)

    def test_training_starts_at_zero(self):
        splits = split_walk_forward_periods(500)
        self.assertEqual(splits[0].start_index, 0)


class TestDegenerateInputs(unittest.TestCase):
    def test_too_few_bars_raises(self):
        with self.assertRaises(ValueError):
            split_walk_forward_periods(2)

    def test_extreme_fractions_that_would_starve_a_period_raise(self):
        config = WalkForwardConfig(training_fraction=0.98, validation_fraction=0.01, out_of_sample_fraction=0.01)
        with self.assertRaises(ValueError):
            split_walk_forward_periods(3, config)

    def test_minimum_viable_bar_count_succeeds(self):
        splits = split_walk_forward_periods(10)
        self.assertEqual(len(splits), 3)


class TestWalkForwardEngineIsAbstractFoundationOnly(unittest.TestCase):
    def test_cannot_instantiate_directly(self):
        with self.assertRaises(TypeError):
            WalkForwardEngine()

    def test_subclass_without_implementation_raises_not_implemented(self):
        class Incomplete(WalkForwardEngine):
            def run_training_window(self, bars, period, config):
                return super().run_training_window(bars, period, config)

            def run_validation_window(self, bars, period, trained_state, config):
                return super().run_validation_window(bars, period, trained_state, config)

            def run_out_of_sample_window(self, bars, period, trained_state, config):
                return super().run_out_of_sample_window(bars, period, trained_state, config)

        instance = Incomplete()
        with self.assertRaises(NotImplementedError):
            instance.run_training_window([], None, None)
        with self.assertRaises(NotImplementedError):
            instance.run_validation_window([], None, None, None)
        with self.assertRaises(NotImplementedError):
            instance.run_out_of_sample_window([], None, None, None)


if __name__ == "__main__":
    unittest.main()
