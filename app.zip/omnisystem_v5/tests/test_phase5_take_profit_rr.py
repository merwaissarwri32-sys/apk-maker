import unittest

from omnisystem_v5.risk.contracts import RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.enums import Direction, RejectionReasonCode, WarningCode
from omnisystem_v5.risk.validators import compute_reward_and_rr, validate_rr, validate_take_profits


def _candidate(direction=Direction.LONG, entry=100.0, sl=98.0, tps=(105.0,)):
    return TradeCandidateInput(symbol="BTCUSDT", direction=direction, entry=entry, stop_loss=sl, take_profits=tps)


class TestTakeProfitValidation(unittest.TestCase):
    def test_single_valid_tp_passes_with_partial_warning(self):
        out = validate_take_profits(_candidate(tps=(105.0,)), RiskPolicy())
        self.assertTrue(out.ok)
        self.assertIn(WarningCode.ONLY_PARTIAL_TAKE_PROFITS_PROVIDED, out.warnings)

    def test_three_ordered_long_tps_pass_without_partial_warning(self):
        out = validate_take_profits(_candidate(tps=(105.0, 110.0, 115.0)), RiskPolicy())
        self.assertTrue(out.ok)
        self.assertNotIn(WarningCode.ONLY_PARTIAL_TAKE_PROFITS_PROVIDED, out.warnings)

    def test_three_ordered_short_tps_pass(self):
        out = validate_take_profits(_candidate(direction=Direction.SHORT, entry=100, sl=102, tps=(95.0, 90.0, 85.0)), RiskPolicy())
        self.assertTrue(out.ok)

    def test_long_tp_wrong_side_rejected(self):
        out = validate_take_profits(_candidate(tps=(95.0,)), RiskPolicy())
        self.assertIn(RejectionReasonCode.TP_WRONG_SIDE, out.rejections)

    def test_short_tp_wrong_side_rejected(self):
        out = validate_take_profits(_candidate(direction=Direction.SHORT, entry=100, sl=102, tps=(105.0,)), RiskPolicy())
        self.assertIn(RejectionReasonCode.TP_WRONG_SIDE, out.rejections)

    def test_tp_equals_entry_rejected(self):
        out = validate_take_profits(_candidate(tps=(100.0,)), RiskPolicy())
        self.assertIn(RejectionReasonCode.TP_EQUALS_ENTRY, out.rejections)

    def test_long_invalid_ordering_rejected(self):
        out = validate_take_profits(_candidate(tps=(110.0, 105.0, 115.0)), RiskPolicy())  # TP2 < TP1
        self.assertIn(RejectionReasonCode.TP_INVALID_ORDERING, out.rejections)

    def test_short_invalid_ordering_rejected(self):
        out = validate_take_profits(_candidate(direction=Direction.SHORT, entry=100, sl=102, tps=(90.0, 95.0, 80.0)), RiskPolicy())
        self.assertIn(RejectionReasonCode.TP_INVALID_ORDERING, out.rejections)

    def test_duplicate_tp_ordering_edge_case(self):
        """Equal consecutive TPs are not strictly ordered — must be flagged,
        not silently accepted as 'ordering satisfied'."""
        out = validate_take_profits(_candidate(tps=(105.0, 105.0, 115.0)), RiskPolicy())
        self.assertIn(RejectionReasonCode.TP_INVALID_ORDERING, out.rejections)

    def test_tp_too_close_rejected(self):
        policy = RiskPolicy(min_tp_distance_pct=1.0)
        out = validate_take_profits(_candidate(tps=(100.05,)), policy)  # 0.05% distance
        self.assertIn(RejectionReasonCode.TP_TOO_CLOSE, out.rejections)

    def test_tp_far_beyond_structure_is_not_rejected_by_this_layer(self):
        """An unusually distant but correctly-ordered TP is not itself
        invalid — that's a market-analysis judgment call belonging to the
        Intelligence layer, not the Risk Engine (separation of concerns)."""
        out = validate_take_profits(_candidate(tps=(1000.0,)), RiskPolicy())
        self.assertTrue(out.ok)


class TestRewardAndRR(unittest.TestCase):
    def test_hand_calculation(self):
        c = _candidate(entry=100, sl=98, tps=(104.0, 106.0))
        rewards, ratios = compute_reward_and_rr(c, risk_amount_per_unit=2.0)
        self.assertEqual(rewards, (4.0, 6.0))
        self.assertEqual(ratios, (2.0, 3.0))

    def test_rr_exactly_at_minimum_passes_as_warning(self):
        out = validate_rr((2.0,), RiskPolicy(min_reward_risk_ratio=2.0, rr_marginal_buffer=0.0))
        self.assertTrue(out.ok)

    def test_rr_slightly_below_minimum_rejected(self):
        out = validate_rr((1.99,), RiskPolicy(min_reward_risk_ratio=2.0))
        self.assertIn(RejectionReasonCode.RR_BELOW_MINIMUM, out.rejections)

    def test_rr_marginal_buffer_produces_warning(self):
        out = validate_rr((2.05,), RiskPolicy(min_reward_risk_ratio=2.0, rr_marginal_buffer=0.1))
        self.assertTrue(out.ok)
        self.assertIn(WarningCode.RR_MARGINAL, out.warnings)

    def test_rr_comfortably_above_minimum_no_warning(self):
        out = validate_rr((5.0,), RiskPolicy(min_reward_risk_ratio=2.0, rr_marginal_buffer=0.1))
        self.assertTrue(out.ok)
        self.assertEqual(out.warnings, ())

    def test_empty_ratios_rejected(self):
        out = validate_rr((), RiskPolicy())
        self.assertIn(RejectionReasonCode.DATA_NO_TAKE_PROFIT, out.rejections)

    def test_only_primary_tp_ratio_decides_outcome(self):
        """Even if TP2/TP3 ratios are excellent, a poor TP1 ratio must
        still fail — the nearest target is the conservative reference."""
        out = validate_rr((1.0, 10.0, 20.0), RiskPolicy(min_reward_risk_ratio=2.0))
        self.assertIn(RejectionReasonCode.RR_BELOW_MINIMUM, out.rejections)


if __name__ == "__main__":
    unittest.main()
