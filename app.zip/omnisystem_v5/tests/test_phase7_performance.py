import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.validation.contracts import SimulatedFill, TradeRecord
from omnisystem_v5.validation.enums import ExitReason, TradeLifecycleState
from omnisystem_v5.validation.performance import calculate_performance_metrics

UTC = timezone.utc
T0 = datetime.now(UTC) - timedelta(hours=1000)


def _trade(i, direction="LONG", pnl=None, r_multiple=None, risk_amount=100.0,
           duration_bars=5, regime="TREND", state=TradeLifecycleState.FINAL_EXIT):
    signal_time = T0 + timedelta(hours=i)
    entry_fill = SimulatedFill(price=100.0, timestamp=signal_time, fee_amount=0.0, slippage_amount=0.0) if pnl is not None else None
    exit_fill = SimulatedFill(price=100.0, timestamp=signal_time + timedelta(hours=1), fee_amount=0.0, slippage_amount=0.0) if pnl is not None else None
    return TradeRecord(
        trade_id=f"t{i}", symbol="BTCUSDT", direction=direction, signal_time=signal_time, state=state,
        entry_zone_bottom=99.0, entry_zone_top=100.0, stop_loss=95.0, take_profits=(110.0,),
        entry_fill=entry_fill, exit_fill=exit_fill, exit_reason=ExitReason.TAKE_PROFIT if pnl and pnl > 0 else ExitReason.STOP_LOSS,
        quantity=10.0, risk_amount=risk_amount, pnl=pnl, r_multiple=r_multiple, duration_bars=duration_bars,
        market_regime=regime,
    )


class TestEmptyAndDegenerateInputs(unittest.TestCase):
    def test_empty_trades_list(self):
        m = calculate_performance_metrics([], initial_capital=10000.0)
        self.assertEqual(m.closed_trades, 0)
        self.assertIsNone(m.win_rate)
        self.assertIsNone(m.profit_factor)
        self.assertIsNone(m.sharpe_ratio)
        self.assertTrue(len(m.reasons) > 0)

    def test_only_non_closed_trades(self):
        trades = [_trade(0, pnl=None, state=TradeLifecycleState.REJECTED_BY_RISK)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.closed_trades, 0)
        self.assertEqual(m.total_trades, 1)

    def test_single_trade(self):
        trades = [_trade(0, pnl=50.0, r_multiple=1.0)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.closed_trades, 1)
        self.assertEqual(m.win_rate, 1.0)
        self.assertTrue(m.sample_size_warning)
        self.assertIsNone(m.sharpe_ratio)


class TestAllWinsAllLosses(unittest.TestCase):
    def test_all_wins(self):
        trades = [_trade(i, pnl=50.0, r_multiple=2.0) for i in range(5)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.win_rate, 1.0)
        self.assertEqual(m.losing_trades, 0)
        self.assertIsNone(m.profit_factor)
        self.assertIn("profit_factor undefined", " ".join(m.reasons))

    def test_all_losses(self):
        trades = [_trade(i, pnl=-30.0, r_multiple=-1.0) for i in range(5)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.win_rate, 0.0)
        self.assertEqual(m.winning_trades, 0)
        self.assertEqual(m.profit_factor, 0.0)
        self.assertLess(m.net_pnl, 0)


class TestZeroNearZeroDenominators(unittest.TestCase):
    def test_zero_variance_returns_sharpe_undefined(self):
        trades = [_trade(i, pnl=50.0, r_multiple=1.0, risk_amount=100.0) for i in range(5)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertIsNone(m.sharpe_ratio)
        self.assertIn("Sharpe undefined", " ".join(m.reasons))

    def test_no_losses_sortino_undefined_not_infinite(self):
        trades = [_trade(i, pnl=50.0 + i, r_multiple=1.0 + i * 0.1) for i in range(5)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertIsNone(m.sortino_ratio)
        self.assertEqual(m.downside_deviation, 0.0)

    def test_zero_risk_amount_excluded_from_sharpe_input(self):
        trades = [_trade(0, pnl=10.0, risk_amount=0.0), _trade(1, pnl=20.0, risk_amount=100.0)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertIsNotNone(m)


class TestFlatEquity(unittest.TestCase):
    def test_flat_equity_zero_drawdown(self):
        trades = [_trade(i, pnl=0.0, r_multiple=0.0) for i in range(3)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.drawdown.max_drawdown_abs, 0.0)
        self.assertIsNone(m.drawdown.recovery_factor)


class TestLargeDrawdown(unittest.TestCase):
    def test_drawdown_and_duration_computed_correctly(self):
        trades = [_trade(0, pnl=100.0), _trade(1, pnl=-300.0), _trade(2, pnl=-50.0), _trade(3, pnl=400.0)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertAlmostEqual(m.drawdown.max_drawdown_abs, 350.0)
        self.assertGreater(m.drawdown.max_drawdown_duration_trades, 0)
        self.assertIsNotNone(m.drawdown.recovery_factor)

    def test_equity_curve_matches_manual_calculation(self):
        trades = [_trade(0, pnl=100.0), _trade(1, pnl=-50.0)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        equities = [p.equity for p in m.equity_curve]
        self.assertEqual(equities, [10000.0, 10100.0, 10050.0])


class TestMixedLongShort(unittest.TestCase):
    def test_directional_breakdown(self):
        trades = [
            _trade(0, direction="LONG", pnl=50.0), _trade(1, direction="LONG", pnl=-20.0),
            _trade(2, direction="SHORT", pnl=30.0), _trade(3, direction="SHORT", pnl=30.0),
        ]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        db = m.directional_breakdown
        self.assertEqual(db.long_count, 2)
        self.assertEqual(db.short_count, 2)
        self.assertAlmostEqual(db.long_win_rate, 0.5)
        self.assertAlmostEqual(db.short_win_rate, 1.0)
        self.assertAlmostEqual(db.long_net_pnl, 30.0)
        self.assertAlmostEqual(db.short_net_pnl, 60.0)


class TestRegimeBreakdown(unittest.TestCase):
    def test_groups_by_actual_regime_labels_only(self):
        trades = [_trade(0, regime="TREND", pnl=10.0), _trade(1, regime="RANGE", pnl=-5.0), _trade(2, regime="TREND", pnl=15.0)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        groups = m.regime_breakdown.groups
        self.assertEqual(groups["TREND"]["count"], 2)
        self.assertEqual(groups["RANGE"]["count"], 1)
        self.assertAlmostEqual(groups["TREND"]["net_pnl"], 25.0)


class TestConsecutiveWinsLosses(unittest.TestCase):
    def test_consecutive_counts(self):
        pnls = [10, 10, -5, 10, -5, -5, -5, 10]
        trades = [_trade(i, pnl=float(p)) for i, p in enumerate(pnls)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m.max_consecutive_wins, 2)
        self.assertEqual(m.max_consecutive_losses, 3)


class TestDeterminism(unittest.TestCase):
    def test_repeated_calls_produce_identical_metrics(self):
        trades = [_trade(i, pnl=float(10 * (1 if i % 2 == 0 else -1)), r_multiple=1.0 if i % 2 == 0 else -1.0) for i in range(10)]
        m1 = calculate_performance_metrics(trades, initial_capital=10000.0)
        m2 = calculate_performance_metrics(trades, initial_capital=10000.0)
        self.assertEqual(m1, m2)


class TestSampleSizeWarning(unittest.TestCase):
    def test_below_threshold_flagged(self):
        trades = [_trade(i, pnl=10.0, r_multiple=1.0) for i in range(5)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0, min_sample_for_stats=20)
        self.assertTrue(m.sample_size_warning)

    def test_at_or_above_threshold_not_flagged(self):
        trades = [_trade(i, pnl=10.0 * (1 if i % 2 == 0 else -1), r_multiple=1.0) for i in range(20)]
        m = calculate_performance_metrics(trades, initial_capital=10000.0, min_sample_for_stats=20)
        self.assertFalse(m.sample_size_warning)


if __name__ == "__main__":
    unittest.main()
