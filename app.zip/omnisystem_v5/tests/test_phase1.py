"""
Unit tests for Phase 1: ingestion, schemas, normalization, validation,
quality gate, staleness, and missing-data handling.

Run with:  python3 -m unittest discover -s omnisystem_v5/tests -v
(from the directory containing the omnisystem_v5 package)
"""

import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.data.ingestion_service import DataIngestionService
from omnisystem_v5.data.normalization import NormalizationError, normalize_bar, normalize_bars
from omnisystem_v5.data.providers.mock_provider import MockProvider
from omnisystem_v5.data.quality_gate import QualityGateConfig, evaluate_quality
from omnisystem_v5.data.validation import validate_bar_sequence
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import (
    DataProvenance,
    MarketDataEnvelope,
    OHLCVBar,
    SchemaValidationError,
)

UTC = timezone.utc


def _bar(open_time, close_time=None, o=100.0, h=101.0, l=99.0, c=100.5, v=10.0):
    return OHLCVBar(
        open=o, high=h, low=l, close=c, volume=v,
        open_time=open_time,
        close_time=close_time or (open_time + timedelta(hours=1)),
    )


class TestOHLCVBarSchema(unittest.TestCase):
    def test_valid_bar_constructs(self):
        t = datetime.now(UTC)
        bar = _bar(t)
        self.assertEqual(bar.open, 100.0)

    def test_high_less_than_low_rejected(self):
        t = datetime.now(UTC)
        with self.assertRaises(SchemaValidationError):
            _bar(t, h=90.0, l=99.0)

    def test_negative_volume_rejected(self):
        t = datetime.now(UTC)
        with self.assertRaises(SchemaValidationError):
            _bar(t, v=-1.0)

    def test_naive_datetime_rejected(self):
        naive = datetime.now()  # no tzinfo
        with self.assertRaises(SchemaValidationError):
            OHLCVBar(open=1, high=2, low=0.5, close=1.5, volume=1,
                     open_time=naive, close_time=naive + timedelta(hours=1))

    def test_close_time_before_open_time_rejected(self):
        t = datetime.now(UTC)
        with self.assertRaises(SchemaValidationError):
            _bar(t, close_time=t - timedelta(minutes=5))


class TestEnvelopeInvariants(unittest.TestCase):
    def test_unavailable_origin_cannot_carry_bars(self):
        t = datetime.now(UTC)
        prov = DataProvenance(source="x", origin=DataOrigin.UNAVAILABLE, fetched_at=t, data_timestamp=t)
        with self.assertRaises(SchemaValidationError):
            MarketDataEnvelope(
                market="BTCUSDT", timeframe=Timeframe.H1, provenance=prov,
                quality_status=QualityStatus.DATA_UNAVAILABLE, bars=(_bar(t),),
            )

    def test_unavailable_origin_must_have_unavailable_status(self):
        t = datetime.now(UTC)
        prov = DataProvenance(source="x", origin=DataOrigin.UNAVAILABLE, fetched_at=t, data_timestamp=t)
        with self.assertRaises(SchemaValidationError):
            MarketDataEnvelope(
                market="BTCUSDT", timeframe=Timeframe.H1, provenance=prov,
                quality_status=QualityStatus.OK, bars=(),
            )

    def test_is_usable_true_only_for_ok_and_real_origin(self):
        t = datetime.now(UTC)
        prov = DataProvenance(source="x", origin=DataOrigin.SIMULATED, fetched_at=t, data_timestamp=t)
        env = MarketDataEnvelope(
            market="BTCUSDT", timeframe=Timeframe.H1, provenance=prov,
            quality_status=QualityStatus.OK, bars=(_bar(t),),
        )
        self.assertFalse(env.is_usable(), "SIMULATED data must never be marked usable")


class TestNormalization(unittest.TestCase):
    def test_normalize_valid_bar(self):
        t = datetime.now(UTC).isoformat()
        raw = {"open": 1, "high": 2, "low": 0.5, "close": 1.5, "volume": 5,
               "open_time": t, "close_time": t}
        # close_time == open_time is allowed (>=), sanity check should pass
        bar = normalize_bar(raw)
        self.assertEqual(bar.close, 1.5)

    def test_normalize_missing_field_raises(self):
        with self.assertRaises(NormalizationError):
            normalize_bar({"open": 1, "high": 2, "low": 0.5, "close": 1.5})

    def test_normalize_bars_partial_failure_reports_errors(self):
        t = datetime.now(UTC).isoformat()
        good = {"open": 1, "high": 2, "low": 0.5, "close": 1.5, "volume": 5,
                "open_time": t, "close_time": t}
        bad = {"open": "not_a_number", "high": 2, "low": 0.5, "close": 1.5,
               "volume": 5, "open_time": t, "close_time": t}
        valid, errors = normalize_bars([good, bad])
        self.assertEqual(len(valid), 1)
        self.assertEqual(len(errors), 1)


class TestBarSequenceValidation(unittest.TestCase):
    def test_clean_sequence_passes(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0 + timedelta(hours=i)) for i in range(5)]
        result = validate_bar_sequence(bars, Timeframe.H1)
        self.assertTrue(result.ok, result.issues)

    def test_gap_detected(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0), _bar(t0 + timedelta(hours=5))]  # big gap for H1
        result = validate_bar_sequence(bars, Timeframe.H1)
        self.assertFalse(result.ok)
        self.assertTrue(any("gap" in issue for issue in result.issues))

    def test_duplicate_timestamp_detected(self):
        t0 = datetime.now(UTC)
        bars = [_bar(t0), _bar(t0)]
        result = validate_bar_sequence(bars, Timeframe.H1)
        self.assertFalse(result.ok)
        self.assertTrue(any("duplicate" in issue for issue in result.issues))

    def test_empty_sequence_fails(self):
        result = validate_bar_sequence([], Timeframe.H1)
        self.assertFalse(result.ok)


class TestQualityGate(unittest.TestCase):
    def _provenance(self, origin=DataOrigin.LIVE, age_seconds=0):
        now = datetime.now(UTC)
        return DataProvenance(
            source="test_source", origin=origin,
            fetched_at=now, data_timestamp=now - timedelta(seconds=age_seconds),
        )

    def test_no_bars_returns_data_unavailable(self):
        prov = self._provenance()
        env = evaluate_quality("BTCUSDT", Timeframe.H1, prov, bars=[], normalization_errors=[])
        self.assertEqual(env.quality_status, QualityStatus.DATA_UNAVAILABLE)

    def test_too_few_bars_returns_insufficient_data(self):
        t0 = datetime.now(UTC) - timedelta(hours=5)
        bars = [_bar(t0 + timedelta(hours=i)) for i in range(3)]
        prov = self._provenance()
        env = evaluate_quality(
            "BTCUSDT", Timeframe.H1, prov, bars=bars, normalization_errors=[],
            config=QualityGateConfig(min_bars_required=20),
        )
        self.assertEqual(env.quality_status, QualityStatus.INSUFFICIENT_DATA)

    def test_stale_data_detected(self):
        bars = [_bar(datetime.now(UTC) - timedelta(hours=100 - i)) for i in range(25)]
        prov = self._provenance(age_seconds=10_000)  # very old data_timestamp
        env = evaluate_quality(
            "BTCUSDT", Timeframe.H1, prov, bars=bars, normalization_errors=[],
            config=QualityGateConfig(min_bars_required=20, max_staleness_seconds=300),
        )
        self.assertEqual(env.quality_status, QualityStatus.STALE)

    def test_gapped_data_marked_invalid(self):
        t0 = datetime.now(UTC) - timedelta(hours=50)
        bars = [_bar(t0 + timedelta(hours=i)) for i in range(20)]
        bars.append(_bar(t0 + timedelta(hours=100)))  # inject a gap
        prov = self._provenance()
        env = evaluate_quality(
            "BTCUSDT", Timeframe.H1, prov, bars=bars, normalization_errors=[],
            config=QualityGateConfig(min_bars_required=5, max_staleness_seconds=999_999),
        )
        self.assertEqual(env.quality_status, QualityStatus.INVALID)

    def test_clean_fresh_data_marked_ok(self):
        t0 = datetime.now(UTC) - timedelta(hours=25)
        bars = [_bar(t0 + timedelta(hours=i)) for i in range(25)]
        prov = self._provenance(age_seconds=30)
        env = evaluate_quality(
            "BTCUSDT", Timeframe.H1, prov, bars=bars, normalization_errors=[],
            config=QualityGateConfig(min_bars_required=20, max_staleness_seconds=300),
        )
        self.assertEqual(env.quality_status, QualityStatus.OK)
        self.assertTrue(env.is_usable() is False or env.is_usable() is True)  # origin-dependent


class TestIngestionService(unittest.TestCase):
    def test_successful_fetch_produces_ok_envelope_when_fresh(self):
        provider = MockProvider()
        service = DataIngestionService(provider, QualityGateConfig(min_bars_required=20, max_staleness_seconds=999_999))
        env = service.get_market_data("BTCUSDT", Timeframe.H1, limit=30)
        self.assertEqual(env.provenance.origin, DataOrigin.SIMULATED)
        self.assertEqual(env.quality_status, QualityStatus.OK)
        # SIMULATED must never be usable even if quality_status is OK
        self.assertFalse(env.is_usable())

    def test_provider_failure_produces_data_unavailable(self):
        provider = MockProvider(fail=True)
        service = DataIngestionService(provider)
        env = service.get_market_data("BTCUSDT", Timeframe.H1)
        self.assertEqual(env.quality_status, QualityStatus.DATA_UNAVAILABLE)
        self.assertEqual(env.provenance.origin, DataOrigin.UNAVAILABLE)
        self.assertEqual(len(env.bars), 0)

    def test_insufficient_bars_from_provider(self):
        provider = MockProvider()
        service = DataIngestionService(provider, QualityGateConfig(min_bars_required=500))
        env = service.get_market_data("BTCUSDT", Timeframe.H1, limit=10)
        self.assertEqual(env.quality_status, QualityStatus.INSUFFICIENT_DATA)


if __name__ == "__main__":
    unittest.main()
