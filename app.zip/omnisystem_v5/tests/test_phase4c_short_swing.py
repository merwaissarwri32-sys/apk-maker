import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.intelligence.enums import NoTradeReason, ScalpStatus
from omnisystem_v5.intelligence.event_risk import EventRiskContext, EventRiskStatus
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig, detect_short_swing_candidate
from omnisystem_v5.intelligence.short_swing_schema import ShortSwingScenarioType
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0, hours=4):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=hours))


def _range_then_breakout(t0, step_hours=4):
    bars = []
    price = 100.0
    for i in range(60):
        price += 0.5 if (i % 6 < 4) else -0.3
        bars.append(_bar(t0 + timedelta(hours=step_hours * i), price, price + 1.2, price - 1.2, price + 0.2, v=10 + i % 5, hours=step_hours))
    for i in range(60, 65):
        price += 3.0
        bars.append(_bar(t0 + timedelta(hours=step_hours * i), price, price + 2, price - 1, price + 1, v=30, hours=step_hours))
    for i in range(65, 80):
        price -= 0.8
        bars.append(_bar(t0 + timedelta(hours=step_hours * i), price, price + 1.0, price - 1.0, price - 0.3, v=15, hours=step_hours))
    for i in range(80, 100):
        price += 1.0 if i % 2 == 0 else -1.0
        bars.append(_bar(t0 + timedelta(hours=step_hours * i), price, price + 1.0, price - 1.0, price + 0.2, v=20 + (i - 80) * 2, hours=step_hours))
    return bars


def _flat_bars(n, t0, step_hours=4):
    return [_bar(t0 + timedelta(hours=step_hours * i), 100.0, 100.3, 99.7, 100.0, hours=step_hours) for i in range(n)]


def _extreme_vol_bars(n, t0, step_hours=4):
    bars = []
    price = 1000.0
    for i in range(n):
        swing = 150.0 if i % 2 == 0 else -140.0
        price = max(price + swing, 50.0)
        bars.append(_bar(t0 + timedelta(hours=step_hours * i), price, price + 40, max(price - 40, 1), price + 5, hours=step_hours))
    return bars


def _build(tf, bars):
    now = datetime.now(UTC)
    prov = DataProvenance(source="test", origin=DataOrigin.HISTORICAL, fetched_at=now, data_timestamp=bars[-1].close_time)
    env = MarketDataEnvelope(market="BTCUSDT", timeframe=tf, provenance=prov, quality_status=QualityStatus.OK, bars=tuple(bars))
    mctx = build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=30))
    qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
    return mctx, qctx


def _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q):
    mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC),
                                       contexts={Timeframe.H4: h4_ctx, Timeframe.D1: d1_ctx})
    return mtf, {Timeframe.H4: h4_q, Timeframe.D1: d1_q}


class TestShortSwingPositive(unittest.TestCase):
    def test_hand_verified_aligned_uptrend_produces_htf_continuation(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _range_then_breakout(t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)

        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig())
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        c = result.candidates[0]
        self.assertEqual(c.scenario_type, ShortSwingScenarioType.HTF_TREND_CONTINUATION)
        self.assertEqual(c.direction.value, "BULLISH")
        self.assertGreaterEqual(c.risk_reward.reward_risk_ratio, ShortSwingEngineConfig().min_reward_risk_ratio)
        self.assertEqual(c.timeframe, Timeframe.H4)
        self.assertEqual(c.higher_timeframe, Timeframe.D1)
        self.assertEqual(c.event_risk_status, EventRiskStatus.EVENT_DATA_UNAVAILABLE)


class TestShortSwingRejections(unittest.TestCase):
    def test_missing_timeframe_context(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 4))
        mtf = MultiTimeframeMarketContext(symbol="BTCUSDT", calculated_at=datetime.now(UTC), contexts={Timeframe.H4: h4_ctx})
        result = detect_short_swing_candidate("BTCUSDT", mtf, {Timeframe.H4: h4_q}, ShortSwingEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_MISSING_TIMEFRAME_CONTEXT, result.rejection_reasons)

    def test_high_volatility_explicitly_rejected(self):
        """Unique to Short-Swing: HIGH volatility regime is an outright
        rejection, unlike Scalp/Intraday which only downgrade a score."""
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _extreme_vol_bars(100, t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _extreme_vol_bars(100, t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)
        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_HIGH_VOLATILITY, result.rejection_reasons)

    def test_flat_market_rejected_as_unstable_regime(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _flat_bars(100, t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _flat_bars(100, t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)
        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig())
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_UNSTABLE_REGIME, result.rejection_reasons)

    def test_poor_rr_rejected_with_high_minimum(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _range_then_breakout(t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)
        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig(min_reward_risk_ratio=100.0))
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)

    def test_confirmed_event_risk_blocks_short_swing(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _range_then_breakout(t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)
        event_risk = EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_AVAILABLE,
                                       checked_at=datetime.now(UTC), high_impact_event_near=True, window_minutes=1440)
        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig(), event_risk=event_risk)
        self.assertEqual(result.status, ScalpStatus.NO_VALID_SCALP)
        self.assertIn(NoTradeReason.NO_TRADE_HIGH_EVENT_RISK, result.rejection_reasons)

    def test_stale_event_data_does_not_block_but_is_surfaced(self):
        t0 = datetime.now(UTC) - timedelta(hours=4 * 100)
        h4_ctx, h4_q = _build(Timeframe.H4, _range_then_breakout(t0, 4))
        d1_ctx, d1_q = _build(Timeframe.D1, _range_then_breakout(t0, 24))
        mtf, quant_by_tf = _mtf_and_quant(h4_ctx, h4_q, d1_ctx, d1_q)
        event_risk = EventRiskContext(symbol="BTCUSDT", status=EventRiskStatus.EVENT_DATA_STALE, checked_at=datetime.now(UTC))
        result = detect_short_swing_candidate("BTCUSDT", mtf, quant_by_tf, ShortSwingEngineConfig(), event_risk=event_risk)
        self.assertEqual(result.status, ScalpStatus.ZONE_IDENTIFIED)
        self.assertEqual(result.candidates[0].event_risk_status, EventRiskStatus.EVENT_DATA_STALE)
        self.assertTrue(any("not treated as safe" in r for r in result.candidates[0].reasons))


class TestShortSwingDistinctFromOthers(unittest.TestCase):
    def test_fvg_boundaries_excluded_from_invalidation_sources(self):
        """Structural check: the _MAJOR_SOURCES filter used by the Short
        Swing engine must not include FVG_BOUNDARY."""
        from omnisystem_v5.intelligence.short_swing_engine import _MAJOR_SOURCES
        from omnisystem_v5.quant.enums import InvalidationSource
        self.assertNotIn(InvalidationSource.FVG_BOUNDARY, _MAJOR_SOURCES)

    def test_evidence_shape_distinct_from_scalp_and_intraday(self):
        from omnisystem_v5.intelligence.short_swing_schema import ShortSwingCandidateEvidence
        fields = ShortSwingCandidateEvidence.__dataclass_fields__.keys()
        self.assertIn("higher_timeframe_structure_alignment", fields)
        self.assertIn("higher_timeframe_fvg_alignment", fields)
        self.assertNotIn("volume_alignment", fields)
        self.assertNotIn("vwap_alignment", fields)


if __name__ == "__main__":
    unittest.main()
