import unittest
from datetime import datetime, timedelta, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.quant.schema import QuantContext, QuantValidationError
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar

UTC = timezone.utc


def _bar(t, o, h, l, c, v=10.0):
    return OHLCVBar(open=o, high=h, low=l, close=c, volume=v, open_time=t, close_time=t + timedelta(hours=1))


def _series(n, t0, base=100.0, vol=10.0):
    bars = []
    price = base
    for i in range(n):
        price += 0.4 if (i % 5 < 3) else -0.3
        bars.append(_bar(t0 + timedelta(hours=i), price, price + 1.5, price - 1.5, price + 0.3, v=vol))
    return bars


def _envelope(bars, timeframe=Timeframe.H1, quality=QualityStatus.OK, origin=DataOrigin.HISTORICAL):
    now = datetime.now(UTC)
    data_ts = bars[-1].close_time if bars else now
    prov = DataProvenance(source="test", origin=origin, fetched_at=now, data_timestamp=data_ts)
    return MarketDataEnvelope(market="BTCUSDT", timeframe=timeframe, provenance=prov, quality_status=quality, bars=tuple(bars))


def _market_context(bars, min_bars_required=30, timeframe=Timeframe.H1):
    env = _envelope(bars, timeframe=timeframe)
    return build_market_context("BTCUSDT", env, MarketContextConfig(min_bars_required=min_bars_required))


class TestQuantEngineStatusMapping(unittest.TestCase):
    def test_non_ok_market_context_maps_through(self):
        t0 = datetime.now(UTC)
        prov = DataProvenance(source="x", origin=DataOrigin.UNAVAILABLE, fetched_at=t0, data_timestamp=t0)
        mctx = MarketContext(
            symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.DATA_UNAVAILABLE,
            calculated_at=t0, provenance=prov,
        )
        qctx = build_quant_context("BTCUSDT", mctx)
        self.assertEqual(qctx.status, QuantStatus.DATA_UNAVAILABLE)
        self.assertIsNone(qctx.current_price)

    def test_insufficient_context_maps_to_insufficient_data(self):
        t0 = datetime.now(UTC)
        mctx = MarketContext(
            symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.INSUFFICIENT_CONTEXT,
            calculated_at=t0, provenance=None,
        )
        qctx = build_quant_context("BTCUSDT", mctx)
        self.assertEqual(qctx.status, QuantStatus.INSUFFICIENT_DATA)

    def test_invalid_context_maps_to_invalid_context(self):
        t0 = datetime.now(UTC)
        mctx = MarketContext(
            symbol="BTCUSDT", timeframe=Timeframe.H1, status=ContextStatus.INVALID_CONTEXT,
            calculated_at=t0, provenance=None,
        )
        qctx = build_quant_context("BTCUSDT", mctx)
        self.assertEqual(qctx.status, QuantStatus.INVALID_CONTEXT)

    def test_own_min_bars_threshold(self):
        t0 = datetime.now(UTC) - timedelta(hours=35)
        bars = _series(35, t0)
        mctx = _market_context(bars, min_bars_required=30)
        self.assertEqual(mctx.status, ContextStatus.OK)  # passes phase 2's own threshold
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.status, QuantStatus.INSUFFICIENT_DATA)
        self.assertIn("40 required", qctx.reasons[0])


class TestQuantEngineHappyPath(unittest.TestCase):
    def test_ok_status_populates_core_fields(self):
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = _series(80, t0)
        mctx = _market_context(bars, min_bars_required=30)
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.status, QuantStatus.OK)
        self.assertEqual(qctx.current_price, bars[-1].close)
        self.assertIsNotNone(qctx.vwap_session.value)
        self.assertIsNotNone(qctx.vwap_rolling.value)
        self.assertIsNotNone(qctx.momentum.rsi)
        self.assertIsNotNone(qctx.volatility.atr_pct)
        self.assertIsNotNone(qctx.normalized.return_zscore)

    def test_zero_volume_leaves_vwap_none_but_status_still_ok(self):
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = _series(80, t0, vol=0.0)
        mctx = _market_context(bars, min_bars_required=30)
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.status, QuantStatus.OK)
        self.assertIsNone(qctx.vwap_session.value)
        self.assertTrue(len(qctx.vwap_session.reasons) > 0)
        # other metrics that don't depend on volume must still compute
        self.assertIsNotNone(qctx.momentum.rsi)

    def test_timeframe_integrity_on_invalidation_candidates(self):
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = _series(80, t0)
        mctx = _market_context(bars, min_bars_required=30, timeframe=Timeframe.H4)
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertTrue(all(c.timeframe == Timeframe.H4 for c in qctx.invalidation_candidates))

    def test_structure_context_passed_through_unmodified(self):
        t0 = datetime.now(UTC) - timedelta(hours=80)
        bars = _series(80, t0)
        mctx = _market_context(bars, min_bars_required=30)
        qctx = build_quant_context("BTCUSDT", mctx, QuantEngineConfig(min_bars_required=40))
        self.assertEqual(qctx.support_resistance, mctx.support_resistance)
        self.assertEqual(qctx.liquidity_zones, mctx.liquidity_zones)
        self.assertEqual(qctx.fair_value_gaps, mctx.fair_value_gaps)


class TestQuantContextSchemaInvariants(unittest.TestCase):
    def test_non_ok_status_cannot_carry_calculated_fields(self):
        t0 = datetime.now(UTC)
        with self.assertRaises(QuantValidationError):
            QuantContext(
                symbol="BTCUSDT", timeframe=Timeframe.H1, status=QuantStatus.DATA_UNAVAILABLE,
                calculated_at=t0, provenance=None, current_price=100.0,
            )


if __name__ == "__main__":
    unittest.main()
