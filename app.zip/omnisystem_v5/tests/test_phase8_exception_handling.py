"""
Phase 8, Priority 3 - Silent Exception Handling.

Test-first: multi_horizon_replay.py's `_collect_intraday` /
`_collect_short_swing` used to wrap their resample_bars() calls in a
bare `except Exception: return`, which silently turned ANY internal
error (a real bug - AttributeError, TypeError, ZeroDivisionError, ...)
into an indistinguishable "no candidate this step" - exactly the
not-production-grade behavior the Phase 8 directive calls out.

These tests prove the four cases are now told apart:
  1. normal no-candidate (nothing wrong, engine just found nothing)
  2. insufficient data (context/quant status not OK - already handled
     by _context_for's own explicit None return, not an exception)
  3. intentionally blocked candidate (engine returns a non-ZONE_IDENTIFIED
     status - already handled explicitly, not an exception)
  4. genuine internal error - MUST propagate, never be swallowed
The only exception type allowed to be caught and treated as "no
candidate this step" is ResamplingError itself (corrupt/misaligned/
duplicated source data for THIS window) - a named, expected, auditable
condition, not a catch-all.
"""
import math
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.validation.multi_horizon_replay import (
    MultiHorizonReplayConfig,
    _collect_intraday,
    _collect_short_swing,
    run_multi_horizon_replay,
)
from omnisystem_v5.validation.resampling import ResamplingError

UTC = timezone.utc
T0 = datetime(2024, 1, 1, tzinfo=UTC)


def _bar(i, base=100.0):
    p = base + 5 * math.sin(i / 20.0) + (i % 7) * 0.3
    return OHLCVBar(open=p, high=p + 1.2, low=p - 1.2, close=p + 0.1, volume=100.0,
                     open_time=T0 + timedelta(minutes=15 * i), close_time=T0 + timedelta(minutes=15 * (i + 1)))


class TestGenuineInternalErrorIsNeverSwallowed(unittest.TestCase):
    def test_intraday_collector_propagates_a_genuine_bug_instead_of_hiding_it(self):
        window = [_bar(i) for i in range(200)]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, max_lookback_bars=200,
        )
        with patch(
            "omnisystem_v5.validation.multi_horizon_replay.resample_bars",
            side_effect=TypeError("simulated real internal bug, not a data problem"),
        ):
            with self.assertRaises(TypeError):
                _collect_intraday("BTCUSDT", config, window, Timeframe.M15, None, None,
                                   datetime.now(UTC), [])

    def test_short_swing_collector_propagates_a_genuine_bug_instead_of_hiding_it(self):
        window = [_bar(i) for i in range(200)]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_intraday=False, max_lookback_bars=4000,
        )
        with patch(
            "omnisystem_v5.validation.multi_horizon_replay.resample_bars",
            side_effect=ZeroDivisionError("simulated real internal bug, not a data problem"),
        ):
            with self.assertRaises(ZeroDivisionError):
                _collect_short_swing("BTCUSDT", config, window, Timeframe.M15, datetime.now(UTC), [])

    def test_full_replay_run_does_not_hide_a_genuine_bug_in_intraday_collection(self):
        bars = [_bar(i) for i in range(300)]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, end_index=299,
        )
        with patch(
            "omnisystem_v5.validation.multi_horizon_replay.resample_bars",
            side_effect=RuntimeError("simulated real internal bug"),
        ):
            with self.assertRaises(RuntimeError):
                run_multi_horizon_replay(bars, config)


class TestExpectedDataIntegrityFailureIsStillCaughtAsNoCandidate(unittest.TestCase):
    """ResamplingError specifically (corrupt/misaligned/duplicate source
    data for this particular window) remains a caught, expected, named
    condition - not a crash - since it's a legitimate data-quality
    outcome for one replay step, not a code bug."""

    def test_intraday_collector_treats_resampling_error_as_no_candidate(self):
        window = [_bar(i) for i in range(200)]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, max_lookback_bars=200,
        )
        pool = []
        with patch(
            "omnisystem_v5.validation.multi_horizon_replay.resample_bars",
            side_effect=ResamplingError("duplicate source bar timestamp detected"),
        ):
            _collect_intraday("BTCUSDT", config, window, Timeframe.M15, None, None, datetime.now(UTC), pool)
        self.assertEqual(pool, [])

    def test_short_swing_collector_treats_resampling_error_as_no_candidate(self):
        window = [_bar(i) for i in range(200)]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_intraday=False, max_lookback_bars=4000,
        )
        pool = []
        with patch(
            "omnisystem_v5.validation.multi_horizon_replay.resample_bars",
            side_effect=ResamplingError("duplicate source bar timestamp detected"),
        ):
            _collect_short_swing("BTCUSDT", config, window, Timeframe.M15, datetime.now(UTC), pool)
        self.assertEqual(pool, [])


class TestNormalNoCandidateAndInsufficientDataStillWorkUnchanged(unittest.TestCase):
    """These paths never went through the except clause at all - they
    are explicit status checks. Locking them in so the Priority 3 fix
    provably didn't touch this behavior."""

    def test_insufficient_bars_in_window_yields_no_candidate_without_raising(self):
        window = [_bar(i) for i in range(5)]  # far below any min_bars_required
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, max_lookback_bars=200,
        )
        pool = []
        _collect_intraday("BTCUSDT", config, window, Timeframe.M15, None, None, datetime.now(UTC), pool)
        self.assertEqual(pool, [])

    def test_flat_market_with_plenty_of_data_but_no_pattern_yields_no_candidate(self):
        window = [_bar(i, base=100.0) for i in range(200)]
        # override sine wave with a perfectly flat series - no structure to trade
        window = [OHLCVBar(open=100.0, high=100.1, low=99.9, close=100.0, volume=10.0,
                            open_time=b.open_time, close_time=b.close_time) for b in window]
        config = MultiHorizonReplayConfig(
            symbol="BTCUSDT", base_timeframe=Timeframe.M15, initial_capital=10000.0,
            enable_short_swing=False, max_lookback_bars=200,
        )
        pool = []
        _collect_intraday("BTCUSDT", config, window, Timeframe.M15, None, None, datetime.now(UTC), pool)
        self.assertEqual(pool, [])  # no raise, no candidate - correct selective behavior


if __name__ == "__main__":
    unittest.main()
