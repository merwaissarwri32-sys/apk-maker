import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.scanner import dedup as D
from omnisystem_v5.scanner.enums import DedupVerdict, SignalState
from omnisystem_v5.scanner.identity import FingerprintPolicy, IdentityError, build_descriptor, same_setup
from omnisystem_v5.scanner.signals import (ALLOWED_TRANSITIONS, InvalidTransitionError, ScanSignal, detect_signal,
                                           transition)
from omnisystem_v5.schemas.enums import Timeframe

T0 = datetime(2024, 3, 1, tzinfo=timezone.utc)
FP = FingerprintPolicy()
DP = D.DedupPolicy(cooldown_seconds=900, expiry_seconds=300)


def zone(b, t):
    return SimpleNamespace(bottom=b, top=t)


def cand(entry=(100.0, 101.0), inval=(96.0, 97.0), targets=(110.0, 115.0), symbol="BTC/USDT", direction=Direction.LONG,
         horizon="INTRADAY", engine="IntradayEngine", scenario=None, atr=2.0, candidate_id="x"):
    raw = SimpleNamespace(preferred_entry_zone=zone(*entry), invalidation_zone=zone(*inval),
                          target_zones=tuple(zone(t, t + 1) for t in targets), timeframe=Timeframe.M15,
                          scenario_type=SimpleNamespace(value=scenario) if scenario else None)
    norm = SimpleNamespace(symbol=symbol, direction=direction, horizon=horizon, source_engine=engine,
                           candidate_id=candidate_id)
    return build_descriptor(raw, norm, atr, FP)


def sig(desc, now):
    return detect_signal(desc, None, now)


class TestIdentity(unittest.TestCase):
    def test_identity_ignores_candidate_id_and_is_reproducible(self):
        a, b = cand(candidate_id="wallclock-1"), cand(candidate_id="wallclock-2")
        self.assertEqual(a.fingerprint, b.fingerprint)
        self.assertEqual(a, b)

    def test_fingerprint_changes_with_family_geometry_and_scenario(self):
        base = cand().fingerprint
        for other in (cand(direction=Direction.SHORT), cand(horizon="SCALP"), cand(engine="ScalpEngine"),
                      cand(symbol="ETH/USDT"), cand(entry=(105.0, 106.0)), cand(targets=(110.0, 130.0)),
                      cand(scenario="BREAKOUT_RETEST")):
            self.assertNotEqual(base, other.fingerprint)

    def test_atr_relative_scale_across_price_scales(self):
        a = cand(entry=(100, 101), inval=(96, 97), targets=(110,), atr=2.0)
        b = cand(entry=(1000, 1010), inval=(960, 970), targets=(1100,), atr=20.0)
        self.assertEqual(a.quantized, b.quantized)
        self.assertEqual((a.basis, b.basis), ("ATR", "ATR"))

    def test_unusable_atr_uses_documented_pct_fallback_never_invented(self):
        for bad in (None, 0, -1.0, float("nan"), float("inf")):
            d = cand(atr=bad)
            self.assertEqual(d.basis, "PCT_FALLBACK")
            self.assertIsNone(d.atr)
            self.assertAlmostEqual(d.unit, 0.0025 * 100.5)
        self.assertNotEqual(cand(atr=None).fingerprint, cand(atr=2.0).fingerprint)   # basis is part of identity

    def test_broken_geometry_fails_closed(self):
        with self.assertRaises(IdentityError):
            cand(targets=())
        with self.assertRaises(IdentityError):
            cand(entry=(float("nan"), 1.0))
        with self.assertRaises(IdentityError):
            build_descriptor(SimpleNamespace(), SimpleNamespace(), 1.0)

    def test_drift_across_a_bucket_boundary_is_still_the_same_setup(self):
        a = cand(entry=(99.99, 100.99))            # bucket = 0.5*ATR = 1.0
        b = cand(entry=(100.01, 101.01))
        self.assertNotEqual(a.quantized, b.quantized)     # quantization boundary crossed...
        self.assertTrue(same_setup(a, b, FP))             # ...but dedup tolerates it

    def test_materiality_boundary_is_inclusive_at_materiality_atr(self):
        ref = cand(atr=2.0)
        at_limit = cand(entry=(102.0, 103.0), atr=2.0)   # exactly 1 ATR
        past = cand(entry=(102.1, 103.1), atr=2.0)
        self.assertTrue(same_setup(ref, at_limit, FP))
        self.assertFalse(same_setup(ref, past, FP))

    def test_different_scenario_or_target_count_is_material(self):
        self.assertFalse(same_setup(cand(), cand(scenario="MEAN_REVERSION"), FP))
        self.assertFalse(same_setup(cand(), cand(targets=(110.0,)), FP))

    def test_policy_validation(self):
        with self.assertRaises(ValueError):
            FingerprintPolicy(atr_bucket_fraction=0)


class TestLifecycle(unittest.TestCase):
    def test_valid_path_and_terminal_states(self):
        s = sig(cand(), T0)
        e = transition(s, SignalState.EMITTED, emitted_at=T0, verdict=DedupVerdict.NEW)
        x = transition(e, SignalState.EXPIRED)
        self.assertEqual(x.state, SignalState.EXPIRED)
        for terminal in (SignalState.SUPPRESSED, SignalState.EXPIRED):
            self.assertEqual(ALLOWED_TRANSITIONS[terminal], frozenset())

    def test_invalid_transitions_rejected(self):
        s = sig(cand(), T0)
        with self.assertRaises(InvalidTransitionError):
            transition(s, SignalState.EXPIRED)                       # DETECTED -> EXPIRED
        e = transition(s, SignalState.EMITTED, emitted_at=T0, verdict=DedupVerdict.NEW)
        for target in (SignalState.DETECTED, SignalState.SUPPRESSED, SignalState.EMITTED):
            with self.assertRaises(InvalidTransitionError):
                transition(e, target, verdict=DedupVerdict.DUPLICATE)
        x = transition(e, SignalState.EXPIRED)
        with self.assertRaises(InvalidTransitionError):
            transition(x, SignalState.EMITTED, emitted_at=T0, verdict=DedupVerdict.NEW)

    def test_invariants_enforced_by_construction(self):
        d = cand()
        with self.assertRaises(ValueError):
            transition(sig(d, T0), SignalState.EMITTED, verdict=DedupVerdict.NEW)              # no emitted_at
        with self.assertRaises(ValueError):
            transition(sig(d, T0), SignalState.SUPPRESSED, verdict=DedupVerdict.NEW)           # emitting verdict
        with self.assertRaises(ValueError):
            transition(sig(d, T0), SignalState.EMITTED, emitted_at=T0, verdict=DedupVerdict.DUPLICATE)


def emit(state, desc, now):
    return D.observe(state, sig(desc, now), now, DP, FP)


class TestDedup(unittest.TestCase):
    def test_first_detection_emits_new(self):
        st, out, sup = emit(D.DedupState(), cand(), T0)
        self.assertEqual((out.state, out.verdict, sup), (SignalState.EMITTED, DedupVerdict.NEW, None))
        self.assertEqual(len(st.active), 1)

    def test_repeat_scans_are_duplicates_and_refresh_last_seen(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        t1 = T0 + timedelta(seconds=60)
        st, out, _ = emit(st, cand(entry=(100.3, 101.3)), t1)          # small drift
        self.assertEqual((out.state, out.verdict), (SignalState.SUPPRESSED, DedupVerdict.DUPLICATE))
        self.assertEqual(st.active[0].last_seen_at, t1)
        self.assertEqual(st.active[0].seen_count, 2)
        self.assertEqual(st.active[0].emitted_at, T0)

    def test_persisting_setup_is_never_re_emitted_while_seen(self):
        st = D.DedupState()
        st, _, _ = emit(st, cand(), T0)
        for i in range(1, 50):                                          # far beyond cooldown, continuously seen
            now = T0 + timedelta(seconds=120 * i)
            st, _ = D.expire(st, now, DP)
            st, out, _ = emit(st, cand(), now)
            self.assertEqual(out.verdict, DedupVerdict.DUPLICATE)

    def test_material_change_supersedes_and_bypasses_cooldown(self):
        st, first, _ = emit(D.DedupState(), cand(), T0)
        t1 = T0 + timedelta(seconds=60)
        st, out, superseded = emit(st, cand(entry=(110.0, 111.0), inval=(106.0, 107.0), targets=(120.0,)), t1)
        self.assertEqual(out.verdict, DedupVerdict.MATERIAL_CHANGE)
        self.assertEqual(superseded.state, SignalState.EXPIRED)
        self.assertEqual(len(st.active), 1)
        self.assertEqual(len(st.recent), 1)

    def test_expiry_boundary_strict(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        st_eq, gone = D.expire(st, T0 + timedelta(seconds=300), DP)         # exactly expiry: still active
        self.assertEqual((len(st_eq.active), gone), (1, ()))
        st_over, gone = D.expire(st, T0 + timedelta(seconds=300.001), DP)
        self.assertEqual((len(st_over.active), len(gone)), (0, 1))
        self.assertEqual(gone[0].state, SignalState.EXPIRED)

    def test_reappearance_after_expiry_inside_cooldown_is_suppressed(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        t = T0 + timedelta(seconds=400)
        st, _ = D.expire(st, t, DP)
        st, out, _ = emit(st, cand(), t)
        self.assertEqual((out.state, out.verdict), (SignalState.SUPPRESSED, DedupVerdict.COOLDOWN))
        self.assertEqual(len(st.active), 0)

    def test_cooldown_boundary_strict_and_pruning(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        st, _ = D.expire(st, T0 + timedelta(seconds=400), DP)
        just_before = T0 + timedelta(seconds=899.999)
        s1, _ = D.expire(st, just_before, DP)
        self.assertEqual(emit(s1, cand(), just_before)[1].verdict, DedupVerdict.COOLDOWN)
        at = T0 + timedelta(seconds=900)                                 # now - emitted_at == cooldown: allowed
        s2, _ = D.expire(st, at, DP)
        self.assertEqual(s2.recent, ())
        self.assertEqual(emit(s2, cand(), at)[1].verdict, DedupVerdict.NEW)

    def test_material_change_inside_cooldown_of_expired_setup_re_emits(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        t = T0 + timedelta(seconds=400)
        st, _ = D.expire(st, t, DP)
        st, out, _ = emit(st, cand(entry=(120.0, 121.0), inval=(116.0, 117.0), targets=(130.0,)), t)
        self.assertEqual(out.verdict, DedupVerdict.MATERIAL_CHANGE)

    def test_families_are_independent(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        for other in (cand(direction=Direction.SHORT), cand(horizon="SCALP", engine="ScalpEngine"), cand(symbol="ETH/USDT")):
            st, out, _ = emit(st, other, T0)
            self.assertEqual(out.verdict, DedupVerdict.NEW)
        self.assertEqual(len(st.active), 4)

    def test_state_ordering_is_deterministic_and_input_state_not_mutated(self):
        descs = [cand(symbol=s) for s in ("SOL/USDT", "BTC/USDT", "ETH/USDT")]
        a, b = D.DedupState(), D.DedupState()
        for d in descs:
            a, _, _ = emit(a, d, T0)
        for d in reversed(descs):
            b, _, _ = emit(b, d, T0)
        self.assertEqual([s.descriptor.symbol for s in a.active], [s.descriptor.symbol for s in b.active])
        self.assertEqual(a.active[0].descriptor.symbol, "BTC/USDT")
        empty = D.DedupState()
        emit(empty, cand(), T0)
        self.assertEqual(empty, D.DedupState())

    def test_expiry_can_be_extended_for_rotation(self):
        st, _, _ = emit(D.DedupState(), cand(), T0)
        st2, gone = D.expire(st, T0 + timedelta(seconds=500), DP, effective_expiry_seconds=600)
        self.assertEqual((len(st2.active), gone), (1, ()))

    def test_policy_validation(self):
        with self.assertRaises(ValueError):
            D.DedupPolicy(expiry_seconds=0)


if __name__ == "__main__":
    unittest.main()
