"""Shared fixtures for the Phase 11 tests.

EVIDENCE CLASS: everything here is SYNTHETIC and deterministic. Scripted providers replay fixtures
(declared HISTORICAL); nothing touches a network; a passing suite is NOT evidence of live behavior.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from omnisystem_v5.marketdata.adapters.scripted import ScriptedProvider, raw_row_from_bar, scripted_capabilities
from omnisystem_v5.marketdata.assets import AssetClass, Instrument, Listing, Venue
from omnisystem_v5.marketdata.catalog import InstrumentCatalog
from omnisystem_v5.marketdata.config import MarketDataConfig
from omnisystem_v5.marketdata.events import CompositeSink, InMemorySink
from omnisystem_v5.marketdata.health import HealthBook
from omnisystem_v5.marketdata.metrics import MetricsSink
from omnisystem_v5.marketdata.provider import RawBarRow
from omnisystem_v5.marketdata.router import ProviderRouter
from omnisystem_v5.marketdata.sessions import MarketStatus, WeeklySession
from omnisystem_v5.marketdata.source import LiveMarketDataSource
from omnisystem_v5.marketdata.symbol_map import SymbolMap
from omnisystem_v5.marketdata.universe import InstrumentUniverse
from omnisystem_v5.scanner import ScanEngine, ScannerConfig, ScanState
from omnisystem_v5.scanner.clock import ManualClock
from omnisystem_v5.scanner.timeframes import required_timeframes
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar
from omnisystem_v5.tests.scanner_fixtures import END, account, bars_ending_at, loose_risk_policy
from omnisystem_v5.validation.resampling import seconds_for_timeframe

UTC = timezone.utc
ALL_TFS = (Timeframe.M1, Timeframe.M5, Timeframe.M15, Timeframe.H1, Timeframe.H4, Timeframe.D1)
LONG_SEED, SHORT_SEED, QUIET_SEED = 1, 8, 7
VENUE = Venue("TESTX")


class ManualTimer:
    def __init__(self, step: float = 0.0):
        self.t, self.step = 0.0, step

    def now(self) -> float:
        self.t += self.step
        return self.t


class RecordingSleep:
    def __init__(self):
        self.calls = []

    def __call__(self, seconds):
        self.calls.append(seconds)


def crypto_instrument(base="BTC", quote="USDT") -> Instrument:
    return Instrument(AssetClass.CRYPTO, base, quote)


def forex_instrument(base="EUR", quote="USD") -> Instrument:
    return Instrument(AssetClass.FOREX, base, quote)


def raw_rows(bars):
    return tuple(raw_row_from_bar(b) for b in bars)


def row(o=100.0, h=101.0, l=99.0, c=100.5, v=10.0, open_time=None, close_time=None) -> RawBarRow:
    return RawBarRow(o, h, l, c, v, open_time, close_time)


def session_bars(tf, n, end, session, seed=1):
    """n contiguous-within-session bars ending at `end`: synthetic prices, timestamps only where the session is OPEN.
    Session gaps are REAL gaps (nothing is filled or compressed)."""
    step = timedelta(seconds=seconds_for_timeframe(tf))
    base = bars_ending_at(tf, n, end, seed=seed)
    times, close = [], end
    while len(times) < n:
        opened = close - step
        if session.status(opened) == MarketStatus.OPEN:
            times.append((opened, close))
        close = opened
    times.reverse()
    return tuple(OHLCVBar(b.open, b.high, b.low, b.close, b.volume, o, c) for b, (o, c) in zip(base, times))


def grid_end(now, tf):
    """Close time of the most recent CLOSED bar at `now` (what a real provider serves): now floored to the timeframe grid."""
    step = seconds_for_timeframe(tf)
    ts = int(now.timestamp())
    return datetime.fromtimestamp(ts - ts % step, tz=UTC)


class Stack:
    """A full Phase 11 stack wired to the real Phase 10 ScanEngine, over scripted providers."""

    def __init__(self, crypto=(("BTC", "USDT", LONG_SEED),), forex=(), n=220, md_kwargs=None, cfg_kwargs=None, sink=None,
                 forex_session=None, provider_tfs=ALL_TFS, origin=DataOrigin.HISTORICAL):
        self.scfg = ScannerConfig(risk_policy=loose_risk_policy(), **(cfg_kwargs or {}))
        self.md = MarketDataConfig.for_scanner(self.scfg, **(md_kwargs or {}))
        self.clock = ManualClock(END)
        self.tfs = required_timeframes(self.scfg)
        self.n = n
        self.seeds = {f"{b}/{q}": seed for b, q, seed in crypto}
        self.forex_seeds = {f"{b}/{q}": 1 for b, q in forex}
        self.forex_session = forex_session or WeeklySession.forex_ny()
        listings, cmap, fmap = [], [], []
        for b, q, _ in crypto:
            ins = crypto_instrument(b, q)
            listings.append(Listing(ins, VENUE))
            cmap.append((f"{b}{q}", ins))
        for b, q in forex:
            ins = forex_instrument(b, q)
            listings.append(Listing(ins, VENUE, session=self.forex_session))
            fmap.append((f"{b}_{q}", ins))
        self.crypto_provider = ScriptedProvider("cryptofeed", scripted_capabilities({AssetClass.CRYPTO}, provider_tfs, origin=origin))
        self.forex_provider = ScriptedProvider("fxfeed", scripted_capabilities({AssetClass.FOREX}, provider_tfs, origin=origin))
        self.catalog = InstrumentCatalog(listings)
        feeds, maps = [], []
        from omnisystem_v5.marketdata.feed import PollingFeed
        if cmap:
            feeds.append(PollingFeed(self.crypto_provider)); maps.append(SymbolMap("cryptofeed", cmap))
        if fmap:
            feeds.append(PollingFeed(self.forex_provider)); maps.append(SymbolMap("fxfeed", fmap))
        self.router = ProviderRouter(feeds, maps)
        self.book = HealthBook(self.md.provider_health, self.md.instrument_health)
        self.metrics, self.memory = MetricsSink(), InMemorySink()
        self.sink = CompositeSink(self.metrics, self.memory)
        self.sleep, self.timer = RecordingSleep(), ManualTimer()
        self.source = LiveMarketDataSource(self.md, self.catalog, self.router, self.book, self.clock, self.sink,
                                           sleep=self.sleep, timer=self.timer)
        self.universe = InstrumentUniverse(self.catalog, self.router, self.book, self.tfs)
        self.engine = ScanEngine(self.source, self.universe, self.scfg, self.clock)
        self.state = ScanState()
        self.provider_tfs = provider_tfs
        self.refresh()

    def refresh(self):
        now = self.clock.now()
        for b, q, seed in [(k.split("/")[0], k.split("/")[1], v) for k, v in self.seeds.items()]:
            for tf in self.provider_tfs:
                self.crypto_provider.set_series(f"{b}{q}", tf, raw_rows(bars_ending_at(tf, self.n, grid_end(now, tf), seed=seed)))
        for k in self.forex_seeds:
            b, q = k.split("/")
            for tf in self.provider_tfs:
                self.forex_provider.set_series(f"{b}_{q}", tf, raw_rows(session_bars(tf, self.n, grid_end(now, tf), self.forex_session)))

    def advance(self, seconds):
        self.clock.advance(seconds)
        self.refresh()

    def cycle(self, advance=0):
        if advance:
            self.advance(advance)
        res = self.engine.run_cycle(self.state, account())
        self.state = res.state
        return res.report
