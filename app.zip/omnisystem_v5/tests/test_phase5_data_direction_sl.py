import math
import unittest

from omnisystem_v5.risk.contracts import AccountState, InstrumentSpec, RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.enums import Direction, RejectionReasonCode
from omnisystem_v5.risk.validators import validate_data_integrity, validate_direction_and_sl


def _account(equity=10000.0):
    return AccountState(equity=equity)


def _candidate(direction=Direction.LONG, entry=100.0, sl=98.0, tps=(105.0,), instrument=None):
    return TradeCandidateInput(symbol="BTCUSDT", direction=direction, entry=entry, stop_loss=sl, take_profits=tps, instrument=instrument)


class TestDataIntegrity(unittest.TestCase):
    def test_valid_input_passes(self):
        out = validate_data_integrity(_candidate(), _account())
        self.assertTrue(out.ok)

    def test_nan_entry_rejected(self):
        out = validate_data_integrity(_candidate(entry=math.nan), _account())
        self.assertIn(RejectionReasonCode.DATA_NOT_FINITE, out.rejections)

    def test_infinity_stop_loss_rejected(self):
        out = validate_data_integrity(_candidate(sl=math.inf), _account())
        self.assertIn(RejectionReasonCode.DATA_NOT_FINITE, out.rejections)

    def test_negative_infinity_take_profit_rejected(self):
        out = validate_data_integrity(_candidate(tps=(-math.inf,)), _account())
        self.assertIn(RejectionReasonCode.DATA_NOT_FINITE, out.rejections)

    def test_zero_equity_rejected(self):
        out = validate_data_integrity(_candidate(), _account(equity=0.0))
        self.assertIn(RejectionReasonCode.DATA_NONPOSITIVE_EQUITY, out.rejections)

    def test_negative_equity_rejected(self):
        out = validate_data_integrity(_candidate(), _account(equity=-500.0))
        self.assertIn(RejectionReasonCode.DATA_NONPOSITIVE_EQUITY, out.rejections)

    def test_zero_entry_rejected(self):
        out = validate_data_integrity(_candidate(entry=0.0), _account())
        self.assertIn(RejectionReasonCode.DATA_NONPOSITIVE_ENTRY, out.rejections)

    def test_negative_entry_rejected(self):
        out = validate_data_integrity(_candidate(entry=-10.0), _account())
        self.assertIn(RejectionReasonCode.DATA_NONPOSITIVE_ENTRY, out.rejections)

    def test_missing_take_profit_rejected(self):
        out = validate_data_integrity(_candidate(tps=()), _account())
        self.assertIn(RejectionReasonCode.DATA_NO_TAKE_PROFIT, out.rejections)

    def test_duplicate_take_profits_rejected(self):
        out = validate_data_integrity(_candidate(tps=(105.0, 105.0)), _account())
        self.assertIn(RejectionReasonCode.DATA_DUPLICATE_TAKE_PROFIT, out.rejections)

    def test_invalid_direction_rejected(self):
        out = validate_data_integrity(_candidate(direction="UP"), _account())
        self.assertIn(RejectionReasonCode.DATA_INVALID_DIRECTION, out.rejections)

    def test_huge_but_finite_numbers_pass(self):
        out = validate_data_integrity(_candidate(entry=1e15, sl=1e15 - 100, tps=(1e15 + 1000,)), _account(equity=1e12))
        self.assertTrue(out.ok)

    def test_invalid_instrument_spec_rejected(self):
        bad_instr = InstrumentSpec(symbol="X", tick_size=-1.0)
        out = validate_data_integrity(_candidate(instrument=bad_instr), _account())
        self.assertIn(RejectionReasonCode.DATA_UNSUPPORTED_INSTRUMENT_SPEC, out.rejections)


class TestDirectionAndSl(unittest.TestCase):
    def test_valid_long_passes(self):
        out = validate_direction_and_sl(_candidate(direction=Direction.LONG, entry=100, sl=98), RiskPolicy())
        self.assertTrue(out.ok)

    def test_valid_short_passes(self):
        out = validate_direction_and_sl(_candidate(direction=Direction.SHORT, entry=100, sl=102), RiskPolicy())
        self.assertTrue(out.ok)

    def test_sl_equals_entry_rejected(self):
        out = validate_direction_and_sl(_candidate(entry=100, sl=100), RiskPolicy())
        self.assertIn(RejectionReasonCode.SL_EQUALS_ENTRY, out.rejections)

    def test_long_sl_above_entry_wrong_side(self):
        out = validate_direction_and_sl(_candidate(direction=Direction.LONG, entry=100, sl=102), RiskPolicy())
        self.assertIn(RejectionReasonCode.SL_WRONG_SIDE, out.rejections)

    def test_short_sl_below_entry_wrong_side(self):
        out = validate_direction_and_sl(_candidate(direction=Direction.SHORT, entry=100, sl=98), RiskPolicy())
        self.assertIn(RejectionReasonCode.SL_WRONG_SIDE, out.rejections)

    def test_extremely_tight_sl_rejected(self):
        policy = RiskPolicy(min_sl_distance_pct=0.5)
        out = validate_direction_and_sl(_candidate(entry=100, sl=99.99), policy)  # 0.01% distance
        self.assertIn(RejectionReasonCode.SL_TOO_TIGHT, out.rejections)

    def test_extremely_wide_sl_rejected(self):
        policy = RiskPolicy(max_sl_distance_pct=10.0)
        out = validate_direction_and_sl(_candidate(entry=100, sl=50), policy)  # 50% distance
        self.assertIn(RejectionReasonCode.SL_TOO_WIDE, out.rejections)

    def test_sl_near_max_distance_warns(self):
        policy = RiskPolicy(max_sl_distance_pct=10.0)
        out = validate_direction_and_sl(_candidate(entry=100, sl=90.5), policy)  # 9.5% -> within 10% of max
        self.assertTrue(out.ok)
        from omnisystem_v5.risk.enums import WarningCode
        self.assertIn(WarningCode.SL_NEAR_MAX_ALLOWED_DISTANCE, out.warnings)

    def test_tick_size_precision_violation_rejected(self):
        instr = InstrumentSpec(symbol="BTCUSDT", tick_size=0.5)
        out = validate_direction_and_sl(_candidate(entry=100, sl=98.3, instrument=instr), RiskPolicy())
        self.assertIn(RejectionReasonCode.SL_PRECISION_INVALID, out.rejections)

    def test_tick_size_aligned_passes(self):
        instr = InstrumentSpec(symbol="BTCUSDT", tick_size=0.5)
        out = validate_direction_and_sl(_candidate(entry=100, sl=98.5, instrument=instr), RiskPolicy())
        self.assertTrue(out.ok)

    def test_floating_point_precision_does_not_false_reject(self):
        """0.1 + 0.2 style float artifacts must not trip precision checks."""
        instr = InstrumentSpec(symbol="BTCUSDT", tick_size=0.1)
        out = validate_direction_and_sl(_candidate(entry=100, sl=99.7, instrument=instr), RiskPolicy())
        self.assertTrue(out.ok)


if __name__ == "__main__":
    unittest.main()
