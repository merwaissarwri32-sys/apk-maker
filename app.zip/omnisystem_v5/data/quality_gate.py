"""
Data Quality Gate.

This is the single authority allowed to set `quality_status` on a
MarketDataEnvelope. No other module may mark data OK. Its job:

  1. Detect staleness (data_timestamp too old vs. now).
  2. Detect insufficient data (too few bars, gaps, missing fields).
  3. Detect invalid data (failed sanity/sequence validation).
  4. Fall back to DATA_UNAVAILABLE rather than ever letting bad or
     absent data pass through silently.

Nothing here fabricates values. If it cannot confirm the data is good,
the honest answer is always one of the non-OK statuses.
"""

from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.data.validation import validate_bar_sequence
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope, OHLCVBar


@dataclass
class QualityGateConfig:
    max_staleness_seconds: float = 300.0   # data older than this (vs now) is STALE
    min_bars_required: int = 20            # fewer bars than this is INSUFFICIENT_DATA


def evaluate_quality(
    market: str,
    timeframe: Timeframe,
    provenance: DataProvenance,
    bars: list[OHLCVBar],
    normalization_errors: list[str],
    config: QualityGateConfig | None = None,
) -> MarketDataEnvelope:
    """Runs the full quality gate and returns the final MarketDataEnvelope.
    This is the ONLY function that should construct an envelope with a
    quality_status other than a raw default."""
    config = config or QualityGateConfig()
    reasons: list[str] = list(normalization_errors)

    # 1. Origin-level short circuit: no data at all.
    if provenance.origin == DataOrigin.UNAVAILABLE or not bars:
        reasons.append("no bars available from provider")
        return MarketDataEnvelope(
            market=market,
            timeframe=timeframe,
            provenance=provenance,
            quality_status=QualityStatus.DATA_UNAVAILABLE,
            bars=tuple(),
            reasons=tuple(reasons),
        )

    # 2. Insufficient data.
    if len(bars) < config.min_bars_required:
        reasons.append(f"only {len(bars)} bars available, {config.min_bars_required} required")
        return MarketDataEnvelope(
            market=market,
            timeframe=timeframe,
            provenance=provenance,
            quality_status=QualityStatus.INSUFFICIENT_DATA,
            bars=tuple(bars),
            reasons=tuple(reasons),
        )

    # 3. Sequence/structural validation (gaps, duplicates, ordering).
    seq_result = validate_bar_sequence(bars, timeframe)
    if not seq_result.ok:
        reasons.extend(seq_result.issues)
        return MarketDataEnvelope(
            market=market,
            timeframe=timeframe,
            provenance=provenance,
            quality_status=QualityStatus.INVALID,
            bars=tuple(bars),
            reasons=tuple(reasons),
        )

    # 4. Staleness — only meaningful for data claiming to be LIVE/HISTORICAL-current.
    freshness = provenance.freshness_seconds
    if freshness > config.max_staleness_seconds:
        reasons.append(
            f"data is {freshness:.0f}s old, exceeds max staleness of "
            f"{config.max_staleness_seconds:.0f}s"
        )
        return MarketDataEnvelope(
            market=market,
            timeframe=timeframe,
            provenance=provenance,
            quality_status=QualityStatus.STALE,
            bars=tuple(bars),
            reasons=tuple(reasons),
        )

    # 5. Passed everything.
    if reasons:
        # normalization dropped some bad bars but enough good ones remain
        reasons.append("some individual bars were dropped during normalization; remainder passed all checks")

    return MarketDataEnvelope(
        market=market,
        timeframe=timeframe,
        provenance=provenance,
        quality_status=QualityStatus.OK,
        bars=tuple(bars),
        reasons=tuple(reasons),
    )
