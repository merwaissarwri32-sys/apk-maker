"""
DataIngestionService — the single entry point the rest of the system
calls to obtain market data. It never returns raw provider payloads;
it always returns a validated, quality-gated MarketDataEnvelope.

This is intentionally thin: it wires together
  provider.fetch_ohlcv() -> normalize_bars() -> evaluate_quality()
and guarantees a DATA_UNAVAILABLE envelope on any failure, instead of
raising an exception the caller has to remember to catch, and instead
of ever inventing data.
"""

from __future__ import annotations

from datetime import datetime, timezone

from omnisystem_v5.data.normalization import normalize_bars
from omnisystem_v5.data.providers.base import DataProvider, DataUnavailableError
from omnisystem_v5.data.quality_gate import QualityGateConfig, evaluate_quality
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope


class DataIngestionService:
    def __init__(self, provider: DataProvider, quality_config: QualityGateConfig | None = None):
        self._provider = provider
        self._quality_config = quality_config or QualityGateConfig()

    def get_market_data(self, market: str, timeframe: Timeframe, limit: int = 200) -> MarketDataEnvelope:
        fetched_at = datetime.now(timezone.utc)

        try:
            result = self._provider.fetch_ohlcv(market, timeframe, limit)
        except DataUnavailableError as e:
            provenance = DataProvenance(
                source=self._provider.name,
                origin=DataOrigin.UNAVAILABLE,
                fetched_at=fetched_at,
                data_timestamp=fetched_at,
            )
            return evaluate_quality(
                market=market,
                timeframe=timeframe,
                provenance=provenance,
                bars=[],
                normalization_errors=[str(e)],
                config=self._quality_config,
            )

        valid_bars, norm_errors = normalize_bars(result.raw_bars)

        data_timestamp = valid_bars[-1].close_time if valid_bars else fetched_at
        provenance = DataProvenance(
            source=result.source_name,
            origin=result.origin,
            fetched_at=fetched_at,
            data_timestamp=data_timestamp,
        )

        return evaluate_quality(
            market=market,
            timeframe=timeframe,
            provenance=provenance,
            bars=valid_bars,
            normalization_errors=norm_errors,
            config=self._quality_config,
        )
