"""
Normalization: turns a provider's raw dict payload into validated
OHLCVBar objects. This is where field-name differences between
providers get reconciled into one internal shape — it does NOT
make quality judgments (that's the quality gate's job).
"""

from __future__ import annotations

from datetime import datetime

from omnisystem_v5.schemas.market_data import OHLCVBar, SchemaValidationError


class NormalizationError(Exception):
    """Raised when a raw bar cannot be normalized into a valid OHLCVBar."""


def _parse_timestamp(value) -> datetime:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        return datetime.fromisoformat(value)
    raise NormalizationError(f"Unrecognized timestamp format: {value!r}")


def normalize_bar(raw: dict) -> OHLCVBar:
    """Convert one raw bar dict into a validated OHLCVBar.
    Raises NormalizationError on any structural or sanity failure —
    callers must not silently drop or patch bad bars."""
    try:
        return OHLCVBar(
            open=float(raw["open"]),
            high=float(raw["high"]),
            low=float(raw["low"]),
            close=float(raw["close"]),
            volume=float(raw["volume"]),
            open_time=_parse_timestamp(raw["open_time"]),
            close_time=_parse_timestamp(raw["close_time"]),
        )
    except (KeyError, TypeError, ValueError) as e:
        raise NormalizationError(f"Malformed raw bar {raw!r}: {e}") from e
    except SchemaValidationError as e:
        raise NormalizationError(f"Bar failed sanity validation {raw!r}: {e}") from e


def normalize_bars(raw_bars: list[dict]) -> tuple[list[OHLCVBar], list[str]]:
    """Normalize a batch of raw bars.

    Returns (valid_bars, error_notes). Bad individual bars are excluded
    from valid_bars but recorded in error_notes rather than silently
    dropped without a trace — the quality gate uses these notes to
    decide INSUFFICIENT_DATA vs INVALID.
    """
    valid: list[OHLCVBar] = []
    errors: list[str] = []
    for raw in raw_bars:
        try:
            valid.append(normalize_bar(raw))
        except NormalizationError as e:
            errors.append(str(e))
    return valid, errors
