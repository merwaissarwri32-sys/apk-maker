"""
Validation rules applied to an already-normalized list of OHLCVBar objects.
These are batch-level checks (ordering, gaps, duplicates) that individual
bar validation (in the Pydantic model) cannot catch on its own.
"""

from __future__ import annotations

from datetime import timedelta

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

_TIMEFRAME_SECONDS = {
    Timeframe.M1: 60,
    Timeframe.M5: 300,
    Timeframe.M15: 900,
    Timeframe.H1: 3600,
    Timeframe.H4: 14400,
    Timeframe.D1: 86400,
}


class ValidationResult:
    def __init__(self, ok: bool, issues: list[str]):
        self.ok = ok
        self.issues = issues


def validate_bar_sequence(bars: list[OHLCVBar], timeframe: Timeframe) -> ValidationResult:
    """Checks chronological order, duplicate timestamps, and gaps between
    consecutive bars relative to the expected step size for the timeframe."""
    issues: list[str] = []

    if not bars:
        return ValidationResult(ok=False, issues=["no bars provided"])

    expected_step = _TIMEFRAME_SECONDS[timeframe]
    sorted_bars = sorted(bars, key=lambda b: b.open_time)

    if sorted_bars != bars:
        issues.append("bars are not in chronological order")

    seen_times = {sorted_bars[0].open_time}
    for i in range(1, len(sorted_bars)):
        prev, curr = sorted_bars[i - 1], sorted_bars[i]

        if curr.open_time in seen_times:
            issues.append(f"duplicate open_time detected: {curr.open_time.isoformat()}")
        seen_times.add(curr.open_time)

        gap = (curr.open_time - prev.open_time).total_seconds()
        # allow small tolerance (10%) for provider timestamp jitter
        if gap > expected_step * 1.1:
            issues.append(
                f"gap detected between {prev.open_time.isoformat()} and "
                f"{curr.open_time.isoformat()} (expected ~{expected_step}s, got {gap:.0f}s)"
            )
        elif gap < expected_step * 0.9:
            issues.append(
                f"bars closer together than expected between {prev.open_time.isoformat()} "
                f"and {curr.open_time.isoformat()} ({gap:.0f}s)"
            )

    return ValidationResult(ok=len(issues) == 0, issues=issues)
