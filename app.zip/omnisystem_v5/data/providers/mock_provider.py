"""
MockProvider — SIMULATED data ONLY.

This exists purely so the ingestion pipeline and its tests can run
without a live network connection. It is hard-wired to DataOrigin.SIMULATED
and must never be substituted for a real provider in a live pipeline
configuration. Engines that check `.is_usable()` on the resulting
envelope will correctly refuse SIMULATED data.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from omnisystem_v5.data.providers.base import DataProvider, DataUnavailableError, RawFetchResult
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe

_TIMEFRAME_SECONDS = {
    Timeframe.M1: 60,
    Timeframe.M5: 300,
    Timeframe.M15: 900,
    Timeframe.H1: 3600,
    Timeframe.H4: 14400,
    Timeframe.D1: 86400,
}


class MockProvider(DataProvider):
    declared_origin = DataOrigin.SIMULATED

    def __init__(self, fail: bool = False, base_price: float = 100.0):
        """
        fail: if True, always raises DataUnavailableError (for testing the
              missing-data path).
        """
        self._fail = fail
        self._base_price = base_price

    @property
    def name(self) -> str:
        return "mock_provider"

    def fetch_ohlcv(self, market: str, timeframe: Timeframe, limit: int = 200) -> RawFetchResult:
        if self._fail:
            raise DataUnavailableError(f"mock_provider: no data for {market} {timeframe}")

        step = _TIMEFRAME_SECONDS[timeframe]
        now = datetime.now(timezone.utc)
        bars = []
        price = self._base_price
        for i in range(limit):
            open_time = now - timedelta(seconds=step * (limit - i))
            close_time = open_time + timedelta(seconds=step)
            o = price
            h = o + 1.5
            l = o - 1.5
            c = o + 0.3
            bars.append(
                {
                    "open": o,
                    "high": h,
                    "low": l,
                    "close": c,
                    "volume": 10.0 + i,
                    "open_time": open_time.isoformat(),
                    "close_time": close_time.isoformat(),
                }
            )
            price = c

        return RawFetchResult(origin=self.declared_origin, source_name=self.name, raw_bars=bars)
