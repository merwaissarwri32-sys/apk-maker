"""
Abstract data provider interface.

A "provider" is anything that can supply raw market data — a real
exchange API, a historical archive, or (for testing only) a simulated
generator. This is the pluggable adapter the architecture doc calls for.

CONTRACT: a provider returns RAW payloads plus a mandatory declaration
of its own DataOrigin. It does NOT decide quality_status — that is the
Data Quality Gate's job, downstream. A provider that cannot get data
must raise DataUnavailableError rather than return empty/fake data.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from omnisystem_v5.schemas.enums import DataOrigin, Timeframe


class DataUnavailableError(Exception):
    """Raised by a provider when it cannot obtain the requested data.
    This is the ONLY acceptable failure mode — providers must never
    fabricate a substitute value."""


class RawFetchResult:
    """Simple carrier for what a provider hands back before normalization."""

    def __init__(self, origin: DataOrigin, source_name: str, raw_bars: list[dict[str, Any]]):
        self.origin = origin
        self.source_name = source_name
        self.raw_bars = raw_bars


class DataProvider(ABC):
    """All concrete providers (real or simulated) implement this."""

    #: Every provider must declare what kind of data it can ever produce.
    #: A real exchange adapter declares LIVE or HISTORICAL.
    #: The mock/test provider declares SIMULATED and nothing else.
    declared_origin: DataOrigin

    @property
    @abstractmethod
    def name(self) -> str:
        """Short unique identifier, e.g. 'binance_spot'."""

    @abstractmethod
    def fetch_ohlcv(self, market: str, timeframe: Timeframe, limit: int = 200) -> RawFetchResult:
        """Fetch raw OHLCV data. Must raise DataUnavailableError on failure —
        never return synthetic/guessed values from a real-data provider."""
        raise NotImplementedError
