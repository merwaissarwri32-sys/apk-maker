"""
Enumerations for the Quant Engine (MERWIS AI, Phase 3).
"""

from enum import Enum


class QuantStatus(str, Enum):
    """Top-level status of a QuantContext. Mirrors Phase 2's ContextStatus
    mapping, one level further downstream."""

    OK = "OK"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    DATA_UNAVAILABLE = "DATA_UNAVAILABLE"
    INVALID_CONTEXT = "INVALID_CONTEXT"


class VwapMethod(str, Enum):
    SESSION = "SESSION"    # cumulative VWAP over the entire available bar series
    ROLLING = "ROLLING"    # VWAP over the most recent N bars only


class VolatilityRegime(str, Enum):
    """Classification of the CURRENT volatility LEVEL against configured,
    static thresholds on ATR% — not a statistical/ML classification, and
    not an AI judgment."""

    LOW = "LOW"
    NORMAL = "NORMAL"
    HIGH = "HIGH"


class VolatilityPhase(str, Enum):
    """Classification of how volatility is CHANGING (recent vs prior
    rolling ATR average) — independent of the absolute level above."""

    EXPANSION = "EXPANSION"
    CONTRACTION = "CONTRACTION"
    STABLE = "STABLE"


class EmaRelationship(str, Enum):
    FAST_ABOVE_SLOW = "FAST_ABOVE_SLOW"
    FAST_BELOW_SLOW = "FAST_BELOW_SLOW"
    EQUAL = "EQUAL"


class InvalidationSource(str, Enum):
    SWING_STRUCTURE = "SWING_STRUCTURE"
    SUPPORT_RESISTANCE = "SUPPORT_RESISTANCE"
    LIQUIDITY_ZONE = "LIQUIDITY_ZONE"
    FVG_BOUNDARY = "FVG_BOUNDARY"


class InvalidationDirection(str, Enum):
    """Where the candidate level sits relative to current price — neutral
    phrasing on purpose; this says nothing about long/short intent."""

    ABOVE_PRICE = "ABOVE_PRICE"
    BELOW_PRICE = "BELOW_PRICE"
