"""
Volume Weighted Average Price (VWAP).

Formula (identical for both methods, differing only in which bars are
included):

    typical_price[i] = (high[i] + low[i] + close[i]) / 3
    VWAP = sum(typical_price[i] * volume[i]) / sum(volume[i])

SESSION VWAP uses every bar in the series provided (this codebase is
timeframe-agnostic and has no concept of an exchange trading-session
boundary yet, so "session" here means "the full window of bars supplied
to this calculation" — documented explicitly, not silently assumed).

ROLLING VWAP uses only the most recent `period` bars.

If total volume across the included bars is zero (e.g. a provider that
does not supply volume, or a genuinely volume-less asset), VWAP CANNOT
be calculated — this function returns None rather than dividing by zero
or substituting a fallback average. Volume is never invented.
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.schemas.market_data import OHLCVBar


def calculate_vwap(bars: Sequence[OHLCVBar]) -> float | None:
    """Computes VWAP over exactly the bars given. Returns None (not an
    exception) when total volume is zero, since that is a valid data
    state ("no volume available") rather than a malformed-input error."""
    if len(bars) == 0:
        raise InsufficientDataError("calculate_vwap", required=1, available=0)

    total_volume = sum(b.volume for b in bars)
    if total_volume <= 0:
        return None

    weighted_sum = sum(((b.high + b.low + b.close) / 3.0) * b.volume for b in bars)
    return weighted_sum / total_volume


def calculate_session_vwap(bars: Sequence[OHLCVBar]) -> float | None:
    """VWAP over the entire bar series provided ('session' = the full
    window supplied to this calculation)."""
    return calculate_vwap(bars)


def calculate_rolling_vwap(bars: Sequence[OHLCVBar], period: int) -> float | None:
    if period < 1:
        raise ValueError("period must be >= 1")
    if len(bars) < period:
        raise InsufficientDataError("calculate_rolling_vwap", required=period, available=len(bars))
    return calculate_vwap(bars[-period:])
