"""
Risk/Reward foundation — MERWIS AI, Phase 3.

These are pure calculators. They take an entry, invalidation, and
(optionally) target price supplied by a FUTURE engine (Risk, Bull,
Bear, Master Decision) — this module never selects, guesses, or
recommends any of those three prices itself. No direction (long/short)
is inferred; the caller's supplied prices already encode that.

Formulas:
    risk_distance   = abs(entry - invalidation)
    reward_distance = abs(target - entry)                (only if target given)
    percentage_risk   = risk_distance / entry * 100
    potential_reward_pct = reward_distance / entry * 100  (only if target given)
    reward_risk_ratio = reward_distance / risk_distance    (only if target given)
    r_multiple(exit_price) = (exit_price - entry) / risk_distance   [signed:
        positive if exit moved in the direction away from invalidation,
        negative if toward/through it — sign is determined by which side
        of entry the invalidation sits on, not assumed]
"""

from __future__ import annotations

from dataclasses import dataclass


class RiskRewardError(ValueError):
    pass


@dataclass(frozen=True)
class RiskRewardResult:
    entry: float
    invalidation: float
    target: float | None
    risk_distance: float
    percentage_risk: float
    reward_distance: float | None
    potential_reward_pct: float | None
    reward_risk_ratio: float | None


def calculate_risk_reward(entry: float, invalidation: float, target: float | None = None) -> RiskRewardResult:
    if entry <= 0:
        raise RiskRewardError("entry must be positive")
    if entry == invalidation:
        raise RiskRewardError("entry and invalidation cannot be equal (zero risk distance)")

    risk_distance = abs(entry - invalidation)
    percentage_risk = (risk_distance / entry) * 100.0

    reward_distance = None
    potential_reward_pct = None
    reward_risk_ratio = None

    if target is not None:
        if target == entry:
            raise RiskRewardError("target and entry cannot be equal (zero reward distance)")
        reward_distance = abs(target - entry)
        potential_reward_pct = (reward_distance / entry) * 100.0
        reward_risk_ratio = reward_distance / risk_distance

    return RiskRewardResult(
        entry=entry,
        invalidation=invalidation,
        target=target,
        risk_distance=risk_distance,
        percentage_risk=percentage_risk,
        reward_distance=reward_distance,
        potential_reward_pct=potential_reward_pct,
        reward_risk_ratio=reward_risk_ratio,
    )


def calculate_r_multiple(entry: float, invalidation: float, exit_price: float) -> float:
    """Signed R multiple: how many "risk units" the exit price represents,
    relative to entry, in the direction AWAY from invalidation.

    If invalidation < entry (long-style risk placement), positive R means
    price moved up. If invalidation > entry (short-style risk placement),
    positive R means price moved down. The sign is derived purely from
    the relative positions given — no direction is assumed independently.
    """
    if entry == invalidation:
        raise RiskRewardError("entry and invalidation cannot be equal (zero risk distance)")
    risk_distance = abs(entry - invalidation)
    raw_move = exit_price - entry
    # if invalidation is below entry, "away from risk" is upward (+1);
    # if invalidation is above entry, "away from risk" is downward (-1).
    direction_sign = 1 if invalidation < entry else -1
    return (raw_move * direction_sign) / risk_distance
