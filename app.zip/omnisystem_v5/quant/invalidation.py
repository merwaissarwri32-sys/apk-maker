"""
Invalidation candidate detection — MERWIS AI, Phase 3.

Gathers mathematically defensible candidate levels from data ALREADY
computed in MarketContext (swing structure, support/resistance,
liquidity zones, FVG boundaries). This module does not detect anything
new from raw bars — it only measures distances and validity of
existing structure relative to current price.

It NEVER selects a final stop — it returns every qualifying candidate,
sorted by distance from current price, for a later engine to choose
from.

"Validity": a candidate is `valid=True` if current price has not
already moved through it (i.e. it could still function as a level to
watch). A support/swing-low BELOW current price is valid; if price has
since traded below it, it is `valid=False` (already breached). Same
logic, mirrored, for resistance/swing-highs above price.
"""

from __future__ import annotations

from datetime import datetime

from omnisystem_v5.context.schema import FairValueGap, LiquidityZone, SupportResistanceLevel, SwingPoint
from omnisystem_v5.context.enums import LiquidityType, SRLevelType, SwingType
from omnisystem_v5.quant.enums import InvalidationDirection, InvalidationSource
from omnisystem_v5.quant.schema import InvalidationCandidate
from omnisystem_v5.schemas.enums import Timeframe


def _make_candidate(
    price: float,
    current_price: float,
    source: InvalidationSource,
    timeframe: Timeframe,
    formed_at: datetime | None,
    calculation_source: str,
    intrinsic_side: InvalidationDirection | None = None,
) -> InvalidationCandidate:
    """
    `direction` is always the CURRENT geometric fact: is this level's price
    above or below current price right now.

    `valid` means something stronger: does that geometric fact still match
    what this type of level is structurally supposed to be. A resistance /
    swing high / equal-highs level is only a meaningful upside reference
    while it remains ABOVE price; if price has since closed through it,
    the level is broken and `valid=False` — it no longer functions as that
    kind of boundary (it may have "flipped" to support, but classifying
    that flip is out of scope for this deterministic layer).

    `intrinsic_side=None` (used for FVG boundaries, which are more neutral
    zone edges than a directional pivot) skips this check and reports
    valid=True — the geometric direction is still returned either way.
    """
    direction = InvalidationDirection.ABOVE_PRICE if price > current_price else InvalidationDirection.BELOW_PRICE
    distance_abs = abs(price - current_price)
    distance_pct = (distance_abs / current_price) * 100.0 if current_price else 0.0

    if intrinsic_side is None:
        valid = True
    else:
        valid = direction == intrinsic_side

    return InvalidationCandidate(
        price=price,
        source=source,
        timeframe=timeframe,
        direction=direction,
        distance_abs=distance_abs,
        distance_pct=distance_pct,
        formed_at=formed_at,
        valid=valid,
        calculation_source=calculation_source,
    )


def candidates_from_swings(
    swings: tuple[SwingPoint, ...], current_price: float, timeframe: Timeframe, most_recent_only: bool = True
) -> list[InvalidationCandidate]:
    """By default returns only the MOST RECENT confirmed swing high and
    the most recent confirmed swing low — those are the structurally
    relevant "last pivot" levels. Set most_recent_only=False to get all
    confirmed swings as candidates."""
    highs = [s for s in swings if s.swing_type == SwingType.HIGH]
    lows = [s for s in swings if s.swing_type == SwingType.LOW]

    selected: list[SwingPoint] = []
    if most_recent_only:
        if highs:
            selected.append(max(highs, key=lambda s: s.timestamp))
        if lows:
            selected.append(max(lows, key=lambda s: s.timestamp))
    else:
        selected = list(swings)

    return [
        _make_candidate(
            price=s.price,
            current_price=current_price,
            source=InvalidationSource.SWING_STRUCTURE,
            timeframe=timeframe,
            formed_at=s.timestamp,
            calculation_source=(
                f"{s.swing_type.value} swing at {s.timestamp.isoformat()} (price={s.price})"
            ),
            intrinsic_side=(
                InvalidationDirection.ABOVE_PRICE if s.swing_type == SwingType.HIGH
                else InvalidationDirection.BELOW_PRICE
            ),
        )
        for s in selected
    ]


def candidates_from_support_resistance(
    levels: tuple[SupportResistanceLevel, ...], current_price: float, timeframe: Timeframe
) -> list[InvalidationCandidate]:
    return [
        _make_candidate(
            price=lv.price,
            current_price=current_price,
            source=InvalidationSource.SUPPORT_RESISTANCE,
            timeframe=timeframe,
            formed_at=lv.last_touched_at,
            calculation_source=(
                f"{lv.level_type.value} level at {lv.price} "
                f"({lv.touch_count} touches, last at {lv.last_touched_at.isoformat()})"
            ),
            intrinsic_side=(
                InvalidationDirection.ABOVE_PRICE if lv.level_type == SRLevelType.RESISTANCE
                else InvalidationDirection.BELOW_PRICE
            ),
        )
        for lv in levels
    ]


def candidates_from_liquidity_zones(
    zones: tuple[LiquidityZone, ...], current_price: float, timeframe: Timeframe
) -> list[InvalidationCandidate]:
    return [
        _make_candidate(
            price=z.price_level,
            current_price=current_price,
            source=InvalidationSource.LIQUIDITY_ZONE,
            timeframe=timeframe,
            formed_at=z.formed_at,
            calculation_source=(
                f"{z.liquidity_type.value} zone at {z.price_level} "
                f"({z.touch_count} touches, formed at {z.formed_at.isoformat()})"
            ),
            intrinsic_side=(
                InvalidationDirection.ABOVE_PRICE if z.liquidity_type == LiquidityType.EQUAL_HIGHS
                else InvalidationDirection.BELOW_PRICE
            ),
        )
        for z in zones
    ]


def candidates_from_fvgs(
    fvgs: tuple[FairValueGap, ...], current_price: float, timeframe: Timeframe
) -> list[InvalidationCandidate]:
    """Only UNFILLED FVGs are returned — a filled gap is no longer a
    structurally meaningful boundary."""
    candidates = []
    for gap in fvgs:
        if gap.filled:
            continue
        for boundary_price, label in ((gap.top, "top"), (gap.bottom, "bottom")):
            candidates.append(
                _make_candidate(
                    price=boundary_price,
                    current_price=current_price,
                    source=InvalidationSource.FVG_BOUNDARY,
                    timeframe=timeframe,
                    formed_at=gap.formed_at,
                    calculation_source=(
                        f"{gap.fvg_type.value} FVG {label} boundary at {boundary_price} "
                        f"(formed at {gap.formed_at.isoformat()}, unfilled)"
                    ),
                )
            )
    return candidates


def gather_invalidation_candidates(
    swings: tuple[SwingPoint, ...],
    support_resistance: tuple[SupportResistanceLevel, ...],
    liquidity_zones: tuple[LiquidityZone, ...],
    fair_value_gaps: tuple[FairValueGap, ...],
    current_price: float,
    timeframe: Timeframe,
) -> list[InvalidationCandidate]:
    all_candidates = (
        candidates_from_swings(swings, current_price, timeframe)
        + candidates_from_support_resistance(support_resistance, current_price, timeframe)
        + candidates_from_liquidity_zones(liquidity_zones, current_price, timeframe)
        + candidates_from_fvgs(fair_value_gaps, current_price, timeframe)
    )
    return sorted(all_candidates, key=lambda c: c.distance_abs)
