"""
Normalization — MERWIS AI, Phase 3.

Every function below documents: formula, input, output range, and
limitations, per the Phase 3 requirement. No arbitrary scoring is
introduced here — each transform has a direct statistical or
dimensional-analysis justification.
"""

from __future__ import annotations

import statistics
from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.schemas.market_data import OHLCVBar


def calculate_return_zscore(bars: Sequence[OHLCVBar], window: int) -> float:
    """
    Formula:
        returns = simple returns over the most recent `window` bars
        z = (returns[-1] - mean(returns)) / stdev(returns)

    Input:  a bar series with at least `window` + 1 bars.
    Output range: theoretically unbounded; in practice, roughly [-4, 4]
        for return distributions with normal-ish behavior (most values
        fall within [-3, 3] under a Gaussian assumption).
    Limitations:
        - Assumes the recent return window is a reasonable sample of the
          local return distribution — this is often violated during
          regime changes.
        - Small `window` values make the estimate noisy; this function
          does not impose a "recommended" window, that is a caller
          decision documented in QuantEngineConfig defaults.
        - stdev == 0 (a perfectly flat window) makes the z-score
          undefined; this function raises ValueError rather than
          returning +/-infinity or an arbitrary fallback.
    """
    required = window + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_return_zscore", required=required, available=len(bars))

    closes = [b.close for b in bars[-required:]]
    returns = [(closes[i] - closes[i - 1]) / closes[i - 1] for i in range(1, len(closes))]
    mean_r = statistics.mean(returns)
    stdev_r = statistics.stdev(returns)
    if stdev_r == 0:
        raise ValueError("cannot compute return z-score: zero variance in return window")
    return (returns[-1] - mean_r) / stdev_r


def calculate_atr_normalized_momentum(momentum: float, atr: float) -> float:
    """
    Formula:
        normalized = momentum / atr

    Input:  a raw momentum value (absolute price difference) and the
        current ATR (also an absolute price unit) — same units, so the
        ratio is dimensionless.
    Output range: theoretically unbounded; expresses "how many average
        true ranges did price move", so values roughly in [-3, 3] are
        typical for normal price action, larger magnitudes indicate an
        unusually large move relative to recent volatility.
    Limitations:
        - Meaningless if ATR is stale or computed over a very different
          regime than the momentum window.
        - ATR == 0 (a perfectly flat market) makes this undefined; this
          function raises ValueError rather than returning infinity.
    """
    if atr == 0:
        raise ValueError("cannot compute ATR-normalized momentum: ATR is zero")
    return momentum / atr
