"""
Momentum metrics.

ROC (Rate of Change), fractional:
    ROC[period] = (close[-1] - close[-1-period]) / close[-1-period]

Momentum, absolute price difference:
    MOM[period] = close[-1] - close[-1-period]

RSI (Wilder's original method — the same smoothing family as ATR, chosen
for consistency and because it is the most widely documented version):
    gain[i] = max(close[i] - close[i-1], 0)
    loss[i] = max(close[i-1] - close[i], 0)
    avg_gain[period] = mean(gain[1..period])          (seed, simple average)
    avg_loss[period] = mean(loss[1..period])
    avg_gain[i > period] = (avg_gain[i-1]*(period-1) + gain[i]) / period
    avg_loss[i > period] = (avg_loss[i-1]*(period-1) + loss[i]) / period
    RS  = avg_gain / avg_loss
    RSI = 100 - 100 / (1 + RS)
    Edge cases (documented, not guessed):
      - avg_loss == 0 and avg_gain > 0  -> RSI = 100
      - avg_gain == 0 and avg_loss == 0 -> RSI = 50 (no movement at all;
        conventionally treated as neutral, not fabricated directional bias)

EMA (Exponential Moving Average):
    multiplier = 2 / (period + 1)
    EMA[period] = SMA(close[0..period-1])              (seed)
    EMA[i > period-1] = close[i]*multiplier + EMA[i-1]*(1-multiplier)
"""

from __future__ import annotations

from typing import Sequence

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.schemas.market_data import OHLCVBar


def calculate_roc(bars: Sequence[OHLCVBar], period: int) -> float:
    if period < 1:
        raise ValueError("period must be >= 1")
    required = period + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_roc", required=required, available=len(bars))
    prior_close = bars[-1 - period].close
    if prior_close == 0:
        raise ValueError("cannot compute ROC: prior close is zero")
    return (bars[-1].close - prior_close) / prior_close


def calculate_momentum(bars: Sequence[OHLCVBar], period: int) -> float:
    if period < 1:
        raise ValueError("period must be >= 1")
    required = period + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_momentum", required=required, available=len(bars))
    return bars[-1].close - bars[-1 - period].close


def calculate_rsi(bars: Sequence[OHLCVBar], period: int = 14) -> float:
    required = period + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_rsi", required=required, available=len(bars))

    closes = [b.close for b in bars]
    gains = []
    losses = []
    for i in range(1, len(closes)):
        delta = closes[i] - closes[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_gain == 0 and avg_loss == 0:
        return 50.0
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def calculate_ema(bars: Sequence[OHLCVBar], period: int) -> float:
    if period < 1:
        raise ValueError("period must be >= 1")
    if len(bars) < period:
        raise InsufficientDataError("calculate_ema", required=period, available=len(bars))

    closes = [b.close for b in bars]
    multiplier = 2 / (period + 1)
    ema = sum(closes[:period]) / period  # seed: simple average
    for c in closes[period:]:
        ema = c * multiplier + ema * (1 - multiplier)
    return ema
