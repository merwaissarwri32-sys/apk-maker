"""
Quant Engine — MERWIS AI, Phase 3.

    MarketDataEnvelope -> MarketContext -> QuantEngine -> QuantContext

This is the ONLY place that turns a Phase 2 MarketContext into a
QuantContext. It consumes MarketContext exclusively (including the
`bars` field added in this phase) — it never reaches back to raw
provider data. No AI reasoning, no trade decisions, no LONG/SHORT
signals are produced anywhere in this module.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MarketContext
from omnisystem_v5.quant.enums import EmaRelationship, QuantStatus, VwapMethod
from omnisystem_v5.quant.invalidation import gather_invalidation_candidates
from omnisystem_v5.quant.momentum import calculate_ema, calculate_momentum, calculate_roc, calculate_rsi
from omnisystem_v5.quant.normalization import calculate_atr_normalized_momentum, calculate_return_zscore
from omnisystem_v5.quant.risk_reward import RiskRewardError  # re-exported for downstream engines
from omnisystem_v5.quant.schema import MomentumMetrics, NormalizedMetrics, QuantContext, VolatilityContext, VwapResult
from omnisystem_v5.quant.volatility import (
    calculate_atr_percentage,
    calculate_rolling_volatility,
    classify_volatility_phase,
    classify_volatility_regime,
)
from omnisystem_v5.quant.vwap import calculate_rolling_vwap, calculate_session_vwap

__all__ = ["QuantEngineConfig", "build_quant_context", "RiskRewardError"]


@dataclass(frozen=True)
class QuantEngineConfig:
    roc_period: int = 10
    momentum_period: int = 10
    rsi_period: int = 14
    ema_fast_period: int = 12
    ema_slow_period: int = 26
    atr_period: int = 14                    # should generally match MarketContextConfig.atr_period
    vwap_rolling_period: int = 20
    rolling_volatility_window: int = 20
    volatility_phase_window: int = 5
    return_zscore_window: int = 20
    low_vol_threshold_pct: float = 0.5
    high_vol_threshold_pct: float = 2.0
    expansion_threshold: float = 0.15
    contraction_threshold: float = 0.15
    # Deliberately generous default so ema_slow (26), vwap_rolling (20),
    # rolling_volatility (21), return_zscore (21), and volatility phase
    # (14 + 2*5 = 24) all have room — explicit and overridable.
    min_bars_required: int = 40


_MARKET_STATUS_TO_QUANT_STATUS = {
    ContextStatus.DATA_UNAVAILABLE: QuantStatus.DATA_UNAVAILABLE,
    ContextStatus.INSUFFICIENT_CONTEXT: QuantStatus.INSUFFICIENT_DATA,
    ContextStatus.INVALID_CONTEXT: QuantStatus.INVALID_CONTEXT,
}


def _empty_quant_context(
    symbol: str, timeframe, status: QuantStatus, provenance, reasons: list[str]
) -> QuantContext:
    return QuantContext(
        symbol=symbol,
        timeframe=timeframe,
        status=status,
        calculated_at=datetime.now(timezone.utc),
        provenance=provenance,
        reasons=tuple(reasons),
    )


def build_quant_context(
    symbol: str,
    market_context: MarketContext,
    config: QuantEngineConfig | None = None,
) -> QuantContext:
    config = config or QuantEngineConfig()

    # 1. Mirror MarketContext's status if it wasn't OK.
    if market_context.status != ContextStatus.OK:
        mapped = _MARKET_STATUS_TO_QUANT_STATUS[market_context.status]
        reasons = list(market_context.reasons) + [
            f"underlying MarketContext.status={market_context.status.value}"
        ]
        return _empty_quant_context(symbol, market_context.timeframe, mapped, market_context.provenance, reasons)

    bars = list(market_context.bars)
    timeframe = market_context.timeframe
    current_price = market_context.current_price

    # 2. Quant Engine's own minimum bar requirement.
    if len(bars) < config.min_bars_required:
        reasons = [
            f"only {len(bars)} bars available in MarketContext, "
            f"{config.min_bars_required} required for quantitative metrics"
        ]
        return _empty_quant_context(symbol, timeframe, QuantStatus.INSUFFICIENT_DATA, market_context.provenance, reasons)

    now = datetime.now(timezone.utc)
    top_level_reasons: list[str] = []

    # 3. VWAP (session + rolling). Individually optional — missing volume
    #    never blocks the rest of the context.
    vwap_session = _build_vwap(bars, VwapMethod.SESSION, current_price, now, period=len(bars))
    vwap_rolling = _build_vwap(
        bars, VwapMethod.ROLLING, current_price, now, period=config.vwap_rolling_period
    )

    # 4. Momentum metrics.
    momentum = _build_momentum(bars, config, now)

    # 5. Volatility context (extends Phase 2's ATR/volatility).
    volatility = _build_volatility(bars, market_context, config, now)

    # 6. Normalization.
    normalized = _build_normalized(bars, momentum, volatility, config, now)

    # 7. Invalidation candidates — from data already in MarketContext.
    invalidation_candidates = tuple(
        gather_invalidation_candidates(
            swings=market_context.swing_points,
            support_resistance=market_context.support_resistance,
            liquidity_zones=market_context.liquidity_zones,
            fair_value_gaps=market_context.fair_value_gaps,
            current_price=current_price,
            timeframe=timeframe,
        )
    ) if current_price is not None else tuple()

    return QuantContext(
        symbol=symbol,
        timeframe=timeframe,
        status=QuantStatus.OK,
        calculated_at=now,
        provenance=market_context.provenance,
        current_price=current_price,
        vwap_session=vwap_session,
        vwap_rolling=vwap_rolling,
        momentum=momentum,
        volatility=volatility,
        normalized=normalized,
        support_resistance=market_context.support_resistance,
        liquidity_zones=market_context.liquidity_zones,
        fair_value_gaps=market_context.fair_value_gaps,
        invalidation_candidates=invalidation_candidates,
        reasons=tuple(top_level_reasons),
    )


def _build_vwap(bars, method: VwapMethod, current_price, now, period: int) -> VwapResult:
    reasons: list[str] = []
    value = None
    try:
        if method == VwapMethod.SESSION:
            value = calculate_session_vwap(bars)
        else:
            value = calculate_rolling_vwap(bars, period)
    except InsufficientDataError as e:
        reasons.append(str(e))

    if value is None and not reasons:
        reasons.append("total volume across included bars is zero or unavailable — VWAP cannot be calculated")

    distance_abs = None
    distance_pct = None
    if value is not None and current_price is not None:
        distance_abs = current_price - value
        distance_pct = (distance_abs / value) * 100.0

    return VwapResult(
        method=method,
        value=value,
        period_bars=period if value is not None else None,
        distance_abs=distance_abs,
        distance_pct=distance_pct,
        calculated_at=now,
        reasons=tuple(reasons),
    )


def _build_momentum(bars, config: QuantEngineConfig, now) -> MomentumMetrics:
    reasons: list[str] = []

    def _safe(fn, *args):
        try:
            return fn(*args)
        except InsufficientDataError as e:
            reasons.append(str(e))
            return None

    roc = _safe(calculate_roc, bars, config.roc_period)
    momentum_val = _safe(calculate_momentum, bars, config.momentum_period)
    rsi = _safe(calculate_rsi, bars, config.rsi_period)
    ema_fast = _safe(calculate_ema, bars, config.ema_fast_period)
    ema_slow = _safe(calculate_ema, bars, config.ema_slow_period)

    relationship = None
    if ema_fast is not None and ema_slow is not None:
        if ema_fast > ema_slow:
            relationship = EmaRelationship.FAST_ABOVE_SLOW
        elif ema_fast < ema_slow:
            relationship = EmaRelationship.FAST_BELOW_SLOW
        else:
            relationship = EmaRelationship.EQUAL

    return MomentumMetrics(
        roc=roc,
        roc_period=config.roc_period,
        momentum=momentum_val,
        momentum_period=config.momentum_period,
        rsi=rsi,
        rsi_period=config.rsi_period,
        ema_fast=ema_fast,
        ema_fast_period=config.ema_fast_period,
        ema_slow=ema_slow,
        ema_slow_period=config.ema_slow_period,
        ema_relationship=relationship,
        calculated_at=now,
        reasons=tuple(reasons),
    )


def _build_volatility(bars, market_context: MarketContext, config: QuantEngineConfig, now) -> VolatilityContext:
    reasons: list[str] = []

    # Reuse the ATR already computed in Phase 2 rather than recomputing —
    # avoids duplicate work and guarantees consistency with MarketContext.
    atr = market_context.volatility.atr if market_context.volatility else None
    atr_period = market_context.volatility.atr_period if market_context.volatility else config.atr_period

    atr_pct = None
    if atr is not None and market_context.current_price:
        try:
            atr_pct = calculate_atr_percentage(atr, market_context.current_price)
        except ValueError as e:
            reasons.append(str(e))
    elif atr is None:
        reasons.append("ATR unavailable from MarketContext — atr_pct cannot be computed")

    rolling_vol = None
    try:
        rolling_vol = calculate_rolling_volatility(bars, config.rolling_volatility_window)
    except InsufficientDataError as e:
        reasons.append(str(e))

    regime = None
    if atr_pct is not None:
        regime = classify_volatility_regime(atr_pct, config.low_vol_threshold_pct, config.high_vol_threshold_pct)

    phase = None
    try:
        phase = classify_volatility_phase(
            bars,
            atr_period=atr_period,
            window=config.volatility_phase_window,
            expansion_threshold=config.expansion_threshold,
            contraction_threshold=config.contraction_threshold,
        )
    except InsufficientDataError as e:
        reasons.append(str(e))

    basis = (
        f"regime thresholds: low<{config.low_vol_threshold_pct}%, high>{config.high_vol_threshold_pct}%; "
        f"phase window={config.volatility_phase_window} bars, "
        f"expansion_threshold={config.expansion_threshold}, contraction_threshold={config.contraction_threshold}"
    )

    return VolatilityContext(
        atr=atr,
        atr_period=atr_period,
        atr_pct=atr_pct,
        rolling_volatility=rolling_vol,
        rolling_window=config.rolling_volatility_window,
        regime=regime,
        phase=phase,
        basis=basis,
        calculated_at=now,
        reasons=tuple(reasons),
    )


def _build_normalized(bars, momentum: MomentumMetrics, volatility: VolatilityContext, config: QuantEngineConfig, now) -> NormalizedMetrics:
    reasons: list[str] = []

    zscore = None
    try:
        zscore = calculate_return_zscore(bars, config.return_zscore_window)
    except (InsufficientDataError, ValueError) as e:
        reasons.append(str(e))

    atr_norm_momentum = None
    if momentum.momentum is not None and volatility.atr is not None:
        try:
            atr_norm_momentum = calculate_atr_normalized_momentum(momentum.momentum, volatility.atr)
        except ValueError as e:
            reasons.append(str(e))
    else:
        reasons.append("momentum or ATR unavailable — atr_normalized_momentum cannot be computed")

    return NormalizedMetrics(
        return_zscore=zscore,
        return_zscore_window=config.return_zscore_window,
        atr_normalized_momentum=atr_norm_momentum,
        calculated_at=now,
        reasons=tuple(reasons),
    )
