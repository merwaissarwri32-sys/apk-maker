"""
Quant Context schemas — MERWIS AI, Phase 3.

Everything here is either a real deterministic calculation or an
explicit None with a reason. No field is ever a guess. No field
represents a trading decision — this layer produces MEASUREMENTS,
not recommendations.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.context.schema import (
    FairValueGap,
    LiquidityZone,
    SupportResistanceLevel,
    _require_tz,
)
from omnisystem_v5.quant.enums import (
    EmaRelationship,
    InvalidationDirection,
    InvalidationSource,
    QuantStatus,
    VolatilityPhase,
    VolatilityRegime,
    VwapMethod,
)
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance


class QuantValidationError(ValueError):
    """Raised when a Phase 3 schema object fails its own invariants."""


@dataclass(frozen=True)
class VwapResult:
    method: VwapMethod
    value: float | None
    period_bars: int | None          # number of bars the VWAP was computed over
    distance_abs: float | None       # current_price - vwap value
    distance_pct: float | None       # distance_abs / vwap value
    calculated_at: datetime
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        if self.value is not None and self.value <= 0:
            raise QuantValidationError("VWAP value must be positive when present")


@dataclass(frozen=True)
class MomentumMetrics:
    roc: float | None                # rate of change, as a fraction (e.g. 0.05 = +5%)
    roc_period: int
    momentum: float | None           # simple price difference over momentum_period
    momentum_period: int
    rsi: float | None                # 0-100
    rsi_period: int
    ema_fast: float | None
    ema_fast_period: int
    ema_slow: float | None
    ema_slow_period: int
    ema_relationship: EmaRelationship | None
    calculated_at: datetime
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        if self.rsi is not None and not (0.0 <= self.rsi <= 100.0):
            raise QuantValidationError("RSI must be within [0, 100]")


@dataclass(frozen=True)
class VolatilityContext:
    atr: float | None
    atr_period: int
    atr_pct: float | None            # atr / current_price * 100
    rolling_volatility: float | None  # sample stdev of returns over rolling_window
    rolling_window: int
    regime: VolatilityRegime | None
    phase: VolatilityPhase | None
    basis: str
    calculated_at: datetime
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        if self.atr_pct is not None and self.atr_pct < 0:
            raise QuantValidationError("atr_pct cannot be negative")


@dataclass(frozen=True)
class NormalizedMetrics:
    """Cross-asset/cross-timeframe comparable metrics. Every field here
    must have a formula documented in calculations code — see
    quant/normalization.py module docstring."""

    return_zscore: float | None          # (latest return - mean) / stdev of a rolling return window
    return_zscore_window: int
    atr_normalized_momentum: float | None  # momentum / atr — momentum expressed in ATR units
    calculated_at: datetime
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")


@dataclass(frozen=True)
class InvalidationCandidate:
    price: float
    source: InvalidationSource
    timeframe: Timeframe
    direction: InvalidationDirection
    distance_abs: float
    distance_pct: float
    formed_at: datetime | None
    valid: bool                          # False if price has already moved through this level
    calculation_source: str              # human-readable derivation explanation

    def __post_init__(self):
        if self.formed_at is not None:
            _require_tz(self.formed_at, "formed_at")
        if self.distance_abs < 0:
            raise QuantValidationError("distance_abs cannot be negative")


@dataclass(frozen=True)
class QuantContext:
    """The single structured object the Risk Engine, Bull Engine, Bear
    Engine, and Master Decision Engine are meant to consume for
    quantitative facts. Contains no trade decision of any kind."""

    symbol: str
    timeframe: Timeframe
    status: QuantStatus
    calculated_at: datetime
    provenance: DataProvenance | None
    current_price: float | None = None

    vwap_session: VwapResult | None = None
    vwap_rolling: VwapResult | None = None
    momentum: MomentumMetrics | None = None
    volatility: VolatilityContext | None = None
    normalized: NormalizedMetrics | None = None

    # Passed through from MarketContext, unmodified — the Quant Engine
    # does not recompute structure, it only reasons about distances to it.
    support_resistance: tuple[SupportResistanceLevel, ...] = field(default_factory=tuple)
    liquidity_zones: tuple[LiquidityZone, ...] = field(default_factory=tuple)
    fair_value_gaps: tuple[FairValueGap, ...] = field(default_factory=tuple)

    invalidation_candidates: tuple[InvalidationCandidate, ...] = field(default_factory=tuple)
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self):
        _require_tz(self.calculated_at, "calculated_at")
        if self.status != QuantStatus.OK and (
            self.current_price is not None
            or self.vwap_session is not None
            or self.vwap_rolling is not None
            or self.momentum is not None
            or self.volatility is not None
            or self.normalized is not None
            or self.invalidation_candidates
        ):
            raise QuantValidationError(
                f"status={self.status} must not carry calculated fields — "
                "never infer/populate results when context is not OK"
            )
        for c in self.invalidation_candidates:
            if c.timeframe != self.timeframe:
                raise QuantValidationError(
                    f"invalidation candidate timeframe {c.timeframe} does not match "
                    f"context timeframe {self.timeframe}"
                )
