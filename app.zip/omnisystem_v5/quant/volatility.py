"""
Extended volatility analysis (builds on Phase 2's ATR/returns primitives).

ATR%:
    atr_pct = (atr / current_price) * 100
    A scale-free measure of volatility relative to price, comparable
    across assets/timeframes with very different absolute prices.

Rolling volatility:
    sample stdev of simple returns over the most recent `window` bars
    (a strict subset of calculate_volatility from Phase 2, windowed).

Volatility REGIME (absolute level, static configured thresholds — NOT
an AI judgment, NOT a statistical percentile against history unless the
caller supplies thresholds derived that way):
    LOW    if atr_pct <  low_threshold_pct
    HIGH   if atr_pct >  high_threshold_pct
    NORMAL otherwise
Thresholds are explicit parameters with documented defaults; there is
no hidden model behind this classification.

Volatility PHASE (how volatility is changing, not its absolute level):
    Compare the average of the most recent `window` ATR values against
    the average of the `window` ATR values immediately preceding them.
        recent_avg = mean(atr_series[-window:])
        prior_avg  = mean(atr_series[-2*window:-window])
        EXPANSION   if recent_avg > prior_avg * (1 + expansion_threshold)
        CONTRACTION if recent_avg < prior_avg * (1 - contraction_threshold)
        STABLE      otherwise
"""

from __future__ import annotations

import statistics
from typing import Sequence

from omnisystem_v5.calculations.atr import AtrSeriesPoint, calculate_atr
from omnisystem_v5.calculations.errors import InsufficientDataError
from omnisystem_v5.quant.enums import VolatilityPhase, VolatilityRegime
from omnisystem_v5.schemas.market_data import OHLCVBar


def calculate_atr_percentage(atr: float, current_price: float) -> float:
    if current_price <= 0:
        raise ValueError("current_price must be positive to compute atr_pct")
    return (atr / current_price) * 100.0


def calculate_rolling_volatility(bars: Sequence[OHLCVBar], window: int) -> float:
    if window < 2:
        raise ValueError("window must be >= 2 (need at least 2 returns)")
    required = window + 1
    if len(bars) < required:
        raise InsufficientDataError("calculate_rolling_volatility", required=required, available=len(bars))

    recent = bars[-required:]
    closes = [b.close for b in recent]
    returns = [(closes[i] - closes[i - 1]) / closes[i - 1] for i in range(1, len(closes))]
    return statistics.stdev(returns)


def classify_volatility_regime(
    atr_pct: float, low_threshold_pct: float = 0.5, high_threshold_pct: float = 2.0
) -> VolatilityRegime:
    if atr_pct < low_threshold_pct:
        return VolatilityRegime.LOW
    if atr_pct > high_threshold_pct:
        return VolatilityRegime.HIGH
    return VolatilityRegime.NORMAL


def classify_volatility_phase(
    bars: Sequence[OHLCVBar],
    atr_period: int = 14,
    window: int = 5,
    expansion_threshold: float = 0.15,
    contraction_threshold: float = 0.15,
) -> VolatilityPhase:
    """Requires enough bars for 2*window confirmed ATR values."""
    required_atr_points = 2 * window
    required_bars = atr_period + required_atr_points
    if len(bars) < required_bars:
        raise InsufficientDataError("classify_volatility_phase", required=required_bars, available=len(bars))

    series: list[AtrSeriesPoint] = calculate_atr(bars, period=atr_period)
    if len(series) < required_atr_points:
        raise InsufficientDataError(
            "classify_volatility_phase (atr series length)", required=required_atr_points, available=len(series)
        )

    recent_values = [p.value for p in series[-window:]]
    prior_values = [p.value for p in series[-2 * window : -window]]
    recent_avg = sum(recent_values) / window
    prior_avg = sum(prior_values) / window

    if prior_avg == 0:
        return VolatilityPhase.STABLE

    if recent_avg > prior_avg * (1 + expansion_threshold):
        return VolatilityPhase.EXPANSION
    if recent_avg < prior_avg * (1 - contraction_threshold):
        return VolatilityPhase.CONTRACTION
    return VolatilityPhase.STABLE
