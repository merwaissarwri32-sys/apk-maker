# MERWIS AI — Phase 10 Final Report
## 24/7 Autonomous Signal Hunter / Market Scanner (foundation)

**Baseline:** Phase 9 frozen ZIP (650/650). **Final:** 764/764 PASS (650 + 114 new). Python 3.12, stdlib only.
**Phase 1–9 files changed: 0** · removed: 0 · added: 28 files (see §11) — verified by SHA-256 manifest of every pre-existing file under `omnisystem_v5/`.
Evidence class of all Phase 10 tests and benchmarks: **SYNTHETIC** (real, unmocked context → quant → engines → decision → risk; bars are generated). Nothing here is market evidence.

---
## 1. What Phase 10 adds
An orchestration/discovery layer that repeatedly answers *"what deserves deeper analysis right now?"* and routes each answer through the **existing** Decision Engine and Risk Engine hard gate. It adds **no strategy, indicator, structure or risk logic** (`scanner/evaluation.py` only composes public APIs, in the frozen replay's order). The scanner **never places or routes a trade**; its products are data (`ScanReport`, `ScanSignal`). A static test asserts the package imports no network / execution modules and never reads the wall clock (except `SystemClock`).

## 2. Stage model — reuse instead of six new types
| Conceptual stage | Represented by (existing unless noted) |
|---|---|
| market observation | `MarketDataEnvelope` |
| detected opportunity / candidate | horizon engines' own candidates + `NormalizedCandidate` (wrapped with ATR in `DiscoveredCandidate`) |
| validated / decision-ready / execution-ready | `FinalDecision` (outcome ≠ NO_TRADE **and** `risk_result.is_actionable`, already enforced by its `__post_init__`) |
| processing state + identity | **`ScanSignal`** (new — the only genuinely new domain object) |

Lifecycle ≠ validity: `SignalState` = `DETECTED → EMITTED → EXPIRED`, `DETECTED → SUPPRESSED`. `EMITTED` means *released to the downstream dispatcher*; whether the trade is acceptable is only ever read from `signal.decision` (carried by reference, `compare=False`). Invalid transitions raise `InvalidTransitionError`; constructor invariants forbid impossible combinations.

## 3. Architecture (`omnisystem_v5/scanner/`, 1,640 lines)
| Concern | Module |
|---|---|
| WHAT — universe, normalization, filters, auditable exclusions | `universe.py` |
| WHEN — pure schedule + systemic back-off | `scheduler.py`, `runner.py` (injectable clock & sleep) |
| HOW — engine, executor boundary, config | `engine.py`, `executor.py`, `config.py` |
| Data boundary (re-gates every envelope) | `market_data.py`, `timeframes.py` |
| Composition of existing intelligence | `evaluation.py` |
| Identity / lifecycle / dedup / cooldown | `identity.py`, `signals.py`, `dedup.py` |
| Priority (explainable, not probability) | `priority.py` |
| Failure taxonomy, ledger, health | `failures.py`, `health.py` |
| Observability, time, state, report | `telemetry.py`, `clock.py`, `state.py`, `report.py` |

Dependency direction: `scanner → (data, context, quant, intelligence, decision, risk, validation.{resampling,warmup})`; **nothing imports the scanner** (tested). Two public helpers are borrowed from `validation/` (`seconds_for_timeframe`, `context_bar_requirement`) rather than re-declaring tables.

## 4. Scan flow (one `run_cycle(state, account) → CycleResult(report, new_state)`)
universe → filter/normalize/sort → quarantine filter → symbol-cursor rotation & budget → per symbol: fetch each required timeframe (bounded timeout retry) → **gate** (shape, quality status, origin, bar count, sequence re-validation, injected-clock freshness, forming/future bar) → **plan horizons** (missing/stale/unsynchronized timeframes block only the horizons that need them) → evaluate runnable horizons → `decide()` per symbol (Risk hard gate inside) → health assessment → ledger update → fingerprint → priority ranking → dedup/cooldown → per-cycle cap → report + new state. `now` is `clock.now()` and is passed explicitly to `decide()`.

## 5. Identity, deduplication, cooldown
* **Fingerprint** = SHA-256(family = symbol/direction/horizon/engine, execution timeframe, scenario, quantized entry zone, invalidation zone, targets). **Excluded on purpose:** wall-clock, `candidate_id` (Phase 9 F1), current price (moves every bar), regime (flips independently of setup geometry — would fragment identity).
* **Scale:** ATR-relative (bucket = 0.5·ATR). If ATR is missing/non-finite/≤0 → documented fallback: bucket = 0.25 % of entry-zone midpoint; basis (`ATR`/`PCT_FALLBACK`) is recorded and hashed. ATR is never invented.
* **Dedup compares by tolerance, not hash equality** (`same_setup`, 1.0 ATR per level, in the *reference's* scale), so a level drifting across a bucket boundary is not a "new" setup (tested).
* **Semantics (all boundaries strict and tested):** a family has ≤1 active signal. Same setup → `DUPLICATE` (refreshes `last_seen`, never re-emits while continuously seen — 40 cycles emit exactly once). Expire when `now − last_seen > expiry`. After expiry the same setup is `COOLDOWN`-suppressed while `now − emitted_at < cooldown`. A materially different setup re-emits (`MATERIAL_CHANGE`), superseding the active one. `DEFERRED_CAP` (max signals/cycle) does **not** track the setup, so it can emit next cycle; duplicates never consume the cap.
* Effective expiry is extended by `(rotation_cycles − 1)·interval` when a symbol budget rotates the universe, so unscanned symbols' signals don't expire spuriously.

## 6. Failure model — precise semantics
Classes (`FailureClass`): provider unavailable / timeout / rate-limited, malformed response, unusable origin, stale, insufficient, invalid, unsynchronized timeframes, internal error. *Feed-level* = provider classes + malformed + stale + unsynchronized.
* **attempted** = symbols actually scanned (excludes quarantined / budget-skipped / rate-limit-aborted). **failed** = attempted with no runnable horizon.
* `attempted=0` → `NO_WORK` (empty universe is not a failure). `attempted < min_sample(5)` → never SYSTEMIC. Otherwise SYSTEMIC if `feed_failed/attempted ≥ 0.8` or every attempted symbol failed; DEGRADED if `failed/attempted ≥ 0.3`, any internal error, or a rate limit; else HEALTHY (thresholds inclusive, tested).
* **Health never discards a symbol that passed every gate** — a SYSTEMIC cycle still emits signals of symbols that are individually fresh/synchronized/validated (tested: 8 of 10 symbols down, 2 good → both emitted). Health only (a) is reported with reasons, (b) freezes failure counters, (c) drives scheduler back-off (60 s → 120 → 240 → 480 → cap 900; returns to 60 s on recovery — tested through the runner).
* **Quarantine** (3 consecutive failures → 900 s, then one probe) counts only in HEALTHY cycles, so an outage can never leave the universe quarantined at recovery; success resets. Quarantined symbols leave the health denominator, so a universe with many known-bad symbols cannot trip health.
* Rate limit: no in-cycle retry; remaining batch work is skipped and reported (`SKIPPED_RATE_LIMIT`); rotation resumes after the last scanned symbol. Only timeouts are retried (bounded, no sleeping).
* Internal exceptions become `INTERNAL_ERROR` with type+message in the report and force ≥ DEGRADED — never swallowed. A failing universe source yields a SYSTEMIC report and **preserves tracked signals**. A failing telemetry sink cannot break a scan (`telemetry_errors` counted).

## 7. Determinism
Time only from the injected `Clock`; ordering explicit (sorted universe, priority key with symbol/horizon/direction tie-breaks, sorted dedup state); no randomness. `ScanReport.canonical_json()` excludes wall-clock-derived ids, decision objects and latency (`compare=False`). Tested: byte-identical reports across independent runs separated by real sleeps (engines stamp wall-clock), across reversed universe input order, and across 4-cycle sequences; fingerprints equal while `candidate_id`s differ.
**F1 verification:** every wall-clock use in engines/builders is `calculated_at`/evidence timestamps; `decide()`/`assess_risk()` only stamp the supplied `now`. **No wall-clock value affects any decision or branch** — nothing to report as a decision-affecting defect. Frozen code was not modified.

## 8. Priority
Lexicographic tuple of named ordinals: the Decision layer's own `rank_key` (reused, 8 components), then `risk_verdict` (VALID/WARNING), `data_freshness`, `liquidity_tier` (tercile inside the scan universe). Labeled `COMPUTATIONAL_PRIORITY_NOT_PROBABILITY`. No sums, weights or probabilities.

## 9. Performance (measured, sequential; `python -m omnisystem_v5.tests.bench_scanner`)
| symbols | cycle | ms/symbol | repeat cycle (all duplicates) |
|---|---|---|---|
| 1 / 10 / 40 / 80 | 0.08 / 0.69 / 2.87 / 5.67 s | 83 / 69 / 72 / 71 | 0.06 / 0.69 / 2.96 / 5.41 s |
Linear scaling, ≈70 ms/symbol on 5 timeframes × 3 horizons, dominated by the real engines (synthetic bar generation ≈ 3 ms/symbol). Dedup: 0.03→0.32 ms per emit and 0.05→0.63 ms per duplicate observation from N=100→2000 (O(N) per call) — <1 % of per-symbol evaluation, so **not optimized** (measure-first).

## 10. Test coverage (114 new)
`test_scanner_universe` 12 · `test_scanner_identity_dedup` 24 · `test_scanner_data_health_schedule` 37 · `test_scanner_engine` 41 (integration with real engines/decision/risk). Covered: universe & normalization; scheduling & back-off; timeframe freshness/sync/plan; data-quality integration (stale, forming bar, simulated, malformed, duplicate/shuffled/gapped bars, missing/desynchronized timeframe); lifecycle transitions & invariants; dedup/cooldown/expiry boundaries; fingerprint (ATR scale, fallback, boundary drift, F1 immunity); priority; failure classification and every scenario requested (isolated bad symbol, repeated bad symbol, provider-wide outage, partial outage, empty universe, recovery); rate limit; internal error; broken telemetry sink; scanner→intelligence→decision→**risk veto** (strict policy yields NO_TRADE with `REJECTED_RISK` in the trace); determinism; rotation/budget/executor ordering; safety (no network/execution imports, no wall clock, no reverse dependency). **Regression: 764/764, zero existing tests removed or altered.**

## 11. Files
Added under `omnisystem_v5/`: `scanner/` (21 modules), `tests/scanner_fixtures.py`, `tests/test_scanner_{universe,identity_dedup,data_health_schedule,engine}.py`, `tests/bench_scanner.py` (not collected by discovery), this report. Root: `CHECKPOINT_STATUS_PHASE10.md` (the Phase 9 checkpoint file is left untouched).

## 12. Known limitations (not hidden)
1. **No incremental evaluation yet:** unchanged bars are re-evaluated each cycle (repeat cycle costs the same as the first). Measured evidence says this is the top optimization; needs care because `decide()` depends on account state. Not implemented.
2. **Executor boundary only:** `SequentialExecutor` is the sole implementation; a concurrent one must return results in input order (documented in `executor.py`). Rate-limit abort is honored between/within sequential batches only.
3. **No real provider adapter / persistence / alert transport** — Phase 11/12. `MarketDataSource` is a structural protocol (`DataIngestionService` satisfies it) and expects `scanner_quality_config()` because Phase 1's wall-clock staleness limit (300 s) would mark every 4h/1d series STALE; the scanner applies its own per-timeframe, injected-clock freshness.
4. **Event-risk context is not supplied** to the engines (no event feed exists); they report it as they do in replay.
5. All candidates from Intraday/Short-Swing results are passed to `decide()` (it arbitrates conflicts); the frozen replay passes only the top-ranked one — a deliberate, documented superset.
6. Counters freeze in non-HEALTHY cycles: during a long DEGRADED period a truly bad symbol is not quarantined (cost only, never suppression).
7. Dedup materiality uses a uniform ATR tolerance across all levels; ScanState is in-memory only (caller-owned).
8. **F6 was not investigated or touched**, per directive. Phase 9's known items remain as documented.

## 13. Extension points
`Universe` (dynamic symbol discovery), `MarketDataSource` (provider adapters), `Executor` (concurrency), `TelemetrySink`, `Clock`, evaluator injection, `ScanState` (persistence), `ScanReport.emitted` (alert dispatch).
