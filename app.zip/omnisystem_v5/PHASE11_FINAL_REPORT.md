# MERWIS AI — PHASE 11 FINAL REPORT
**Live Data & Multi-Asset Infrastructure ("the data nervous system")**

Status: **IMPLEMENTED and TESTED (synthetic, offline). NOT live-connected. NOT live-verified.**
Baseline: Phase 10 ZIP = 764/764 → now **1038/1038** (764 regression + 274 new Phase 11).

## 1. Evidence levels (what is and is not claimed)

| Claim | State |
|---|---|
| Phase 11 code exists and is covered by deterministic tests | **Implemented, Tested** |
| Any provider adapter reached a real endpoint | **No** (Live-connected: none) |
| Observed / validated in production | **No** |
| `KlinesRestAdapter` | **IMPLEMENTED — NOT LIVE-VERIFIED** (shape assumptions from public docs as remembered, never observed) |
| Scripted / legacy adapters | TESTED (fixtures; scripted declares HISTORICAL, never LIVE) |

All market data in every test is SYNTHETIC. A passing suite is not evidence of live-market behavior or performance.

## 2. Files

**Created (43)** — `omnisystem_v5/marketdata/` (31 files, 2,868 lines): `__init__, assets, canonical, catalog, catalog_en, catalog_fa, config, events, feed, freshness, health, i18n, issues, metrics, normalize, pipeline, provider, quotes, retry, router, sessions, source, state, stream, symbol_map, system, universe, validation` + `adapters/{__init__, klines_rest, legacy, scripted}`;
`omnisystem_v5/tests/` (2,765 lines): `marketdata_fixtures.py, phase10_frozen_manifest.txt, test_marketdata_{architecture,domain,freshness_config,health_retry,integration,providers,scenarios,source_universe,validation}.py`; plus this report and `CHECKPOINT_STATUS_PHASE11.md`.

**Modified (1, authorized D1)** — `omnisystem_v5/tests/test_scanner_engine.py`, exactly one line:
```
-            if rel[0] in ("scanner", "tests"):
+            if rel[0] in ("scanner", "tests", "marketdata"):
```
No Phase 1–10 implementation file was modified.

## 3. Frozen integrity (GATE B)
176 files recorded before; 175 byte-identical after; the single difference is the D1 line above (the manifest test reverses exactly that edit and re-hashes to the recorded value). 0 files removed. Enforced permanently by `TestFrozenManifest` using `tests/phase10_frozen_manifest.txt`.

## 4. Architecture as built
```
Provider adapter → RawBars (primitives, explicit request echo)
  → normalize (strict) → validate → freshness → (MarketDataEnvelope, StreamHealth)
  → LiveMarketDataSource  ──►  Phase 10 ScanEngine (unchanged)
InstrumentCatalog + ProviderHealth + Sessions → InstrumentUniverse ──► Phase 10 ScanEngine (unchanged)
```
* **Provider boundary** (`provider.py`): `MarketDataProvider`, `ProviderCapabilities` (only `live_capable` adapters may declare LIVE), `RawBars/RawQuote`, `Transport`, `CredentialSource`, `EvidenceLevel`. Vendor JSON never crosses it; timeframe is always the requested one; epoch integers are refused (unit would be guessed).
* **Data contracts**: `MarketDataEnvelope` untouched. Richer state lives in `StreamHealth` (freshness state, age, dropped bars, issues, provider state, SHA-256 digest of the delivered bars), keyed `(symbol, timeframe)`. Optional `Quote` (finite, >0, ask ≥ bid) is separate and never reaches the scanner.
* **Asset model**: `AssetClass` (6), `Instrument` (asset class, base, quote → canonical symbol = `SymbolSpec.symbol`), `Venue`, `Listing` (session, tick/precision, bar anchor). `SymbolMap` is explicit and fail-closed. `InstrumentCatalog` rejects cross-class symbol collisions.
* **Sessions**: `AlwaysOpenSession` (crypto), `WeeklySession` (local-time windows in an IANA zone, DST-correct, explicit closures, fails closed without tz data), `MarketStatus`.
* **Validation** (`validation.py`): schema → non-finite/price/volume/OHLC → timestamp alignment + exact duration → order/duplicates → forming/future bar → gaps → composed frozen `validate_bar_sequence` → min bars. Composes, does not rewrite, the frozen validator. Any fatal issue ⇒ no bars exposed.
* **Freshness**: `FRESH/DEGRADED/STALE/EXPIRED/MISSING/INVALID`. FRESH∪DEGRADED ≡ the scanner's usable region by construction (same comparison, single `SharedLimits`); only EXPIRED is Phase-11-owned.
* **Health**: provider machine `HEALTHY/DEGRADED/THROTTLED/UNAVAILABLE/RECOVERING` (pure transitions, cooldown backoff, operator reset for auth failures); instrument machine `AVAILABLE/DEGRADED/QUARANTINED` (+ computed `UNAVAILABLE/DISABLED` in the universe). `FaultScope` (SYMBOL/INSTRUMENT/PROVIDER/ASSET_CLASS/SYSTEMIC) is orthogonal to the reused `FailureClass`.
* **Failure model**: provider faults are *raised* with the existing types (`ProviderRateLimitedError`, `TimeoutError`, `DataUnavailableError`; thin subclasses `ProviderAuthError`, `ProviderPayloadError` map through the unchanged `classify_fetch_exception`); symbol/instrument defects are *returned* as non-OK envelopes.
* **Retry** (`retry.py`): bounded, deterministic (SHA-256 jitter), injected sleep/timer, default 1 attempt (no hidden retries), rate limits never waited on by default, auth never retried, sliding-window client throttle. `MarketDataConfig` refuses `Phase11 attempts × scanner attempts > cap`.
* **Feeds**: `BarFeed` with `PollingFeed` and `StreamingFeed` (+ `BarStore` rejecting out-of-order updates). Polling and streaming yield identical envelopes (tested). No stream is faked.
* **Observability / assistant boundary**: reused `TelemetrySink` family with `DataEventKind`; `MetricsSink`; `DataSystemSnapshot` (canonical JSON, schema-versioned, evidence levels, roll-ups) behind read-only `StateReader`. No assistant, no LLM.
* **Localization** (`i18n.py`): `MessageKey`, `StructuredMessage`, `LocalizedMessage`, `Locale`, `MessageCatalog`; complete EN catalog, FA catalog (placeholders verified identical). Core is language-neutral.
* **Real-time boundary**: only `system.py` may touch real time (`time.sleep`, `time.monotonic`); default timer is `NullTimer`, default retry never sleeps.

## 5. Tests — 274 new, 1038 total, 0 failures
| File | Tests |
|---|---|
| domain (assets, symbol map, catalog, sessions incl. DST, quotes, i18n) | 33 |
| validation (fail-closed suite, session-gap policy) | 40 |
| freshness_config (single-source agreement, attempt budget) | 13 |
| health_retry (every state transition, backoff, throttle, stream store) | 48 |
| providers (reusable contract suite ×3 providers, REST adapter) | 45 |
| source_universe (source, universe, metrics, snapshot, isolation) | 43 |
| integration (real `ScanEngine`: parity, multi-asset, D2, isolation) | 16 |
| scenarios (A–N through the real scanner) | 12 |
| architecture (static safety, frozen manifest) | 24 |
| **Phase 11 total** | **274** |
| Regression (Phases 1–10, run in isolation) | **764 / 764** |
| **Everything** | **1038 / 1038** |

Key gates proven: scan report through Phase 11 is **byte-identical** to the Phase 10 stub path (single and multi-cycle); freshness agreement over a dense age grid × 5 staleness values × 6 timeframes; retry attempts cannot exceed the global cap; NaN/±inf/non-positive/negative-volume/impossible-OHLC/naive & epoch timestamps/misalignment/duplicates/out-of-order/forming/future/insufficient all refused, never repaired. The architecture guards were mutation-checked on a throwaway copy (each injected violation fails the matching test).

## 6. Determinism
Same inputs + clock + config ⇒ identical canonical output: 3 repeated in-process runs equal; identical SHA-256 of (3 scan reports + full snapshot) across 4 separate processes with `PYTHONHASHSEED` ∈ {0, 1, 7, 424242}.

## 7. Performance (measured once, informational)
40-symbol full scan cycle: ~1.98 s stub source vs ~2.16 s through Phase 11 (includes building the stack and series) — the cost is dominated by the frozen analytics. Ingest (normalize+validate+freshness+digest) ≈ 1.7 ms per 200-bar stream. Default execution stays sequential; caching, batching, bounded concurrency and connection reuse have seams but are not implemented.

## 8. Known limitations (honest list)
1. **D2 (accepted)** — the frozen gate rejects session gaps. Forex: SCALP runs; INTRADAY needs a gap-free 1h window (or opt-in truncation and enough bars since the open); **SHORT_SWING (4h+1d) stays blocked**. For ~40 hours after each weekly open the 1h series is insufficient. Nothing is filled, compressed or fabricated. Pinned by tests. Fix (session-aware sequence check) is a separate, additive Phase 10 extension.
2. **Timeout blame is provider-scope.** Ten consecutive timeouts (5 timeframes × 2 scanner attempts) from one symbol trip that provider's breaker (30 s cooldown) and other symbols on the same provider fail fast. Documented trade-off of fail-fast; other providers are unaffected.
3. `KlinesRestAdapter` is not live-verified; no real HTTP transport exists; no forex vendor adapter.
4. INVALID envelopes produced with no real data (unknown/unmapped instrument) carry origin `SIMULATED` because the frozen envelope forbids origin `UNAVAILABLE` with a non-`DATA_UNAVAILABLE` status; the status alone makes the scanner refuse them.
5. Universe exclusions appear in `UniverseSnapshot.excluded` with typed reasons, **not** in the scanner's own `excluded` list.
6. `TelemetryEvent.kind` is annotated as the scanner's `EventKind`; Phase 11 passes `DataEventKind` (runtime-compatible, nominal-typing note only).
7. Persian catalog is unreviewed by a native speaker. RTL/numeral shaping are presentation concerns, not implemented.
8. Forex session (`forex_ny`) is a convention (Sun 17:00 → Fri 17:00 New York); holidays are supplied as explicit closures, not modeled. DST-anchored daily bars are unsupported (fixed UTC anchor offset only). `zoneinfo` needs system tz data; absence fails closed.
9. Quotes: record, normalization and freshness exist; no quote-serving service is wired into the source (scanner does not consume quotes).
10. Health state is in-memory (no persistence). No cross-provider failover (sticky first-usable selection; deliberate).

## 9. Deviations from the approved Step 3
* Two modules added that were not in the tree: `issues.py` (DataIssue/FaultScope) and `canonical.py` (serialization/digest) — needed to avoid import cycles.
* A trailing forming-bar drop is **recorded but does not mark the stream DEGRADED** (Step 3 had said it would; it is routine for providers that include the forming bar). Session-gap truncation and provider state still do.
* Integration found a real defect, fixed before completion: session gaps were being counted as instrument failures, quarantining a forex symbol after one cycle. They now produce a distinct `data.session_gap` issue (still refused) and never count against instrument health (regression test added).
* `MessageKey.DATA_SESSION_GAP` added for that purpose.
* `HealthPolicy` named `ProviderHealthPolicy` to avoid confusion with the scanner's.

## 10. Deferred (not started)
Alert transport and notification delivery; the assistant itself; UI; cross-provider failover/arbitration; real HTTP transport and live verification; forex vendor adapter; session-aware scanner gate; holiday calendars; concurrency/caching/batching; persistence.

## 11. Exact next phase
**Phase 12 — Alert & Notification Infrastructure** (consumes `DataSystemSnapshot`/events and scanner signals via structured messages + the localization boundary). **Not started; awaiting authorization.** Recommended pre-work that needs its own authorization: (a) the additive session-aware scanner-gate extension that unblocks forex SHORT_SWING, (b) live verification of the REST adapter against a real endpoint.
