# MERWIS AI - Phase 8: Multi-Horizon Replay, Walk-Forward & Adversarial Validation - Final Report

Boundaries respected: no Execution Engine, no Auto Trading, no Broker/Exchange
integration, no live data provider, no order placement, and no parameter-fitting
/ machine-learning layer were built or implied. Phase 9 was not started.

---

## 1. Scope of Phase 8

Phase 8 extended Phase 7's single-horizon (Scalp-only) historical replay into a
genuine Multi-Horizon (Scalp + Intraday + Short-Swing) replay engine, closed
three real engineering gaps discovered by auditing the codebase against its own
tests, and added the two remaining Phase 8 deliverables: a real Walk-Forward
Runner and an Adversarial/Overfitting Validation utility. Phase 7 was never
modified; every fix and addition in this phase is additive.

---

## 2. Architecture and Data Flow

```
Historical OHLCV bars (caller-provided, never fabricated)
                |
        validate_historical_dataset()          <- blocking data-quality gate
                |
        run_multi_horizon_replay()              (Phase 8 Multi-Horizon Replay Engine)
                |
   for each replay step idx (chronological, sliding window bars[lo:idx+1],
   lo bounded by max_lookback_bars - see Warmup Calculation below):
                |
        base timeframe context/quant  ---->  _collect_scalp()
        resample_bars() to each horizon's exec/higher timeframe (Priority 1
        hardened - see Resampling below) ---->  _collect_intraday(), _collect_short_swing()
                |
        ALL horizons' candidates -> decision_bridge -> decide()
        [Master Decision Engine: dedup -> directional conflict -> quality gate
         -> ranking -> Risk Engine hard gate, unmodified from Phase 6]
                |
        (LONG/SHORT winner) -> find_entry_fill -> simulate_position_lifecycle
        -> TradeRecord (FINAL_EXIT / EXPIRED / INVALIDATED / REJECTED_BY_RISK),
        every non-winning candidate ALSO recorded via candidate_trace
                |
                v
        BacktestResult (dataset, data_quality, trades, reproducibility, period_splits)
                |
        +-------+--------------------------------+
        |                                         |
run_walk_forward()                    check_look_ahead_leakage() /
(validation/walk_forward_runner.py)   check_window_robustness() /
  runs run_multi_horizon_replay       check_parameter_sensitivity() /
  independently per fold              check_structural_robustness()
        |                             (validation/adversarial_validation.py)
        v
WalkForwardResult (per-fold BacktestResult + PeriodSplit + aggregate metrics)
```

Independence/reuse guarantee (unchanged principle from Phase 7): no parallel or
approximate decision algorithm exists anywhere in Phase 8. Every horizon calls
the exact Phase 4/6 production functions (`detect_scalp_candidate`,
`detect_intraday_candidate`, `detect_short_swing_candidate`, `decide`). The
Risk Engine's hard gate was never bypassed. The Walk-Forward Runner and the
Adversarial Validation utility call `run_multi_horizon_replay` itself, unmodified
- neither introduces a second execution or decision path.

---

## 3. Resampling Integrity (Priority 1)

**Root cause found:** `resample_bars()` validated a target-timeframe bucket by
bar *count* alone (`len(group) < ratio`). A bucket containing one duplicated
source timestamp and one genuinely missing interval also has `len(group) ==
ratio`, and was silently accepted as a complete, valid candle.

**Fix:** before bucketing, every source bar's timestamp is now checked for grid
alignment and duplication (raising `ResamplingError`, fail-closed, on either);
each bucket is then accepted only if its bars' timestamps exactly equal the
full expected set of source-interval starts for that bucket - count alone is no
longer sufficient.

**Tests added:** 9 adversarial cases (missing first/middle/last source bar,
duplicate timestamp, duplicate-with-conflicting-values, out-of-order input,
malformed/misaligned timestamp, duplicate+missing combination, perfect
sequence) in `test_phase8_resampling.py`.

---

## 4. Warmup Calculation (Priority 2)

**Root cause found:** `MultiHorizonReplayConfig.max_lookback_bars` was a single
fixed default (400) shared across all horizons. Short-Swing's D1 higher-
timeframe context requires far more base-timeframe history than that -
computed (never hardcoded) as `ratio * N + (ratio - 1)` where `N =
max(MarketContextConfig.min_bars_required, QuantEngineConfig.min_bars_required)`
and the `+ (ratio - 1)` term is the worst-case margin for a sliding window not
starting on a calendar boundary. With the project's own default configs this
works out to 3,935 M15 bars for Short-Swing's D1 leg - meaning Short-Swing
could never reach a complete context under the old fixed 400-bar default,
regardless of how much real history was available.

**Fix:** new module `validation/warmup.py` computes each enabled horizon's real
requirement from its own actual config values (never a hardcoded constant).
`MultiHorizonReplayConfig.max_lookback_bars` defaults to `None`, meaning
"auto-compute the smallest lookback that is genuinely sufficient for every
enabled horizon"; an explicit value smaller than that requirement is rejected
fail-closed with a message naming the exact shortfall.

**Tests added:** 22 tests in `test_phase8_warmup.py`, including an end-to-end
proof (not just formula-checking) that the computed number is both *sufficient*
and *tight* (one bar short, at worst-case window alignment, is provably
insufficient).

---

## 5. Silent Exception Handling (Priority 3)

**Root cause found:** `_collect_intraday`/`_collect_short_swing` wrapped their
`resample_bars()` calls in `except Exception: return`, indistinguishably
converting a genuine internal bug (e.g. a future `TypeError` from a code
regression) into "no candidate this step."

**Fix:** narrowed to `except ResamplingError:` - the one named, expected,
auditable data-integrity condition. Every other exception type now propagates
and fails loudly, as required by the fail-closed principle governing this
entire phase.

**Tests added:** 7 tests in `test_phase8_exception_handling.py`, proving (a) a
genuine internal error is never swallowed at the collector or full-replay
level, (b) `ResamplingError` specifically is still treated as an expected "no
candidate," and (c) the pre-existing `insufficient data`/`intentionally
blocked` paths (explicit status checks, never exceptions) are unaffected.

---

## 6. Multi-Horizon Replay Orchestration

No further root-cause bugs were found in `run_multi_horizon_replay` itself
beyond Priorities 1-3 above. The existing architecture already implements, with
no bypass found anywhere in the chain: real, blocking data-quality validation
before any horizon runs; the exact Phase 6 conflict-resolution contract
(`decision/conflict.py`) for Cross-Horizon Conflict, with no new ranking
invented; a structurally single-position design (idx only advances past a
trade's own exit) plus an explicit fail-closed rejection of any
`max_concurrent_positions != 1`; and full metadata (`horizon`, `source_engine`)
propagation from raw engine candidate through `NormalizedCandidate` ->
`FinalDecision` -> `TradeRecord`, verified for both the winning and every
rejected candidate.

**Tests added:** 21 tests in `test_phase8_multi_horizon_replay.py`, covering
all ten required areas: Determinism, Look-Ahead Protection (including a direct
comparison of the `MultiTimeframeMarketContext`/quant objects passed into a
horizon engine, not just final trade output), Cross-Horizon Conflict (a
hand-verified three-horizon scenario using `decide()`'s real lexicographic
ranking), Data-Quality Blocking, Per-Horizon Enable/Disable, Max Concurrent
Positions, Metadata Propagation, Rejected-Candidate Traceability, Error
Semantics, and Deterministic Ordering.

---

## 7. Walk-Forward Runner

**Design note (read before using):** MERWIS's horizon engines are rule-based
against explicit, human-set configuration thresholds - nothing is fit to data
anywhere in this codebase. Phase 7's `validation/walk_forward.py` foundation
already recognized this: its `WalkForwardEngine` ABC assumes a
`trained_state`-producing training step and was explicitly left unimplemented
("a future-phase deliverable"). Implementing that ABC here would have required
inventing a fake "training" step that does nothing real - exactly the
fabricated-validation failure mode this phase must avoid. Phase 7's
`walk_forward.py` was therefore left untouched; the new module
`validation/walk_forward_runner.py` is a genuinely different, additive
capability suited to a non-fitted system: proving that a forward-moving,
chronologically bounded sequence of independent evaluation windows produces
decisions using only each window's own warmup history, exactly as a live
deployment would encounter the data one day at a time.

**What it does:** `WalkForwardRunConfig` (ROLLING or EXPANDING mode,
configurable `train_bars`/`test_bars`/`step_bars`) plus `compute_folds()` (pure,
deterministic index arithmetic - reads no bar data, so it cannot itself
introduce leakage) plus `run_walk_forward()`, which calls the unmodified
`run_multi_horizon_replay()` once per fold against `bars[fold.warmup_start_index
: fold.test_end_index + 1]` only - a fold's bars slice physically does not
contain a single bar beyond its own test window, a stronger and simpler
leakage guarantee than relying on internal windowing alone. Each fold's
`BacktestResult.period_splits` field (present in the Phase 7 contract but
never previously populated) is now filled in with real `PeriodSplit(TRAINING,
...)` / `PeriodSplit(OUT_OF_SAMPLE, ...)` entries, reusing the existing Phase 7
`ValidationPeriodType` enum rather than inventing a new one. ROLLING mode's
`train_bars` is validated fail-closed against the real per-horizon requirement
from `validation/warmup.py` (the exact Priority 2 fix, applied consistently
here) - a rolling window too small for the enabled horizons is rejected at
config time, not silently run half-starved. Every fold runs with a fresh
`initial_capital` (no equity carried over) and no shared mutable state, so
folds are independently reproducible.

**Tests added:** 18 tests in `test_phase8_walk_forward_runner.py`: config
validation, hand-verified fold-boundary arithmetic for both modes, non-overlap/
chronological ordering, the zero-fold case (dataset too short - an explicit,
traced result, never a crash), determinism, look-ahead (extra trailing bars
never change earlier, already-computed folds), fold independence (identical
candidate/account state reproduces identical risk outcome across folds), a
genuine internal error propagating rather than being swallowed, `period_splits`
population, and aggregate-metric correctness against hand calculation.

---

## 8. Adversarial / Overfitting Validation Utility

**Design note (read before using):** "Overfitting" in the classic sense
(a model memorizing training data) cannot literally occur in a system with no
fitted parameters. `validation/adversarial_validation.py` therefore implements
only what is genuinely checkable, and every report dataclass it returns carries
an explicit `limitations` tuple stating what that specific check does not
prove - no function fabricates a pass/fail verdict beyond what was actually
computed from real code execution:

1. **`check_look_ahead_leakage`** - runs `run_multi_horizon_replay` on a bar
   prefix and again on that prefix plus caller-supplied extra trailing bars,
   both with the same `end_index`, and compares every decision-time field of
   every trade (excluding only the final trade's legitimately forward-looking
   execution-outcome fields). Verified to have real teeth: engineered-leak test
   cases (a fake replay function whose output depends on total bar count) are
   correctly flagged, not rubber-stamped.
2. **`check_window_robustness`** - computes PNL concentration across a real
   `WalkForwardResult`'s folds; flags when a single window dominates the
   aggregate result, with an explicit caveat that a concentrated result may
   also simply mean most folds had no qualifying setup.
3. **`check_parameter_sensitivity`** - runs a caller-supplied baseline config
   plus caller-supplied variant configs (this module never guesses which
   thresholds "should" be perturbed) and reports the relative PNL change;
   `None` (never a fabricated 0 or infinity) whenever the baseline had zero
   closed-trade PNL, since no relative comparison is meaningful there.
4. **`check_structural_robustness`** - runs caller-supplied stress-test bars
   (never fabricated here) through the unmodified replay engine and reports,
   per case, whether it completed (blocked by data quality, or produced N
   trades) or raised - a genuine exception is recorded with its type and
   message, never silently discarded, and one case's crash does not stop the
   remaining cases from being tried and reported independently.

**Tests added:** 12 tests in `test_phase8_adversarial_validation.py`, each
proving the relevant function both stays quiet on a clean case AND correctly
fires on an engineered/adversarial case (a leak-injecting fake replay function,
a single dominant fold, a config change that makes the real Risk gate reject a
previously winning trade - baseline PNL > 0, variant closed trades = 0,
relative change = 1.0 - and an injected crash) - never merely "always returns clean."

---

## 9. Tests Added This Phase

| File | Tests |
|---|---|
| `test_phase8_resampling.py` (Priority 1 additions) | 9 |
| `test_phase8_warmup.py` (Priority 2) | 22 |
| `test_phase8_exception_handling.py` (Priority 3) | 7 |
| `test_phase8_multi_horizon_replay.py` | 21 |
| `test_phase8_walk_forward_runner.py` | 18 |
| `test_phase8_adversarial_validation.py` | 12 |
| **Total new Phase 8 tests** | **89** (plus 14 pre-existing `test_phase8_resampling.py` tests carried forward = 103 total Phase 8 tests) |

## 10. Exact Test Counts (final, this session)

```
Targeted (all Phase 8 test files combined):        103/103 PASS
  - test_phase8_resampling.py:                      23/23
  - test_phase8_warmup.py:                          22/22
  - test_phase8_exception_handling.py:               7/7
  - test_phase8_multi_horizon_replay.py:            21/21
  - test_phase8_walk_forward_runner.py:             18/18
  - test_phase8_adversarial_validation.py:          12/12
Module (Phase 7, untouched):                        96/96 PASS
FULL REGRESSION (entire suite):                    591/591 PASS
```
Zero regressions introduced at any point in Phase 8.

---

## 11. Phase 7 Regression Status

**Untouched and healthy.** No Phase 7 file (`replay_engine.py` or any other
Phase 1-7 module) was modified at any point in this phase. 96/96 Phase 7 tests
pass, unchanged, at every checkpoint throughout Phase 8.

---

## 12. Determinism Status

Verified, not assumed, at every layer added or touched this phase:
- `resample_bars()`: identical output regardless of input bar ordering (sorted
  internally before bucketing).
- `run_multi_horizon_replay()`: identical `trades` (including `trade_id`,
  `decision_id`, `candidate_id`, ordering) across repeated runs with identical
  input, including under three simultaneously conflicting horizons.
- `run_walk_forward()`: identical `WalkForwardResult` (fold boundaries, each
  fold's trades, `period_splits`, aggregate metrics) across repeated runs.
- All identifiers are content-derived SHA-256 hashes (`candidate_id`,
  `decision_id`, `trade_id`, `dataset_hash`) - no random UUID or wall-clock
  value is ever embedded in an identifier.
- Trade/candidate ordering follows a real, explainable data path (dict
  insertion order through `decide()`'s trace, itself driven by the fixed
  Scalp -> Intraday -> Short-Swing collection order) - never Python
  set/dict-hash-order or timing.

---

## 13. Look-Ahead Protection

Proven at four independent levels, not merely asserted:
1. `resample_bars()` never emits an incomplete/still-forming target candle
   (Priority 1 tests).
2. Within a single replay, the `MultiTimeframeMarketContext`/quant objects
   built and passed into a horizon engine at step `idx` are byte-identical
   whether or not bars beyond `idx` exist in the array
   (`test_phase8_multi_horizon_replay.py`).
3. Within a walk-forward run, each fold is given a bars slice that physically
   excludes every bar beyond its own `test_end_index` - a structural
   guarantee, not a windowing-logic guarantee alone
   (`test_phase8_walk_forward_runner.py`).
4. `check_look_ahead_leakage()` packages guarantee (2) as a reusable utility
   callable against any dataset/config the user supplies going forward.

---

## 14. Data Quality Behavior

Unchanged principle from Phase 7, verified again at the multi-horizon level:
`validate_historical_dataset()` is a blocking gate evaluated once, before any
horizon engine is ever invoked; a blocking issue (duplicate timestamp,
out-of-order data, impossible OHLC, missing required field) yields an explicit
`BacktestResult` with `trades=()` and `data_quality.is_valid=False`. Phase 8
tests exercise this with a real duplicate-timestamp dataset and prove
`detect_scalp_candidate` is never called (the other blocking types -
out-of-order, impossible OHLC, missing required field - share the same
`is_valid` early-return code path and are covered by Phase 7's own data-quality
tests, but were not re-tested individually at the multi-horizon level here). No
partial/fallback processing of an invalid dataset occurs.

---

## 15. Failure Handling

No new `except Exception: return` (or equivalent silent-swallow pattern) was
introduced anywhere in Phase 8. The one intentionally broad exception catch in
the entire phase is `check_structural_robustness()`'s stress-test harness,
whose explicit purpose is to catch and REPORT a crash (exception type, message,
and which stress case triggered it) rather than let one bad case abort testing
the rest - every case's outcome, crash or not, is individually recorded in the
returned result, never discarded.

---

## 16. Real Limitations Remaining (honestly reported, not hidden)

- **Test-quality defect found and fixed during final review (recorded for
  audit):** several mocked orchestration tests originally keyed their
  `detect_scalp_candidate` stub on `base_mctx.calculated_at`, which is
  wall-clock `datetime.now()` inside `build_market_context`, so the stub never
  matched and those tests passed vacuously (walk-forward fold independence,
  walk-forward aggregate, multi-horizon no-overlap, parameter sensitivity).
  They now key on the window's last bar (`base_mctx.bars[-1].close_time`) and
  each asserts that candidates genuinely fired (e.g. 3 real FINAL_EXIT trades
  in the no-overlap test; baseline PNL > 0 in the sensitivity test). Two
  further off-by-one signal indices and a never-exiting trade in those tests
  were corrected the same way. No production code changed as a result.
- **Observation, not changed:** `calculated_at` fields on contexts and
  candidates carry wall-clock time. Deterministic IDs (`trade_id`,
  `decision_id`, `candidate_id`) are verified stable across repeated runs, but
  the raw `calculated_at` timestamps themselves are not byte-reproducible. Any
  future audit-log comparison should exclude them or derive them from bar time.

- **No parameter-fitting exists**, so "overfitting" in the classical sense is
  structurally inapplicable to this codebase; Section 8 documents exactly what
  was checked instead and why.
- **`check_parameter_sensitivity` and `check_structural_robustness` require the
  caller to supply variant configs / stress-test bars** - this utility
  deliberately does not guess which configuration thresholds matter most or
  what a "realistic" stress scenario looks like for any given market; doing so
  would itself be a form of fabricated evidence.
- **`check_window_robustness`'s concentration ratio can be misleading in
  isolation** if most folds legitimately produced zero trades (a correct
  NO_TRADE outcome) - the result's `limitations` field says this explicitly,
  and per-fold trade counts are always returned alongside it.
- **Performance/runtime**: a full-length replay across thousands of bars with
  all three horizons enabled was not exhaustively timed at production data
  volumes in this environment (a 3-step probe with Short-Swing's ~3,935-bar
  window completed in ~0.14s; a 300-step scalp+intraday run completed in
  ~3s) - real-world large-dataset runtime characteristics for Walk-Forward with
  many folds should be measured against actual production data volumes before
  relying on wall-clock expectations.
- **Cross-horizon conflict testing covers the scenarios exercised in this
  phase's test suite** (two- and three-way direction conflicts with the
  evidence levels used in those tests); the underlying `decision/conflict.py`
  contract is Phase 6 code and was not itself modified or newly tested beyond
  what these Phase 8 tests exercised through it.

---

## 17. Deliberately Deferred to Phase 9

- Any live/real-time data ingestion, execution, or broker/exchange integration
  (explicitly out of Phase 8 scope per the original directive).
- A 24/7 autonomous market scanner.
- Any parameter-optimization or model-fitting capability (which would be the
  first point at which "overfitting" in the classical sense becomes a real,
  checkable risk for this codebase - `check_parameter_sensitivity` above is a
  deliberately honest placeholder for that future need, not a substitute for it).
- Extending Walk-Forward/Adversarial validation to run at real production data
  volumes and report empirical runtime/scaling characteristics.
- Any new provider/API integrations or production-observability tooling.

---

## 18. Final Status

**Phase 8: COMPLETE.**

- Resampling integrity: complete, adversarial-tested (23 tests).
- Warmup/lookback architecture: complete, deterministic, per-horizon,
  proven both sufficient and tight (22 tests).
- Silent exception handling: eliminated at every site found; fail-closed
  error semantics locked in with tests (7 tests).
- Multi-Horizon Replay: complete across all ten required orchestration
  properties (21 tests).
- Real Walk-Forward Runner: complete, deterministic, leakage-safe by
  construction, fold-independent (18 tests).
- Adversarial/Overfitting Validation utility: complete within the honest
  bounds of a non-fitted, rule-based architecture; every limitation
  explicitly reported rather than papered over (12 tests).
- Full regression: 591/591 PASS. Phase 7: 96/96 PASS, untouched.
- No known critical/high-severity issue remains open and unrecorded; Section
  16 above is the complete, honest list of real remaining limitations.
