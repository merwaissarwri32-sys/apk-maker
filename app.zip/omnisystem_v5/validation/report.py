"""
Validation Reporting Layer - MERWIS AI, Phase 7.

The report is a structured dataclass FIRST (machine/UI/API consumable
via to_dict()) and a markdown renderer SECOND (to_markdown(), for human
review) - never text-only. Every section is built strictly from data
already present on BacktestResult/PerformanceMetrics; nothing here
computes anything new or invents a verdict.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.validation.contracts import BacktestResult, ExecutionConfig
from omnisystem_v5.validation.performance import PerformanceMetrics


@dataclass(frozen=True)
class SignalStatistics:
    total_signals: int = 0
    final_exit_count: int = 0
    expired_count: int = 0
    invalidated_count: int = 0
    rejected_by_risk_count: int = 0
    cancelled_count: int = 0
    candidate_to_trade_conversion_rate: object = None


@dataclass(frozen=True)
class RiskStatistics:
    max_risk_per_trade_pct_policy: float = 0.0
    min_reward_risk_ratio_policy: float = 0.0
    average_realized_risk_pct: object = None
    average_realized_rr: object = None


@dataclass(frozen=True)
class FailureModeEntry:
    detail: str
    count: int


@dataclass(frozen=True)
class ValidationReport:
    generated_at: datetime

    determinism_confirmed: bool
    pipeline_description: str

    data_quality_is_valid: bool
    data_quality_issue_count: int
    data_quality_warmup_sufficient: bool

    execution_assumptions: ExecutionConfig

    signal_statistics: SignalStatistics

    performance: PerformanceMetrics

    risk_statistics: RiskStatistics

    regime_analysis: dict

    failure_modes: tuple

    limitations: tuple

    reproducibility_run_id: str
    reproducibility_dataset_hash: str
    reproducibility_config_summary: dict

    def __post_init__(self):
        if self.generated_at.tzinfo is None:
            raise ValueError("generated_at must be timezone-aware (UTC)")

    def to_dict(self) -> dict:
        return asdict(self)


_KNOWN_LIMITATIONS = (
    "Sequential single-position replay only (max_concurrent_positions=1); overlapping positions are not simulated.",
    "Scalp horizon only in this phase; Intraday and Short-Swing replay use the identical bridge pattern but are not yet wired into the replay loop.",
    "No real historical bid/ask data is available - spread/slippage are explicit configurable assumptions, not measured facts.",
    "Intrabar SL/TP ambiguity is resolved conservatively (stop-loss assumed to trigger first) - this may understate performance versus a favorable-fill assumption, never overstate it.",
    "Sharpe/Sortino are computed on a per-trade return series (pnl / risk_amount), not a calendar-time return series - they describe risk-adjusted return per trade, not an annualized figure.",
    "Walk-Forward and Monte Carlo are foundation/contracts only in this phase - no optimization or randomized robustness testing is implemented yet.",
)


def build_validation_report(result, metrics, execution_config, risk_policy_summary, determinism_confirmed=True):
    trades = result.trades

    def _count(state_value):
        return sum(1 for t in trades if t.state.value == state_value)

    final_exit = _count("FINAL_EXIT")
    total_signals = len(trades)

    signal_stats = SignalStatistics(
        total_signals=total_signals,
        final_exit_count=final_exit,
        expired_count=_count("EXPIRED"),
        invalidated_count=_count("INVALIDATED"),
        rejected_by_risk_count=_count("REJECTED_BY_RISK"),
        cancelled_count=_count("CANCELLED"),
        candidate_to_trade_conversion_rate=(final_exit / total_signals) if total_signals else None,
    )

    closed = [t for t in trades if t.pnl is not None]
    avg_risk_pct = None
    avg_rr = None
    if closed:
        r_values = [t.r_multiple for t in closed if t.r_multiple is not None]
        avg_rr = sum(r_values) / len(r_values) if r_values else None

    risk_stats = RiskStatistics(
        max_risk_per_trade_pct_policy=risk_policy_summary.get("max_risk_per_trade_pct", 0.0),
        min_reward_risk_ratio_policy=risk_policy_summary.get("min_reward_risk_ratio", 0.0),
        average_realized_risk_pct=avg_risk_pct,
        average_realized_rr=avg_rr,
    )

    failure_details = {}
    for t in trades:
        if t.rejection_detail:
            failure_details[t.rejection_detail] = failure_details.get(t.rejection_detail, 0) + 1
    failure_modes = tuple(FailureModeEntry(detail=d, count=c) for d, c in sorted(failure_details.items(), key=lambda x: -x[1]))

    pipeline_description = (
        "Context -> Quant -> Intelligence (Bull/Bear + ScalpEngine) -> Decision (Master Decision Engine) "
        "-> Risk Engine (hard gate) -> Execution Simulation. The exact Phase 2-6 production functions were "
        "called at every replay step; no parallel/approximate decision algorithm was used."
    )

    return ValidationReport(
        generated_at=datetime.now(timezone.utc),
        determinism_confirmed=determinism_confirmed,
        pipeline_description=pipeline_description,
        data_quality_is_valid=result.data_quality.is_valid,
        data_quality_issue_count=len(result.data_quality.issues),
        data_quality_warmup_sufficient=result.data_quality.warmup_sufficient,
        execution_assumptions=execution_config,
        signal_statistics=signal_stats,
        performance=metrics,
        risk_statistics=risk_stats,
        regime_analysis=metrics.regime_breakdown.groups,
        failure_modes=failure_modes,
        limitations=_KNOWN_LIMITATIONS,
        reproducibility_run_id=result.reproducibility.run_id if result.reproducibility else "",
        reproducibility_dataset_hash=result.dataset.dataset_hash,
        reproducibility_config_summary=result.reproducibility.replay_config_summary if result.reproducibility else {},
    )


def render_markdown(report):
    lines = []
    lines.append("# MERWIS AI - Validation Report")
    lines.append(f"\nGenerated: {report.generated_at.isoformat()}\n")

    lines.append("## A. System Validation")
    lines.append(f"- Determinism confirmed: {report.determinism_confirmed}")
    lines.append(f"- Pipeline: {report.pipeline_description}\n")

    lines.append("## B. Data Quality")
    lines.append(f"- Valid: {report.data_quality_is_valid}")
    lines.append(f"- Issue count: {report.data_quality_issue_count}")
    lines.append(f"- Warmup sufficient: {report.data_quality_warmup_sufficient}\n")

    lines.append("## C. Execution Assumptions")
    ec = report.execution_assumptions
    lines.append(f"- Spread: {ec.spread_pct}% | Slippage: {ec.slippage_model.value}={ec.slippage_value} | Fee/side: {ec.fee_pct_per_side}%")
    lines.append(f"- Entry timeout: {ec.entry_timeout_bars} bars | Fill assumption: {ec.intrabar_fill_assumption}\n")

    lines.append("## D. Signal Statistics")
    s = report.signal_statistics
    lines.append(f"- Total signals: {s.total_signals} | FINAL_EXIT: {s.final_exit_count} | EXPIRED: {s.expired_count}")
    lines.append(f"- INVALIDATED: {s.invalidated_count} | REJECTED_BY_RISK: {s.rejected_by_risk_count}")
    lines.append(f"- Conversion rate: {s.candidate_to_trade_conversion_rate}\n")

    lines.append("## E. Trading Performance")
    p = report.performance
    lines.append(f"- Closed trades: {p.closed_trades} | Win rate: {p.win_rate} | Expectancy: {p.expectancy}")
    lines.append(f"- Net P&L: {p.net_pnl} | Profit factor: {p.profit_factor}")
    lines.append(f"- Max drawdown: {p.drawdown.max_drawdown_pct}% over {p.drawdown.max_drawdown_duration_trades} trades")
    lines.append(f"- Sharpe: {p.sharpe_ratio} | Sortino: {p.sortino_ratio}")
    if p.sample_size_warning:
        lines.append("- WARNING: sample size is below the statistical-significance threshold - treat all ratios as indicative only.\n")
    else:
        lines.append("")

    lines.append("## F. Risk Statistics")
    r = report.risk_statistics
    lines.append(f"- Policy max risk/trade: {r.max_risk_per_trade_pct_policy}% | Policy min R:R: {r.min_reward_risk_ratio_policy}")
    lines.append(f"- Average realized R: {r.average_realized_rr}\n")

    lines.append("## G. Regime Analysis")
    for label, g in report.regime_analysis.items():
        lines.append(f"- {label}: count={g['count']}, win_rate={g['win_rate']}, net_pnl={g['net_pnl']}")
    lines.append("")

    lines.append("## H. Failure Modes")
    for fm in report.failure_modes:
        lines.append(f"- ({fm.count}x) {fm.detail}")
    lines.append("")

    lines.append("## I. Limitations")
    for lim in report.limitations:
        lines.append(f"- {lim}")
    lines.append("")

    lines.append("## J. Reproducibility")
    lines.append(f"- Run ID: {report.reproducibility_run_id}")
    lines.append(f"- Dataset hash: {report.reproducibility_dataset_hash}")
    lines.append(f"- Config summary: {report.reproducibility_config_summary}")

    return "\n".join(lines)
