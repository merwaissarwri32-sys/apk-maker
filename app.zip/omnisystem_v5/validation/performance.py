"""
Performance Analytics - MERWIS AI, Phase 7.

Every metric here is computed purely from the tuple of closed TradeRecord
objects passed in - no hidden state, no wall-clock reads, no randomness.
Metrics that are mathematically undefined for the given sample (e.g.
Sharpe ratio with zero variance, profit factor with zero losses) are
reported as None with a reason, never as a fabricated number (0.0, inf,
or otherwise). Metrics computed from a small sample are flagged via
sample_size_warning rather than presented with false confidence.
"""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field


@dataclass(frozen=True)
class EquityCurvePoint:
    trade_index: int
    timestamp: object
    equity: float


@dataclass(frozen=True)
class DrawdownInfo:
    max_drawdown_abs: object = None
    max_drawdown_pct: object = None
    max_drawdown_duration_trades: object = None
    recovery_factor: object = None
    reasons: tuple = field(default_factory=tuple)


@dataclass(frozen=True)
class RMultipleStats:
    average_r: object = None
    stdev_r: object = None
    best_r: object = None
    worst_r: object = None
    sample_count: int = 0


@dataclass(frozen=True)
class DirectionalBreakdown:
    long_count: int = 0
    long_win_rate: object = None
    long_net_pnl: object = None
    short_count: int = 0
    short_win_rate: object = None
    short_net_pnl: object = None


@dataclass(frozen=True)
class GroupBreakdown:
    group_field: str
    groups: dict = field(default_factory=dict)


@dataclass(frozen=True)
class PerformanceMetrics:
    total_trades: int = 0
    closed_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    breakeven_trades: int = 0

    win_rate: object = None
    loss_rate: object = None

    average_win: object = None
    average_loss: object = None
    expectancy: object = None

    total_pnl: object = None
    net_pnl: object = None

    profit_factor: object = None
    r_multiple_stats: RMultipleStats = field(default_factory=RMultipleStats)

    equity_curve: tuple = field(default_factory=tuple)
    drawdown: DrawdownInfo = field(default_factory=DrawdownInfo)

    sharpe_ratio: object = None
    sortino_ratio: object = None
    downside_deviation: object = None

    average_trade_duration_bars: object = None
    best_trade_pnl: object = None
    worst_trade_pnl: object = None
    max_consecutive_wins: int = 0
    max_consecutive_losses: int = 0

    directional_breakdown: DirectionalBreakdown = field(default_factory=DirectionalBreakdown)
    regime_breakdown: GroupBreakdown = field(default_factory=lambda: GroupBreakdown(group_field="market_regime"))

    sample_size_warning: bool = True
    reasons: tuple = field(default_factory=tuple)


_MIN_SAMPLE_FOR_STATS = 20


def _closed_with_pnl(trades):
    return [t for t in trades if t.pnl is not None]


def _compute_equity_curve(closed_trades, initial_capital):
    curve = [EquityCurvePoint(trade_index=-1, timestamp=None, equity=initial_capital)]
    equity = initial_capital
    for i, t in enumerate(closed_trades):
        equity += t.pnl
        curve.append(EquityCurvePoint(trade_index=i, timestamp=t.signal_time, equity=equity))
    return tuple(curve)


def _compute_drawdown(equity_curve):
    if len(equity_curve) < 2:
        return DrawdownInfo(reasons=("insufficient equity curve points to compute drawdown",))

    peak = equity_curve[0].equity
    max_dd_abs = 0.0
    max_dd_pct = 0.0
    max_dd_duration = 0
    current_peak_index = 0

    for i, point in enumerate(equity_curve):
        if point.equity > peak:
            peak = point.equity
            current_peak_index = i
        dd_abs = peak - point.equity
        dd_pct = (dd_abs / peak * 100.0) if peak > 0 else 0.0
        if dd_abs > max_dd_abs:
            max_dd_abs = dd_abs
            max_dd_pct = dd_pct
            max_dd_duration = i - current_peak_index

    recovery_factor = None
    net_gain = equity_curve[-1].equity - equity_curve[0].equity
    if max_dd_abs > 0:
        recovery_factor = net_gain / max_dd_abs

    return DrawdownInfo(
        max_drawdown_abs=max_dd_abs, max_drawdown_pct=max_dd_pct,
        max_drawdown_duration_trades=max_dd_duration, recovery_factor=recovery_factor,
    )


def _compute_r_multiple_stats(closed_trades):
    r_values = [t.r_multiple for t in closed_trades if t.r_multiple is not None]
    if not r_values:
        return RMultipleStats(sample_count=0)
    stdev = statistics.stdev(r_values) if len(r_values) >= 2 else None
    return RMultipleStats(
        average_r=statistics.mean(r_values), stdev_r=stdev,
        best_r=max(r_values), worst_r=min(r_values), sample_count=len(r_values),
    )


def _compute_consecutive(closed_trades):
    max_wins = max_losses = cur_wins = cur_losses = 0
    for t in closed_trades:
        if t.pnl > 0:
            cur_wins += 1
            cur_losses = 0
        elif t.pnl < 0:
            cur_losses += 1
            cur_wins = 0
        else:
            cur_wins = cur_losses = 0
        max_wins = max(max_wins, cur_wins)
        max_losses = max(max_losses, cur_losses)
    return max_wins, max_losses


def _compute_sharpe_sortino(closed_trades):
    returns = [t.pnl / t.risk_amount for t in closed_trades if t.pnl is not None and t.risk_amount]
    if len(returns) < 2:
        return None, None, None, ("fewer than 2 trades with both pnl and risk_amount - Sharpe/Sortino undefined",)

    mean_r = statistics.mean(returns)
    stdev_r = statistics.stdev(returns)
    sharpe = (mean_r / stdev_r) if stdev_r > 0 else None

    downside = [r for r in returns if r < 0]
    downside_dev = math.sqrt(sum(r ** 2 for r in downside) / len(returns)) if downside else 0.0
    sortino = (mean_r / downside_dev) if downside_dev > 0 else None

    reasons = []
    if stdev_r == 0:
        reasons.append("zero variance in per-trade returns - Sharpe undefined")
    if downside_dev == 0:
        reasons.append("no losing trades - Sortino undefined (not the same as infinitely good)")

    return sharpe, sortino, downside_dev, tuple(reasons)


def _directional_breakdown(closed_trades):
    longs = [t for t in closed_trades if t.direction == "LONG"]
    shorts = [t for t in closed_trades if t.direction == "SHORT"]

    def _wr(group):
        wins = sum(1 for t in group if t.pnl > 0)
        return (wins / len(group)) if group else None

    def _net(group):
        return sum(t.pnl for t in group) if group else None

    return DirectionalBreakdown(
        long_count=len(longs), long_win_rate=_wr(longs), long_net_pnl=_net(longs),
        short_count=len(shorts), short_win_rate=_wr(shorts), short_net_pnl=_net(shorts),
    )


def _group_breakdown(closed_trades, field_name):
    groups = {}
    for t in closed_trades:
        label = getattr(t, field_name, "") or "UNLABELED"
        bucket = groups.setdefault(label, {"count": 0, "wins": 0, "net_pnl": 0.0})
        bucket["count"] += 1
        bucket["net_pnl"] += t.pnl
        if t.pnl > 0:
            bucket["wins"] += 1

    result = {}
    for label, b in groups.items():
        result[label] = {
            "count": b["count"],
            "win_rate": (b["wins"] / b["count"]) if b["count"] else None,
            "net_pnl": b["net_pnl"],
        }
    return GroupBreakdown(group_field=field_name, groups=result)


def calculate_performance_metrics(trades, initial_capital, min_sample_for_stats=_MIN_SAMPLE_FOR_STATS):
    reasons = []
    closed = _closed_with_pnl(trades)

    if not closed:
        return PerformanceMetrics(
            total_trades=len(trades), closed_trades=0,
            equity_curve=(EquityCurvePoint(trade_index=-1, timestamp=None, equity=initial_capital),),
            reasons=("no closed trades with a computed pnl - all metrics below are undefined, not zero",),
        )

    wins = [t for t in closed if t.pnl > 0]
    losses = [t for t in closed if t.pnl < 0]
    breakeven = [t for t in closed if t.pnl == 0]

    total_pnl = sum(t.pnl for t in closed)
    net_pnl = total_pnl

    win_rate = len(wins) / len(closed)
    loss_rate = len(losses) / len(closed)
    average_win = statistics.mean([t.pnl for t in wins]) if wins else None
    average_loss = statistics.mean([t.pnl for t in losses]) if losses else None

    expectancy = None
    if average_win is not None or average_loss is not None:
        expectancy = (win_rate * (average_win or 0.0)) + (loss_rate * (average_loss or 0.0))

    gross_profit = sum(t.pnl for t in wins) if wins else 0.0
    gross_loss = abs(sum(t.pnl for t in losses)) if losses else 0.0
    profit_factor = None
    if gross_loss > 0:
        profit_factor = gross_profit / gross_loss
    elif gross_profit > 0:
        reasons.append("profit_factor undefined: no losing trades to divide by (not the same as infinite)")

    equity_curve = _compute_equity_curve(closed, initial_capital)
    drawdown = _compute_drawdown(equity_curve)
    r_stats = _compute_r_multiple_stats(closed)
    max_wins, max_losses = _compute_consecutive(closed)
    sharpe, sortino, downside_dev, sr_reasons = _compute_sharpe_sortino(closed)
    reasons.extend(sr_reasons)

    durations = [t.duration_bars for t in closed if t.duration_bars is not None]
    avg_duration = statistics.mean(durations) if durations else None

    sample_warning = len(closed) < min_sample_for_stats
    if sample_warning:
        reasons.append(f"only {len(closed)} closed trades - below the {min_sample_for_stats}-trade threshold for statistically meaningful metrics")

    return PerformanceMetrics(
        total_trades=len(trades), closed_trades=len(closed),
        winning_trades=len(wins), losing_trades=len(losses), breakeven_trades=len(breakeven),
        win_rate=win_rate, loss_rate=loss_rate,
        average_win=average_win, average_loss=average_loss, expectancy=expectancy,
        total_pnl=total_pnl, net_pnl=net_pnl, profit_factor=profit_factor,
        r_multiple_stats=r_stats, equity_curve=equity_curve, drawdown=drawdown,
        sharpe_ratio=sharpe, sortino_ratio=sortino, downside_deviation=downside_dev,
        average_trade_duration_bars=avg_duration,
        best_trade_pnl=max(t.pnl for t in closed), worst_trade_pnl=min(t.pnl for t in closed),
        max_consecutive_wins=max_wins, max_consecutive_losses=max_losses,
        directional_breakdown=_directional_breakdown(closed),
        regime_breakdown=_group_breakdown(closed, "market_regime"),
        sample_size_warning=sample_warning, reasons=tuple(reasons),
    )
