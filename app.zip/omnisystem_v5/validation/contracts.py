"""
Validation Layer contracts - MERWIS AI, Phase 7.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.decision.policy import DecisionPolicy
from omnisystem_v5.context.builder import MarketContextConfig
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig
from omnisystem_v5.quant.engine import QuantEngineConfig
from omnisystem_v5.risk.contracts import RiskPolicy
from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.validation.enums import (
    DataQualityIssueType,
    ExitReason,
    SlippageModel,
    TradeLifecycleState,
    ValidationPeriodType,
)


def _require_tz(value, name):
    if value.tzinfo is None:
        raise ValueError(f"{name} must be timezone-aware (UTC)")


@dataclass(frozen=True)
class ExecutionConfig:
    spread_pct: float = 0.0
    slippage_model: SlippageModel = SlippageModel.NONE
    slippage_value: float = 0.0
    fee_pct_per_side: float = 0.0
    entry_timeout_bars: int = 20
    intrabar_fill_assumption: str = "conservative_worst_case"
    max_concurrent_positions: int = 1


@dataclass(frozen=True)
class ReplayConfig:
    symbol: str
    timeframe: Timeframe
    initial_capital: float
    max_lookback_bars: int = 200
    min_bars_required: int = 60
    start_index: int = 0
    end_index: int = None
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    risk_policy: RiskPolicy = field(default_factory=RiskPolicy)
    decision_policy: DecisionPolicy = field(default_factory=DecisionPolicy)
    market_context_config: MarketContextConfig = field(default_factory=MarketContextConfig)
    quant_engine_config: QuantEngineConfig = field(default_factory=QuantEngineConfig)
    scalp_engine_config: ScalpEngineConfig = field(default_factory=ScalpEngineConfig)
    random_seed: int = None


@dataclass(frozen=True)
class PeriodSplit:
    period_type: ValidationPeriodType
    start_index: int
    end_index: int


@dataclass(frozen=True)
class HistoricalDatasetDescriptor:
    symbol: str
    timeframe: Timeframe
    bar_count: int
    start_timestamp: datetime
    end_timestamp: datetime
    source_description: str
    dataset_hash: str

    def __post_init__(self):
        _require_tz(self.start_timestamp, "start_timestamp")
        _require_tz(self.end_timestamp, "end_timestamp")

    @staticmethod
    def compute_hash(bars):
        h = hashlib.sha256()
        for b in bars:
            h.update(f"{b.open_time.isoformat()}|{b.open}|{b.high}|{b.low}|{b.close}|{b.volume}\n".encode("utf-8"))
        return h.hexdigest()[:16]


@dataclass(frozen=True)
class DataQualityIssue:
    issue_type: DataQualityIssueType
    index: object
    timestamp: object
    detail: str


@dataclass(frozen=True)
class DataQualityReport:
    issues: tuple = field(default_factory=tuple)
    is_valid: bool = True
    warmup_sufficient: bool = True

    def blocking_issue_types(self):
        return {DataQualityIssueType.DUPLICATE_TIMESTAMP, DataQualityIssueType.OUT_OF_ORDER,
                DataQualityIssueType.IMPOSSIBLE_OHLC, DataQualityIssueType.MISSING_REQUIRED_FIELD}


@dataclass(frozen=True)
class SimulatedFill:
    price: float
    timestamp: datetime
    fee_amount: float
    slippage_amount: float

    def __post_init__(self):
        _require_tz(self.timestamp, "timestamp")


@dataclass(frozen=True)
class TradeRecord:
    trade_id: str
    symbol: str
    direction: str
    signal_time: datetime
    state: TradeLifecycleState

    entry_zone_bottom: float
    entry_zone_top: float
    stop_loss: float
    take_profits: tuple

    entry_fill: object = None
    exit_fill: object = None
    exit_reason: object = None

    quantity: object = None
    risk_amount: object = None
    pnl: object = None
    r_multiple: object = None
    mae: object = None
    mfe: object = None
    duration_bars: object = None

    decision_id: str = ""
    candidate_id: str = ""
    market_regime: str = ""
    rejection_detail: str = ""
    # Added in Phase 8 (additive, backward-compatible - default preserves
    # all existing Phase 7 construction/equality behavior): which
    # Intelligence Engine and horizon produced this trade, enabling
    # per-horizon performance breakdown (Scalp vs Intraday vs Short-Swing)
    # in the reporting layer without any change to Phase 7's own
    # single-horizon replay_engine.py.
    horizon: str = ""
    source_engine: str = ""

    def __post_init__(self):
        _require_tz(self.signal_time, "signal_time")

    @property
    def is_closed(self):
        return self.state in (TradeLifecycleState.FINAL_EXIT, TradeLifecycleState.INVALIDATED,
                               TradeLifecycleState.EXPIRED, TradeLifecycleState.REJECTED_BY_RISK,
                               TradeLifecycleState.CANCELLED)

    @property
    def is_win(self):
        if self.pnl is None:
            return None
        return self.pnl > 0


@dataclass(frozen=True)
class ReproducibilityRecord:
    run_id: str
    dataset: HistoricalDatasetDescriptor
    replay_config_summary: dict
    software_note: str = "MERWIS AI Phase 7 validation engine v1.0"
    random_seed: object = None


@dataclass(frozen=True)
class BacktestResult:
    dataset: HistoricalDatasetDescriptor
    data_quality: DataQualityReport
    trades: tuple = field(default_factory=tuple)
    reproducibility: object = None
    period_splits: tuple = field(default_factory=tuple)
