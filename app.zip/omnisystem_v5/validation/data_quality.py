"""
Historical dataset data-quality validation - MERWIS AI, Phase 7.

Invalid datasets must not silently produce "successful" backtests -
every check here either flags a blocking issue (is_valid=False, which
the replay engine refuses to run against) or a non-blocking warning
(recorded but replay proceeds).
"""

from __future__ import annotations

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.validation.contracts import DataQualityIssue, DataQualityReport
from omnisystem_v5.validation.enums import DataQualityIssueType

_TIMEFRAME_SECONDS = {
    Timeframe.M1: 60, Timeframe.M5: 300, Timeframe.M15: 900,
    Timeframe.H1: 3600, Timeframe.H4: 14400, Timeframe.D1: 86400,
}


def validate_historical_dataset(bars, timeframe, min_bars_required=60, gap_tolerance_multiple=3.0):
    issues = []

    if len(bars) < min_bars_required:
        issues.append(DataQualityIssue(
            DataQualityIssueType.INSUFFICIENT_WARMUP, None, None,
            f"dataset has {len(bars)} bars, {min_bars_required} required for warm-up",
        ))

    expected_step = _TIMEFRAME_SECONDS.get(timeframe)
    seen_timestamps = set()

    for i, bar in enumerate(bars):
        if bar.open_time is None or bar.close_time is None:
            issues.append(DataQualityIssue(DataQualityIssueType.MISSING_REQUIRED_FIELD, i, None,
                                            f"bar at index {i} missing open_time/close_time"))
            continue

        if bar.open_time in seen_timestamps:
            issues.append(DataQualityIssue(DataQualityIssueType.DUPLICATE_TIMESTAMP, i, bar.open_time,
                                            f"duplicate open_time at index {i}: {bar.open_time.isoformat()}"))
        seen_timestamps.add(bar.open_time)

        if bar.high < bar.low or bar.high < bar.open or bar.high < bar.close or bar.low > bar.open or bar.low > bar.close:
            issues.append(DataQualityIssue(DataQualityIssueType.IMPOSSIBLE_OHLC, i, bar.open_time,
                                            f"impossible OHLC relationship at index {i}"))

        if i > 0:
            prev = bars[i - 1]
            if prev.open_time is not None:
                if bar.open_time < prev.open_time:
                    issues.append(DataQualityIssue(DataQualityIssueType.OUT_OF_ORDER, i, bar.open_time,
                                                    f"bar at index {i} precedes previous bar chronologically"))
                elif expected_step:
                    gap = (bar.open_time - prev.open_time).total_seconds()
                    if gap > expected_step * gap_tolerance_multiple:
                        issues.append(DataQualityIssue(DataQualityIssueType.ABNORMAL_GAP, i, bar.open_time,
                                                        f"gap of {gap:.0f}s at index {i}, expected ~{expected_step:.0f}s"))
                    elif gap > expected_step * 1.5:
                        issues.append(DataQualityIssue(DataQualityIssueType.MISSING_CANDLE, i, bar.open_time,
                                                        f"likely missing candle(s) before index {i} (gap {gap:.0f}s)"))

    blocking_types = DataQualityReport().blocking_issue_types()
    is_valid = not any(iss.issue_type in blocking_types for iss in issues)
    warmup_sufficient = not any(iss.issue_type == DataQualityIssueType.INSUFFICIENT_WARMUP for iss in issues)

    return DataQualityReport(issues=tuple(issues), is_valid=is_valid, warmup_sufficient=warmup_sufficient)
