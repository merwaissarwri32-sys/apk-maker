"""
Per-horizon warmup / lookback requirement calculation - MERWIS AI,
Phase 8, Priority 2.

PROBLEM THIS SOLVES
--------------------
Multi-Horizon Replay slides one window `bars[lo:idx+1]` of the BASE
timeframe and, for Intraday/Short-Swing, resamples that same window
into each horizon's execution/higher timeframe via resample_bars().
A single fixed `max_lookback_bars` shared by all horizons is wrong:
a window sized for Scalp is nowhere near big enough to ever produce a
complete D1 context for Short-Swing, so that horizon silently starves
forever regardless of how much history is actually available.

This module computes - explicitly, deterministically, and from the
project's OWN real dependency chain (never a hand-picked constant) -
exactly how many BASE-timeframe bars each enabled horizon needs before
its execution/higher-timeframe contexts can possibly reach OK status.
The replay/data layer (multi_horizon_replay.py) is responsible for
actually supplying a window that large; this module only calculates
the requirement.

DEPENDENCY CHAIN (read directly off the real engines, not assumed)
--------------------------------------------------------------------
1. build_market_context() rejects a timeframe's bar series outright if
   len(bars) < MarketContextConfig.min_bars_required.
2. build_quant_context() then ALSO rejects that same series if
   len(bars) < QuantEngineConfig.min_bars_required.
   Both operate on the *same* bar list (quant does not re-slice), so
   the real bottleneck for "how many closed candles of timeframe TF do
   I need" is max(market_context.min_bars_required,
   quant_engine.min_bars_required) - not either number alone.
3. Intraday/Short-Swing each need this many closed candles at BOTH
   their execution_timeframe and higher_timeframe (intelligence/
   intraday_engine.py and short_swing_engine.py reject immediately if
   either context/quant status isn't OK - no additional bar minimum of
   their own beyond that).
4. Turning N closed TF candles out of a BASE-timeframe window via
   resample_bars()'s calendar-boundary bucketing takes `ratio * N`
   base bars only if the window happens to start exactly on a TF
   calendar boundary. Since the replay's sliding window can start
   anywhere, up to `ratio - 1` leading base bars can be wasted on a
   partial first bucket - so the real worst-case guarantee is
   `ratio * N + (ratio - 1)`.
"""

from __future__ import annotations

from omnisystem_v5.validation.resampling import seconds_for_timeframe


def required_base_bars_for_timeframe(base_timeframe, target_timeframe, target_bar_count):
    """Worst-case number of base_timeframe bars needed to guarantee at
    least `target_bar_count` CLOSED target_timeframe candles out of
    resample_bars(), regardless of where the sliding window happens to
    start relative to target_timeframe's calendar boundaries.
    Deterministic and independent of any specific dataset."""
    if target_bar_count <= 0:
        return 0
    if target_timeframe == base_timeframe:
        return target_bar_count
    base_sec = seconds_for_timeframe(base_timeframe)
    target_sec = seconds_for_timeframe(target_timeframe)
    ratio = target_sec // base_sec
    return ratio * target_bar_count + (ratio - 1)


def context_bar_requirement(market_context_config, quant_engine_config) -> int:
    """The number of CLOSED candles of a single timeframe that must be
    present before build_market_context() AND build_quant_context()
    can both return an OK status - read directly from those two
    engines' own configured minimums."""
    return max(market_context_config.min_bars_required, quant_engine_config.min_bars_required)


def scalp_warmup_requirement(base_timeframe, market_context_config, quant_engine_config) -> int:
    """Scalp operates directly on the base timeframe - no resampling."""
    n = context_bar_requirement(market_context_config, quant_engine_config)
    return required_base_bars_for_timeframe(base_timeframe, base_timeframe, n)


def intraday_warmup_requirement(base_timeframe, intraday_engine_config, market_context_config, quant_engine_config) -> int:
    n = context_bar_requirement(market_context_config, quant_engine_config)
    exec_req = required_base_bars_for_timeframe(base_timeframe, intraday_engine_config.execution_timeframe, n)
    higher_req = required_base_bars_for_timeframe(base_timeframe, intraday_engine_config.higher_timeframe, n)
    return max(exec_req, higher_req)


def short_swing_warmup_requirement(base_timeframe, short_swing_engine_config, market_context_config, quant_engine_config) -> int:
    n = context_bar_requirement(market_context_config, quant_engine_config)
    exec_req = required_base_bars_for_timeframe(base_timeframe, short_swing_engine_config.execution_timeframe, n)
    higher_req = required_base_bars_for_timeframe(base_timeframe, short_swing_engine_config.higher_timeframe, n)
    return max(exec_req, higher_req)


def compute_required_lookback_bars(
    base_timeframe,
    enable_scalp,
    enable_intraday,
    enable_short_swing,
    market_context_config,
    quant_engine_config,
    intraday_engine_config,
    short_swing_engine_config,
    floor_bars,
) -> int:
    """The single deterministic answer to: how many base_timeframe bars
    must the sliding window contain so that every ENABLED horizon has a
    genuine, non-fabricated chance at a complete context? This is what
    the replay/data-acquisition layer must supply; it is never invented,
    padded, or shrunk to make a test or a run pass.

    `floor_bars` is the replay's own baseline minimum (e.g. its
    min_bars_required for the base timeframe / data-quality gate) and
    is always respected as a lower bound even if no horizon is enabled
    (config validation elsewhere already guarantees at least one is).
    """
    requirements = [floor_bars]
    if enable_scalp:
        requirements.append(scalp_warmup_requirement(base_timeframe, market_context_config, quant_engine_config))
    if enable_intraday:
        requirements.append(intraday_warmup_requirement(base_timeframe, intraday_engine_config, market_context_config, quant_engine_config))
    if enable_short_swing:
        requirements.append(short_swing_warmup_requirement(base_timeframe, short_swing_engine_config, market_context_config, quant_engine_config))
    return max(requirements)
