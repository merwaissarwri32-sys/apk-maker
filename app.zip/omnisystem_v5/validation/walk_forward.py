"""
Walk-Forward Validation FOUNDATION - MERWIS AI, Phase 7.

EXPLICITLY NOT A FULL IMPLEMENTATION. This module provides only:
  1. A deterministic, leakage-free period-splitting utility
     (split_walk_forward_periods) that partitions a bar range into
     TRAINING / VALIDATION / OUT_OF_SAMPLE index windows.
  2. An abstract WalkForwardEngine interface documenting the contract a
     future optimization/selection loop must satisfy.

No parameter optimization, no walk-forward re-fitting loop, and no
"best window" selection logic exists here - building that is future
work. Calling split_walk_forward_periods only produces INDEX
boundaries; it never looks at, scores, or reorders the underlying bar
data, so there is no way for it to introduce leakage on its own - the
leakage guarantee comes entirely from the boundaries being
non-overlapping and strictly chronological, enforced below.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from omnisystem_v5.validation.contracts import PeriodSplit
from omnisystem_v5.validation.enums import ValidationPeriodType


@dataclass(frozen=True)
class WalkForwardConfig:
    training_fraction: float = 0.6
    validation_fraction: float = 0.2
    out_of_sample_fraction: float = 0.2

    def __post_init__(self):
        total = self.training_fraction + self.validation_fraction + self.out_of_sample_fraction
        if abs(total - 1.0) > 1e-9:
            raise ValueError(f"fractions must sum to 1.0, got {total}")
        if min(self.training_fraction, self.validation_fraction, self.out_of_sample_fraction) < 0:
            raise ValueError("fractions must be non-negative")


def split_walk_forward_periods(bar_count, config=None):
    config = config or WalkForwardConfig()
    if bar_count < 3:
        raise ValueError(f"bar_count={bar_count} is too small to split into three periods")

    train_end = int(bar_count * config.training_fraction)
    validation_end = int(bar_count * (config.training_fraction + config.validation_fraction))

    train_end = max(1, train_end)
    validation_end = max(train_end + 1, validation_end)
    validation_end = min(validation_end, bar_count - 1)

    if train_end >= validation_end or validation_end >= bar_count:
        raise ValueError(
            f"bar_count={bar_count} with fractions {config.training_fraction}/"
            f"{config.validation_fraction}/{config.out_of_sample_fraction} produces a degenerate split"
        )

    splits = (
        PeriodSplit(period_type=ValidationPeriodType.TRAINING, start_index=0, end_index=train_end - 1),
        PeriodSplit(period_type=ValidationPeriodType.VALIDATION, start_index=train_end, end_index=validation_end - 1),
        PeriodSplit(period_type=ValidationPeriodType.OUT_OF_SAMPLE, start_index=validation_end, end_index=bar_count - 1),
    )

    _assert_no_overlap_and_chronological(splits)
    return splits


def _assert_no_overlap_and_chronological(splits):
    for i in range(len(splits) - 1):
        current, nxt = splits[i], splits[i + 1]
        if current.end_index >= nxt.start_index:
            raise ValueError(
                f"period split leakage detected: {current.period_type.value} ends at "
                f"{current.end_index} but {nxt.period_type.value} starts at {nxt.start_index}"
            )
        if current.start_index > current.end_index:
            raise ValueError(f"period {current.period_type.value} has start_index > end_index")


class WalkForwardEngine(ABC):
    """Interface a future real Walk-Forward implementation must satisfy.
    NOT implemented in Phase 7 - documented here so the eventual
    implementation has a stable contract to target."""

    @abstractmethod
    def run_training_window(self, bars, period, config):
        raise NotImplementedError("Walk-Forward training loop is a future-phase deliverable, not implemented in Phase 7")

    @abstractmethod
    def run_validation_window(self, bars, period, trained_state, config):
        raise NotImplementedError("Walk-Forward validation loop is a future-phase deliverable, not implemented in Phase 7")

    @abstractmethod
    def run_out_of_sample_window(self, bars, period, trained_state, config):
        raise NotImplementedError("Walk-Forward out-of-sample evaluation is a future-phase deliverable, not implemented in Phase 7")
