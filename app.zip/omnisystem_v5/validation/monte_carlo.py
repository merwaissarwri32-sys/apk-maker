"""
Monte Carlo / Robustness FOUNDATION - MERWIS AI, Phase 7.

EXPLICITLY NOT A FULL IMPLEMENTATION. No trade-order randomization,
bootstrap resampling, or stress simulation is actually performed here.
This module provides only:
  1. MonteCarloConfig - a config contract with a mandatory, explicit
     random_seed (never an unseeded/hidden RNG).
  2. make_seeded_rng() - the ONE approved way to obtain randomness
     anywhere in this codebase's future Monte Carlo work, so every
     simulation is reproducible from its config alone.
  3. An abstract MonteCarloSampler interface documenting what a future
     real sampler must implement.
  4. MonteCarloResult - an empty-by-construction result contract; no
     code path in Phase 7 populates it with actual simulated outcomes.
"""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum


class MonteCarloMethod(str, Enum):
    TRADE_ORDER_SHUFFLE = "TRADE_ORDER_SHUFFLE"
    BOOTSTRAP_RESAMPLE = "BOOTSTRAP_RESAMPLE"
    SLIPPAGE_STRESS = "SLIPPAGE_STRESS"
    FEE_STRESS = "FEE_STRESS"
    PARAMETER_SENSITIVITY = "PARAMETER_SENSITIVITY"
    DRAWDOWN_STRESS = "DRAWDOWN_STRESS"


@dataclass(frozen=True)
class MonteCarloConfig:
    method: MonteCarloMethod
    num_simulations: int
    random_seed: int

    def __post_init__(self):
        if self.num_simulations <= 0:
            raise ValueError("num_simulations must be positive")
        if not isinstance(self.random_seed, int):
            raise ValueError("random_seed must be an explicit int - unseeded Monte Carlo is not permitted")


def make_seeded_rng(seed):
    return random.Random(seed)


@dataclass(frozen=True)
class MonteCarloResult:
    config: MonteCarloConfig
    implemented: bool = False
    simulated_outcomes: tuple = field(default_factory=tuple)
    notes: tuple = ("Monte Carlo simulation is a foundation/contract only in Phase 7 - no simulations were run.",)


class MonteCarloSampler(ABC):
    @abstractmethod
    def generate_samples(self, trades, config):
        raise NotImplementedError("Monte Carlo sampling is a future-phase deliverable, not implemented in Phase 7")

    @abstractmethod
    def summarize(self, samples, config):
        raise NotImplementedError("Monte Carlo summarization is a future-phase deliverable, not implemented in Phase 7")
