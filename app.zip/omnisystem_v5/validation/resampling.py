"""
Deterministic bar resampling - MERWIS AI, Phase 8.

Aggregates a lower-timeframe bar series into a higher-timeframe series
using calendar-boundary bucketing (not a fixed bar-count ratio), so the
result is correct even when the input series has gaps. This is a pure,
deterministic transformation of REAL data - never fabrication.

CRITICAL LOOK-AHEAD RULE: a target-timeframe bucket is only emitted
once it contains the FULL expected number of source bars. An
in-progress (not-yet-closed) higher-timeframe candle is never emitted,
since presenting it as if it were closed would let a caller reason
about a candle that has not actually finished forming - the exact
shape of look-ahead bias this project treats as a hard requirement to
prevent everywhere else (see replay_engine.py's window slicing).
"""

from __future__ import annotations

from omnisystem_v5.schemas.enums import Timeframe
from omnisystem_v5.schemas.market_data import OHLCVBar

_TF_SECONDS = {
    Timeframe.M1: 60, Timeframe.M5: 300, Timeframe.M15: 900,
    Timeframe.H1: 3600, Timeframe.H4: 14400, Timeframe.D1: 86400,
}


class ResamplingError(ValueError):
    pass


def seconds_for_timeframe(timeframe):
    """Public accessor for a timeframe's duration in seconds - used by
    validation/warmup.py to compute per-horizon data requirements
    without duplicating this table."""
    if timeframe not in _TF_SECONDS:
        raise ResamplingError(f"unsupported timeframe: {timeframe}")
    return _TF_SECONDS[timeframe]


def resample_bars(bars, source_timeframe, target_timeframe):
    if source_timeframe not in _TF_SECONDS or target_timeframe not in _TF_SECONDS:
        raise ResamplingError(f"unsupported timeframe(s): {source_timeframe}, {target_timeframe}")

    source_sec = _TF_SECONDS[source_timeframe]
    target_sec = _TF_SECONDS[target_timeframe]

    if target_sec <= source_sec:
        raise ResamplingError(
            f"target_timeframe {target_timeframe.value} must be strictly larger than "
            f"source_timeframe {source_timeframe.value}"
        )
    if target_sec % source_sec != 0:
        raise ResamplingError(
            f"target_timeframe {target_timeframe.value} is not an exact multiple of "
            f"source_timeframe {source_timeframe.value} - cannot resample cleanly"
        )

    ratio = target_sec // source_sec

    # --- Timestamp integrity pass (Phase 8, Priority 1 hardening) ---
    # A bucket cannot be trusted just because it holds `ratio` bars: two
    # duplicate timestamps plus one genuinely missing interval also
    # produces a bucket of length `ratio`, but is silently wrong data,
    # not a complete candle. So before any bucketing/aggregation we
    # validate the source series itself, independent of input order:
    #   - every source bar must land exactly on the source_timeframe
    #     grid (misaligned/malformed timestamps are corrupt input)
    #   - no two source bars may share the same open_time (ambiguous/
    #     duplicated input - we cannot know which one is real)
    # Both are systemic data-integrity problems, not a per-bucket
    # concern, so they fail the whole call closed (raise) rather than
    # being silently dropped or guessed at.
    sorted_bars = sorted(bars, key=lambda b: b.open_time)
    seen_epochs = set()
    for b in sorted_bars:
        epoch = int(b.open_time.timestamp())
        if epoch % source_sec != 0:
            raise ResamplingError(
                f"source bar open_time {b.open_time.isoformat()} is not aligned to the "
                f"{source_timeframe.value} grid - malformed/corrupt timestamp"
            )
        if epoch in seen_epochs:
            raise ResamplingError(
                f"duplicate source bar timestamp detected: {b.open_time.isoformat()} - "
                f"ambiguous input, cannot resample safely"
            )
        seen_epochs.add(epoch)

    buckets = {}
    for b in sorted_bars:
        epoch = int(b.open_time.timestamp())
        bucket_start = epoch - (epoch % target_sec)
        buckets.setdefault(bucket_start, []).append(b)

    result = []
    for bucket_start in sorted(buckets.keys()):
        group = buckets[bucket_start]  # already time-sorted via sorted_bars
        expected_starts = {bucket_start + k * source_sec for k in range(ratio)}
        actual_starts = {int(g.open_time.timestamp()) for g in group}
        # Reject not just short buckets but buckets whose bars don't
        # correspond exactly to the full, contiguous set of expected
        # source intervals (e.g. a missing-middle bar) - count alone is
        # not proof of completeness.
        if len(group) != ratio or actual_starts != expected_starts:
            continue
        result.append(
            OHLCVBar(
                open=group[0].open,
                high=max(g.high for g in group),
                low=min(g.low for g in group),
                close=group[-1].close,
                volume=sum(g.volume for g in group),
                open_time=group[0].open_time,
                close_time=group[-1].close_time,
            )
        )
    return result


def min_source_bars_for_target(source_timeframe, target_timeframe, target_bar_count):
    source_sec = _TF_SECONDS[source_timeframe]
    target_sec = _TF_SECONDS[target_timeframe]
    ratio = target_sec // source_sec
    return ratio * target_bar_count
