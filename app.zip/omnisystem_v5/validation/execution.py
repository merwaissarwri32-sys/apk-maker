"""
Execution simulation - MERWIS AI, Phase 7.

CRITICAL HONESTY NOTE: no historical bid/ask or intrabar tick sequence
is available to this system. Every assumption below is therefore
EXPLICIT and CONSERVATIVE, never fabricated as if it were real market
microstructure data:

  - Entry fill price: the edge of the entry zone the bar first reaches
    (the WORSE edge for the trader, not a favorable mid-zone fill).
  - Intrabar SL/TP ambiguity (a single bar's range contains both the
    stop and a target): STOP LOSS IS ASSUMED TO HIT FIRST. This is the
    standard conservative convention for backtests without tick data -
    it never overstates performance from an assumption.
  - Spread and slippage always work AGAINST the trader on both entry
    and exit.

These assumptions are recorded on every ExecutionConfig and echoed
verbatim into the validation report (section C) - never silently
applied.
"""

from __future__ import annotations

from omnisystem_v5.risk.enums import Direction
from omnisystem_v5.validation.contracts import ExecutionConfig, SimulatedFill
from omnisystem_v5.validation.enums import ExitReason, SlippageModel


def _slippage_amount(price, config):
    if config.slippage_model == SlippageModel.NONE:
        return 0.0
    if config.slippage_model == SlippageModel.FIXED_PCT:
        return price * (config.slippage_value / 100.0)
    if config.slippage_model == SlippageModel.FIXED_TICKS:
        return config.slippage_value
    return 0.0


def adjusted_entry_price(raw_price, direction, config):
    slip = _slippage_amount(raw_price, config)
    half_spread = raw_price * (config.spread_pct / 100.0) / 2.0
    sign = 1 if direction == Direction.LONG else -1
    adjusted = raw_price + sign * (half_spread + slip)
    return adjusted, slip


def adjusted_exit_price(raw_price, direction, config):
    slip = _slippage_amount(raw_price, config)
    half_spread = raw_price * (config.spread_pct / 100.0) / 2.0
    sign = -1 if direction == Direction.LONG else 1
    adjusted = raw_price + sign * (half_spread + slip)
    return adjusted, slip


def calculate_fee(notional, config):
    return abs(notional) * (config.fee_pct_per_side / 100.0)


def find_entry_fill(bars, entry_bottom, entry_top, direction, config):
    for i, bar in enumerate(bars[: config.entry_timeout_bars]):
        if bar.low <= entry_top and bar.high >= entry_bottom:
            raw_price = entry_top if direction == Direction.LONG else entry_bottom
            adjusted, slip = adjusted_entry_price(raw_price, direction, config)
            fee = calculate_fee(adjusted, config)
            return SimulatedFill(price=adjusted, timestamp=bar.close_time, fee_amount=fee, slippage_amount=slip), i + 1
    return None, min(len(bars), config.entry_timeout_bars)


def simulate_position_lifecycle(bars, direction, entry_price, stop_loss, take_profit, config):
    mae = 0.0
    mfe = 0.0

    for i, bar in enumerate(bars):
        if direction == Direction.LONG:
            adverse_excursion = entry_price - bar.low
            favorable_excursion = bar.high - entry_price
        else:
            adverse_excursion = bar.high - entry_price
            favorable_excursion = entry_price - bar.low
        mae = max(mae, adverse_excursion)
        mfe = max(mfe, favorable_excursion)

        hit_sl = (bar.low <= stop_loss) if direction == Direction.LONG else (bar.high >= stop_loss)
        hit_tp = (bar.high >= take_profit) if direction == Direction.LONG else (bar.low <= take_profit)

        if hit_sl:
            adjusted, slip = adjusted_exit_price(stop_loss, direction, config)
            fee = calculate_fee(adjusted, config)
            return {
                "exit_fill": SimulatedFill(price=adjusted, timestamp=bar.close_time, fee_amount=fee, slippage_amount=slip),
                "exit_reason": ExitReason.STOP_LOSS, "mae": mae, "mfe": mfe, "duration_bars": i + 1,
            }
        if hit_tp:
            adjusted, slip = adjusted_exit_price(take_profit, direction, config)
            fee = calculate_fee(adjusted, config)
            return {
                "exit_fill": SimulatedFill(price=adjusted, timestamp=bar.close_time, fee_amount=fee, slippage_amount=slip),
                "exit_reason": ExitReason.TAKE_PROFIT, "mae": mae, "mfe": mfe, "duration_bars": i + 1,
            }

    return {"exit_fill": None, "exit_reason": None, "mae": mae, "mfe": mfe, "duration_bars": len(bars)}
