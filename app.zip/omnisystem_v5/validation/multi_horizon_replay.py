"""
Multi-Horizon Historical Replay Engine - MERWIS AI, Phase 8.

Extends Phase 7's single-horizon (Scalp-only) replay to run Scalp,
Intraday, and Short-Swing side by side at every replay step, feeding
ALL horizons' candidates into the SAME Master Decision Engine call
(decide()) so Phase 6's conflict-resolution/ranking/quality-gate
machinery arbitrates across horizons exactly as it would live - no
separate "pick a horizon" logic was invented for this phase.

Look-ahead discipline is identical to Phase 7, extended to resampling:
Intraday's higher timeframe (default 1H) and Short-Swing's execution/
higher timeframes (default 4H/1D) are built by resample_bars() on the
SAME bars[lo:idx+1] window already used for the base timeframe - never
on any bar beyond idx. resample_bars() itself never emits an
incomplete (still-forming) higher-timeframe candle, so even the
resampled series cannot leak a partially-formed future candle.

Execution/fill simulation always uses the BASE (lowest) timeframe's
future bars for every horizon's winning candidate, regardless of which
horizon produced it - this is more precise than simulating fills on a
coarser timeframe and requires no per-horizon special-casing in
execution.py (unchanged from Phase 7).

This module does NOT implement a second/parallel decision algorithm -
it calls detect_scalp_candidate, detect_intraday_candidate,
detect_short_swing_candidate, and decide() exactly as Phase 4/6 expose
them. The Risk Engine's hard gate (inside decide()) is never bypassed.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone

from omnisystem_v5.context.builder import MarketContextConfig, build_market_context
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.context.schema import MultiTimeframeMarketContext
from omnisystem_v5.decision.engine import decide
from omnisystem_v5.decision.enums import CandidateStatus, DecisionOutcome
from omnisystem_v5.decision.policy import DecisionPolicy
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.decision_bridge import (
    from_intraday_candidate,
    from_scalp_candidate,
    from_short_swing_candidate,
)
from omnisystem_v5.intelligence.intraday_engine import IntradayEngineConfig, detect_intraday_candidate
from omnisystem_v5.intelligence.scalp_engine import ScalpEngineConfig, detect_scalp_candidate
from omnisystem_v5.intelligence.short_swing_engine import ShortSwingEngineConfig, detect_short_swing_candidate
from omnisystem_v5.quant.engine import QuantEngineConfig, build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.risk.contracts import AccountState, RiskPolicy
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope
from omnisystem_v5.validation.contracts import (
    BacktestResult,
    ExecutionConfig,
    HistoricalDatasetDescriptor,
    ReproducibilityRecord,
    SimulatedFill,
    TradeRecord,
)
from omnisystem_v5.validation.data_quality import validate_historical_dataset
from omnisystem_v5.validation.enums import ExitReason, TradeLifecycleState
from omnisystem_v5.validation.execution import calculate_fee, find_entry_fill, simulate_position_lifecycle
from omnisystem_v5.validation.resampling import ResamplingError, resample_bars
from omnisystem_v5.validation.warmup import compute_required_lookback_bars


@dataclass(frozen=True)
class MultiHorizonReplayConfig:
    symbol: str
    base_timeframe: Timeframe
    initial_capital: float
    # None (default) means: auto-compute the smallest lookback window
    # that is genuinely sufficient for every ENABLED horizon, from the
    # real dependency chain in validation/warmup.py - never a shared
    # fixed guess. If the caller pins an explicit value instead, it is
    # validated against that same requirement and rejected (fail
    # closed) if it would starve an enabled horizon.
    max_lookback_bars: int | None = None
    min_bars_required: int = 60
    start_index: int = 0
    end_index: int = None
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    risk_policy: RiskPolicy = field(default_factory=RiskPolicy)
    decision_policy: DecisionPolicy = field(default_factory=DecisionPolicy)
    market_context_config: MarketContextConfig = field(default_factory=MarketContextConfig)
    quant_engine_config: QuantEngineConfig = field(default_factory=QuantEngineConfig)
    scalp_engine_config: ScalpEngineConfig = field(default_factory=ScalpEngineConfig)
    intraday_engine_config: IntradayEngineConfig = field(default_factory=IntradayEngineConfig)
    short_swing_engine_config: ShortSwingEngineConfig = field(default_factory=ShortSwingEngineConfig)
    enable_scalp: bool = True
    enable_intraday: bool = True
    enable_short_swing: bool = True
    random_seed: int = None

    def __post_init__(self):
        if not (self.enable_scalp or self.enable_intraday or self.enable_short_swing):
            raise ValueError("at least one horizon must be enabled")

        required = compute_required_lookback_bars(
            self.base_timeframe, self.enable_scalp, self.enable_intraday, self.enable_short_swing,
            self.market_context_config, self.quant_engine_config,
            self.intraday_engine_config, self.short_swing_engine_config,
            floor_bars=self.min_bars_required,
        )
        if self.max_lookback_bars is None:
            # frozen dataclass - object.__setattr__ is the documented
            # way to set a computed default in __post_init__.
            object.__setattr__(self, "max_lookback_bars", required)
        elif self.max_lookback_bars < required:
            enabled = [n for n, e in (("scalp", self.enable_scalp), ("intraday", self.enable_intraday),
                                       ("short_swing", self.enable_short_swing)) if e]
            raise ValueError(
                f"max_lookback_bars={self.max_lookback_bars} is not enough base-timeframe "
                f"({self.base_timeframe.value}) bars for the enabled horizon(s) {enabled}: "
                f"at least {required} bars are required (see validation/warmup.py for the "
                f"per-horizon calculation) or a higher-timeframe context for one of them can "
                f"never reach OK status, no matter how much history is actually available. "
                f"Pass max_lookback_bars={required} or higher, or disable the horizon(s) that "
                f"need more history."
            )


def _make_trade_id(symbol, direction_value, signal_time, entry_bottom, entry_top, stop_loss, take_profits, source_engine):
    raw = f"{symbol}|{source_engine}|{direction_value}|{signal_time.isoformat()}|{entry_bottom}|{entry_top}|{stop_loss}|{take_profits}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _build_envelope(symbol, timeframe, window, fetched_at):
    provenance = DataProvenance(
        source="multi_horizon_replay", origin=DataOrigin.HISTORICAL,
        fetched_at=fetched_at, data_timestamp=window[-1].close_time,
    )
    return MarketDataEnvelope(
        market=symbol, timeframe=timeframe, provenance=provenance,
        quality_status=QualityStatus.OK, bars=tuple(window),
    )


def _context_for(symbol, timeframe, bars_series, mcc, fetched_at, min_bars_required):
    if len(bars_series) < min_bars_required:
        return None, None
    envelope = _build_envelope(symbol, timeframe, bars_series, fetched_at)
    mctx = build_market_context(symbol, envelope, mcc)
    if mctx.status != ContextStatus.OK:
        return mctx, None
    return mctx, None


def _collect_scalp(symbol, base_mctx, base_qctx, config, candidates_pool):
    if base_mctx is None or base_mctx.status != ContextStatus.OK or base_qctx is None or base_qctx.status != QuantStatus.OK:
        return
    bull = build_bull_case(symbol, base_mctx, base_qctx)
    bear = build_bear_case(symbol, base_mctx, base_qctx)
    result = detect_scalp_candidate(symbol, base_mctx, base_qctx, bull, bear, config.scalp_engine_config)
    if result.status.value == "ZONE_IDENTIFIED":
        raw = result.candidates[0]
        candidates_pool.append((raw, from_scalp_candidate(raw)))


def _collect_intraday(symbol, config, window, base_timeframe, base_mctx, base_qctx, now_for_run, candidates_pool):
    itf = config.intraday_engine_config
    try:
        if itf.execution_timeframe == base_timeframe:
            exec_mctx, exec_qctx = base_mctx, base_qctx
        else:
            exec_series = resample_bars(window, base_timeframe, itf.execution_timeframe)
            exec_mctx, _ = _context_for(symbol, itf.execution_timeframe, exec_series, config.market_context_config, now_for_run, config.market_context_config.min_bars_required)
            exec_qctx = build_quant_context(symbol, exec_mctx, config.quant_engine_config) if exec_mctx and exec_mctx.status == ContextStatus.OK else None

        higher_series = resample_bars(window, base_timeframe, itf.higher_timeframe)
    except ResamplingError:
        # Expected, named, auditable data-integrity condition (corrupt/
        # misaligned/duplicate source data for THIS window) - treated as
        # "no candidate this step", never as a crash. Any other
        # exception type is a genuine internal error and is deliberately
        # NOT caught here: it must propagate and fail loudly rather than
        # being silently reinterpreted as "no candidate" (Priority 3).
        return

    higher_mctx, _ = _context_for(symbol, itf.higher_timeframe, higher_series, config.market_context_config, now_for_run, config.market_context_config.min_bars_required)
    if higher_mctx is None or higher_mctx.status != ContextStatus.OK:
        return
    higher_qctx = build_quant_context(symbol, higher_mctx, config.quant_engine_config)
    if higher_qctx.status != QuantStatus.OK:
        return
    if exec_mctx is None or exec_mctx.status != ContextStatus.OK or exec_qctx is None or exec_qctx.status != QuantStatus.OK:
        return

    calculated_at = window[-1].close_time
    mtf = MultiTimeframeMarketContext(symbol=symbol, calculated_at=calculated_at,
                                       contexts={itf.execution_timeframe: exec_mctx, itf.higher_timeframe: higher_mctx})
    quant_by_tf = {itf.execution_timeframe: exec_qctx, itf.higher_timeframe: higher_qctx}
    result = detect_intraday_candidate(symbol, mtf, quant_by_tf, itf)
    if result.status.value == "ZONE_IDENTIFIED":
        raw = result.candidates[0]
        candidates_pool.append((raw, from_intraday_candidate(raw)))


def _collect_short_swing(symbol, config, window, base_timeframe, now_for_run, candidates_pool):
    ssf = config.short_swing_engine_config
    try:
        exec_series = resample_bars(window, base_timeframe, ssf.execution_timeframe)
        higher_series = resample_bars(window, base_timeframe, ssf.higher_timeframe)
    except ResamplingError:
        # Same rationale as _collect_intraday above: only the named,
        # expected data-integrity condition is caught here.
        return

    exec_mctx, _ = _context_for(symbol, ssf.execution_timeframe, exec_series, config.market_context_config, now_for_run, config.market_context_config.min_bars_required)
    higher_mctx, _ = _context_for(symbol, ssf.higher_timeframe, higher_series, config.market_context_config, now_for_run, config.market_context_config.min_bars_required)
    if exec_mctx is None or exec_mctx.status != ContextStatus.OK or higher_mctx is None or higher_mctx.status != ContextStatus.OK:
        return
    exec_qctx = build_quant_context(symbol, exec_mctx, config.quant_engine_config)
    higher_qctx = build_quant_context(symbol, higher_mctx, config.quant_engine_config)
    if exec_qctx.status != QuantStatus.OK or higher_qctx.status != QuantStatus.OK:
        return

    calculated_at = window[-1].close_time
    mtf = MultiTimeframeMarketContext(symbol=symbol, calculated_at=calculated_at,
                                       contexts={ssf.execution_timeframe: exec_mctx, ssf.higher_timeframe: higher_mctx})
    quant_by_tf = {ssf.execution_timeframe: exec_qctx, ssf.higher_timeframe: higher_qctx}
    result = detect_short_swing_candidate(symbol, mtf, quant_by_tf, ssf)
    if result.status.value == "ZONE_IDENTIFIED":
        raw = result.candidates[0]
        candidates_pool.append((raw, from_short_swing_candidate(raw)))


def run_multi_horizon_replay(bars, config: MultiHorizonReplayConfig, run_id=None) -> BacktestResult:
    if config.execution.max_concurrent_positions != 1:
        raise ValueError(
            "the replay engine only supports max_concurrent_positions=1 "
            "(sequential, non-overlapping trades) across ALL horizons combined"
        )

    dq_report = validate_historical_dataset(bars, config.base_timeframe, config.min_bars_required)
    dataset = HistoricalDatasetDescriptor(
        symbol=config.symbol, timeframe=config.base_timeframe, bar_count=len(bars),
        start_timestamp=bars[0].open_time if bars else datetime.now(timezone.utc),
        end_timestamp=bars[-1].close_time if bars else datetime.now(timezone.utc),
        source_description="caller-provided historical OHLCV bars (multi-horizon)",
        dataset_hash=HistoricalDatasetDescriptor.compute_hash(bars) if bars else "empty",
    )
    if not dq_report.is_valid:
        return BacktestResult(dataset=dataset, data_quality=dq_report, trades=(),
                               reproducibility=_build_repro(run_id, dataset, config))

    end_index = config.end_index if config.end_index is not None else len(bars) - 1
    idx = max(config.start_index, config.min_bars_required - 1)

    trades = []
    current_equity = config.initial_capital
    now_for_run = datetime.now(timezone.utc)

    while idx <= end_index:
        lo = max(0, idx - config.max_lookback_bars + 1)
        window = bars[lo: idx + 1]
        signal_time = window[-1].close_time

        base_mctx = base_qctx = None
        if config.enable_scalp or (config.enable_intraday and config.intraday_engine_config.execution_timeframe == config.base_timeframe):
            base_mctx, _ = _context_for(config.symbol, config.base_timeframe, window, config.market_context_config, now_for_run, config.min_bars_required)
            if base_mctx is not None and base_mctx.status == ContextStatus.OK:
                base_qctx = build_quant_context(config.symbol, base_mctx, config.quant_engine_config)

        candidates_pool = []

        if config.enable_scalp:
            _collect_scalp(config.symbol, base_mctx, base_qctx, config, candidates_pool)
        if config.enable_intraday:
            _collect_intraday(config.symbol, config, window, config.base_timeframe, base_mctx, base_qctx, now_for_run, candidates_pool)
        if config.enable_short_swing:
            _collect_short_swing(config.symbol, config, window, config.base_timeframe, now_for_run, candidates_pool)

        if not candidates_pool:
            idx += 1
            continue

        raw_by_id = {n.candidate_id: r for (r, n) in candidates_pool}
        norm_by_id = {n.candidate_id: n for (_, n) in candidates_pool}
        normalized_list = list(norm_by_id.values())

        account = AccountState(equity=current_equity)
        final_decision = decide(normalized_list, account, config.risk_policy, config.decision_policy, now=signal_time)

        winner_id = final_decision.selected_candidate.candidate_id if final_decision.outcome != DecisionOutcome.NO_TRADE else None

        for rec in final_decision.candidate_trace:
            if rec.candidate_id == winner_id or rec.candidate_id not in raw_by_id:
                continue
            raw = raw_by_id[rec.candidate_id]
            norm = norm_by_id[rec.candidate_id]
            state = TradeLifecycleState.REJECTED_BY_RISK if rec.status == CandidateStatus.REJECTED_RISK else TradeLifecycleState.INVALIDATED
            trades.append(TradeRecord(
                trade_id=_make_trade_id(config.symbol, norm.direction.value, signal_time,
                                         raw.preferred_entry_zone.bottom, raw.preferred_entry_zone.top,
                                         norm.stop_loss, norm.take_profits, norm.source_engine),
                symbol=config.symbol, direction=norm.direction.value, signal_time=signal_time, state=state,
                entry_zone_bottom=raw.preferred_entry_zone.bottom, entry_zone_top=raw.preferred_entry_zone.top,
                stop_loss=norm.stop_loss, take_profits=norm.take_profits,
                decision_id=final_decision.decision_id, candidate_id=norm.candidate_id,
                market_regime=raw.market_regime.value, rejection_detail=", ".join(rec.reasons),
                horizon=norm.horizon, source_engine=norm.source_engine,
            ))

        if final_decision.outcome == DecisionOutcome.NO_TRADE:
            idx += 1
            continue

        winner_norm = final_decision.selected_candidate
        winner_raw = raw_by_id[winner_norm.candidate_id]
        risk_result = final_decision.risk_result
        future_bars = bars[idx + 1:]

        entry_fill, bars_consumed = find_entry_fill(
            future_bars, winner_raw.preferred_entry_zone.bottom, winner_raw.preferred_entry_zone.top,
            winner_norm.direction, config.execution,
        )

        if entry_fill is None:
            trades.append(TradeRecord(
                trade_id=_make_trade_id(config.symbol, winner_norm.direction.value, signal_time,
                                         winner_raw.preferred_entry_zone.bottom, winner_raw.preferred_entry_zone.top,
                                         winner_norm.stop_loss, winner_norm.take_profits, winner_norm.source_engine),
                symbol=config.symbol, direction=winner_norm.direction.value, signal_time=signal_time,
                state=TradeLifecycleState.EXPIRED, exit_reason=ExitReason.ENTRY_NEVER_FILLED,
                entry_zone_bottom=winner_raw.preferred_entry_zone.bottom, entry_zone_top=winner_raw.preferred_entry_zone.top,
                stop_loss=winner_norm.stop_loss, take_profits=winner_norm.take_profits,
                decision_id=final_decision.decision_id, candidate_id=winner_norm.candidate_id,
                market_regime=winner_raw.market_regime.value,
                horizon=winner_norm.horizon, source_engine=winner_norm.source_engine,
            ))
            idx = idx + 1 + bars_consumed
            continue

        quantity = risk_result.position_size
        stop_loss = winner_norm.stop_loss
        take_profit = winner_norm.take_profits[0]
        remaining_bars = bars[idx + 1 + bars_consumed:]
        lifecycle = simulate_position_lifecycle(remaining_bars, winner_norm.direction, entry_fill.price,
                                                 stop_loss, take_profit, config.execution)

        if lifecycle["exit_fill"] is not None:
            exit_fill = lifecycle["exit_fill"]
            advance = 1 + bars_consumed + lifecycle["duration_bars"]
        else:
            last_bar = bars[-1]
            exit_fill = SimulatedFill(price=last_bar.close, timestamp=last_bar.close_time,
                                       fee_amount=calculate_fee(last_bar.close, config.execution), slippage_amount=0.0)
            lifecycle = dict(lifecycle)
            lifecycle["exit_reason"] = ExitReason.END_OF_REPLAY_WINDOW
            advance = end_index - idx + 1

        sign = 1 if winner_norm.direction.value == "LONG" else -1
        gross_pnl = (exit_fill.price - entry_fill.price) * sign * quantity
        total_fees = (entry_fill.fee_amount + exit_fill.fee_amount) * quantity
        net_pnl = gross_pnl - total_fees
        risk_amount = risk_result.risk_amount
        r_multiple = (net_pnl / risk_amount) if risk_amount else None
        current_equity += net_pnl

        trades.append(TradeRecord(
            trade_id=_make_trade_id(config.symbol, winner_norm.direction.value, signal_time,
                                     winner_raw.preferred_entry_zone.bottom, winner_raw.preferred_entry_zone.top,
                                     stop_loss, winner_norm.take_profits, winner_norm.source_engine),
            symbol=config.symbol, direction=winner_norm.direction.value, signal_time=signal_time,
            state=TradeLifecycleState.FINAL_EXIT, entry_fill=entry_fill, exit_fill=exit_fill,
            exit_reason=lifecycle["exit_reason"],
            entry_zone_bottom=winner_raw.preferred_entry_zone.bottom, entry_zone_top=winner_raw.preferred_entry_zone.top,
            stop_loss=stop_loss, take_profits=winner_norm.take_profits,
            quantity=quantity, risk_amount=risk_amount, pnl=net_pnl, r_multiple=r_multiple,
            mae=lifecycle["mae"], mfe=lifecycle["mfe"], duration_bars=lifecycle["duration_bars"],
            decision_id=final_decision.decision_id, candidate_id=winner_norm.candidate_id,
            market_regime=winner_raw.market_regime.value,
            horizon=winner_norm.horizon, source_engine=winner_norm.source_engine,
        ))
        idx += advance

    return BacktestResult(dataset=dataset, data_quality=dq_report, trades=tuple(trades),
                           reproducibility=_build_repro(run_id, dataset, config))


def _build_repro(run_id, dataset, config: MultiHorizonReplayConfig):
    rid = run_id or hashlib.sha256(
        f"{dataset.dataset_hash}|{config.symbol}|{config.base_timeframe.value}|{config.initial_capital}|multi_horizon".encode("utf-8")
    ).hexdigest()[:16]
    summary = {
        "symbol": config.symbol, "base_timeframe": config.base_timeframe.value,
        "initial_capital": str(config.initial_capital), "max_lookback_bars": str(config.max_lookback_bars),
        "min_bars_required": str(config.min_bars_required),
        "enable_scalp": str(config.enable_scalp), "enable_intraday": str(config.enable_intraday),
        "enable_short_swing": str(config.enable_short_swing),
        "min_reward_risk_ratio": str(config.risk_policy.min_reward_risk_ratio),
        "decision_policy_version": config.decision_policy.policy_version,
    }
    return ReproducibilityRecord(run_id=rid, dataset=dataset, replay_config_summary=summary, random_seed=config.random_seed)
