"""
Adversarial / Overfitting Validation Utility - MERWIS AI, Phase 8.

HONESTY NOTE (read before using anything in this module): MERWIS's
Scalp/Intraday/Short-Swing engines are rule-based against explicit,
human-set thresholds - there is no parameter-fitting step anywhere in
this codebase (see validation/walk_forward_runner.py's own docstring
for the identical point). "Overfitting" in the classic
train-a-model-until-it-memorizes-the-data sense cannot literally occur
here, because nothing is ever fit to data. Claiming to detect that
would be exactly the fabricated-validation failure mode Phase 8 is
required to avoid.

What genuinely CAN be checked, and is what this module actually
implements, nothing more:

  1. Look-ahead / future-data leakage - a real, structural, provable
     property of the code (does changing bars beyond a decision point
     change that decision?), not a statistical guess.
  2. Cross-window robustness - does the SAME, unchanged configuration
     produce wildly inconsistent results across different historical
     windows, or does a single window dominate all of the aggregate
     performance? Computed directly from real WalkForwardResult fold
     data (validation/walk_forward_runner.py) - no new replay logic.
  3. Configuration sensitivity - does a small, CALLER-SPECIFIED change
     to a threshold produce a disproportionate change in outcome? A
     knife-edge configuration is a genuine overfitting-adjacent risk
     even in a rule-based system (thresholds tuned to one dataset's
     quirks) - this module never invents which thresholds "should" be
     perturbed; the caller supplies the variant configs.
  4. Structural robustness under adversarial/stress input data - does
     the pipeline fail CLOSED (block via data quality, or return
     NO_TRADE) rather than crash or silently swallow a real error on
     corrupt/gapped/extreme-looking data? The caller supplies the
     stress-test bars; this module never fabricates market data and
     presents it as evidence of real-world performance - checking (4)
     tests CRASH-SAFETY and fail-closed behavior, not profitability.

Every report dataclass below carries a `limitations` tuple of
plain-English strings stating what that specific check does NOT prove.
No function here produces a pass/fail verdict beyond what was actually
computed from real code execution.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

from omnisystem_v5.validation.enums import TradeLifecycleState
from omnisystem_v5.validation.multi_horizon_replay import run_multi_horizon_replay
from omnisystem_v5.validation.walk_forward_runner import fold_is_usable, run_walk_forward

_LEAKAGE_LIMITATIONS = (
    "Checks only the decision-time fields the replay engine itself "
    "computes (direction, entry/SL/TP, decision_id, candidate_id, "
    "market_regime, horizon, source_engine, rejection_detail) for every "
    "trade except the very last one in the compared range, whose "
    "execution-outcome fields (entry_fill, exit_fill, pnl, state, ...) "
    "are legitimately allowed to differ - those depend on real forward "
    "price data past end_index by design, not on a leak into decision-"
    "making. A pass here does not prove there is no leak in code paths "
    "this dataset/config never exercises (e.g. a horizon left disabled). "
    "With the real engines decision_id/candidate_id embed the wall clock and never "
    "match across runs; pass exclude_wall_clock_ids=True there, and treat "
    "vacuous=True (fewer than 2 trades compared) as NOT verified.",
)


# Phase 9: with the REAL engines these two ids are hashes that include the engine's wall-clock
# `calculated_at`, so two runs over identical input never agree on them. Comparing them yields a
# false "leak" on every trade; callers using real engines opt out with exclude_wall_clock_ids=True.
# (Default stays False: Phase 8 behaviour, correct when the candidate clock is pinned, e.g. mocks.)
_WALL_CLOCK_DERIVED_FIELDS = ("candidate_id", "decision_id")


def _decision_time_fields(t, exclude_wall_clock_ids=False):
    return (t.symbol, t.direction, t.signal_time, t.entry_zone_bottom, t.entry_zone_top,
            t.stop_loss, t.take_profits,
            *(() if exclude_wall_clock_ids else (t.decision_id, t.candidate_id)),
            t.market_regime, t.horizon, t.source_engine, t.rejection_detail, t.trade_id)


@dataclass(frozen=True)
class LeakageCheckResult:
    leak_detected: bool
    checked_trade_count: int
    differing_trade_indices: tuple
    limitations: tuple = _LEAKAGE_LIMITATIONS
    # Phase 9 (additive). vacuous=True: fewer than 2 trades existed, so NOTHING was compared and
    # leak_detected=False proves nothing.
    vacuous: bool = False
    excluded_fields: tuple = ()


def check_look_ahead_leakage(bars, config, end_index, extra_future_bars, exclude_wall_clock_ids=False) -> LeakageCheckResult:
    """Runs run_multi_horizon_replay on bars[:end_index+1] and again on
    bars[:end_index+1] + extra_future_bars appended, both with the SAME
    end_index, and compares every decision-time field of every trade
    except the last (see LeakageCheckResult.limitations). Any
    difference in an earlier trade's decision-time fields, or a
    difference in trade COUNT, is unambiguous evidence of a look-ahead
    leak - the replay engine ran with `end_index` fixed, so nothing
    past it should have been reachable at all.
    """
    bars_a = list(bars[: end_index + 1])
    bars_b = bars_a + list(extra_future_bars)
    config_a = replace(config, end_index=end_index)
    config_b = replace(config, end_index=end_index)

    result_a = run_multi_horizon_replay(bars_a, config_a)
    result_b = run_multi_horizon_replay(bars_b, config_b)

    excluded = _WALL_CLOCK_DERIVED_FIELDS if exclude_wall_clock_ids else ()
    trades_a, trades_b = result_a.trades, result_b.trades
    if len(trades_a) != len(trades_b):
        return LeakageCheckResult(leak_detected=True, checked_trade_count=0,
                                   differing_trade_indices=("trade_count_mismatch",), excluded_fields=excluded)

    compare_upto = max(0, len(trades_a) - 1)  # exclude only the final trade
    differing = tuple(
        i for i in range(compare_upto)
        if _decision_time_fields(trades_a[i], exclude_wall_clock_ids)
        != _decision_time_fields(trades_b[i], exclude_wall_clock_ids)
    )
    return LeakageCheckResult(leak_detected=bool(differing), checked_trade_count=compare_upto,
                               differing_trade_indices=differing, vacuous=(compare_upto == 0),
                               excluded_fields=excluded)


_WINDOW_ROBUSTNESS_LIMITATIONS = (
    "Measures dispersion/concentration of PNL and trade activity across "
    "the folds actually produced by the supplied WalkForwardResult only "
    "- it says nothing about market conditions or regimes not present "
    "in that dataset. A concentrated result may also simply mean most "
    "folds legitimately had no qualifying setup (a correct NO_TRADE "
    "outcome, not fragility) - this must be read alongside per-fold "
    "trade counts, not the concentration ratio alone.",
)


@dataclass(frozen=True)
class WindowRobustnessResult:
    fold_count: int
    per_fold_pnl: tuple
    per_fold_trade_count: tuple
    per_fold_win_rate: tuple
    pnl_concentration_ratio: object  # None if total |pnl| across folds is 0 (nothing to concentrate)
    dominated_by_single_window: object  # None if pnl_concentration_ratio is None
    dominance_threshold: float
    limitations: tuple = _WINDOW_ROBUSTNESS_LIMITATIONS
    # Phase 9 (additive): a blocked fold shows pnl 0 above but is NOT a real zero-pnl fold.
    per_fold_valid: tuple = ()
    blocked_fold_count: int = 0


def check_window_robustness(walk_forward_result, dominance_threshold=0.8) -> WindowRobustnessResult:
    per_fold_pnl = []
    per_fold_trade_count = []
    per_fold_win_rate = []
    for fr in walk_forward_result.fold_results:
        closed = [t for t in fr.backtest.trades if t.state == TradeLifecycleState.FINAL_EXIT and t.pnl is not None]
        fold_pnl = sum(t.pnl for t in closed)
        per_fold_pnl.append(fold_pnl)
        per_fold_trade_count.append(len(fr.backtest.trades))
        wins = sum(1 for t in closed if t.pnl > 0)
        per_fold_win_rate.append((wins / len(closed)) if closed else None)

    total_abs_pnl = sum(abs(p) for p in per_fold_pnl)
    if total_abs_pnl == 0:
        concentration = None
        dominated = None
    else:
        concentration = max(abs(p) for p in per_fold_pnl) / total_abs_pnl
        dominated = concentration >= dominance_threshold

    return WindowRobustnessResult(
        fold_count=len(walk_forward_result.fold_results), per_fold_pnl=tuple(per_fold_pnl),
        per_fold_trade_count=tuple(per_fold_trade_count), per_fold_win_rate=tuple(per_fold_win_rate),
        pnl_concentration_ratio=concentration, dominated_by_single_window=dominated,
        dominance_threshold=dominance_threshold,
        per_fold_valid=tuple(fold_is_usable(fr.backtest) for fr in walk_forward_result.fold_results),
        blocked_fold_count=sum(1 for fr in walk_forward_result.fold_results if not fold_is_usable(fr.backtest)),
    )


_SENSITIVITY_LIMITATIONS = (
    "Only exercises the specific config variants the caller supplied - "
    "this module never guesses which thresholds 'should' be perturbed. "
    "A config field left unperturbed across all variants is not "
    "assessed for sensitivity at all. Relative-change figures are None "
    "(never fabricated as 0 or infinite) whenever the baseline had zero "
    "closed-trade PNL, since no relative comparison is meaningful there.",
)


@dataclass(frozen=True)
class ConfigVariant:
    label: str
    config: object  # MultiHorizonReplayConfig


@dataclass(frozen=True)
class VariantOutcome:
    label: str
    trade_count: int
    closed_trade_count: int
    total_pnl: object
    win_rate: object


@dataclass(frozen=True)
class SensitivityCheckResult:
    baseline: VariantOutcome
    variants: tuple  # tuple[VariantOutcome, ...]
    max_relative_pnl_change: object  # None if baseline.total_pnl == 0
    high_sensitivity_flagged: object  # None if max_relative_pnl_change is None
    sensitivity_threshold: float
    limitations: tuple = _SENSITIVITY_LIMITATIONS


def _run_and_summarize(bars, config, label) -> VariantOutcome:
    result = run_multi_horizon_replay(bars, config)
    closed = [t for t in result.trades if t.state == TradeLifecycleState.FINAL_EXIT and t.pnl is not None]
    total_pnl = sum(t.pnl for t in closed)
    wins = sum(1 for t in closed if t.pnl > 0)
    win_rate = (wins / len(closed)) if closed else None
    return VariantOutcome(label=label, trade_count=len(result.trades), closed_trade_count=len(closed),
                           total_pnl=total_pnl, win_rate=win_rate)


def check_parameter_sensitivity(bars, baseline: ConfigVariant, variants, sensitivity_threshold=0.5) -> SensitivityCheckResult:
    baseline_outcome = _run_and_summarize(bars, baseline.config, baseline.label)
    variant_outcomes = tuple(_run_and_summarize(bars, v.config, v.label) for v in variants)

    if baseline_outcome.total_pnl == 0 or not variant_outcomes:
        max_rel_change = None
        flagged = None
    else:
        max_rel_change = max(
            abs(v.total_pnl - baseline_outcome.total_pnl) / abs(baseline_outcome.total_pnl)
            for v in variant_outcomes
        )
        flagged = max_rel_change >= sensitivity_threshold

    return SensitivityCheckResult(baseline=baseline_outcome, variants=variant_outcomes,
                                   max_relative_pnl_change=max_rel_change, high_sensitivity_flagged=flagged,
                                   sensitivity_threshold=sensitivity_threshold)


_STRUCTURAL_ROBUSTNESS_LIMITATIONS = (
    "Only proves the pipeline fails CLOSED (blocks via data quality, or "
    "returns zero/valid trades) or raises a genuine, visible exception "
    "on the exact stress-test bars the caller supplied - it makes no "
    "claim about profitability, realism of the stress scenario, or "
    "behavior on any market condition not represented in those bars. "
    "The stress-test data itself must come from the caller: this "
    "module never fabricates market data and reports it as evidence.",
)


@dataclass(frozen=True)
class StressCaseResult:
    label: str
    raised_exception_type: object  # None, or the exception class name (str)
    raised_exception_message: object
    data_quality_blocked: object
    trade_count: object


@dataclass(frozen=True)
class StructuralRobustnessResult:
    case_results: tuple
    all_cases_handled_without_unhandled_crash: bool
    limitations: tuple = _STRUCTURAL_ROBUSTNESS_LIMITATIONS


def check_structural_robustness(config, stress_cases) -> StructuralRobustnessResult:
    """stress_cases: iterable of (label, bars) pairs supplied by the
    caller. A raised exception is recorded here, never swallowed -
    this utility follows the identical no-silent-failure discipline as
    the rest of Phase 8 (see test_phase8_exception_handling.py)."""
    results = []
    any_crash = False
    for label, case_bars in stress_cases:
        try:
            backtest = run_multi_horizon_replay(case_bars, config)
            results.append(StressCaseResult(
                label=label, raised_exception_type=None, raised_exception_message=None,
                data_quality_blocked=not backtest.data_quality.is_valid, trade_count=len(backtest.trades),
            ))
        except Exception as exc:  # noqa: BLE001 - deliberately broad: THIS is the crash-safety probe itself,
            # the one place in Phase 8 code where catching Exception is the explicit point of the function -
            # every case is still individually reported, nothing is silently discarded (see AGGREGATE below).
            any_crash = True
            results.append(StressCaseResult(
                label=label, raised_exception_type=type(exc).__name__, raised_exception_message=str(exc),
                data_quality_blocked=None, trade_count=None,
            ))
    return StructuralRobustnessResult(case_results=tuple(results), all_cases_handled_without_unhandled_crash=not any_crash)


_FUTURE_MUTATION_LIMITATIONS = (
    "Compares every fold whose test window ends before mutate_from_index against a run on the mutated "
    "dataset (all trade fields except the wall-clock-derived candidate_id/decision_id, plus the fold's "
    "data-quality validity). It proves those folds did not read the mutated bars for THIS dataset, "
    "config and mutation; it does not prove absence of a leak on paths this data never exercises.",
    "vacuous=True means the check could not distinguish a clean pipeline from a broken one (no closed "
    "trade compared, or the mutation changed no fold it was supposed to reach) - treat it as NOT verified.",
)


@dataclass(frozen=True)
class FutureMutationCheckResult:
    leak_detected: bool
    compared_fold_count: int
    compared_closed_trade_count: int
    differing_fold_indices: tuple
    mutated_fold_count: int            # folds whose test window reaches the mutated region
    mutated_fold_changed_count: int    # ...of which the mutation really changed the result (control)
    vacuous: bool
    limitations: tuple = _FUTURE_MUTATION_LIMITATIONS


def _fold_fingerprint(fr):
    trades = tuple(
        tuple((k, getattr(t, k)) for k in t.__dataclass_fields__ if k not in _WALL_CLOCK_DERIVED_FIELDS)
        for t in fr.backtest.trades
    )
    return (fr.fold, fold_is_usable(fr.backtest), trades)


def check_walk_forward_future_mutation(bars, config, mutate_from_index, mutation) -> FutureMutationCheckResult:
    """Runs walk-forward on `bars` and on `bars[:mutate_from_index] + mutation(bars[mutate_from_index:])`
    (mutation is caller-supplied and must not change the earlier bars). Any fold whose test window ends
    before `mutate_from_index` must be IDENTICAL in both runs; a difference is a future-data leak.
    The folds that do reach the mutated region act as a positive control: if none of them changed, the
    mutation was ineffective and a clean result is reported as vacuous rather than as a pass."""
    original = list(bars)
    mutated = original[:mutate_from_index] + list(mutation(original[mutate_from_index:]))
    if mutated[:mutate_from_index] != original[:mutate_from_index]:
        raise ValueError("mutation must leave bars before mutate_from_index untouched")

    run_a = run_walk_forward(original, config)
    run_b = run_walk_forward(mutated, config)
    by_index_b = {fr.fold.fold_index: fr for fr in run_b.fold_results}

    differing, compared, compared_closed = [], 0, 0
    mutated_folds = changed = 0
    for fr_a in run_a.fold_results:
        fr_b = by_index_b.get(fr_a.fold.fold_index)
        if fr_a.fold.test_end_index < mutate_from_index:
            compared += 1
            compared_closed += sum(1 for t in fr_a.backtest.trades if t.state == TradeLifecycleState.FINAL_EXIT)
            if fr_b is None or _fold_fingerprint(fr_a) != _fold_fingerprint(fr_b):
                differing.append(fr_a.fold.fold_index)
        else:
            mutated_folds += 1
            if fr_b is None or _fold_fingerprint(fr_a) != _fold_fingerprint(fr_b):
                changed += 1

    vacuous = compared_closed == 0 or changed == 0
    return FutureMutationCheckResult(
        leak_detected=bool(differing), compared_fold_count=compared,
        compared_closed_trade_count=compared_closed, differing_fold_indices=tuple(differing),
        mutated_fold_count=mutated_folds, mutated_fold_changed_count=changed, vacuous=vacuous,
    )
