"""
Historical Replay Engine - MERWIS AI, Phase 7.

THE SINGLE MOST IMPORTANT GUARANTEE IN THIS FILE: at replay step idx,
the ONLY bars ever passed into MarketContext/QuantContext/Intelligence/
Decision are bars[lo:idx+1] - a slice that ends AT idx and never
reaches idx+1 or beyond. This is the entire look-ahead-bias defense;
it is enforced by slicing, not by convention, so it cannot be
accidentally bypassed by a future edit to an unrelated function.

This module does NOT implement a second trading algorithm. It calls
the exact same production functions Phase 2-6 already expose:
build_market_context, build_quant_context, build_bull_case,
build_bear_case, detect_scalp_candidate, from_scalp_candidate, decide.
The Risk Engine's hard gate (inside decide()) is never bypassed -
every LONG/SHORT outcome here came from an actionable RiskAssessmentResult,
exactly as Phase 6 designed.

Scope (v1, documented): sequential single-position replay only
(max_concurrent_positions must be 1). Scalp horizon only - Intraday and
Short-Swing replay would use the identical pattern via their own
bridge functions, left for a future extension (see Known Limitations).
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone

from omnisystem_v5.context.builder import build_market_context
from omnisystem_v5.intelligence.bear_engine import build_bear_case
from omnisystem_v5.intelligence.bull_engine import build_bull_case
from omnisystem_v5.intelligence.decision_bridge import from_scalp_candidate
from omnisystem_v5.intelligence.scalp_engine import detect_scalp_candidate
from omnisystem_v5.context.enums import ContextStatus
from omnisystem_v5.decision.engine import decide
from omnisystem_v5.decision.enums import DecisionOutcome, DecisionReasonCode
from omnisystem_v5.quant.engine import build_quant_context
from omnisystem_v5.quant.enums import QuantStatus
from omnisystem_v5.risk.contracts import AccountState
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope
from omnisystem_v5.validation.contracts import (
    BacktestResult,
    HistoricalDatasetDescriptor,
    ReplayConfig,
    ReproducibilityRecord,
    SimulatedFill,
    TradeRecord,
)
from omnisystem_v5.validation.data_quality import validate_historical_dataset
from omnisystem_v5.validation.enums import ExitReason, TradeLifecycleState
from omnisystem_v5.validation.execution import calculate_fee, find_entry_fill, simulate_position_lifecycle


def _make_trade_id(symbol, direction_value, signal_time, entry_bottom, entry_top, stop_loss, take_profits):
    """Deterministic by construction from data-derived fields only.
    Deliberately does NOT use decision_id/candidate_id, since those
    embed a wall-clock calculated_at timestamp set inside the
    Intelligence/Decision layers (correct for live use, but it would
    make trade_id non-reproducible across separate replay runs of the
    identical historical dataset - the exact failure Phase 7's
    determinism requirement forbids)."""
    raw = f"{symbol}|{direction_value}|{signal_time.isoformat()}|{entry_bottom}|{entry_top}|{stop_loss}|{take_profits}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _build_envelope(symbol, timeframe, window, fetched_at):
    provenance = DataProvenance(
        source="historical_replay", origin=DataOrigin.HISTORICAL,
        fetched_at=fetched_at, data_timestamp=window[-1].close_time,
    )
    return MarketDataEnvelope(
        market=symbol, timeframe=timeframe, provenance=provenance,
        quality_status=QualityStatus.OK, bars=tuple(window),
    )


def run_replay(bars, config, run_id=None):
    if config.execution.max_concurrent_positions != 1:
        raise ValueError(
            "Phase 7 v1 replay engine only supports max_concurrent_positions=1 "
            "(sequential, non-overlapping trades) - overlapping-position simulation "
            "is a documented future extension, not a silently-ignored setting"
        )

    dq_report = validate_historical_dataset(bars, config.timeframe, config.min_bars_required)

    dataset = HistoricalDatasetDescriptor(
        symbol=config.symbol, timeframe=config.timeframe, bar_count=len(bars),
        start_timestamp=bars[0].open_time if bars else datetime.now(timezone.utc),
        end_timestamp=bars[-1].close_time if bars else datetime.now(timezone.utc),
        source_description="caller-provided historical OHLCV bars",
        dataset_hash=HistoricalDatasetDescriptor.compute_hash(bars) if bars else "empty",
    )

    if not dq_report.is_valid:
        return BacktestResult(dataset=dataset, data_quality=dq_report, trades=(),
                               reproducibility=_build_repro(run_id, dataset, config))

    end_index = config.end_index if config.end_index is not None else len(bars) - 1
    idx = max(config.start_index, config.min_bars_required - 1)

    trades = []
    current_equity = config.initial_capital
    now_for_run = datetime.now(timezone.utc)

    while idx <= end_index:
        lo = max(0, idx - config.max_lookback_bars + 1)
        window = bars[lo: idx + 1]

        envelope = _build_envelope(config.symbol, config.timeframe, window, now_for_run)
        mctx = build_market_context(config.symbol, envelope, config.market_context_config)
        if mctx.status != ContextStatus.OK:
            idx += 1
            continue

        qctx = build_quant_context(config.symbol, mctx, config.quant_engine_config)
        if qctx.status != QuantStatus.OK:
            idx += 1
            continue

        bull = build_bull_case(config.symbol, mctx, qctx)
        bear = build_bear_case(config.symbol, mctx, qctx)
        scalp_result = detect_scalp_candidate(config.symbol, mctx, qctx, bull, bear, config.scalp_engine_config)

        if scalp_result.status.value != "ZONE_IDENTIFIED":
            idx += 1
            continue

        candidate = scalp_result.candidates[0]
        normalized = from_scalp_candidate(candidate)
        signal_time = window[-1].close_time

        account = AccountState(equity=current_equity)
        final_decision = decide([normalized], account, config.risk_policy, config.decision_policy, now=signal_time)

        if final_decision.outcome == DecisionOutcome.NO_TRADE:
            state = (TradeLifecycleState.REJECTED_BY_RISK
                     if final_decision.reason_code == DecisionReasonCode.NO_CANDIDATE_PASSED_RISK_GATE
                     else TradeLifecycleState.INVALIDATED)
            trades.append(TradeRecord(
                trade_id=_make_trade_id(config.symbol, normalized.direction.value, signal_time,
                                         candidate.preferred_entry_zone.bottom, candidate.preferred_entry_zone.top,
                                         normalized.stop_loss, normalized.take_profits),
                symbol=config.symbol, direction=normalized.direction.value, signal_time=signal_time, state=state,
                entry_zone_bottom=candidate.preferred_entry_zone.bottom, entry_zone_top=candidate.preferred_entry_zone.top,
                stop_loss=normalized.stop_loss, take_profits=normalized.take_profits,
                decision_id=final_decision.decision_id, candidate_id=normalized.candidate_id,
                market_regime=candidate.market_regime.value, rejection_detail=", ".join(final_decision.reasons),
            ))
            idx += 1
            continue

        winner = final_decision.selected_candidate
        risk_result = final_decision.risk_result
        future_bars = bars[idx + 1:]

        entry_fill, bars_consumed = find_entry_fill(
            future_bars, candidate.preferred_entry_zone.bottom, candidate.preferred_entry_zone.top,
            winner.direction, config.execution,
        )

        if entry_fill is None:
            trades.append(TradeRecord(
                trade_id=_make_trade_id(config.symbol, winner.direction.value, signal_time,
                                         candidate.preferred_entry_zone.bottom, candidate.preferred_entry_zone.top,
                                         winner.stop_loss, winner.take_profits),
                symbol=config.symbol, direction=winner.direction.value, signal_time=signal_time,
                state=TradeLifecycleState.EXPIRED, exit_reason=ExitReason.ENTRY_NEVER_FILLED,
                entry_zone_bottom=candidate.preferred_entry_zone.bottom, entry_zone_top=candidate.preferred_entry_zone.top,
                stop_loss=winner.stop_loss, take_profits=winner.take_profits,
                decision_id=final_decision.decision_id, candidate_id=winner.candidate_id,
                market_regime=candidate.market_regime.value,
            ))
            idx = idx + 1 + bars_consumed
            continue

        quantity = risk_result.position_size
        stop_loss = winner.stop_loss
        take_profit = winner.take_profits[0]
        remaining_bars = bars[idx + 1 + bars_consumed:]
        lifecycle = simulate_position_lifecycle(remaining_bars, winner.direction, entry_fill.price,
                                                 stop_loss, take_profit, config.execution)

        if lifecycle["exit_fill"] is not None:
            exit_fill = lifecycle["exit_fill"]
            advance = 1 + bars_consumed + lifecycle["duration_bars"]
        else:
            last_bar = bars[-1]
            exit_fill = SimulatedFill(price=last_bar.close, timestamp=last_bar.close_time,
                                       fee_amount=calculate_fee(last_bar.close, config.execution), slippage_amount=0.0)
            lifecycle = dict(lifecycle)
            lifecycle["exit_reason"] = ExitReason.END_OF_REPLAY_WINDOW
            advance = end_index - idx + 1

        sign = 1 if winner.direction.value == "LONG" else -1
        gross_pnl = (exit_fill.price - entry_fill.price) * sign * quantity
        total_fees = (entry_fill.fee_amount + exit_fill.fee_amount) * quantity
        net_pnl = gross_pnl - total_fees
        risk_amount = risk_result.risk_amount
        r_multiple = (net_pnl / risk_amount) if risk_amount else None
        current_equity += net_pnl

        trades.append(TradeRecord(
            trade_id=_make_trade_id(config.symbol, winner.direction.value, signal_time,
                                     candidate.preferred_entry_zone.bottom, candidate.preferred_entry_zone.top,
                                     stop_loss, winner.take_profits),
            symbol=config.symbol, direction=winner.direction.value, signal_time=signal_time,
            state=TradeLifecycleState.FINAL_EXIT, entry_fill=entry_fill, exit_fill=exit_fill,
            exit_reason=lifecycle["exit_reason"],
            entry_zone_bottom=candidate.preferred_entry_zone.bottom, entry_zone_top=candidate.preferred_entry_zone.top,
            stop_loss=stop_loss, take_profits=winner.take_profits,
            quantity=quantity, risk_amount=risk_amount, pnl=net_pnl, r_multiple=r_multiple,
            mae=lifecycle["mae"], mfe=lifecycle["mfe"], duration_bars=lifecycle["duration_bars"],
            decision_id=final_decision.decision_id, candidate_id=winner.candidate_id,
            market_regime=candidate.market_regime.value,
        ))
        idx += advance

    return BacktestResult(dataset=dataset, data_quality=dq_report, trades=tuple(trades),
                           reproducibility=_build_repro(run_id, dataset, config))


def _build_repro(run_id, dataset, config):
    rid = run_id or hashlib.sha256(
        f"{dataset.dataset_hash}|{config.symbol}|{config.timeframe.value}|{config.initial_capital}".encode("utf-8")
    ).hexdigest()[:16]
    summary = {
        "symbol": config.symbol, "timeframe": config.timeframe.value,
        "initial_capital": str(config.initial_capital), "max_lookback_bars": str(config.max_lookback_bars),
        "min_bars_required": str(config.min_bars_required),
        "min_reward_risk_ratio": str(config.risk_policy.min_reward_risk_ratio),
        "decision_policy_version": config.decision_policy.policy_version,
    }
    return ReproducibilityRecord(run_id=rid, dataset=dataset, replay_config_summary=summary, random_seed=config.random_seed)
