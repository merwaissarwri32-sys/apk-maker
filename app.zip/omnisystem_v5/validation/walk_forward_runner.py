"""
Real Walk-Forward Runner - MERWIS AI, Phase 8.

Builds on top of, and does not replace, Phase 7's walk_forward.py
foundation. That module's `WalkForwardEngine` ABC assumes a fittable
system: a training window produces `trained_state` that a validation/
out-of-sample window is then evaluated against. MERWIS's Scalp/
Intraday/Short-Swing engines are rule-based against explicit,
human-set configs (structure/ATR/quality thresholds) - there is no
per-fold parameter fit anywhere in this codebase. Implementing
`run_training_window` against that ABC would mean inventing a fake
"training" step that does nothing real, which is exactly the
fabricated-validation failure mode the Phase 8 directive forbids.

What a walk-forward validation genuinely means for a NON-fitted,
rule-based system is still real and still valuable: prove the engine's
decisions in each forward-moving, chronologically-bounded window are
produced using ONLY that window's own warmup history - never a bar
from beyond the window being evaluated - and report each window's
results independently and out-of-sample, exactly the way a live
deployment would encounter them one day at a time. That is what this
module does, reusing the existing architecture directly:

  - MultiHorizonReplayConfig / run_multi_horizon_replay (Phase 8) does
    the actual, unmodified decision -> risk -> execution pipeline, per
    fold - no second decision engine is built here.
  - PeriodSplit / ValidationPeriodType (Phase 7, validation/contracts.py
    and validation/enums.py) label each fold's warmup ("TRAINING") and
    evaluated ("OUT_OF_SAMPLE") index ranges - reusing the existing
    contract instead of inventing a new one. BacktestResult.period_splits
    (present but unused by Phase 7/8's single-run replay) is populated
    here for the first time.

LEAK SAFETY: each fold is given ONLY `bars[fold_start:test_end+1]` -
the slice passed into run_multi_horizon_replay physically does not
contain a single bar beyond that fold's own test_end. This is a
stronger, simpler guarantee than relying solely on run_multi_horizon_
replay's own internal max_lookback windowing (which is independently
tested in test_phase8_multi_horizon_replay.py) - defense in depth, not
a replacement for it.

FOLD INDEPENDENCE: every fold starts from `initial_capital` fresh (no
equity carried over from a previous fold) and is computed by a fresh,
stateless call to run_multi_horizon_replay - no shared mutable state
between folds, so folds are independently reproducible and could be
parallelized without any change to this module.
"""

from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass, field, replace
from enum import Enum

from omnisystem_v5.validation.contracts import BacktestResult, HistoricalDatasetDescriptor, PeriodSplit
from omnisystem_v5.validation.enums import (
    DataQualityIssueType, ExitReason, TradeLifecycleState, ValidationPeriodType,
)
from omnisystem_v5.validation.multi_horizon_replay import MultiHorizonReplayConfig, run_multi_horizon_replay
from omnisystem_v5.validation.performance import calculate_performance_metrics
from omnisystem_v5.validation.warmup import compute_required_lookback_bars


class WalkForwardMode(str, Enum):
    ROLLING = "ROLLING"      # each fold's warmup window is the most recent `train_bars` bars only
    EXPANDING = "EXPANDING"  # each fold's warmup window is ALWAYS bars[0:test_start] (grows every fold)


# Phase 9: explicit, honest statement of what this validation layer does and
# does NOT establish. Carried on every WalkForwardResult (first entries are
# static; run-specific notes are appended after them).
WALK_FORWARD_LIMITATIONS = (
    "Each fold starts from initial_capital with no equity carry-over. pooled_performance concatenates "
    "usable folds' closed trades in fold order as an additive PnL series, so its equity curve and "
    "drawdown are NOT those of one continuous account.",
    "END_OF_REPLAY_WINDOW: a trade still open at a fold's last bar is closed at that bar's close "
    "(state FINAL_EXIT, exit_reason END_OF_REPLAY_WINDOW). Its outcome is truncated by the fold "
    "boundary, not decided by price reaching SL/TP. It stays in the metrics (Phase 7/8 contract "
    "unchanged) and is listed in forced_close_trade_ids / forced_close_trade_count.",
    "EXPANDING vs ROLLING: replay windows are capped at max_lookback_bars, so once train_bars covers "
    "the required warmup, EXPANDING makes the same decisions as ROLLING - the extra history is not "
    "read by any decision. The modes then differ only in the audited train window size.",
    "The engines stamp calculated_at with the wall clock, and candidate_id / decision_id are derived "
    "from it, so those two ids are not reproducible across runs with real engines. trade_id and every "
    "other trade field are; determinism comparisons must exclude candidate_id, decision_id and calculated_at.",
    "No parameter is fitted per fold: results describe how fixed rules behave in each out-of-window "
    "segment. Fold-level ratios are descriptive; fewer than ~20 closed trades carries "
    "sample_size_warning and is not statistical proof.",
    "Non-blocking data-quality warnings (ABNORMAL_GAP, MISSING_CANDLE) do not block a fold; they are "
    "counted per fold slice in which they appear, so a gap inside a shared warmup region is counted by "
    "every fold containing it. Folds are index-based, not equal wall-clock spans, when data has gaps.",
    "step_bars greater than test_bars is allowed but leaves bars untested (see total_test_bars).",
)


def required_warmup_bars(template: MultiHorizonReplayConfig) -> int:
    """Base-timeframe bars a fold's warmup window must contain for every horizon
    enabled in `template`, taken from validation/warmup.py - never hard-coded here."""
    return compute_required_lookback_bars(
        template.base_timeframe, template.enable_scalp, template.enable_intraday, template.enable_short_swing,
        template.market_context_config, template.quant_engine_config,
        template.intraday_engine_config, template.short_swing_engine_config,
        floor_bars=template.min_bars_required,
    )


@dataclass(frozen=True)
class WalkForwardRunConfig:
    mode: WalkForwardMode
    train_bars: int
    test_bars: int
    replay_config_template: MultiHorizonReplayConfig
    step_bars: int = None  # default: test_bars (non-overlapping, sequential test windows)

    def __post_init__(self):
        if self.train_bars <= 0:
            raise ValueError(f"train_bars must be positive, got {self.train_bars}")
        if self.test_bars <= 0:
            raise ValueError(f"test_bars must be positive, got {self.test_bars}")
        step = self.step_bars if self.step_bars is not None else self.test_bars
        if step <= 0:
            raise ValueError(f"step_bars must be positive, got {step}")
        object.__setattr__(self, "step_bars", step)

        if self.mode == WalkForwardMode.ROLLING and self.train_bars < self.replay_config_template.max_lookback_bars:
            raise ValueError(
                f"ROLLING train_bars={self.train_bars} is smaller than "
                f"max_lookback_bars={self.replay_config_template.max_lookback_bars} required by the enabled "
                f"horizon(s) in replay_config_template (see validation/warmup.py) - every fold's warmup "
                f"window would silently starve a higher-timeframe horizon the whole way through. Pass a "
                f"larger train_bars, or use WalkForwardMode.EXPANDING where the window grows fold over fold."
            )

        # Phase 9 - both modes: the FIRST fold has the smallest warmup window (ROLLING: always
        # train_bars; EXPANDING: train_bars, then growing), so train_bars >= requirement guarantees
        # every fold is warmed up. Requirement comes from validation/warmup.py.
        required = required_warmup_bars(self.replay_config_template)
        if self.train_bars < required:
            raise ValueError(
                f"{self.mode.value} train_bars={self.train_bars} is smaller than the {required} "
                f"base-timeframe bars required by the enabled horizon(s) in replay_config_template "
                f"(see validation/warmup.py). The first fold would start without enough history for a "
                f"higher-timeframe context; pass train_bars >= {required} or disable the horizon(s) "
                f"that need more history."
            )

        # Phase 9 - overlapping test windows have no valid meaning here: every bar would be
        # simulated by several folds and the aggregate would count the same trade more than once.
        if step < self.test_bars:
            raise ValueError(
                f"step_bars={step} < test_bars={self.test_bars} would make consecutive test windows "
                f"overlap and double-count trades in the aggregate. Use step_bars >= test_bars "
                f"(default: step_bars == test_bars)."
            )


@dataclass(frozen=True)
class Fold:
    fold_index: int
    warmup_start_index: int   # GLOBAL index into the original bars array
    warmup_end_index: int     # GLOBAL index (inclusive)
    test_start_index: int     # GLOBAL index (inclusive)
    test_end_index: int       # GLOBAL index (inclusive)


class FoldStatus(str, Enum):
    BLOCKED = "BLOCKED"                                    # data-quality/warmup gate refused the fold
    VALID_NO_TRADES = "VALID_NO_TRADES"                    # valid fold, zero candidates traced (a correct NO_TRADE)
    VALID_NO_CLOSED_TRADES = "VALID_NO_CLOSED_TRADES"      # valid fold, candidates traced but none executed
    VALID_WITH_CLOSED_TRADES = "VALID_WITH_CLOSED_TRADES"


@dataclass(frozen=True)
class FoldAudit:
    """Deterministic per-fold trace (no wall-clock fields)."""
    fold_index: int
    warmup_start_index: int
    warmup_end_index: int
    test_start_index: int
    test_end_index: int
    train_bar_count: int
    test_bar_count: int
    status: FoldStatus
    is_valid: bool
    warmup_sufficient: bool
    blocking_issue_types: tuple          # sorted issue-type names that blocked the fold
    warning_issue_counts: tuple          # sorted (issue_type, count) for non-blocking issues
    trade_record_count: int
    closed_trade_count: int
    rejected_by_risk_count: int
    invalidated_count: int
    expired_count: int
    forced_close_trade_ids: tuple        # exit_reason == END_OF_REPLAY_WINDOW
    rejection_reason_counts: tuple       # sorted (rejection_detail, count)
    fold_pnl: object = None              # None when the fold has no closed trade - never a fabricated 0


@dataclass(frozen=True)
class FoldResult:
    fold: Fold
    backtest: BacktestResult
    audit: object = None  # FoldAudit; populated by run_walk_forward


_NOT_EXECUTED_STATES = (TradeLifecycleState.REJECTED_BY_RISK, TradeLifecycleState.INVALIDATED,
                        TradeLifecycleState.EXPIRED)


def fold_is_usable(backtest: BacktestResult) -> bool:
    """A fold contributes to metrics only if its data passed the data-quality gate AND its warmup
    was sufficient. INSUFFICIENT_WARMUP is non-blocking in the Phase 7 data-quality contract
    (unchanged); this layer treats it as blocking because a fold without warmup is not a valid
    out-of-sample evaluation."""
    dq = backtest.data_quality
    return bool(dq.is_valid and dq.warmup_sufficient)


def build_fold_audit(fold: Fold, backtest: BacktestResult) -> FoldAudit:
    dq = backtest.data_quality
    blocking_types = dq.blocking_issue_types()
    blocking = {i.issue_type.value for i in dq.issues if i.issue_type in blocking_types}
    if not dq.warmup_sufficient:
        blocking.add(DataQualityIssueType.INSUFFICIENT_WARMUP.value)
    warnings = Counter(i.issue_type.value for i in dq.issues
                       if i.issue_type not in blocking_types and i.issue_type != DataQualityIssueType.INSUFFICIENT_WARMUP)
    trades = backtest.trades
    closed = [t for t in trades if t.state == TradeLifecycleState.FINAL_EXIT]
    not_executed = [t for t in trades if t.state in _NOT_EXECUTED_STATES]
    usable = fold_is_usable(backtest)
    if not usable:
        status = FoldStatus.BLOCKED
    elif not trades:
        status = FoldStatus.VALID_NO_TRADES
    elif not closed:
        status = FoldStatus.VALID_NO_CLOSED_TRADES
    else:
        status = FoldStatus.VALID_WITH_CLOSED_TRADES
    pnls = [t.pnl for t in closed if t.pnl is not None]
    return FoldAudit(
        fold_index=fold.fold_index, warmup_start_index=fold.warmup_start_index,
        warmup_end_index=fold.warmup_end_index, test_start_index=fold.test_start_index,
        test_end_index=fold.test_end_index,
        train_bar_count=fold.warmup_end_index - fold.warmup_start_index + 1,
        test_bar_count=fold.test_end_index - fold.test_start_index + 1,
        status=status, is_valid=dq.is_valid, warmup_sufficient=dq.warmup_sufficient,
        blocking_issue_types=tuple(sorted(blocking)), warning_issue_counts=tuple(sorted(warnings.items())),
        trade_record_count=len(trades), closed_trade_count=len(closed),
        rejected_by_risk_count=sum(1 for t in trades if t.state == TradeLifecycleState.REJECTED_BY_RISK),
        invalidated_count=sum(1 for t in trades if t.state == TradeLifecycleState.INVALIDATED),
        expired_count=sum(1 for t in trades if t.state == TradeLifecycleState.EXPIRED),
        forced_close_trade_ids=tuple(t.trade_id for t in closed if t.exit_reason == ExitReason.END_OF_REPLAY_WINDOW),
        rejection_reason_counts=tuple(sorted(Counter(t.rejection_detail for t in not_executed).items(),
                                             key=lambda kv: str(kv[0]))),
        fold_pnl=sum(pnls) if pnls else None,
    )


@dataclass(frozen=True)
class WalkForwardAggregateMetrics:
    fold_count: int
    total_candidates_traced: int
    total_closed_trades: int
    winning_trades: int
    losing_trades: int
    total_pnl: float
    win_rate: object = None            # None when there are zero closed trades - never fabricated as 0.0
    average_r_multiple: object = None  # None when no closed trade has an r_multiple
    trades_by_horizon: dict = field(default_factory=dict)
    # ---- Phase 9 (additive). All trade-derived numbers above and below come from USABLE folds only.
    valid_fold_count: int = 0
    blocked_fold_count: int = 0
    empty_fold_count: int = 0            # usable folds with zero candidates traced
    no_execution_fold_count: int = 0     # usable folds with candidates traced but no closed trade
    blocked_fold_reasons: tuple = ()     # ((fold_index, (issue_type, ...)), ...)
    warning_issue_counts: dict = field(default_factory=dict)  # non-blocking issues, counted per fold slice
    forced_close_trade_count: int = 0    # END_OF_REPLAY_WINDOW closes (also counted in total_closed_trades)
    rejection_state_counts: dict = field(default_factory=dict)
    rejection_reason_counts: dict = field(default_factory=dict)
    fold_pnls: tuple = ()                # ((fold_index, pnl), ...) usable folds with >= 1 closed trade
    profitable_fold_count: int = 0
    losing_fold_count: int = 0
    flat_fold_count: int = 0
    profitable_fold_ratio: object = None  # None when no fold has a closed trade
    fold_pnl_stdev: object = None         # None with fewer than 2 folds having closed trades
    total_test_bars: int = 0              # over all folds; < span when step_bars > test_bars
    pooled_performance: object = None     # performance.PerformanceMetrics over usable folds' closed trades


@dataclass(frozen=True)
class WalkForwardResult:
    mode: WalkForwardMode
    dataset_hash: str
    fold_results: tuple  # tuple[FoldResult, ...]
    aggregate: WalkForwardAggregateMetrics
    config_summary: dict
    limitations: tuple = ()  # WALK_FORWARD_LIMITATIONS + run-specific notes


def compute_folds(bar_count, config: WalkForwardRunConfig) -> tuple:
    """Pure, deterministic fold-boundary computation - no bar data is
    read or reordered here, only integer index arithmetic, so this
    function cannot itself introduce leakage (same guarantee style as
    Phase 7's split_walk_forward_periods)."""
    folds = []
    if config.mode == WalkForwardMode.ROLLING:
        fold_index = 0
        fold_start = 0
        while True:
            test_start = fold_start + config.train_bars
            test_end = test_start + config.test_bars - 1
            if test_end > bar_count - 1:
                break
            folds.append(Fold(fold_index, fold_start, test_start - 1, test_start, test_end))
            fold_index += 1
            fold_start += config.step_bars
    else:
        fold_index = 0
        test_start = config.train_bars
        while True:
            test_end = test_start + config.test_bars - 1
            if test_end > bar_count - 1:
                break
            folds.append(Fold(fold_index, 0, test_start - 1, test_start, test_end))
            fold_index += 1
            test_start += config.step_bars
    return tuple(folds)


def _run_single_fold(bars, fold: Fold, config: WalkForwardRunConfig) -> FoldResult:
    bars_slice = bars[fold.warmup_start_index: fold.test_end_index + 1]
    local_test_start = fold.test_start_index - fold.warmup_start_index
    local_test_end = fold.test_end_index - fold.warmup_start_index

    fold_config = replace(
        config.replay_config_template,
        start_index=local_test_start,
        end_index=local_test_end,
    )
    backtest = run_multi_horizon_replay(bars_slice, fold_config, run_id=f"wf-fold-{fold.fold_index}")

    period_splits = (
        PeriodSplit(period_type=ValidationPeriodType.TRAINING, start_index=0, end_index=local_test_start - 1),
        PeriodSplit(period_type=ValidationPeriodType.OUT_OF_SAMPLE, start_index=local_test_start, end_index=local_test_end),
    )
    backtest_with_splits = replace(backtest, period_splits=period_splits)
    return FoldResult(fold=fold, backtest=backtest_with_splits, audit=build_fold_audit(fold, backtest_with_splits))


def _aggregate(fold_results, initial_capital=None) -> WalkForwardAggregateMetrics:
    """Folds refused by the data-quality/warmup gate are counted and explained (blocked_fold_*) but
    NEVER enter any trade-derived metric, even if a result object somehow carried trades."""
    usable = [fr for fr in fold_results if fold_is_usable(fr.backtest)]
    blocked = [fr for fr in fold_results if not fold_is_usable(fr.backtest)]

    total_traced = 0
    closed = []
    trades_by_horizon = {}
    not_executed = []
    fold_pnls = []
    empty_folds = no_execution_folds = 0
    for fr in usable:
        fold_closed = []
        for t in fr.backtest.trades:
            total_traced += 1
            trades_by_horizon[t.horizon] = trades_by_horizon.get(t.horizon, 0) + 1
            if t.state == TradeLifecycleState.FINAL_EXIT:
                closed.append(t)
                fold_closed.append(t)
            elif t.state in _NOT_EXECUTED_STATES:
                not_executed.append(t)
        if not fr.backtest.trades:
            empty_folds += 1
        elif not fold_closed:
            no_execution_folds += 1
        fold_pnl_values = [t.pnl for t in fold_closed if t.pnl is not None]
        if fold_pnl_values:
            fold_pnls.append((fr.fold.fold_index, sum(fold_pnl_values)))

    winning = sum(1 for t in closed if t.pnl is not None and t.pnl > 0)
    losing = sum(1 for t in closed if t.pnl is not None and t.pnl <= 0)
    total_pnl = sum(t.pnl for t in closed if t.pnl is not None)
    win_rate = (winning / len(closed)) if closed else None
    r_values = [t.r_multiple for t in closed if t.r_multiple is not None]
    avg_r = (sum(r_values) / len(r_values)) if r_values else None

    warnings = Counter()
    for fr in fold_results:
        for name, count in build_fold_audit(fr.fold, fr.backtest).warning_issue_counts:
            warnings[name] += count

    pnl_values = [p for _, p in fold_pnls]
    return WalkForwardAggregateMetrics(
        fold_count=len(fold_results), total_candidates_traced=total_traced, total_closed_trades=len(closed),
        winning_trades=winning, losing_trades=losing, total_pnl=total_pnl, win_rate=win_rate,
        average_r_multiple=avg_r, trades_by_horizon=trades_by_horizon,
        valid_fold_count=len(usable), blocked_fold_count=len(blocked),
        empty_fold_count=empty_folds, no_execution_fold_count=no_execution_folds,
        blocked_fold_reasons=tuple((fr.fold.fold_index, build_fold_audit(fr.fold, fr.backtest).blocking_issue_types)
                                   for fr in blocked),
        warning_issue_counts=dict(sorted(warnings.items())),
        forced_close_trade_count=sum(1 for t in closed if t.exit_reason == ExitReason.END_OF_REPLAY_WINDOW),
        rejection_state_counts=dict(sorted(Counter(t.state.value for t in not_executed).items())),
        rejection_reason_counts=dict(sorted(Counter(t.rejection_detail for t in not_executed).items(),
                                            key=lambda kv: str(kv[0]))),
        fold_pnls=tuple(fold_pnls),
        profitable_fold_count=sum(1 for p in pnl_values if p > 0),
        losing_fold_count=sum(1 for p in pnl_values if p < 0),
        flat_fold_count=sum(1 for p in pnl_values if p == 0),
        profitable_fold_ratio=(sum(1 for p in pnl_values if p > 0) / len(pnl_values)) if pnl_values else None,
        fold_pnl_stdev=statistics.stdev(pnl_values) if len(pnl_values) >= 2 else None,
        total_test_bars=sum(fr.fold.test_end_index - fr.fold.test_start_index + 1 for fr in fold_results),
        pooled_performance=(calculate_performance_metrics(closed, initial_capital)
                            if initial_capital is not None else None),
    )


def run_walk_forward(bars, config: WalkForwardRunConfig) -> WalkForwardResult:
    """Runs every fold independently (fresh initial_capital each time,
    no shared state) against bars[fold.warmup_start_index:fold.test_end_index+1]
    ONLY - never against the full `bars` array - so a fold physically
    cannot see a bar beyond its own test_end_index. Any genuine internal
    error from a fold's run_multi_horizon_replay call propagates
    unmodified; nothing here catches or reinterprets it as a normal
    outcome (Priority 3's fail-closed discipline extended to this
    orchestration layer)."""
    folds = compute_folds(len(bars), config)
    fold_results = tuple(_run_single_fold(bars, f, config) for f in folds)
    aggregate = _aggregate(fold_results, initial_capital=config.replay_config_template.initial_capital)

    dataset_hash = HistoricalDatasetDescriptor.compute_hash(bars) if bars else "empty"
    config_summary = {
        "mode": config.mode.value, "train_bars": str(config.train_bars),
        "test_bars": str(config.test_bars), "step_bars": str(config.step_bars),
        "symbol": config.replay_config_template.symbol,
        "base_timeframe": config.replay_config_template.base_timeframe.value,
        "max_lookback_bars": str(config.replay_config_template.max_lookback_bars),
        "fold_count": str(len(folds)),
    }
    notes = []
    if not folds:
        notes.append(
            f"No fold could be formed: the dataset has {len(bars)} bars but at least "
            f"train_bars + test_bars = {config.train_bars + config.test_bars} are required; "
            f"every aggregate metric is undefined (None), not zero."
        )
    return WalkForwardResult(mode=config.mode, dataset_hash=dataset_hash, fold_results=fold_results,
                              aggregate=aggregate, config_summary=config_summary,
                              limitations=WALK_FORWARD_LIMITATIONS + tuple(notes))
