"""
Walk-Forward Robustness Layer - MERWIS AI, Phase 9.

WHY A SEPARATE MODULE: walk_forward_runner.py answers "what does ONE
configuration do across forward windows?". This module answers the
question one level up - "does that answer survive reasonable changes to
the window, the step, the horizons, the configuration, or the data?" -
by orchestrating many real walk-forward runs and comparing each to a
baseline. It contains no decision, risk, or replay logic: every scenario
is executed by the unmodified run_walk_forward (Decision -> Risk Hard
Gate -> Execution pipeline intact), so it is a validation layer only.

HONESTY RULES (enforced by structure, not convention):
  * The caller supplies (or generates from explicit option lists) every
    scenario. Nothing here searches for scenarios that look good.
  * Variants that are invalid are RECORDED as RejectedVariant with the
    exact reason - never silently dropped.
  * A scenario that replaces the dataset must state an evidence_class;
    a synthetic stress fixture is labelled as such and is never market
    evidence (see ROBUSTNESS_LIMITATIONS).
  * Undefined comparisons are None (zero baseline, no closed trades,
    all folds blocked), never a fabricated number.
  * Genuine internal errors propagate; only the documented config
    ValueError is handled, and only inside the variant generators.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from itertools import combinations

from omnisystem_v5.validation.walk_forward_runner import WalkForwardRunConfig, run_walk_forward

ROBUSTNESS_LIMITATIONS = (
    "Scenario results describe how the fixed rule set behaves under each tested change on the supplied "
    "data only. They are not statistical proof of robustness and say nothing about regimes absent from "
    "that data.",
    "Stress-fixture scenarios (evidence_class other than BASE_DATASET) use caller-constructed or "
    "transformed bars. They test fail-closed behaviour and sensitivity of the pipeline; the numbers are "
    "not market evidence and must never be reported as market performance.",
    "Flags are a descriptive rule (sign flip, or |relative PnL change| above a caller-set threshold), "
    "not a pass/fail verdict. A non-flagged scenario is not thereby 'robust'; a flagged one is not "
    "thereby 'broken'. Both must be read with per-fold trade counts and the sample-size warnings.",
    "Window/step variants that share bars are correlated re-uses of the same history, not independent "
    "samples; agreement between them is weaker evidence than agreement across separate datasets.",
)

_BASE_EVIDENCE = "BASE_DATASET"


class ScenarioKind(str, Enum):
    BASELINE = "BASELINE"
    WINDOW = "WINDOW"                # train and/or test window size changed (also changes their proportion)
    STEP = "STEP"                    # only the step changed
    HORIZON = "HORIZON"              # a subset of the enabled horizons
    CONFIG_VARIANT = "CONFIG_VARIANT"
    STRESS_FIXTURE = "STRESS_FIXTURE"


class ScenarioStatus(str, Enum):
    COMPLETED = "COMPLETED"
    NO_FOLDS = "NO_FOLDS"                      # dataset too short for a single fold
    ALL_FOLDS_BLOCKED = "ALL_FOLDS_BLOCKED"    # every fold refused by the data-quality/warmup gate


@dataclass(frozen=True)
class RobustnessScenario:
    label: str
    kind: ScenarioKind
    run_config: WalkForwardRunConfig
    bars: object = None                    # None -> use the suite's dataset; otherwise a caller-supplied dataset
    evidence_class: str = _BASE_EVIDENCE

    def __post_init__(self):
        if not self.label or not self.label.strip():
            raise ValueError("scenario label must be a non-empty string (labels are the trace keys)")
        if not self.evidence_class or not self.evidence_class.strip():
            raise ValueError("evidence_class must be a non-empty string")
        if self.bars is not None and self.evidence_class == _BASE_EVIDENCE:
            raise ValueError(
                f"scenario {self.label!r} replaces the dataset, so it must declare what the data is via "
                f"evidence_class (e.g. 'SYNTHETIC_STRESS_FIXTURE'); {_BASE_EVIDENCE!r} is reserved for the "
                f"suite's own dataset"
            )


@dataclass(frozen=True)
class RejectedVariant:
    label: str
    reason: str          # the exact configuration-validation message


@dataclass(frozen=True)
class ScenarioOutcome:
    label: str
    kind: ScenarioKind
    evidence_class: str
    mode: str
    train_bars: int
    test_bars: int
    step_bars: int
    horizons_enabled: tuple
    status: ScenarioStatus
    fold_count: int
    valid_fold_count: int
    blocked_fold_count: int
    empty_fold_count: int
    closed_trade_count: int
    total_pnl: object              # None when there are no closed trades in usable folds
    win_rate: object
    profitable_fold_ratio: object
    fold_pnls: tuple
    trades_by_horizon: dict
    warning_issue_counts: dict
    forced_close_trade_count: int
    dataset_hash: str


@dataclass(frozen=True)
class ScenarioComparison:
    label: str
    pnl_delta: object              # None if either PnL is undefined
    pnl_relative_change: object    # None if baseline PnL is undefined or exactly 0
    closed_trade_delta: int
    pnl_sign_flipped: object       # None unless both PnLs are defined and non-zero


@dataclass(frozen=True)
class RobustnessReport:
    baseline: ScenarioOutcome
    outcomes: tuple                # tuple[ScenarioOutcome, ...] in scenario order
    comparisons: tuple             # tuple[ScenarioComparison, ...] same order
    flagged: tuple                 # tuple[(label, reason), ...]
    sign_flip_count: int
    max_abs_relative_pnl_change: object
    flag_relative_change_threshold: float
    rejected_variants: tuple = ()
    limitations: tuple = ROBUSTNESS_LIMITATIONS


_HORIZON_FLAGS = (("SCALP", "enable_scalp"), ("INTRADAY", "enable_intraday"), ("SHORT_SWING", "enable_short_swing"))


def _horizons_enabled(template):
    return tuple(name for name, attr in _HORIZON_FLAGS if getattr(template, attr))


def _summarize(scenario: RobustnessScenario, dataset) -> ScenarioOutcome:
    result = run_walk_forward(list(dataset), scenario.run_config)
    agg = result.aggregate
    if agg.fold_count == 0:
        status = ScenarioStatus.NO_FOLDS
    elif agg.valid_fold_count == 0:
        status = ScenarioStatus.ALL_FOLDS_BLOCKED
    else:
        status = ScenarioStatus.COMPLETED
    cfg = scenario.run_config
    return ScenarioOutcome(
        label=scenario.label, kind=scenario.kind, evidence_class=scenario.evidence_class,
        mode=cfg.mode.value, train_bars=cfg.train_bars, test_bars=cfg.test_bars, step_bars=cfg.step_bars,
        horizons_enabled=_horizons_enabled(cfg.replay_config_template), status=status,
        fold_count=agg.fold_count, valid_fold_count=agg.valid_fold_count,
        blocked_fold_count=agg.blocked_fold_count, empty_fold_count=agg.empty_fold_count,
        closed_trade_count=agg.total_closed_trades,
        total_pnl=agg.pooled_performance.total_pnl, win_rate=agg.win_rate,
        profitable_fold_ratio=agg.profitable_fold_ratio, fold_pnls=agg.fold_pnls,
        trades_by_horizon=dict(agg.trades_by_horizon), warning_issue_counts=dict(agg.warning_issue_counts),
        forced_close_trade_count=agg.forced_close_trade_count, dataset_hash=result.dataset_hash,
    )


def compare_outcomes(baseline: ScenarioOutcome, outcome: ScenarioOutcome) -> ScenarioComparison:
    b, o = baseline.total_pnl, outcome.total_pnl
    delta = (o - b) if (b is not None and o is not None) else None
    relative = (delta / abs(b)) if (delta is not None and b != 0) else None
    flipped = ((b > 0) != (o > 0)) if (b is not None and o is not None and b != 0 and o != 0) else None
    return ScenarioComparison(label=outcome.label, pnl_delta=delta, pnl_relative_change=relative,
                              closed_trade_delta=outcome.closed_trade_count - baseline.closed_trade_count,
                              pnl_sign_flipped=flipped)


def _flag_for(outcome: ScenarioOutcome, comparison: ScenarioComparison, threshold):
    if outcome.status != ScenarioStatus.COMPLETED:
        return (outcome.label, f"SCENARIO_NOT_EVALUABLE:{outcome.status.value}")
    if comparison.pnl_sign_flipped:
        return (outcome.label, "PNL_SIGN_FLIPPED")
    if comparison.pnl_relative_change is not None and abs(comparison.pnl_relative_change) > threshold:
        return (outcome.label, "RELATIVE_PNL_CHANGE_EXCEEDS_THRESHOLD")
    return None


def run_robustness_suite(bars, baseline: RobustnessScenario, scenarios, flag_relative_change_threshold=0.5,
                         rejected_variants=()) -> RobustnessReport:
    """Runs the baseline and every scenario through the real walk-forward runner and compares each to
    the baseline. `rejected_variants` (from the generators) is carried into the report unchanged so
    that nothing that was asked for disappears from the trace."""
    scenarios = tuple(scenarios)
    if baseline.kind != ScenarioKind.BASELINE:
        raise ValueError(f"baseline scenario {baseline.label!r} must have kind BASELINE, got {baseline.kind.value}")
    for s in scenarios:
        if s.kind == ScenarioKind.BASELINE:
            raise ValueError(f"scenario {s.label!r} has kind BASELINE; the suite takes exactly one baseline")
    labels = [baseline.label] + [s.label for s in scenarios]
    duplicates = sorted({label for label in labels if labels.count(label) > 1})
    if duplicates:
        raise ValueError(f"scenario labels must be unique (trace keys); duplicated: {duplicates}")

    def dataset_for(scenario):
        return scenario.bars if scenario.bars is not None else bars

    base_outcome = _summarize(baseline, dataset_for(baseline))
    outcomes = tuple(_summarize(s, dataset_for(s)) for s in scenarios)
    comparisons = tuple(compare_outcomes(base_outcome, o) for o in outcomes)
    flagged = tuple(f for f in (_flag_for(o, c, flag_relative_change_threshold)
                                for o, c in zip(outcomes, comparisons)) if f is not None)
    relatives = [abs(c.pnl_relative_change) for c in comparisons if c.pnl_relative_change is not None]
    return RobustnessReport(
        baseline=base_outcome, outcomes=outcomes, comparisons=comparisons, flagged=flagged,
        sign_flip_count=sum(1 for c in comparisons if c.pnl_sign_flipped),
        max_abs_relative_pnl_change=max(relatives) if relatives else None,
        flag_relative_change_threshold=flag_relative_change_threshold,
        rejected_variants=tuple(rejected_variants),
    )


def generate_window_variants(base: WalkForwardRunConfig, train_options=None, test_options=None, step_options=None):
    """Cartesian product of the caller's explicit train/test/step options (each defaults to the base
    value; step defaults to following test_bars). Returns (scenarios, rejected_variants). The base
    combination itself is skipped (it is the baseline). Combinations the runner rejects (overlap,
    insufficient warmup, ...) are returned as RejectedVariant with the exact reason."""
    trains = tuple(train_options) if train_options is not None else (base.train_bars,)
    tests = tuple(test_options) if test_options is not None else (base.test_bars,)
    steps = tuple(step_options) if step_options is not None else (None,)
    scenarios, rejected = [], []
    for train in trains:
        for test in tests:
            for step in steps:
                effective_step = step if step is not None else test
                if (train, test, effective_step) == (base.train_bars, base.test_bars, base.step_bars):
                    continue
                label = f"window train={train} test={test} step={effective_step}"
                kind = ScenarioKind.STEP if (train, test) == (base.train_bars, base.test_bars) else ScenarioKind.WINDOW
                try:
                    cfg = WalkForwardRunConfig(mode=base.mode, train_bars=train, test_bars=test,
                                               replay_config_template=base.replay_config_template, step_bars=step)
                except ValueError as exc:   # the documented fail-closed config contract
                    rejected.append(RejectedVariant(label=label, reason=str(exc)))
                    continue
                scenarios.append(RobustnessScenario(label=label, kind=kind, run_config=cfg))
    return tuple(scenarios), tuple(rejected)


def generate_horizon_variants(base: WalkForwardRunConfig):
    """One scenario per non-empty PROPER subset of the horizons enabled in the base template, run with
    the same window settings. Returns (scenarios, rejected_variants); a single-horizon base has no proper
    subsets and returns two empty tuples."""
    template = base.replay_config_template
    enabled = [(name, attr) for name, attr in _HORIZON_FLAGS if getattr(template, attr)]
    scenarios, rejected = [], []
    for size in range(1, len(enabled)):
        for subset in combinations(enabled, size):
            chosen = {attr for _, attr in subset}
            label = "horizons=" + "+".join(name for name, _ in subset)
            flags = {attr: (attr in chosen) for _, attr in _HORIZON_FLAGS}
            try:
                cfg = WalkForwardRunConfig(mode=base.mode, train_bars=base.train_bars, test_bars=base.test_bars,
                                           replay_config_template=replace(template, **flags),
                                           step_bars=base.step_bars)
            except ValueError as exc:
                rejected.append(RejectedVariant(label=label, reason=str(exc)))
                continue
            scenarios.append(RobustnessScenario(label=label, kind=ScenarioKind.HORIZON, run_config=cfg))
    return tuple(scenarios), tuple(rejected)
