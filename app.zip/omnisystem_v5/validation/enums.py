"""
Validation Layer enumerations - MERWIS AI, Phase 7.

This package imports from context/, quant/, intelligence/, and decision/
directly - it is the OUTERMOST orchestration layer (the historical
analogue of a live trading loop), not a sibling of those layers. It is
never imported BY any of them.
"""

from enum import Enum


class TradeLifecycleState(str, Enum):
    SIGNAL_CREATED = "SIGNAL_CREATED"
    SIGNAL_VALID = "SIGNAL_VALID"
    ENTRY_PENDING = "ENTRY_PENDING"
    ENTRY_FILLED = "ENTRY_FILLED"
    POSITION_OPEN = "POSITION_OPEN"
    PARTIAL_EXIT = "PARTIAL_EXIT"
    BREAK_EVEN = "BREAK_EVEN"
    FINAL_EXIT = "FINAL_EXIT"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"
    REJECTED_BY_RISK = "REJECTED_BY_RISK"
    CANCELLED = "CANCELLED"


class ExitReason(str, Enum):
    TAKE_PROFIT = "TAKE_PROFIT"
    STOP_LOSS = "STOP_LOSS"
    BREAK_EVEN_STOP = "BREAK_EVEN_STOP"
    END_OF_REPLAY_WINDOW = "END_OF_REPLAY_WINDOW"
    ENTRY_NEVER_FILLED = "ENTRY_NEVER_FILLED"


class DataQualityIssueType(str, Enum):
    MISSING_CANDLE = "MISSING_CANDLE"
    DUPLICATE_TIMESTAMP = "DUPLICATE_TIMESTAMP"
    OUT_OF_ORDER = "OUT_OF_ORDER"
    IMPOSSIBLE_OHLC = "IMPOSSIBLE_OHLC"
    ABNORMAL_GAP = "ABNORMAL_GAP"
    INSUFFICIENT_WARMUP = "INSUFFICIENT_WARMUP"
    MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD"


class ValidationPeriodType(str, Enum):
    TRAINING = "TRAINING"
    VALIDATION = "VALIDATION"
    OUT_OF_SAMPLE = "OUT_OF_SAMPLE"


class SlippageModel(str, Enum):
    NONE = "NONE"
    FIXED_TICKS = "FIXED_TICKS"
    FIXED_PCT = "FIXED_PCT"
