# MERWIS AI — Phase 9 Final Report: Walk-Forward & Robust Validation

**Status: COMPLETE (pending user freeze).** Baseline in: `MERWIS_AI_PHASE8_FINAL.zip` (591/591). Result: **650/650 PASS**
(Phase 7: 96/96, Phase 8: 103/103, Phase 9: 59 new). **Phase 7 files changed: 0.** Phase 10 was not started.

## 1. File change ledger

| Category | File | Reason |
|---|---|---|
| Phase 7 | *(none)* | 0 files changed (verified by diff against the pristine Phase 8 checkpoint). |
| Phase 8 production (additive) | `validation/walk_forward_runner.py` | Priorities 1–4, 9: `FoldStatus`, `FoldAudit`, `build_fold_audit`, `fold_is_usable`, `required_warmup_bars`, `WALK_FORWARD_LIMITATIONS`; config now fails closed on insufficient warmup (both modes) and overlapping test windows; aggregate gained valid/blocked/empty folds, blocked reasons, warning counts, forced-close count, rejection counts, fold consistency, `total_test_bars`, `pooled_performance` (reuses `performance.py`); `WalkForwardResult.limitations`. All new dataclass fields have defaults; the first nine legacy aggregate fields and their meaning are unchanged. |
| Phase 8 production (additive) | `validation/adversarial_validation.py` | Priority 6, real gaps: `LeakageCheckResult.vacuous/excluded_fields` + `exclude_wall_clock_ids` (default False = old behaviour); `WindowRobustnessResult.per_fold_valid/blocked_fold_count`; new `check_walk_forward_future_mutation`. The four existing checks are preserved. |
| Phase 8 tests (modified) | `tests/test_phase8_walk_forward_runner.py` | (a) 3 vacuous tests made real (see §3); (b) **one contract inversion**: `test_expanding_mode_allows_small_initial_train_bars` asserted the old behaviour that Priority 2 required to be fail-closed; it now asserts `ValueError`. |
| Phase 8 tests (modified) | `tests/test_phase8_adversarial_validation.py` | 1 vacuous test made real (§3). |
| New Phase 9 | `validation/robustness.py` | Priority 5. Separate module: orchestrates many real walk-forward runs vs a baseline; no decision/risk logic. |
| New Phase 9 | `tests/phase9_fixtures.py`, `tests/test_phase9_walk_forward_robust_validation.py` (32), `tests/test_phase9_robustness_adversarial.py` (27) | Test-first suites. |
| Docs | `PHASE9_FINAL_REPORT.md`, `CHECKPOINT_STATUS.md` | This report / checkpoint. |

Untouched by design: `data_quality.py`, `schemas/*`, `replay_engine.py`, `multi_horizon_replay.py`, `warmup.py`, `resampling.py`, `performance.py`, all engines, decision, risk.

## 2. Priorities: decision and evidence

1. **Fold validity** — done. Every fold has a deterministic `FoldAudit` (boundaries, status BLOCKED / VALID_NO_TRADES / VALID_NO_CLOSED_TRADES / VALID_WITH_CLOSED_TRADES, blocking types, warnings, counts). Blocked folds are counted and explained, never removed, and never enter any trade metric (tested even against a forged result carrying trades).
2. **Warmup** — done. `train_bars >= required_warmup_bars(template)` for ROLLING and EXPANDING; the number comes from `validation/warmup.py`, not a constant. Rationale: the first fold has the smallest warmup window in both modes. A fold-level `INSUFFICIENT_WARMUP` is treated as BLOCKED *at the walk-forward layer* while the Phase 7 data-quality contract (non-blocking) is unchanged.
3. **Overlap** — chosen: **fail closed**. In this runner each fold re-simulates its test bars from scratch, so overlapping windows have no valid meaning and would double-count trades. `step > test` is allowed and made visible (`total_test_bars`).
4. **Fold metrics** — done via `performance.calculate_performance_metrics` (no duplicated metric code); cross-checked against independent hand calculation (PnL, win rate, profit factor, expectancy, max drawdown, fold consistency, stdev). Undefined values are `None` with reasons, not zeros. *Note:* the legacy field `total_pnl` still returns `0` for no trades (Phase 8 contract); `pooled_performance.total_pnl` is `None`.
5. **Robustness layer** — `validation/robustness.py`: window / step / train:test proportion / horizon subset / config variant / stress-fixture scenarios, compared to a baseline. Invalid variants are returned as `RejectedVariant` with the exact reason (never dropped). Bars-overriding scenarios must declare an `evidence_class`. Flags follow a stated rule (sign flip, or relative PnL change above a caller threshold; non-evaluable scenarios also flagged) and are descriptive, not verdicts.
6. **Adversarial** — four existing checks kept. Added only real gaps (see §3 findings F1, F2, F4).
7. **Malformed timestamp** — *correct fail-closed behaviour, no change.* `OHLCVBar.__post_init__` (Phase 1 schema) raises `SchemaValidationError` at construction, so a malformed bar cannot exist as an object and never reaches the data-quality gate; the failure is named, deterministic and happens at the ingestion boundary. Locked by tests.
8. **ABNORMAL_GAP** — *contract kept non-blocking.* It is reflected per fold in `warning_issue_counts` and in the aggregate, and never blocks a fold.
9. **END_OF_REPLAY_WINDOW** — *contract kept* (state `FINAL_EXIT`, PnL counted). Now traced in `forced_close_trade_ids` / `forced_close_trade_count` and stated in the limitations.
10. **calculated_at** — not altered. Determinism tests compare everything except the wall-clock-derived fields (see F1).

## 3. Findings (real, reproduced)

- **F1 — `candidate_id`/`decision_id` are not reproducible with real engines.** `decision_bridge` hashes the engine's wall-clock `calculated_at` into `candidate_id`; `decision_id` derives from it. Two runs on identical input differ on exactly these two fields (verified: count, order, `trade_id`, `rejection_detail` and every other field matched). Phase 8 tests never saw it because they pin `calculated_at` via a mock. `trade_id` is content-derived and reproducible. Not changed (Phase 7/8 frozen, engine code); documented in `WALK_FORWARD_LIMITATIONS`; excluded from comparisons. **Note:** the Phase 8 report's claim that all identifiers are content-derived holds for `trade_id` only.
- **F2 — `check_look_ahead_leakage` false-positives on real engines** (root cause: F1; on 30 real trades it flagged all 30 even when only genuine later bars were appended). Minimal additive fix: opt-in `exclude_wall_clock_ids=True`. The default is unchanged, so Phase 8 behaviour and tests are preserved; **callers using real engines must pass the flag** (a test locks the old default behaviour).
- **F3 — four Phase 8 tests were vacuous** (found by instrumenting every replay: zero closed trades): `test_real_engine_reports_no_leak`, `TestDeterminism.test_repeated_full_run_is_byte_identical`, `TestLookAheadProtection.test_extra_trailing_bars_never_change_earlier_folds_results`, `TestFoldIndependence.test_every_fold_uses_the_templates_initial_capital_fresh_not_compounded`. Fixed by firing a fixed-clock candidate that produces real closed trades and adding `>= 3 closed trades` preconditions; assertions were not weakened, production untouched. Root cause behind the first: its "future" bars restarted at `T0` (duplicate timestamps), so run B was silently data-quality-blocked — hidden by the zero-trade vacuity; the fixture now continues chronologically. Remaining zero-trade tests in the audited files are intentional (zero-baseline sensitivity, clean/blocked structural cases, period-split structure).
- **F4 — a "no leak" result with fewer than 2 compared trades passed silently.** Now reported `vacuous=True`.
- **F5 — `EXPANDING` ≈ `ROLLING` for decisions.** Replay windows are capped at `max_lookback_bars`, so with `train_bars >=` requirement both modes produce identical trades (tested; documented). EXPANDING differs only in the audited train-window size.
- **F6 (observation, not investigated, not changed).** In the synthetic fixture with the loosened `RiskPolicy`, 23 of 32 closed trades exit `STOP_LOSS` with `exit price == entry fill == stop_loss` (PnL 0.0). Reproduce: `oscillating_bars(700, seed=1)`, `wf_config()`, inspect closed trades. It may be an interaction of the fixture, the loosened policy (`max_exposure_pct=100000`) and entry-zone/stop geometry, or a real Phase 6/7 defect; it needs its own reproduce → root-cause pass before any change. Metric tests therefore use a second dataset (`seed=11`) that yields both wins and losses.

## 4. Test evidence
- Test-first: suites written before production; initially failed with ImportError.
- 59 new tests use real, unmocked engines on SYNTHETIC fixtures; each proves its behaviour occurred (≥3 real closed trades; real blocked folds; positive controls for mutation; stub call-counts for exceptions).
- Mutation check on a scratch copy: 10 deliberate production breaks (overlap check, warmup check, blocked folds in aggregate, warmup usability, forced-close trace, future-leaking slice, mutation-check diff recording, sign-flip logic, vacuous flag, silent dropping of rejected variants) — **10/10 killed**.
- Regression order after changes: targeted → affected modules → Phase 7 (96) → Phase 8 (103) → full (650). All green.

## 5. Limitations (explicit)
- Not statistical proof; folds/variants sharing bars are correlated re-uses of one history.
- No fitted model exists, so classic overfitting cannot occur or be measured; what is checked is leakage, cross-window stability, configuration/window sensitivity and fail-closed behaviour.
- No real market dataset exists in the project: regime and stress tests use labelled synthetic fixtures and are **not market evidence**. Regime-, liquidity- and volatility-conditioned validation on real data is **not done** and needs real data (Phase 11).
- Pooled drawdown is over an additive PnL series of fresh-capital folds, not one continuous account.
- Forced closes at fold ends truncate outcomes; folds are index-based, not equal wall-clock spans, when data has gaps; step > test leaves untested bars.
- Speed: a full run takes ~38 s (correctness over performance; no caching added).

## 6. Freeze and next step
Baseline for Phase 10: `MERWIS_AI_PHASE9_FINAL.zip`. Open items for the owner: F6 investigation; whether to make `exclude_wall_clock_ids=True` the default in a future phase; whether to stamp a deterministic clock into engine candidates (would remove F1 at the source). Nothing of Phase 10 (scanner, live hunter, notifications) was written.
