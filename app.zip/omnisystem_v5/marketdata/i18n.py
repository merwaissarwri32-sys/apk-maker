"""Localization boundary - MERWIS AI, Phase 11.

The data/trading core is LANGUAGE-NEUTRAL: it only ever produces StructuredMessage
(a MessageKey plus named parameters). Turning that into user-facing text is a
presentation concern done by a MessageCatalog. Right-to-left layout and numeral
shaping (Persian) are presentation-layer concerns and deliberately absent here.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Protocol


class MessageKey(str, Enum):
    DATA_UNKNOWN_INSTRUMENT = "data.unknown_instrument"
    DATA_UNMAPPED_INSTRUMENT = "data.unmapped_instrument"
    DATA_UNSUPPORTED_TIMEFRAME = "data.unsupported_timeframe"
    DATA_INVALID_REQUEST = "data.invalid_request"
    DATA_NO_PROVIDER = "data.no_provider"
    DATA_PROVIDER_BLOCKED = "data.provider_blocked"
    DATA_NO_BARS = "data.no_bars"
    DATA_PAYLOAD_MALFORMED = "data.payload_malformed"
    DATA_ECHO_MISMATCH = "data.echo_mismatch"
    DATA_NON_FINITE = "data.non_finite"
    DATA_NON_POSITIVE_PRICE = "data.non_positive_price"
    DATA_NEGATIVE_VOLUME = "data.negative_volume"
    DATA_OHLC_INVALID = "data.ohlc_invalid"
    DATA_TIMESTAMP_INVALID = "data.timestamp_invalid"
    DATA_TIMESTAMP_MISALIGNED = "data.timestamp_misaligned"
    DATA_BAR_DURATION_INVALID = "data.bar_duration_invalid"
    DATA_DUPLICATE_BAR = "data.duplicate_bar"
    DATA_OUT_OF_ORDER = "data.out_of_order"
    DATA_GAP = "data.gap"
    DATA_SESSION_GAP = "data.session_gap"
    DATA_FUTURE_BAR = "data.future_bar"
    DATA_FORMING_BAR = "data.forming_bar"
    DATA_FORMING_BAR_DROPPED = "data.forming_bar_dropped"
    DATA_MALFORMED_BAR_DROPPED = "data.malformed_bar_dropped"
    DATA_SESSION_GAP_TRUNCATED = "data.session_gap_truncated"
    DATA_MALFORMED_BAR_LIMIT = "data.malformed_bar_limit"
    DATA_INSUFFICIENT_BARS = "data.insufficient_bars"
    DATA_STALE = "data.stale"
    DATA_EXPIRED = "data.expired"
    PROVIDER_HEALTHY = "provider.healthy"
    PROVIDER_DEGRADED = "provider.degraded"
    PROVIDER_THROTTLED = "provider.throttled"
    PROVIDER_UNAVAILABLE = "provider.unavailable"
    PROVIDER_AUTH_FAILURE = "provider.auth_failure"
    PROVIDER_RECOVERING = "provider.recovering"
    INSTRUMENT_DISABLED = "instrument.disabled"
    INSTRUMENT_SESSION_CLOSED = "instrument.session_closed"
    INSTRUMENT_QUARANTINED = "instrument.quarantined"
    INSTRUMENT_DEGRADED = "instrument.degraded"
    INSTRUMENT_NO_PROVIDER = "instrument.no_provider"
    INSTRUMENT_PROVIDER_UNAVAILABLE = "instrument.provider_unavailable"
    INSTRUMENT_INTERNAL_ERROR = "instrument.internal_error"
    QUOTE_INVALID = "quote.invalid"
    QUOTE_CROSSED = "quote.crossed"
    QUOTE_STALE = "quote.stale"
    STREAM_UPDATE_OUT_OF_ORDER = "stream.update_out_of_order"
    STREAM_UPDATE_MALFORMED = "stream.update_malformed"
    SYSTEM_INTERNAL_ERROR = "system.internal_error"


def _fmt(value) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        return "nan" if math.isnan(value) else repr(round(value, 6))
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value)


@dataclass(frozen=True)
class StructuredMessage:
    """Language-neutral message: key + sorted ((name, value-as-text), ...)."""
    key: MessageKey
    params: tuple = ()

    def reason_str(self) -> str:
        """Machine-readable, language-neutral one-liner (used where a plain str is required)."""
        return " ".join([self.key.value, *(f"{k}={v}" for k, v in self.params)])


def msg(key: MessageKey, **params) -> StructuredMessage:
    return StructuredMessage(key, tuple(sorted((k, _fmt(v)) for k, v in params.items())))


_TAG = re.compile(r"^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$")


@dataclass(frozen=True)
class Locale:
    tag: str

    def __post_init__(self):
        if not isinstance(self.tag, str) or not _TAG.match(self.tag):
            raise ValueError(f"invalid locale tag {self.tag!r}")

    @property
    def language(self) -> str:
        return self.tag.split("-")[0]


EN = Locale("en")
FA = Locale("fa")


@dataclass(frozen=True)
class LocalizedMessage:
    message: StructuredMessage
    locale: Locale
    text: str
    fallback: bool = False      # True: no template was usable, `text` is the neutral reason string


class MessageCatalog(Protocol):
    def render(self, message: StructuredMessage, locale: Locale) -> LocalizedMessage: ...


class InMemoryCatalog:
    """tables: language tag -> {MessageKey: template using {param} placeholders}.
    Fallback chain (deterministic): exact tag -> language -> default language -> neutral reason string."""

    def __init__(self, tables: dict, default_language: str = "en"):
        self._tables = {k.lower(): dict(v) for k, v in tables.items()}
        self._default = default_language.lower()

    def render(self, message: StructuredMessage, locale: Locale) -> LocalizedMessage:
        params = dict(message.params)
        chain = []
        for tag in (locale.tag.lower(), locale.language.lower(), self._default):
            if tag not in chain:
                chain.append(tag)
        for tag in chain:
            template = self._tables.get(tag, {}).get(message.key)
            if template is None:
                continue
            try:
                text = template.format_map(params)
            except (KeyError, IndexError, ValueError):
                continue
            return LocalizedMessage(message, locale, text, fallback=(tag != locale.tag.lower() and tag != locale.language.lower()))
        return LocalizedMessage(message, locale, message.reason_str(), fallback=True)


def default_catalog() -> InMemoryCatalog:
    from omnisystem_v5.marketdata.catalog_en import MESSAGES as en
    from omnisystem_v5.marketdata.catalog_fa import MESSAGES as fa
    return InMemoryCatalog({"en": en, "fa": fa})
