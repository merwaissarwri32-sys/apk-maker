"""Persian (fa) message catalog.

STATUS: authored without native-speaker review - to be reviewed before user-facing release.
Placeholders are identical to the English catalog (enforced by a test). Digits stay ASCII in
the core; numeral shaping and RTL layout belong to the presentation layer.
"""
from omnisystem_v5.marketdata.i18n import MessageKey as K

REVIEWED_BY_NATIVE_SPEAKER = False

MESSAGES = {
    K.DATA_UNKNOWN_INSTRUMENT: "ابزار معاملاتی ناشناخته: {symbol}",
    K.DATA_UNMAPPED_INSTRUMENT: "برای {symbol} نگاشت نمادِ ارائه‌دهنده تعریف نشده است",
    K.DATA_UNSUPPORTED_TIMEFRAME: "تایم‌فریم {timeframe} برای {symbol} پشتیبانی نمی‌شود",
    K.DATA_INVALID_REQUEST: "درخواست داده نامعتبر است: {detail}",
    K.DATA_NO_PROVIDER: "هیچ ارائه‌دهندهٔ داده‌ای برای {symbol} در تایم‌فریم {timeframe} در دسترس نیست",
    K.DATA_PROVIDER_BLOCKED: "ارائه‌دهندهٔ {provider} در وضعیت {state} است و درخواستی ارسال نشد",
    K.DATA_NO_BARS: "هیچ کندلی برای {symbol} در تایم‌فریم {timeframe} دریافت نشد",
    K.DATA_PAYLOAD_MALFORMED: "ساختار پاسخ ارائه‌دهنده نامعتبر است: {detail}",
    K.DATA_ECHO_MISMATCH: "ناهماهنگی در {field}: مورد انتظار {expected}، دریافتی {actual}",
    K.DATA_NON_FINITE: "عدد نامتناهی یا نامعتبر در فیلد {field} (ردیف {index})",
    K.DATA_NON_POSITIVE_PRICE: "قیمت غیرمثبت در فیلد {field} (ردیف {index})",
    K.DATA_NEGATIVE_VOLUME: "حجم منفی یا نامعتبر (ردیف {index})",
    K.DATA_OHLC_INVALID: "رابطهٔ OHLC نامعتبر (ردیف {index}): {detail}",
    K.DATA_TIMESTAMP_INVALID: "زمان نامعتبر یا بدون منطقهٔ زمانی در فیلد {field} (ردیف {index})",
    K.DATA_TIMESTAMP_MISALIGNED: "زمان شروع کندل با مرز تایم‌فریم {timeframe} هم‌تراز نیست (ردیف {index})",
    K.DATA_BAR_DURATION_INVALID: "مدت کندل با تایم‌فریم {timeframe} سازگار نیست (ردیف {index})",
    K.DATA_DUPLICATE_BAR: "کندل تکراری (ردیف {index})",
    K.DATA_OUT_OF_ORDER: "کندل خارج از ترتیب زمانی (ردیف {index})",
    K.DATA_GAP: "شکاف در دادهٔ کندل (ردیف {index}، {seconds} ثانیه)",
    K.DATA_SESSION_GAP: "شکاف نشست معاملاتی در دادهٔ کندل (ردیف {index}، {seconds} ثانیه)؛ کندل‌ها هرگز پر یا فشرده نمی‌شوند",
    K.DATA_FUTURE_BAR: "کندل با زمان آینده (ردیف {index})",
    K.DATA_FORMING_BAR: "پاسخ شامل کندلِ در حال شکل‌گیری است (ردیف {index})",
    K.DATA_FORMING_BAR_DROPPED: "{count} کندل در حال شکل‌گیری حذف شد",
    K.DATA_MALFORMED_BAR_DROPPED: "{count} کندل ناقص در محدودهٔ تحمل تنظیم‌شده حذف شد",
    K.DATA_SESSION_GAP_TRUNCATED: "دادهٔ پیش از آخرین شکاف نشست معاملاتی کنار گذاشته شد ({dropped} کندل)",
    K.DATA_MALFORMED_BAR_LIMIT: "تعداد کندل‌های ناقص ({count}) از حد مجاز ({limit}) بیشتر است",
    K.DATA_INSUFFICIENT_BARS: "تعداد کندل‌ها کافی نیست: {have} از {need}",
    K.DATA_STALE: "داده کهنه است: {age_seconds} ثانیه (حد مجاز {limit_seconds})",
    K.DATA_EXPIRED: "داده منقضی شده است: {age_seconds} ثانیه (حد مجاز {limit_seconds})",
    K.PROVIDER_HEALTHY: "ارائه‌دهنده سالم است",
    K.PROVIDER_DEGRADED: "ارائه‌دهنده دچار افت کیفیت است ({failures} خطای متوالی)",
    K.PROVIDER_THROTTLED: "ارائه‌دهنده تا {until} محدودیت نرخ اعمال کرده است",
    K.PROVIDER_UNAVAILABLE: "ارائه‌دهنده در دسترس نیست ({failures} خطای متوالی)",
    K.PROVIDER_AUTH_FAILURE: "احراز هویت ارائه‌دهنده ناموفق بود؛ نیازمند اقدام اپراتور",
    K.PROVIDER_RECOVERING: "ارائه‌دهنده در حال بازیابی است ({successes} از {needed})",
    K.INSTRUMENT_DISABLED: "ابزار غیرفعال است",
    K.INSTRUMENT_SESSION_CLOSED: "وضعیت بازار: {status}",
    K.INSTRUMENT_QUARANTINED: "ابزار تا {until} در قرنطینه است",
    K.INSTRUMENT_DEGRADED: "کیفیت دادهٔ ابزار افت کرده است ({failures} خطای متوالی)",
    K.INSTRUMENT_NO_PROVIDER: "برای تایم‌فریم {timeframe} هیچ ارائه‌دهنده‌ای پیکربندی نشده است",
    K.INSTRUMENT_PROVIDER_UNAVAILABLE: "ارائه‌دهندهٔ تایم‌فریم {timeframe} فعلاً در دسترس نیست",
    K.INSTRUMENT_INTERNAL_ERROR: "خطای داخلی هنگام ارزیابی ابزار: {detail}",
    K.QUOTE_INVALID: "قیمت لحظه‌ای نامعتبر: {detail}",
    K.QUOTE_CROSSED: "قیمت‌های خرید و فروش متقاطع‌اند (bid={bid}، ask={ask})",
    K.QUOTE_STALE: "قیمت لحظه‌ای کهنه است: {age_seconds} ثانیه (حد مجاز {limit_seconds})",
    K.STREAM_UPDATE_OUT_OF_ORDER: "به‌روزرسانی جریانیِ خارج از ترتیب رد شد (شمارهٔ {sequence}، آخرین {last})",
    K.STREAM_UPDATE_MALFORMED: "به‌روزرسانی جریانیِ نامعتبر رد شد: {detail}",
    K.SYSTEM_INTERNAL_ERROR: "خطای داخلی سامانه: {detail}",
}
