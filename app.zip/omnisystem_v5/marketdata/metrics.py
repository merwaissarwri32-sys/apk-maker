"""Ingestion metrics - MERWIS AI, Phase 11. A sink that folds events into deterministic counters."""
from __future__ import annotations

from dataclasses import dataclass

from omnisystem_v5.marketdata.events import DataEventKind


@dataclass(frozen=True)
class IngestionMetrics:
    ingested: int = 0
    accepted: int = 0
    rejected: int = 0
    stale: int = 0
    retries: int = 0
    rate_limited: int = 0
    local_throttled: int = 0
    reconnect_attempts: int = 0
    recoveries: int = 0
    stream_updates_rejected: int = 0
    quotes_accepted: int = 0
    quotes_rejected: int = 0
    provider_errors: tuple = ()          # ((failure class, count), ...)
    rejected_by_reason: tuple = ()       # ((reason key, count), ...)
    latency_count: int = 0
    latency_total_seconds: float = 0.0
    latency_max_seconds: float = 0.0


def _detail(event, name, default=None):
    for k, v in event.detail:
        if k == name:
            return v
    return default


class MetricsSink:
    def __init__(self):
        self._c: dict = {}
        self._errors: dict = {}
        self._reasons: dict = {}
        self._lat_n, self._lat_total, self._lat_max = 0, 0.0, 0.0

    def _inc(self, name):
        self._c[name] = self._c.get(name, 0) + 1

    def emit(self, event) -> None:
        k = event.kind
        if k == DataEventKind.DATA_INGESTED:
            self._inc("ingested")
            if _detail(event, "status") == "OK":
                self._inc("accepted")
            lat = _detail(event, "latency_seconds")
            if isinstance(lat, (int, float)):
                self._lat_n += 1
                self._lat_total += float(lat)
                self._lat_max = max(self._lat_max, float(lat))
        elif k == DataEventKind.DATA_REJECTED:
            self._inc("rejected")
            reason = str(_detail(event, "reason", "unknown"))
            self._reasons[reason] = self._reasons.get(reason, 0) + 1
        elif k == DataEventKind.DATA_STALE:
            self._inc("stale")
        elif k == DataEventKind.PROVIDER_ERROR:
            cls = str(_detail(event, "failure_class", "unknown"))
            self._errors[cls] = self._errors.get(cls, 0) + 1
        else:
            name = {DataEventKind.RETRY_ATTEMPT: "retries", DataEventKind.RATE_LIMITED: "rate_limited",
                    DataEventKind.LOCAL_THROTTLED: "local_throttled", DataEventKind.RECONNECT_ATTEMPT: "reconnect_attempts",
                    DataEventKind.RECOVERY: "recoveries", DataEventKind.STREAM_UPDATE_REJECTED: "stream_updates_rejected",
                    DataEventKind.QUOTE_ACCEPTED: "quotes_accepted", DataEventKind.QUOTE_REJECTED: "quotes_rejected"}.get(k)
            if name:
                self._inc(name)

    def snapshot(self) -> IngestionMetrics:
        return IngestionMetrics(**self._c, provider_errors=tuple(sorted(self._errors.items())),
                                rejected_by_reason=tuple(sorted(self._reasons.items())), latency_count=self._lat_n,
                                latency_total_seconds=round(self._lat_total, 9), latency_max_seconds=round(self._lat_max, 9))
