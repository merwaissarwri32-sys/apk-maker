"""Bounded retry / backoff / client-side throttle - MERWIS AI, Phase 11.

* Attempts are bounded by RetryPolicy.max_attempts (default 1: no hidden retries).
* Backoff is exponential and capped; jitter is DETERMINISTIC (SHA-256 of seed|key|attempt).
* Sleep and timer are injected; this module never touches the wall clock.
* Rate limits are not waited on unless rate_limit_max_wait_seconds > 0, and never beyond it.
* Auth failures are never retried.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable, Protocol

from omnisystem_v5.marketdata.config import RetryPolicy, ThrottlePolicy
from omnisystem_v5.marketdata.events import DataEventKind, emit
from omnisystem_v5.marketdata.provider import ProviderAuthError
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError, classify_fetch_exception

Sleep = Callable[[float], None]


class Timer(Protocol):
    def now(self) -> float: ...


class NullTimer:
    """Deterministic default: every latency measures as 0.0 s."""
    def now(self) -> float:
        return 0.0


def jitter_unit(seed: int, key: str, attempt: int) -> float:
    """Deterministic value in [-1, 1)."""
    h = hashlib.sha256(f"{seed}|{key}|{attempt}".encode("utf-8")).digest()
    return int.from_bytes(h[:8], "big") / 2 ** 63 - 1.0


def compute_delay(policy: RetryPolicy, key: str, attempt: int) -> float:
    """Delay before attempt+1, after `attempt` failed (attempt >= 1)."""
    base = min(policy.max_delay_seconds, policy.base_delay_seconds * policy.multiplier ** (attempt - 1))
    delay = base * (1.0 + policy.jitter_fraction * jitter_unit(policy.jitter_seed, key, attempt))
    return max(0.0, min(policy.max_delay_seconds, delay))


@dataclass(frozen=True)
class RetryTrace:
    attempts: int
    delays: tuple = ()
    failure_classes: tuple = ()      # FailureClass per failed attempt


@dataclass(frozen=True)
class RetryOutcome:
    value: object
    error: Exception | None
    trace: RetryTrace


class RetryExecutor:
    def __init__(self, policy: RetryPolicy, sleep: Sleep, sink=None):
        self._p, self._sleep, self._sink = policy, sleep, sink

    def execute(self, fn: Callable, key: str, now: datetime | None = None) -> RetryOutcome:
        attempt, delays, classes = 0, [], []
        while True:
            attempt += 1
            try:
                value = fn()
                return RetryOutcome(value, None, RetryTrace(attempt, tuple(delays), tuple(classes)))
            except Exception as exc:               # classified below; never swallowed - returned in the outcome
                cls = FailureClass.PROVIDER_UNAVAILABLE if isinstance(exc, ProviderAuthError) else classify_fetch_exception(exc)
                classes.append(cls)
                wait = self._wait_for(exc, cls, key, attempt)
                if wait is None:
                    return RetryOutcome(None, exc, RetryTrace(attempt, tuple(delays), tuple(classes)))
                delays.append(wait)
                emit(self._sink, DataEventKind.RETRY_ATTEMPT, now, key, attempt=attempt, delay_seconds=wait, failure_class=cls)
                self._sleep(wait)

    def _wait_for(self, exc, cls, key, attempt):
        if attempt >= self._p.max_attempts or isinstance(exc, ProviderAuthError):
            return None
        if isinstance(exc, ProviderRateLimitedError):
            after = exc.retry_after_seconds
            if self._p.rate_limit_max_wait_seconds > 0 and after is not None and 0 <= after <= self._p.rate_limit_max_wait_seconds:
                return float(after)
            return None
        if cls in self._p.retry_on:
            return compute_delay(self._p, key, attempt)
        return None


class Throttle:
    """Sliding-window request limiter driven by the injected clock (explicit state, no globals)."""

    def __init__(self, policy: ThrottlePolicy):
        self._p = policy
        self._stamps: list = []

    def try_acquire(self, now: datetime):
        """(True, None) and records the request, or (False, retry_after_seconds)."""
        if self._p.max_requests is None:
            return True, None
        horizon = now - timedelta(seconds=self._p.per_seconds)
        self._stamps = [t for t in self._stamps if t > horizon]
        if len(self._stamps) >= self._p.max_requests:
            oldest = self._stamps[0]
            return False, max(0.0, (oldest + timedelta(seconds=self._p.per_seconds) - now).total_seconds())
        self._stamps.append(now)
        return True, None
