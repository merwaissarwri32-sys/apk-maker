"""Provider boundary - MERWIS AI, Phase 11.

Vendor JSON never crosses this boundary. An adapter converts vendor payloads into RawBars /
RawQuote (primitive-typed, provider-agnostic); the core then normalizes strictly. The timeframe is
always the REQUESTED one - it is never inferred from a payload. Timestamps must arrive as
timezone-aware datetimes or ISO-8601 strings with an offset: epoch integers are refused in the
core because their unit (s / ms) would have to be guessed - adapters convert explicitly.

Adapter failures reuse the existing taxonomy: ProviderRateLimitedError, TimeoutError,
DataUnavailableError, ConnectionError. Two thin subclasses exist only so those types can carry
extra meaning through the UNCHANGED classify_fetch_exception():
  ProviderAuthError    (a DataUnavailableError)  -> PROVIDER_UNAVAILABLE, never retried
  ProviderPayloadError (a ValueError)            -> MALFORMED_RESPONSE
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.assets import AssetClass
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe


class ProviderAuthError(DataUnavailableError):
    """Credentials rejected. Not retryable; needs operator action."""


class ProviderPayloadError(ValueError):
    """The response is structurally unusable (wrong shape, wrong echo)."""


class EvidenceLevel(str, Enum):
    """What has actually been demonstrated about an adapter. Never inferred; declared statically."""
    IMPLEMENTED = "IMPLEMENTED"
    TESTED = "TESTED"
    LIVE_CONNECTED = "LIVE_CONNECTED"
    OBSERVED = "OBSERVED"
    VALIDATED_IN_PRODUCTION = "VALIDATED_IN_PRODUCTION"


LIVE_CLAIMS = frozenset({EvidenceLevel.LIVE_CONNECTED, EvidenceLevel.OBSERVED, EvidenceLevel.VALIDATED_IN_PRODUCTION})


@dataclass(frozen=True)
class ProviderCapabilities:
    asset_classes: frozenset
    timeframes: frozenset
    declared_origin: DataOrigin
    live_capable: bool = False
    supports_quotes: bool = False
    supports_streaming: bool = False
    venues: frozenset = frozenset()          # empty = any venue
    evidence: EvidenceLevel = EvidenceLevel.IMPLEMENTED

    def __post_init__(self):
        if not self.asset_classes or not all(isinstance(a, AssetClass) for a in self.asset_classes):
            raise ValueError("asset_classes must be a non-empty set of AssetClass")
        if not self.timeframes or not all(isinstance(t, Timeframe) for t in self.timeframes):
            raise ValueError("timeframes must be a non-empty set of Timeframe")
        if self.declared_origin == DataOrigin.LIVE and not self.live_capable:
            raise ValueError("only a live_capable adapter may declare DataOrigin.LIVE")
        if self.declared_origin == DataOrigin.UNAVAILABLE:
            raise ValueError("a provider cannot declare origin UNAVAILABLE")


@dataclass(frozen=True)
class BarRequest:
    provider_symbol: str
    timeframe: Timeframe
    limit: int

    def __post_init__(self):
        if not isinstance(self.provider_symbol, str) or not self.provider_symbol:
            raise ValueError("provider_symbol must be a non-empty string")
        if not isinstance(self.timeframe, Timeframe):
            raise ValueError("timeframe must be a Timeframe")
        if isinstance(self.limit, bool) or not isinstance(self.limit, int) or self.limit < 1:
            raise ValueError("limit must be an int >= 1")


@dataclass(frozen=True)
class RawBarRow:
    open: Any
    high: Any
    low: Any
    close: Any
    volume: Any
    open_time: Any
    close_time: Any


@dataclass(frozen=True)
class RawBars:
    provider_name: str
    provider_symbol: str
    rows: tuple
    timeframe: Timeframe | None = None     # echo, only if the provider states it; cross-checked, never trusted alone
    sequence: int | None = None


@dataclass(frozen=True)
class RawQuote:
    provider_name: str
    provider_symbol: str
    timestamp: Any
    bid: Any = None
    ask: Any = None
    last: Any = None
    sequence: int | None = None


class MarketDataProvider(Protocol):
    name: str

    @property
    def capabilities(self) -> ProviderCapabilities: ...

    def fetch_bars(self, request: BarRequest) -> RawBars: ...

    def fetch_quote(self, provider_symbol: str) -> RawQuote: ...     # only if capabilities.supports_quotes


@dataclass(frozen=True)
class TransportRequest:
    method: str
    path: str
    params: tuple = ()                 # ((name, value), ...) - no secrets are ever placed here by core code
    timeout_seconds: float = 10.0


@dataclass(frozen=True)
class TransportResponse:
    status: int
    body: str
    headers: tuple = field(default_factory=tuple)     # ((name, value), ...)


class Transport(Protocol):
    """The ONLY thing a real adapter uses to reach a network. Implementations live outside the core."""
    def request(self, request: TransportRequest) -> TransportResponse: ...


class CredentialSource(Protocol):
    """Secure configuration boundary: credentials are injected, never stored in config or code."""
    def get(self, name: str) -> str | None: ...
