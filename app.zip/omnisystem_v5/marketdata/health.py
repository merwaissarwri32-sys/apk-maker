"""Health state machines - MERWIS AI, Phase 11. Pure transition functions + an explicit registry.

Provider states describe the provider as a whole. Only PROVIDER-scope faults (timeouts, outages,
structural payload errors, rate limits, auth) move them; one symbol's bad bars never do. Time enters
only as the `now` argument (the injected clock). The directive's cause labels (TIMEOUT, RATE_LIMITED,
INVALID_RESPONSE, AUTH_FAILURE) are carried as `last_failure_class` (the existing FailureClass) plus a
reason MessageKey; CONNECTED is a transport property and STALE a per-stream freshness state.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

from omnisystem_v5.marketdata.config import InstrumentHealthPolicy, ProviderHealthPolicy
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import StructuredMessage, msg
from omnisystem_v5.scanner.failures import FailureClass
from omnisystem_v5.validation.resampling import seconds_for_timeframe


class ProviderState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    THROTTLED = "THROTTLED"
    UNAVAILABLE = "UNAVAILABLE"
    RECOVERING = "RECOVERING"


class ObsKind(str, Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    RATE_LIMITED = "RATE_LIMITED"
    AUTH_FAILURE = "AUTH_FAILURE"


@dataclass(frozen=True)
class ProviderObservation:
    kind: ObsKind
    failure_class: FailureClass | None = None
    retry_after_seconds: float | None = None


@dataclass(frozen=True)
class ProviderHealth:
    provider: str
    state: ProviderState
    since: datetime
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    outage_episodes: int = 0
    last_failure_class: FailureClass | None = None
    reason: StructuredMessage | None = None
    next_attempt_at: datetime | None = None
    requires_operator: bool = False


def initial_provider_health(provider: str, now: datetime) -> ProviderHealth:
    return ProviderHealth(provider, ProviderState.HEALTHY, now, reason=msg(K.PROVIDER_HEALTHY))


def _cooldown(policy: ProviderHealthPolicy, episodes: int) -> timedelta:
    secs = min(policy.cooldown_max_seconds, policy.cooldown_base_seconds * policy.cooldown_multiplier ** max(0, episodes - 1))
    return timedelta(seconds=secs)


def next_provider_state(h: ProviderHealth, obs: ProviderObservation, now: datetime, policy: ProviderHealthPolicy) -> ProviderHealth:
    if obs.kind == ObsKind.SUCCESS:
        return _on_success(h, now, policy)
    if obs.kind == ObsKind.RATE_LIMITED:
        wait = obs.retry_after_seconds if obs.retry_after_seconds is not None and obs.retry_after_seconds > 0 else policy.throttle_default_seconds
        until = now + timedelta(seconds=wait)
        return dataclasses.replace(
            h, state=ProviderState.THROTTLED, since=now if h.state != ProviderState.THROTTLED else h.since,
            consecutive_successes=0, last_failure_class=FailureClass.PROVIDER_RATE_LIMITED,
            reason=msg(K.PROVIDER_THROTTLED, until=until), next_attempt_at=until, requires_operator=False)
    if obs.kind == ObsKind.AUTH_FAILURE:
        return dataclasses.replace(
            h, state=ProviderState.UNAVAILABLE, since=now if h.state != ProviderState.UNAVAILABLE else h.since,
            consecutive_failures=h.consecutive_failures + 1, consecutive_successes=0,
            outage_episodes=h.outage_episodes + 1, last_failure_class=FailureClass.PROVIDER_UNAVAILABLE,
            reason=msg(K.PROVIDER_AUTH_FAILURE), next_attempt_at=None, requires_operator=True)
    return _on_failure(h, obs, now, policy)


def _on_success(h, now, policy):
    if h.state == ProviderState.HEALTHY:
        return dataclasses.replace(h, consecutive_failures=0, consecutive_successes=0)
    n = h.consecutive_successes + 1 if h.state == ProviderState.RECOVERING else 1
    if n >= policy.recover_successes:
        return ProviderHealth(h.provider, ProviderState.HEALTHY, now, reason=msg(K.PROVIDER_HEALTHY))
    return dataclasses.replace(
        h, state=ProviderState.RECOVERING, since=now if h.state != ProviderState.RECOVERING else h.since,
        consecutive_failures=0, consecutive_successes=n, reason=msg(K.PROVIDER_RECOVERING, successes=n, needed=policy.recover_successes),
        next_attempt_at=None, requires_operator=False)


def _on_failure(h, obs, now, policy):
    f = h.consecutive_failures + 1
    cls = obs.failure_class
    if h.state == ProviderState.HEALTHY:
        if f >= policy.degrade_after:
            return dataclasses.replace(h, state=ProviderState.DEGRADED, since=now, consecutive_failures=f, consecutive_successes=0,
                                       last_failure_class=cls, reason=msg(K.PROVIDER_DEGRADED, failures=f))
        return dataclasses.replace(h, consecutive_failures=f, last_failure_class=cls)
    if h.state in (ProviderState.DEGRADED, ProviderState.THROTTLED) and f < policy.unavailable_after:
        return dataclasses.replace(h, state=ProviderState.DEGRADED, since=h.since if h.state == ProviderState.DEGRADED else now,
                                   consecutive_failures=f, consecutive_successes=0, last_failure_class=cls,
                                   reason=msg(K.PROVIDER_DEGRADED, failures=f), next_attempt_at=None)
    episodes = h.outage_episodes + 1                   # DEGRADED/THROTTLED reaching the limit, RECOVERING, or a failed probe
    return dataclasses.replace(
        h, state=ProviderState.UNAVAILABLE, since=h.since if h.state == ProviderState.UNAVAILABLE else now,
        consecutive_failures=f, consecutive_successes=0, outage_episodes=episodes, last_failure_class=cls,
        reason=msg(K.PROVIDER_UNAVAILABLE, failures=f), next_attempt_at=now + _cooldown(policy, episodes), requires_operator=False)


def may_attempt(h: ProviderHealth, now: datetime) -> bool:
    """Fail-fast gate: a broken provider is not called again until its cooldown ends (then one probe)."""
    if h.state in (ProviderState.HEALTHY, ProviderState.DEGRADED, ProviderState.RECOVERING):
        return True
    if h.requires_operator or h.next_attempt_at is None:
        return False
    return now >= h.next_attempt_at


def retry_after_seconds(h: ProviderHealth, now: datetime) -> float | None:
    if h.next_attempt_at is None:
        return None
    return max(0.0, (h.next_attempt_at - now).total_seconds())


def operator_reset(h: ProviderHealth, now: datetime, policy: ProviderHealthPolicy) -> ProviderHealth:
    """Explicit human action after an auth failure: the provider must prove itself again."""
    return dataclasses.replace(h, state=ProviderState.RECOVERING, since=now, consecutive_failures=0, consecutive_successes=0,
                               reason=msg(K.PROVIDER_RECOVERING, successes=0, needed=policy.recover_successes),
                               next_attempt_at=None, requires_operator=False)


# ---- instrument health -------------------------------------------------------------------------

class InstrumentState(str, Enum):
    AVAILABLE = "AVAILABLE"
    DEGRADED = "DEGRADED"
    QUARANTINED = "QUARANTINED"
    UNAVAILABLE = "UNAVAILABLE"     # computed by the universe (session, mapping, providers); never stored here
    DISABLED = "DISABLED"           # computed by the universe from the catalog; never stored here


@dataclass(frozen=True)
class InstrumentHealth:
    symbol: str
    state: InstrumentState
    since: datetime
    consecutive_failures: int = 0
    quarantined_until: datetime | None = None
    reason: StructuredMessage | None = None


def next_instrument_state(h: InstrumentHealth | None, symbol: str, ok: bool, now: datetime,
                          policy: InstrumentHealthPolicy) -> InstrumentHealth:
    prev = h or InstrumentHealth(symbol, InstrumentState.AVAILABLE, now)
    if ok:
        if prev.state == InstrumentState.AVAILABLE and prev.consecutive_failures == 0:
            return prev
        return InstrumentHealth(symbol, InstrumentState.AVAILABLE, now)
    f = prev.consecutive_failures + 1
    if f >= policy.quarantine_after:
        until = now + timedelta(seconds=policy.quarantine_seconds)
        return InstrumentHealth(symbol, InstrumentState.QUARANTINED, now, f, until, msg(K.INSTRUMENT_QUARANTINED, until=until))
    if f >= policy.degrade_after:
        return InstrumentHealth(symbol, InstrumentState.DEGRADED, prev.since if prev.state == InstrumentState.DEGRADED else now, f, None,
                                msg(K.INSTRUMENT_DEGRADED, failures=f))
    return dataclasses.replace(prev, consecutive_failures=f)


def instrument_scannable(h: InstrumentHealth | None, now: datetime) -> bool:
    if h is None or h.state != InstrumentState.QUARANTINED:
        return True
    return h.quarantined_until is not None and now >= h.quarantined_until      # after the window: one probe


# ---- registry ----------------------------------------------------------------------------------

class HealthBook:
    """Explicit, injected, in-memory registry of health records. No globals; mutated only by its owner."""

    def __init__(self, provider_policy: ProviderHealthPolicy, instrument_policy: InstrumentHealthPolicy):
        self._pp, self._ip = provider_policy, instrument_policy
        self._providers: dict = {}
        self._instruments: dict = {}
        self._streams: dict = {}

    def provider(self, name: str, now: datetime) -> ProviderHealth:
        h = self._providers.get(name)
        if h is None:
            h = self._providers[name] = initial_provider_health(name, now)
        return h

    def observe_provider(self, name: str, obs: ProviderObservation, now: datetime) -> tuple:
        prev = self.provider(name, now)
        new = next_provider_state(prev, obs, now, self._pp)
        self._providers[name] = new
        return prev, new

    def reset_provider(self, name: str, now: datetime) -> tuple:
        prev = self.provider(name, now)
        new = operator_reset(prev, now, self._pp)
        self._providers[name] = new
        return prev, new

    def instrument(self, symbol: str) -> InstrumentHealth | None:
        return self._instruments.get(symbol)

    def observe_instrument(self, symbol: str, ok: bool, now: datetime) -> tuple:
        prev = self._instruments.get(symbol)
        new = next_instrument_state(prev, symbol, ok, now, self._ip)
        self._instruments[symbol] = new
        return prev, new

    def record_stream(self, stream) -> None:
        self._streams[(stream.symbol, stream.timeframe)] = stream

    def providers(self) -> tuple:
        return tuple(self._providers[k] for k in sorted(self._providers))

    def instruments(self) -> tuple:
        return tuple(self._instruments[k] for k in sorted(self._instruments))

    def streams(self) -> tuple:
        return tuple(self._streams[k] for k in sorted(self._streams, key=lambda k: (k[0], seconds_for_timeframe(k[1]))))
