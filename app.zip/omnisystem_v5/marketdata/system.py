"""The ONLY module in marketdata allowed to touch real time - MERWIS AI, Phase 11.

Controlled infrastructure boundary: a real sleep and a real monotonic timer for latency measurement.
Nothing here is used by default in deterministic logic (default retry never sleeps; default timer is
NullTimer). Wall-clock *datetimes* still come from the injected scanner Clock (SystemClock in production).
"""
from __future__ import annotations

import time


class SystemSleep:
    def __call__(self, seconds: float) -> None:
        if seconds > 0:
            time.sleep(seconds)


class MonotonicTimer:
    def now(self) -> float:
        return time.monotonic()
