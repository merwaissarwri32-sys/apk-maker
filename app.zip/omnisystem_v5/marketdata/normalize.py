"""Strict normalization: RawBarRow -> OHLCVBar candidates - MERWIS AI, Phase 11.

Complements (does not replace) data.normalization: refuses NaN / +-inf / booleans / naive
timestamps, and non-positive prices, none of which the frozen OHLCVBar rejects. Bad rows are
never patched; each yields a typed DataIssue.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal

from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import msg
from omnisystem_v5.marketdata.issues import DataIssue, FaultScope
from omnisystem_v5.marketdata.provider import RawBarRow
from omnisystem_v5.schemas.market_data import OHLCVBar, SchemaValidationError


def to_float(value):
    """(float, None) or (None, 'type' | 'non_finite')."""
    if isinstance(value, bool) or value is None:
        return None, "type"
    try:
        if isinstance(value, (int, float, Decimal)):
            f = float(value)
        elif isinstance(value, str):
            f = float(value.strip())
        else:
            return None, "type"
    except (ValueError, OverflowError, ArithmeticError):
        return None, "type"
    if not math.isfinite(f):
        return None, "non_finite"
    return f, None


def parse_timestamp(value):
    """Aware datetime (UTC) or None. Epoch numbers are deliberately NOT accepted (unit ambiguity)."""
    if isinstance(value, datetime):
        return value.astimezone(timezone.utc) if value.tzinfo is not None else None
    if isinstance(value, str):
        s = value.strip()
        if s[-1:] in ("Z", "z"):
            s = s[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(s)
        except ValueError:
            return None
        return dt.astimezone(timezone.utc) if dt.tzinfo is not None else None
    return None


@dataclass(frozen=True)
class NormalizedSeries:
    bars: tuple            # OHLCVBar
    indices: tuple         # source row index of each bar
    issues: tuple          # DataIssue (all fatal at this stage; the caller applies tolerance)
    malformed: int         # rows that produced at least one issue


def _issue(key, **p):
    return DataIssue(msg(key, **p), FaultScope.SYMBOL, True)


def normalize_row(row: RawBarRow, index: int, require_positive_prices: bool = True):
    """(OHLCVBar | None, [DataIssue])"""
    issues = []
    prices = {}
    for f in ("open", "high", "low", "close"):
        v, err = to_float(getattr(row, f))
        if err:
            issues.append(_issue(K.DATA_NON_FINITE, field=f, index=index))
        elif require_positive_prices and v <= 0:
            issues.append(_issue(K.DATA_NON_POSITIVE_PRICE, field=f, index=index))
        else:
            prices[f] = v
    vol, err = to_float(row.volume)
    if err:
        issues.append(_issue(K.DATA_NON_FINITE, field="volume", index=index))
    elif vol < 0:
        issues.append(_issue(K.DATA_NEGATIVE_VOLUME, index=index))
    times = {}
    for f in ("open_time", "close_time"):
        t = parse_timestamp(getattr(row, f))
        if t is None:
            issues.append(_issue(K.DATA_TIMESTAMP_INVALID, field=f, index=index))
        else:
            times[f] = t
    if issues:
        return None, issues
    try:
        bar = OHLCVBar(prices["open"], prices["high"], prices["low"], prices["close"], vol,
                       times["open_time"], times["close_time"])
    except SchemaValidationError as exc:
        return None, [_issue(K.DATA_OHLC_INVALID, index=index, detail=str(exc))]
    return bar, []


def normalize_rows(rows, require_positive_prices: bool = True) -> NormalizedSeries:
    bars, indices, issues, malformed = [], [], [], 0
    for i, row in enumerate(rows):
        bar, row_issues = normalize_row(row, i, require_positive_prices)
        if bar is None:
            malformed += 1
            issues.extend(row_issues)
        else:
            bars.append(bar)
            indices.append(i)
    return NormalizedSeries(tuple(bars), tuple(indices), tuple(issues), malformed)
