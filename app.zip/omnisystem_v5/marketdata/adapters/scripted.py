"""Deterministic scripted provider - test double, MERWIS AI Phase 11.

Serves pre-built series and scripted failures. Declares HISTORICAL origin (recorded-fixture replay),
never LIVE: a fixture must not be able to pass itself off as a live feed. Evidence level: TESTED.
"""
from __future__ import annotations

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.provider import (BarRequest, EvidenceLevel, ProviderCapabilities, RawBarRow, RawBars, RawQuote)
from omnisystem_v5.schemas.enums import DataOrigin


def raw_row_from_bar(bar) -> RawBarRow:
    return RawBarRow(bar.open, bar.high, bar.low, bar.close, bar.volume, bar.open_time, bar.close_time)


class ScriptedProvider:
    def __init__(self, name: str, capabilities: ProviderCapabilities, series: dict | None = None, outcomes: dict | None = None,
                 quotes: dict | None = None):
        """series: {(provider_symbol, Timeframe): sequence of RawBarRow}
        outcomes: {(provider_symbol, Timeframe): [Exception | RawBars | None, ...]} consumed one per call, in order
                  (None = serve the series). quotes: {provider_symbol: RawQuote | Exception}."""
        self.name = name
        self._caps = capabilities
        self._series = {k: tuple(v) for k, v in (series or {}).items()}
        self._outcomes = {k: list(v) for k, v in (outcomes or {}).items()}
        self._quotes = dict(quotes or {})
        self.calls: list = []

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._caps

    def script(self, provider_symbol, timeframe, outcomes) -> None:
        """Queue outcomes (Exception | RawBars | None) consumed one per call for this stream."""
        self._outcomes[(provider_symbol, timeframe)] = list(outcomes)

    def set_series(self, provider_symbol, timeframe, rows) -> None:
        self._series[(provider_symbol, timeframe)] = tuple(rows)

    def fetch_bars(self, request: BarRequest) -> RawBars:
        self.calls.append(request)
        key = (request.provider_symbol, request.timeframe)
        queue = self._outcomes.get(key)
        if queue:
            item = queue.pop(0)
            if isinstance(item, BaseException):
                raise item
            if item is not None:
                return item
        if key not in self._series:
            raise DataUnavailableError(f"{self.name}: no scripted data for {request.provider_symbol} {request.timeframe.value}")
        return RawBars(self.name, request.provider_symbol, self._series[key][-request.limit:], request.timeframe)

    def fetch_quote(self, provider_symbol: str) -> RawQuote:
        item = self._quotes.get(provider_symbol)
        if item is None:
            raise DataUnavailableError(f"{self.name}: no scripted quote for {provider_symbol}")
        if isinstance(item, BaseException):
            raise item
        return item


def scripted_capabilities(asset_classes, timeframes, *, supports_quotes=False, venues=frozenset(),
                          origin=DataOrigin.HISTORICAL) -> ProviderCapabilities:
    return ProviderCapabilities(frozenset(asset_classes), frozenset(timeframes), origin, live_capable=False,
                                supports_quotes=supports_quotes, venues=frozenset(venues), evidence=EvidenceLevel.TESTED)
