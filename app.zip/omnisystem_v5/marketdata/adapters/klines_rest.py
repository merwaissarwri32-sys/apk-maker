"""Thin REST candlestick adapter behind an injected Transport - MERWIS AI, Phase 11.

    STATUS: IMPLEMENTED — NOT LIVE-VERIFIED

* It has never been connected to a real endpoint. Its response-shape assumptions come from the public
  documentation of common "klines" endpoints as remembered, NOT from observed traffic: a JSON array of
  arrays [open_time_ms, open, high, low, close, volume, ...] with numeric strings, oldest first, the
  newest row possibly still forming. Interval codes are assumed identical to MERWIS timeframe values.
* Tests use a scripted fake transport and hand-authored fixtures only.
* No credentials are used (public market data). No network code lives here: the Transport is injected.
* close_time is derived from the EXPLICIT requested timeframe (open + step); the provider's own close
  timestamp (often open + step - 1 ms) is ignored on purpose.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.assets import AssetClass
from omnisystem_v5.marketdata.provider import (BarRequest, EvidenceLevel, ProviderAuthError, ProviderCapabilities, ProviderPayloadError,
                                               RawBarRow, RawBars, RawQuote, Transport, TransportRequest)
from omnisystem_v5.scanner.failures import ProviderRateLimitedError
from omnisystem_v5.schemas.enums import DataOrigin, Timeframe
from omnisystem_v5.validation.resampling import seconds_for_timeframe

STATUS = "IMPLEMENTED — NOT LIVE-VERIFIED"
_INTERVALS = {Timeframe.M1: "1m", Timeframe.M5: "5m", Timeframe.M15: "15m", Timeframe.H1: "1h", Timeframe.H4: "4h", Timeframe.D1: "1d"}


def _header(headers, name):
    for k, v in headers:
        if k.lower() == name:
            return v
    return None


class KlinesRestAdapter:
    status = STATUS

    def __init__(self, name: str, transport: Transport, path: str = "/klines", timeout_seconds: float = 10.0,
                 venues: frozenset = frozenset()):
        self.name = name
        self._transport = transport
        self._path = path
        self._timeout = timeout_seconds
        self._caps = ProviderCapabilities(
            asset_classes=frozenset({AssetClass.CRYPTO}), timeframes=frozenset(_INTERVALS), declared_origin=DataOrigin.LIVE,
            live_capable=True, supports_quotes=False, supports_streaming=False, venues=frozenset(venues),
            evidence=EvidenceLevel.IMPLEMENTED)

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._caps

    def fetch_bars(self, request: BarRequest) -> RawBars:
        interval = _INTERVALS.get(request.timeframe)
        if interval is None:
            raise ProviderPayloadError(f"unsupported timeframe {request.timeframe.value}")
        resp = self._transport.request(TransportRequest(
            "GET", self._path, (("symbol", request.provider_symbol), ("interval", interval), ("limit", str(request.limit))), self._timeout))
        st = resp.status
        if st in (429, 418):
            after = _header(resp.headers, "retry-after")
            try:
                wait = float(after) if after is not None else None
            except ValueError:
                wait = None
            raise ProviderRateLimitedError(f"{self.name}: HTTP {st}", wait)
        if st in (401, 403):
            raise ProviderAuthError(f"{self.name}: HTTP {st}")
        if st in (408, 504):
            raise TimeoutError(f"{self.name}: HTTP {st}")
        if st != 200:
            raise DataUnavailableError(f"{self.name}: HTTP {st}")
        try:
            payload = json.loads(resp.body)
        except (ValueError, TypeError) as exc:
            raise ProviderPayloadError(f"{self.name}: body is not valid JSON") from exc
        if not isinstance(payload, list):
            raise ProviderPayloadError(f"{self.name}: expected a JSON array")
        step = timedelta(seconds=seconds_for_timeframe(request.timeframe))
        rows = []
        for i, item in enumerate(payload):
            if not isinstance(item, list) or len(item) < 6:
                raise ProviderPayloadError(f"{self.name}: row {i} is not an array of at least 6 fields")
            ms = item[0]
            if isinstance(ms, bool) or not isinstance(ms, int):
                raise ProviderPayloadError(f"{self.name}: row {i} open time is not an integer millisecond epoch")
            try:
                opened = datetime.fromtimestamp(ms / 1000.0, tz=timezone.utc)
            except (OverflowError, OSError, ValueError) as exc:
                raise ProviderPayloadError(f"{self.name}: row {i} open time out of range") from exc
            rows.append(RawBarRow(item[1], item[2], item[3], item[4], item[5], opened, opened + step))
        return RawBars(self.name, request.provider_symbol, tuple(rows), request.timeframe)

    def fetch_quote(self, provider_symbol: str) -> RawQuote:
        raise NotImplementedError("this adapter does not serve quotes")
