"""Adapter that plugs any Phase 1 DataProvider into the Phase 11 boundary (reuse, not a rewrite)."""
from __future__ import annotations

from omnisystem_v5.data.providers.base import DataProvider
from omnisystem_v5.marketdata.provider import BarRequest, ProviderCapabilities, ProviderPayloadError, RawBarRow, RawBars, RawQuote

_KEYS = ("open", "high", "low", "close", "volume", "open_time", "close_time")


class LegacyDataProviderAdapter:
    def __init__(self, provider: DataProvider, capabilities: ProviderCapabilities):
        self._provider = provider
        self._caps = capabilities
        self.name = provider.name

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._caps

    def fetch_bars(self, request: BarRequest) -> RawBars:
        result = self._provider.fetch_ohlcv(request.provider_symbol, request.timeframe, request.limit)   # DataUnavailableError propagates
        rows = []
        for i, r in enumerate(result.raw_bars):
            if not isinstance(r, dict) or any(k not in r for k in _KEYS):
                raise ProviderPayloadError(f"legacy row {i} is missing required keys")
            rows.append(RawBarRow(*(r[k] for k in _KEYS)))
        return RawBars(self.name, request.provider_symbol, tuple(rows), request.timeframe)

    def fetch_quote(self, provider_symbol: str) -> RawQuote:
        raise NotImplementedError("legacy providers do not serve quotes")
