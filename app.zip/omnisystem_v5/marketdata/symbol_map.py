"""Explicit provider-symbol <-> Instrument mapping - MERWIS AI, Phase 11.

No parsing heuristics: every mapping is declared. Ambiguity is rejected when the map is built and
an unknown symbol fails closed at lookup. Provider symbols are matched EXACTLY (case-sensitive).
"""
from __future__ import annotations

from typing import Iterable

from omnisystem_v5.marketdata.assets import Instrument


class SymbolMapError(ValueError):
    pass


class UnknownSymbolError(LookupError):
    pass


class SymbolMap:
    def __init__(self, provider: str, entries: Iterable[tuple]):
        if not isinstance(provider, str) or not provider:
            raise SymbolMapError("provider name must be a non-empty string")
        self.provider = provider
        self._to_instrument: dict = {}
        self._to_provider: dict = {}
        for provider_symbol, instrument in entries:
            if not isinstance(provider_symbol, str) or not provider_symbol.strip() or provider_symbol != provider_symbol.strip():
                raise SymbolMapError(f"invalid provider symbol {provider_symbol!r}")
            if not isinstance(instrument, Instrument):
                raise SymbolMapError(f"{provider_symbol!r} must map to an Instrument")
            if provider_symbol in self._to_instrument and self._to_instrument[provider_symbol] != instrument:
                raise SymbolMapError(f"provider symbol {provider_symbol!r} maps to two instruments")
            if instrument in self._to_provider and self._to_provider[instrument] != provider_symbol:
                raise SymbolMapError(f"{instrument.canonical_symbol} has two provider symbols on {provider}")
            self._to_instrument[provider_symbol] = instrument
            self._to_provider[instrument] = provider_symbol

    def instrument_for(self, provider_symbol: str) -> Instrument:
        try:
            return self._to_instrument[provider_symbol]
        except (KeyError, TypeError):
            raise UnknownSymbolError(f"{self.provider}: unknown provider symbol {provider_symbol!r}") from None

    def provider_symbol_for(self, instrument: Instrument) -> str:
        try:
            return self._to_provider[instrument]
        except KeyError:
            raise UnknownSymbolError(f"{self.provider}: no mapping for {instrument.canonical_symbol}") from None

    def __contains__(self, instrument) -> bool:
        return instrument in self._to_provider

    def instruments(self) -> tuple:
        return tuple(sorted(self._to_provider, key=lambda i: (i.canonical_symbol, i.asset_class.value)))
