"""Asset model - MERWIS AI, Phase 11.

Instrument = economic identity (asset class, base, quote); its canonical symbol is exactly the
existing SymbolSpec.symbol contract (BASE/QUOTE, via scanner.universe.normalize_symbol).
Venue is NOT part of instrument identity (BTC/USDT is one instrument on many venues): a Listing
is (Instrument x Venue) plus market microstructure facts and the trading session.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from enum import Enum

from omnisystem_v5.marketdata.sessions import AlwaysOpenSession, TradingSession
from omnisystem_v5.scanner.enums import MarketType
from omnisystem_v5.scanner.universe import normalize_symbol


class AssetModelError(ValueError):
    pass


class AssetClass(str, Enum):
    CRYPTO = "CRYPTO"
    FOREX = "FOREX"
    COMMODITY = "COMMODITY"
    INDEX = "INDEX"
    EQUITY = "EQUITY"
    FUTURES = "FUTURES"


# The single place where asset class is translated to the scanner's MarketType.
_MARKET_TYPE = {
    AssetClass.CRYPTO: MarketType.SPOT,
    AssetClass.FOREX: MarketType.FX,
    AssetClass.EQUITY: MarketType.EQUITY,
    AssetClass.COMMODITY: MarketType.OTHER,
    AssetClass.INDEX: MarketType.OTHER,
    AssetClass.FUTURES: MarketType.OTHER,
}


def market_type_for(asset_class: AssetClass) -> MarketType:
    return _MARKET_TYPE[asset_class]


_CODE = re.compile(r"^[A-Z0-9.]+$")


@dataclass(frozen=True)
class Instrument:
    asset_class: AssetClass
    base: str
    quote: str

    def __post_init__(self):
        if not isinstance(self.asset_class, AssetClass):
            raise AssetModelError("asset_class must be an AssetClass")
        for name in ("base", "quote"):
            v = getattr(self, name)
            if not isinstance(v, str):
                raise AssetModelError(f"{name} must be a string")
            v = v.strip().upper()
            if not _CODE.match(v):
                raise AssetModelError(f"invalid {name} {getattr(self, name)!r}")
            object.__setattr__(self, name, v)
        if self.base == self.quote:
            raise AssetModelError("base and quote must differ")

    @property
    def canonical_symbol(self) -> str:
        return normalize_symbol(f"{self.base}/{self.quote}")


@dataclass(frozen=True)
class Venue:
    code: str

    def __post_init__(self):
        if not isinstance(self.code, str) or not re.match(r"^[A-Z0-9_]+$", self.code):
            raise AssetModelError(f"invalid venue code {self.code!r}")


def _pos_finite(v, name):
    if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0):
        raise AssetModelError(f"{name} must be a finite number > 0 or None")


@dataclass(frozen=True)
class Listing:
    instrument: Instrument
    venue: Venue
    session: TradingSession = field(default_factory=AlwaysOpenSession)
    tick_size: float | None = None
    price_precision: int | None = None
    quantity_precision: int | None = None
    bar_anchor_offset_seconds: int = 0     # UTC offset of the bar-boundary grid (daily-bar anchor)
    market_type: MarketType | None = None  # None -> derived from the asset class
    enabled: bool = True
    quote_volume_24h: float | None = None  # liquidity proxy for the scanner's UniverseFilter; None = unknown

    def __post_init__(self):
        _pos_finite(self.tick_size, "tick_size")
        for n in ("price_precision", "quantity_precision"):
            v = getattr(self, n)
            if v is not None and (isinstance(v, bool) or not isinstance(v, int) or v < 0):
                raise AssetModelError(f"{n} must be an int >= 0 or None")
        a = self.bar_anchor_offset_seconds
        if isinstance(a, bool) or not isinstance(a, int) or not 0 <= a < 86400:
            raise AssetModelError("bar_anchor_offset_seconds must be an int in [0, 86400)")
        v = self.quote_volume_24h
        if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0):
            raise AssetModelError("quote_volume_24h must be a finite number >= 0 or None")

    @property
    def symbol(self) -> str:
        return self.instrument.canonical_symbol

    @property
    def effective_market_type(self) -> MarketType:
        return self.market_type or market_type_for(self.instrument.asset_class)
