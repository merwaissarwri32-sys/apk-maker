"""Ingestion pipeline - MERWIS AI, Phase 11.

RawBars -> validate (strict) -> freshness -> (MarketDataEnvelope, StreamHealth).

The envelope contract stays frozen: richer state (freshness state, dropped bars, digest, provider
state) lives in the adjacent StreamHealth record keyed by the same (market, timeframe).
Status mapping:  instrument/symbol defect -> INVALID   too few bars -> INSUFFICIENT_DATA
                 stale or expired         -> STALE     otherwise      -> OK
The pipeline never returns OK for data the scanner would refuse on freshness (same expression).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from omnisystem_v5.marketdata import validation as V
from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.canonical import digest
from omnisystem_v5.marketdata.config import MarketDataConfig
from omnisystem_v5.marketdata.freshness import FreshnessState, StreamHealth, classify_freshness
from omnisystem_v5.marketdata.health import ProviderState
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import msg
from omnisystem_v5.marketdata.issues import DataIssue, FaultScope
from omnisystem_v5.marketdata.provider import BarRequest, RawBars
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope


@dataclass(frozen=True)
class IngestionResult:
    envelope: MarketDataEnvelope
    stream: StreamHealth


_DEGRADING_PROVIDER = frozenset({ProviderState.DEGRADED, ProviderState.RECOVERING, ProviderState.THROTTLED})


def bars_digest(bars) -> str:
    return digest([(b.open, b.high, b.low, b.close, b.volume, b.open_time, b.close_time) for b in bars])


class IngestionPipeline:
    def __init__(self, config: MarketDataConfig):
        self._cfg = config

    def ingest(self, raw: RawBars, request: BarRequest, listing: Listing, provider_name: str, origin: DataOrigin,
               provider_state: ProviderState | None, now: datetime) -> IngestionResult:
        """May raise ProviderPayloadError (a structurally unusable response is a PROVIDER-scope fault)."""
        cfg = self._cfg
        market, tf = listing.symbol, request.timeframe
        out = V.validate_series(raw, request, listing, now, cfg.validation, cfg.limits)
        issues = list(out.issues)
        last_close = out.bars[-1].close_time if out.bars else None

        if out.kind in (V.INVALID, V.NO_BARS):
            fresh = classify_freshness(None, now, tf, cfg.limits, cfg.freshness, valid=(out.kind == V.NO_BARS))
            status = QualityStatus.INVALID
        else:
            truncated = any(k == K.DATA_SESSION_GAP_TRUNCATED.value for k, _ in out.dropped)
            degraded = truncated or provider_state in _DEGRADING_PROVIDER
            fresh = classify_freshness(last_close, now, tf, cfg.limits, cfg.freshness, True, degraded)
            if out.kind == V.INSUFFICIENT:
                status = QualityStatus.INSUFFICIENT_DATA
            elif fresh.state in (FreshnessState.STALE, FreshnessState.EXPIRED):
                key = K.DATA_STALE if fresh.state == FreshnessState.STALE else K.DATA_EXPIRED
                limit = fresh.stale_after_seconds if fresh.state == FreshnessState.STALE else fresh.expired_after_seconds
                issues.append(DataIssue(msg(key, age_seconds=fresh.age_seconds, limit_seconds=limit), FaultScope.SYMBOL, True))
                status = QualityStatus.STALE
            elif fresh.state == FreshnessState.INVALID:
                issues.append(DataIssue(msg(K.DATA_FUTURE_BAR, index=0), FaultScope.SYMBOL, True))
                status = QualityStatus.INVALID
            else:
                status = QualityStatus.OK

        bars = out.bars if status in (QualityStatus.OK, QualityStatus.STALE, QualityStatus.INSUFFICIENT_DATA) else ()
        provenance = DataProvenance(provider_name, origin, now, last_close if last_close is not None else now)
        envelope = MarketDataEnvelope(market, tf, provenance, status, tuple(bars),
                                      tuple(i.message.reason_str() for i in issues))
        stream = StreamHealth(
            symbol=market, timeframe=tf, provider=provider_name, status=status, freshness=fresh.state,
            age_seconds=fresh.age_seconds, last_bar_close=last_close, bars=len(bars), dropped=out.dropped,
            issues=tuple(issues), provider_state=provider_state.value if provider_state else None,
            evaluated_at=now, digest=bars_digest(bars) if bars else None)
        return IngestionResult(envelope, stream)

    @staticmethod
    def failed_stream(market: str, tf: Timeframe, provider: str | None, status: QualityStatus,
                      issue: DataIssue | None, provider_state, now: datetime) -> StreamHealth:
        return StreamHealth(market, tf, provider, status, FreshnessState.MISSING, None, None, 0, (),
                            (issue,) if issue else (), provider_state.value if provider_state else None, now, None)
