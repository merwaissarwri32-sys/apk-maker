"""Instrument catalog - MERWIS AI, Phase 11. The explicit, declared set of Listings the system may serve."""
from __future__ import annotations

from typing import Iterable

from omnisystem_v5.marketdata.assets import AssetModelError, Listing


class InstrumentCatalog:
    """Rules enforced at build time (never silently resolved later):
    * one canonical symbol belongs to exactly one asset class (the scanner keys everything by that string);
    * an (instrument, venue) pair is listed once;
    * when the same instrument is listed on several venues, the FIRST ENABLED listing in declared order is primary."""

    def __init__(self, listings: Iterable[Listing]):
        by_symbol: dict = {}
        seen = set()
        for lst in listings:
            if not isinstance(lst, Listing):
                raise AssetModelError(f"catalog entries must be Listing, got {type(lst).__name__}")
            key = (lst.instrument, lst.venue)
            if key in seen:
                raise AssetModelError(f"{lst.symbol} on {lst.venue.code} is listed twice")
            seen.add(key)
            group = by_symbol.setdefault(lst.symbol, [])
            if group and group[0].instrument.asset_class != lst.instrument.asset_class:
                raise AssetModelError(f"symbol {lst.symbol} collides across asset classes "
                                      f"({group[0].instrument.asset_class.value} vs {lst.instrument.asset_class.value})")
            group.append(lst)
        self._by_symbol = {k: tuple(v) for k, v in by_symbol.items()}

    def symbols(self) -> tuple:
        return tuple(sorted(self._by_symbol))

    def listings_for(self, symbol: str) -> tuple:
        return self._by_symbol.get(symbol, ())

    def primary(self, symbol: str) -> Listing | None:
        for lst in self._by_symbol.get(symbol, ()):
            if lst.enabled:
                return lst
        return None

    def any_listing(self, symbol: str) -> Listing | None:
        group = self._by_symbol.get(symbol)
        return group[0] if group else None
