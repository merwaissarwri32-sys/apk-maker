"""Trading sessions - MERWIS AI, Phase 11. Schedule facts only; no strategy logic.

Crypto: AlwaysOpenSession. Session-based markets (forex): WeeklySession, defined in the venue's
LOCAL wall-clock time so daylight-saving shifts are handled by the IANA zone, not by hand.
A missing tz database fails closed at construction (no silent UTC fallback).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from enum import Enum
from typing import Protocol
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

_WEEK = 7 * 86400


class SessionConfigError(ValueError):
    pass


class MarketStatus(str, Enum):
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    HALTED = "HALTED"      # explicit closure interval (halt / holiday supplied as data)
    UNKNOWN = "UNKNOWN"    # a session that cannot be evaluated is never treated as open


class TradingSession(Protocol):
    def status(self, at: datetime) -> MarketStatus: ...
    def next_open(self, at: datetime) -> datetime | None: ...


def _require_aware(at: datetime) -> datetime:
    if not isinstance(at, datetime) or at.tzinfo is None:
        raise ValueError("session time must be a timezone-aware datetime")
    return at


@dataclass(frozen=True)
class AlwaysOpenSession:
    """24/7 markets."""

    def status(self, at: datetime) -> MarketStatus:
        _require_aware(at)
        return MarketStatus.OPEN

    def next_open(self, at: datetime) -> datetime | None:
        return _require_aware(at)


@dataclass(frozen=True)
class WeeklyWindow:
    """Open interval [open, close) in local time; weekday 0=Monday..6=Sunday; seconds from local midnight.
    close <= open wraps across the week boundary (e.g. Sun 17:00 -> Fri 17:00)."""
    open_weekday: int
    open_seconds: int
    close_weekday: int
    close_seconds: int

    def __post_init__(self):
        for wd in (self.open_weekday, self.close_weekday):
            if not isinstance(wd, int) or not 0 <= wd <= 6:
                raise SessionConfigError("weekday must be 0..6")
        for s in (self.open_seconds, self.close_seconds):
            if not isinstance(s, int) or not 0 <= s < 86400:
                raise SessionConfigError("seconds must be 0..86399")

    @property
    def bounds(self) -> tuple:
        start = self.open_weekday * 86400 + self.open_seconds
        end = self.close_weekday * 86400 + self.close_seconds
        if end <= start:
            end += _WEEK
        return start, end


@dataclass(frozen=True)
class WeeklySession:
    tz_name: str
    windows: tuple
    closures: tuple = ()     # ((start_utc, end_utc), ...) explicit halts / holidays supplied as data

    def __post_init__(self):
        if not self.windows or any(not isinstance(w, WeeklyWindow) for w in self.windows):
            raise SessionConfigError("windows must be a non-empty tuple of WeeklyWindow")
        try:
            ZoneInfo(self.tz_name)
        except (ZoneInfoNotFoundError, ValueError, OSError) as exc:
            raise SessionConfigError(f"time zone {self.tz_name!r} is unavailable: {exc}") from exc
        for c in self.closures:
            if len(c) != 2 or any(not isinstance(x, datetime) or x.tzinfo is None for x in c) or c[1] <= c[0]:
                raise SessionConfigError("closures must be ((aware_start, aware_end), ...) with end > start")

    @classmethod
    def forex_ny(cls, closures: tuple = ()) -> "WeeklySession":
        """Conventional FX week: opens Sunday 17:00, closes Friday 17:00, America/New_York.
        A convention, not a venue guarantee - verify per venue."""
        return cls("America/New_York", (WeeklyWindow(6, 17 * 3600, 4, 17 * 3600),), closures)

    def _zone(self) -> ZoneInfo:
        return ZoneInfo(self.tz_name)

    def status(self, at: datetime) -> MarketStatus:
        _require_aware(at)
        for start, end in self.closures:
            if start <= at < end:
                return MarketStatus.HALTED
        local = at.astimezone(self._zone())
        t = local.weekday() * 86400 + local.hour * 3600 + local.minute * 60 + local.second + local.microsecond / 1e6
        for w in self.windows:
            start, end = w.bounds
            if start <= t < end or start <= t + _WEEK < end:
                return MarketStatus.OPEN
        return MarketStatus.CLOSED

    def next_open(self, at: datetime) -> datetime | None:
        """First scheduled open at or after `at` (schedule only; explicit closures are not consulted)."""
        _require_aware(at)
        if self.status(at) == MarketStatus.OPEN:
            return at
        zone = self._zone()
        local = at.astimezone(zone)
        monday: date = local.date() - timedelta(days=local.weekday())
        best = None
        for k in range(3):
            for w in self.windows:
                d = monday + timedelta(days=7 * k + w.open_weekday)
                opened = (datetime.combine(d, time(0), tzinfo=zone) + timedelta(seconds=w.open_seconds)).astimezone(timezone.utc)
                if opened > at and (best is None or opened < best):
                    best = opened
        return best
