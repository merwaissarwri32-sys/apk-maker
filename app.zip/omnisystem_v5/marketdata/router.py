"""Provider routing - MERWIS AI, Phase 11.

Ordered candidates, first USABLE one wins (declared order = priority). That is inherently sticky:
the primary stays primary while it is usable. There is NO cross-provider failover in Phase 11 by
design - mixing 5m from provider A with 1h from provider B for one symbol could produce a
desynchronized picture. The seam (candidates() / RouteDecision) is what a future policy would use.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.health import HealthBook, ProviderHealth, may_attempt
from omnisystem_v5.marketdata.symbol_map import SymbolMap
from omnisystem_v5.schemas.enums import Timeframe

UNMAPPED, UNSUPPORTED, BLOCKED, OK = "UNMAPPED", "UNSUPPORTED_TIMEFRAME", "BLOCKED", "OK"


@dataclass(frozen=True)
class Route:
    feed: object = field(compare=False)
    provider: str
    provider_symbol: str


@dataclass(frozen=True)
class RouteDecision:
    route: Route | None
    reason: str
    candidates: tuple = ()
    blocked: tuple = ()          # ((provider name, ProviderHealth), ...)


class ProviderRouter:
    def __init__(self, feeds, symbol_maps):
        self._feeds = tuple(feeds)
        names = [f.name for f in self._feeds]
        if len(set(names)) != len(names):
            raise ValueError("feed names must be unique")
        self._maps = {}
        for m in symbol_maps:
            if not isinstance(m, SymbolMap):
                raise ValueError("symbol_maps must contain SymbolMap objects")
            if m.provider in self._maps:
                raise ValueError(f"two symbol maps for provider {m.provider}")
            self._maps[m.provider] = m
        missing = [n for n in names if n not in self._maps]
        if missing:
            raise ValueError(f"no symbol map for provider(s): {missing}")

    @property
    def feeds(self) -> tuple:
        return self._feeds

    def _mapped(self, listing: Listing) -> tuple:
        out = []
        for f in self._feeds:
            caps = f.capabilities
            if listing.instrument.asset_class not in caps.asset_classes:
                continue
            if caps.venues and listing.venue.code not in caps.venues:
                continue
            m = self._maps[f.name]
            if listing.instrument in m:
                out.append(Route(f, f.name, m.provider_symbol_for(listing.instrument)))
        return tuple(out)

    def candidates(self, listing: Listing, timeframe: Timeframe | None = None) -> tuple:
        routes = self._mapped(listing)
        if timeframe is None:
            return routes
        return tuple(r for r in routes if timeframe in r.feed.capabilities.timeframes)

    def resolve(self, listing: Listing, timeframe: Timeframe, book: HealthBook, now: datetime) -> RouteDecision:
        if not self._mapped(listing):
            return RouteDecision(None, UNMAPPED)
        cands = self.candidates(listing, timeframe)
        if not cands:
            return RouteDecision(None, UNSUPPORTED)
        blocked = []
        for r in cands:
            h = book.provider(r.provider, now)
            if may_attempt(h, now):
                return RouteDecision(r, OK, cands, tuple(blocked))
            blocked.append((r.provider, h))
        return RouteDecision(None, BLOCKED, cands, tuple(blocked))
