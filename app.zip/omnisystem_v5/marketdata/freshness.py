"""Freshness model and per-stream health record - MERWIS AI, Phase 11.

Phase 11 has NO threshold of its own for FRESH: FRESH/DEGRADED are exactly the region the scanner
accepts (age <= staleness_bars x timeframe seconds, the same expression the scanner uses). Only
EXPIRED (a longer horizon that the scanner does not use) is Phase 11's own.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from omnisystem_v5.marketdata.config import FreshnessPolicy, SharedLimits
from omnisystem_v5.marketdata.issues import DataIssue
from omnisystem_v5.schemas.enums import QualityStatus, Timeframe
from omnisystem_v5.validation.resampling import seconds_for_timeframe


class FreshnessState(str, Enum):
    FRESH = "FRESH"
    DEGRADED = "DEGRADED"     # fresh and valid, but carrying a caveat (provider not healthy, series truncated)
    STALE = "STALE"
    EXPIRED = "EXPIRED"
    MISSING = "MISSING"
    INVALID = "INVALID"


@dataclass(frozen=True)
class FreshnessAssessment:
    state: FreshnessState
    age_seconds: float | None
    stale_after_seconds: float
    expired_after_seconds: float


def classify_freshness(last_close: datetime | None, now: datetime, timeframe: Timeframe, limits: SharedLimits,
                       policy: FreshnessPolicy, valid: bool = True, degraded: bool = False) -> FreshnessAssessment:
    step = seconds_for_timeframe(timeframe)
    stale_after = limits.staleness_bars * step
    expired_after = policy.expired_bars * step
    if not valid:
        return FreshnessAssessment(FreshnessState.INVALID, None, stale_after, expired_after)
    if last_close is None:
        return FreshnessAssessment(FreshnessState.MISSING, None, stale_after, expired_after)
    if last_close > now:
        return FreshnessAssessment(FreshnessState.INVALID, None, stale_after, expired_after)
    age = (now - last_close).total_seconds()
    if not age > stale_after:                       # identical comparison to scanner.timeframes.check_envelope_time
        state = FreshnessState.DEGRADED if degraded else FreshnessState.FRESH
    elif not age > expired_after:
        state = FreshnessState.STALE
    else:
        state = FreshnessState.EXPIRED
    return FreshnessAssessment(state, age, stale_after, expired_after)


@dataclass(frozen=True)
class StreamHealth:
    """Data-health record for one (symbol, timeframe) stream. Keyed like the envelope: (market, timeframe)."""
    symbol: str
    timeframe: Timeframe
    provider: str | None
    status: QualityStatus
    freshness: FreshnessState
    age_seconds: float | None
    last_bar_close: datetime | None
    bars: int
    dropped: tuple            # ((MessageKey value, count), ...)
    issues: tuple             # DataIssue
    provider_state: str | None
    evaluated_at: datetime
    digest: str | None        # SHA-256 of the canonical bars (identity of the data actually delivered)
