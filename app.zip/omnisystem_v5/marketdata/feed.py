"""Transport-neutral bar feeds - MERWIS AI, Phase 11.

The pipeline and scanner consume a BarFeed and cannot tell polling from streaming. PollingFeed pulls
from a provider on demand; StreamingFeed (stream.py) serves the latest bars from a store that a
stream keeps filled.
"""
from __future__ import annotations

from typing import Protocol

from omnisystem_v5.marketdata.provider import BarRequest, MarketDataProvider, ProviderCapabilities, RawBars


class BarFeed(Protocol):
    name: str

    @property
    def capabilities(self) -> ProviderCapabilities: ...

    def latest_bars(self, request: BarRequest) -> RawBars: ...


class PollingFeed:
    def __init__(self, provider: MarketDataProvider):
        self._provider = provider
        self.name = provider.name

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._provider.capabilities

    def latest_bars(self, request: BarRequest) -> RawBars:
        return self._provider.fetch_bars(request)

    @property
    def provider(self) -> MarketDataProvider:
        return self._provider
