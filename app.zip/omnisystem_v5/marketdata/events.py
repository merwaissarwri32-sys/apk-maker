"""Structured observability events - MERWIS AI, Phase 11.

Reuses the existing sink contract (scanner.telemetry.TelemetrySink / TelemetryEvent / NullSink /
InMemorySink). TelemetryEvent.kind is annotated as the scanner's EventKind but is not enforced at
runtime; Phase 11 passes its own DataEventKind (a str-Enum). This is a nominal-typing note, not a
behavioral change to the scanner. A failing sink can never break ingestion.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum

from omnisystem_v5.scanner.telemetry import InMemorySink, NullSink, TelemetryEvent, TelemetrySink  # noqa: F401 (re-exported)


class DataEventKind(str, Enum):
    DATA_INGESTED = "DATA_INGESTED"                  # a structurally valid payload was received and evaluated
    DATA_REJECTED = "DATA_REJECTED"                  # evaluated and refused (invalid / insufficient / unavailable)
    DATA_STALE = "DATA_STALE"
    PROVIDER_ERROR = "PROVIDER_ERROR"
    PROVIDER_STATE_CHANGED = "PROVIDER_STATE_CHANGED"
    INSTRUMENT_STATE_CHANGED = "INSTRUMENT_STATE_CHANGED"
    RETRY_ATTEMPT = "RETRY_ATTEMPT"
    RATE_LIMITED = "RATE_LIMITED"
    LOCAL_THROTTLED = "LOCAL_THROTTLED"
    RECONNECT_ATTEMPT = "RECONNECT_ATTEMPT"          # a probe sent to a provider that was UNAVAILABLE / THROTTLED
    RECOVERY = "RECOVERY"                            # provider returned to HEALTHY
    STREAM_UPDATE_REJECTED = "STREAM_UPDATE_REJECTED"
    QUOTE_ACCEPTED = "QUOTE_ACCEPTED"
    QUOTE_REJECTED = "QUOTE_REJECTED"


def _plain(v):
    if isinstance(v, Enum):
        return v.value
    if isinstance(v, datetime):
        return v.isoformat()
    if isinstance(v, float):
        return round(v, 6)
    return v


def emit(sink, kind: DataEventKind, at: datetime, subject: str | None = None, **detail) -> bool:
    """Returns False if the sink failed (swallowed on purpose: observability must not break data flow)."""
    if sink is None:
        return True
    try:
        sink.emit(TelemetryEvent(kind, at, subject, tuple(sorted((k, _plain(v)) for k, v in detail.items()))))
        return True
    except Exception:
        return False


class CompositeSink:
    """Fan-out to several sinks (e.g. metrics + in-memory + a future exporter)."""

    def __init__(self, *sinks):
        self._sinks = sinks

    def emit(self, event) -> None:
        for s in self._sinks:
            try:
                s.emit(event)
            except Exception:
                pass
