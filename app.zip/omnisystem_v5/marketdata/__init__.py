"""MERWIS AI - Phase 11: Live Data & Multi-Asset Infrastructure ("the data nervous system").

Sibling of `scanner`. Consumed by the Phase 10 scanner ONLY through its existing structural
protocols (scanner.market_data.MarketDataSource, scanner.universe.Universe). Nothing in Phases 1-10
imports this package. Data infrastructure only: no execution, no alert transport, no UI, no assistant.
"""
