"""Strict validation pipeline - MERWIS AI, Phase 11.

schema -> normalize/semantic -> timestamp -> sequence (order, duplicates) -> forming/future bar
-> gaps (session-aware, optional) -> composed frozen validator -> minimum bars.

It COMPOSES data.validation.validate_bar_sequence (the same check the scanner re-applies) instead
of rewriting it, and adds what the frozen layers do not check: non-finite values, non-positive
prices, timeframe-boundary alignment, exact bar duration, an explicit dropped-bar policy.
Invalid bars are never exposed: any fatal issue yields an outcome with no bars.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from datetime import datetime, timedelta

from omnisystem_v5.data.validation import validate_bar_sequence
from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.config import SharedLimits, ValidationPolicy
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import msg
from omnisystem_v5.marketdata.issues import DataIssue, FaultScope
from omnisystem_v5.marketdata.normalize import normalize_rows
from omnisystem_v5.marketdata.provider import BarRequest, ProviderPayloadError, RawBarRow, RawBars
from omnisystem_v5.marketdata.sessions import MarketStatus
from omnisystem_v5.validation.resampling import seconds_for_timeframe

OK, INVALID, INSUFFICIENT, NO_BARS = "OK", "INVALID", "INSUFFICIENT", "NO_BARS"


@dataclass(frozen=True)
class ValidationOutcome:
    kind: str                 # OK | INVALID | INSUFFICIENT | NO_BARS
    bars: tuple               # only ever non-empty for OK / INSUFFICIENT
    issues: tuple             # DataIssue (fatal and informational)
    dropped: tuple = ()       # ((MessageKey value, count), ...)

    @property
    def fatal(self) -> tuple:
        return tuple(i for i in self.issues if i.fatal)


def _err(key, **p) -> DataIssue:
    return DataIssue(msg(key, **p), FaultScope.SYMBOL, True)


def _info(key, scope=FaultScope.SYMBOL, **p) -> DataIssue:
    return DataIssue(msg(key, **p), scope, False)


def check_structure(raw, request: BarRequest) -> None:
    """Structural violations mean the RESPONSE is unusable (provider-level) -> ProviderPayloadError."""
    if not isinstance(raw, RawBars):
        raise ProviderPayloadError(msg(K.DATA_PAYLOAD_MALFORMED, detail=f"got {type(raw).__name__}, not RawBars").reason_str())
    if raw.provider_symbol != request.provider_symbol:
        raise ProviderPayloadError(msg(K.DATA_ECHO_MISMATCH, field="symbol", expected=request.provider_symbol,
                                       actual=raw.provider_symbol).reason_str())
    if raw.timeframe is not None and raw.timeframe != request.timeframe:
        raise ProviderPayloadError(msg(K.DATA_ECHO_MISMATCH, field="timeframe", expected=request.timeframe.value,
                                       actual=getattr(raw.timeframe, "value", raw.timeframe)).reason_str())
    if not isinstance(raw.rows, (tuple, list)):
        raise ProviderPayloadError(msg(K.DATA_PAYLOAD_MALFORMED, detail="rows must be a sequence").reason_str())
    for i, row in enumerate(raw.rows):
        if not isinstance(row, RawBarRow):
            raise ProviderPayloadError(msg(K.DATA_PAYLOAD_MALFORMED, detail=f"row {i} is not a RawBarRow").reason_str())


def _is_session_gap(session, prev_close: datetime, next_open: datetime, step: int) -> bool:
    """A gap is a SESSION gap only if the market was not open when it began AND the next bar is the one
    containing the scheduled reopen. A missing bar after the reopen is a data defect, not a session gap."""
    try:
        if session.status(prev_close) == MarketStatus.OPEN:
            return False
        reopen = session.next_open(prev_close)
    except Exception:
        return False
    if reopen is None or reopen <= prev_close:
        return False
    return _contains(reopen, next_open, step)


def _step_td(step):
    return timedelta(seconds=step)


def _contains(reopen: datetime, bar_open: datetime, step: int) -> bool:
    delta = (bar_open - reopen).total_seconds()
    # the bar either opens at/after the reopen by less than one step, or is the bar that straddles it
    return delta < step and (bar_open + _step_td(step)) > reopen


def validate_series(raw, request: BarRequest, listing: Listing, now: datetime, policy: ValidationPolicy,
                    limits: SharedLimits) -> ValidationOutcome:
    check_structure(raw, request)
    tf = request.timeframe
    step = seconds_for_timeframe(tf)
    if len(raw.rows) == 0:
        return ValidationOutcome(NO_BARS, (), (_err(K.DATA_NO_BARS, symbol=listing.symbol, timeframe=tf.value),))

    # -- normalize + semantic (non-finite, prices, volume, OHLC, timestamp shape) --
    norm = normalize_rows(raw.rows, policy.require_positive_prices)
    issues = list(norm.issues)
    dropped = []
    if norm.malformed > policy.max_malformed_bars:
        issues.append(_err(K.DATA_MALFORMED_BAR_LIMIT, count=norm.malformed, limit=policy.max_malformed_bars))
        return ValidationOutcome(INVALID, (), tuple(issues))
    if norm.malformed:                                   # tolerated: dropped, recorded, never silent
        issues = [dataclasses.replace(i, fatal=False) for i in issues]
        issues.append(_info(K.DATA_MALFORMED_BAR_DROPPED, count=norm.malformed))
        dropped.append((K.DATA_MALFORMED_BAR_DROPPED.value, norm.malformed))
    bars, idx = list(norm.bars), list(norm.indices)

    # -- timestamp: boundary alignment and exact duration --
    anchor = listing.bar_anchor_offset_seconds
    for pos, bar in enumerate(bars):
        o = bar.open_time
        if o.microsecond or (int(o.timestamp()) - anchor) % step != 0:
            issues.append(_err(K.DATA_TIMESTAMP_MISALIGNED, index=idx[pos], timeframe=tf.value))
        if (bar.close_time - bar.open_time).total_seconds() != step:
            issues.append(_err(K.DATA_BAR_DURATION_INVALID, index=idx[pos], timeframe=tf.value))
    if any(i.fatal for i in issues):
        return ValidationOutcome(INVALID, (), tuple(issues))

    # -- sequence: strict order and duplicates (order is never repaired by sorting) --
    for pos in range(1, len(bars)):
        if bars[pos].open_time == bars[pos - 1].open_time:
            issues.append(_err(K.DATA_DUPLICATE_BAR, index=idx[pos]))
        elif bars[pos].open_time < bars[pos - 1].open_time:
            issues.append(_err(K.DATA_OUT_OF_ORDER, index=idx[pos]))
    if any(i.fatal for i in issues):
        return ValidationOutcome(INVALID, (), tuple(issues))

    # -- forming / future bar (only the newest bar can legitimately still be forming) --
    if bars:
        last = bars[-1]
        if last.open_time > now:
            issues.append(_err(K.DATA_FUTURE_BAR, index=idx[-1]))
            return ValidationOutcome(INVALID, (), tuple(issues))
        if last.close_time > now:
            if policy.drop_forming_bar:
                bars.pop(); idx.pop()
                issues.append(_info(K.DATA_FORMING_BAR_DROPPED, count=1))
                dropped.append((K.DATA_FORMING_BAR_DROPPED.value, 1))
            else:
                issues.append(_err(K.DATA_FORMING_BAR, index=idx[-1]))
                return ValidationOutcome(INVALID, (), tuple(issues))

    # -- gaps: session-aware truncation is optional; any other gap is fatal --
    cut = 0
    for i in range(1, len(bars)):
        gap = (bars[i].open_time - bars[i - 1].open_time).total_seconds()
        if gap > step * 1.1:                              # same tolerance as data.validation
            session_gap = _is_session_gap(listing.session, bars[i - 1].close_time, bars[i].open_time, step)
            if session_gap and policy.truncate_at_session_gap:
                cut = i
            elif session_gap:                             # expected schedule gap: still refused (never bridged), but named as such
                issues.append(_err(K.DATA_SESSION_GAP, index=idx[i], seconds=int(gap)))
            else:
                issues.append(_err(K.DATA_GAP, index=idx[i], seconds=int(gap)))
    if any(i.fatal for i in issues):
        return ValidationOutcome(INVALID, (), tuple(issues))
    if cut:
        issues.append(_info(K.DATA_SESSION_GAP_TRUNCATED, FaultScope.INSTRUMENT, dropped=cut))
        dropped.append((K.DATA_SESSION_GAP_TRUNCATED.value, cut))
        bars, idx = bars[cut:], idx[cut:]

    # -- composition: the exact check the scanner will re-apply must pass on what we deliver --
    if bars:
        seq = validate_bar_sequence(list(bars), tf)
        if not seq.ok:
            issues.append(_err(K.DATA_GAP, index=0, seconds=0))    # unreachable unless the checks above disagree with data.validation
            return ValidationOutcome(INVALID, (), tuple(issues))

    if len(bars) < limits.min_bars:
        issues.append(_err(K.DATA_INSUFFICIENT_BARS, have=len(bars), need=limits.min_bars))
        return ValidationOutcome(INSUFFICIENT, tuple(bars), tuple(issues), tuple(dropped))
    return ValidationOutcome(OK, tuple(bars), tuple(issues), tuple(dropped))
