"""LiveMarketDataSource - MERWIS AI, Phase 11. Implements scanner.market_data.MarketDataSource.

get_market_data(market, timeframe, limit) -> MarketDataEnvelope, with these guarantees:
* Provider-level faults (timeout, outage, rate limit, auth, malformed payload) are RAISED as the
  existing exception types, so the scanner classifies them with its unchanged taxonomy.
* Symbol/instrument-level defects are RETURNED as non-OK envelopes (INVALID, INSUFFICIENT_DATA, STALE).
* A provider that is UNAVAILABLE / THROTTLED is not called again until its cooldown ends (fail-fast).
* OK is never returned for data the scanner would refuse.
"""
from __future__ import annotations

from datetime import datetime

from omnisystem_v5.marketdata.assets import Listing
from omnisystem_v5.marketdata.catalog import InstrumentCatalog
from omnisystem_v5.marketdata.config import MarketDataConfig
from omnisystem_v5.marketdata.events import DataEventKind, emit
from omnisystem_v5.marketdata.health import HealthBook, InstrumentState, ObsKind, ProviderObservation, ProviderState, retry_after_seconds
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import StructuredMessage, msg
from omnisystem_v5.marketdata.issues import DataIssue, FaultScope
from omnisystem_v5.marketdata.pipeline import IngestionPipeline
from omnisystem_v5.marketdata.provider import BarRequest, ProviderAuthError
from omnisystem_v5.marketdata.retry import NullTimer, RetryExecutor, Throttle
from omnisystem_v5.marketdata.router import BLOCKED, OK, UNMAPPED, UNSUPPORTED, ProviderRouter
from omnisystem_v5.marketdata.system import SystemSleep
from omnisystem_v5.scanner.clock import Clock
from omnisystem_v5.scanner.failures import FailureClass, ProviderRateLimitedError, classify_fetch_exception
from omnisystem_v5.schemas.enums import DataOrigin, QualityStatus, Timeframe
from omnisystem_v5.schemas.market_data import DataProvenance, MarketDataEnvelope

_SOURCE = "marketdata"


class LiveMarketDataSource:
    def __init__(self, config: MarketDataConfig, catalog: InstrumentCatalog, router: ProviderRouter, book: HealthBook,
                 clock: Clock, sink=None, sleep=None, timer=None, pipeline: IngestionPipeline | None = None):
        self._cfg, self._catalog, self._router, self._book = config, catalog, router, book
        self._clock, self._sink = clock, sink
        self._timer = timer or NullTimer()
        self._retry = RetryExecutor(config.retry, sleep or SystemSleep(), sink)
        self._pipeline = pipeline or IngestionPipeline(config)
        self._throttles: dict = {}

    # ---- helpers ---------------------------------------------------------------------------
    def _refuse(self, market: str, tf: Timeframe, now: datetime, status: QualityStatus, message: StructuredMessage,
                provider: str | None = None) -> MarketDataEnvelope:
        # No real data exists here. INVALID cannot carry origin UNAVAILABLE (frozen invariant), so it carries
        # SIMULATED = "not real data, never usable"; the status alone already makes the scanner refuse it.
        origin = DataOrigin.UNAVAILABLE if status == QualityStatus.DATA_UNAVAILABLE else DataOrigin.SIMULATED
        env = MarketDataEnvelope(market, tf, DataProvenance(provider or _SOURCE, origin, now, now), status, (), (message.reason_str(),))
        self._book.record_stream(self._pipeline.failed_stream(market, tf, provider, status, DataIssue(message, FaultScope.SYMBOL), None, now))
        emit(self._sink, DataEventKind.DATA_REJECTED, now, market, timeframe=tf, reason=message.key.value, status=status)
        return env

    def _observe_provider(self, name: str, obs: ProviderObservation, now: datetime):
        prev, new = self._book.observe_provider(name, obs, now)
        if prev.state != new.state:
            emit(self._sink, DataEventKind.PROVIDER_STATE_CHANGED, now, name, from_state=prev.state, to_state=new.state)
            if new.state == ProviderState.HEALTHY and prev.state == ProviderState.RECOVERING:
                emit(self._sink, DataEventKind.RECOVERY, now, name)

    def _observe_instrument(self, symbol: str, ok: bool, now: datetime):
        prev, new = self._book.observe_instrument(symbol, ok, now)
        if prev is None and new.state == InstrumentState.AVAILABLE:
            return
        if prev is None or prev.state != new.state:
            emit(self._sink, DataEventKind.INSTRUMENT_STATE_CHANGED, now, symbol,
                 from_state=prev.state if prev else InstrumentState.AVAILABLE, to_state=new.state)

    def _provider_failure(self, route, exc: Exception, cls: FailureClass, market: str, tf: Timeframe, now: datetime) -> None:
        if isinstance(exc, ProviderRateLimitedError):
            obs = ProviderObservation(ObsKind.RATE_LIMITED, cls, exc.retry_after_seconds)
            emit(self._sink, DataEventKind.RATE_LIMITED, now, route.provider, retry_after=exc.retry_after_seconds)
        elif isinstance(exc, ProviderAuthError):
            obs = ProviderObservation(ObsKind.AUTH_FAILURE, cls)
        else:
            obs = ProviderObservation(ObsKind.FAILURE, cls)
        emit(self._sink, DataEventKind.PROVIDER_ERROR, now, route.provider, failure_class=cls, error=type(exc).__name__)
        self._observe_provider(route.provider, obs, now)
        h = self._book.provider(route.provider, now)
        self._book.record_stream(self._pipeline.failed_stream(
            market, tf, route.provider, QualityStatus.ERROR,
            DataIssue(msg(K.DATA_PAYLOAD_MALFORMED if cls == FailureClass.MALFORMED_RESPONSE else K.DATA_NO_PROVIDER,
                          **({"detail": type(exc).__name__} if cls == FailureClass.MALFORMED_RESPONSE else {"symbol": market, "timeframe": tf.value})),
                      FaultScope.PROVIDER), h.state, now))

    # ---- MarketDataSource ------------------------------------------------------------------
    def get_market_data(self, market: str, timeframe: Timeframe, limit: int = 200) -> MarketDataEnvelope:
        now = self._clock.now()
        listing: Listing | None = self._catalog.primary(market) if isinstance(market, str) else None
        if listing is None:
            return self._refuse(str(market), timeframe, now, QualityStatus.INVALID, msg(K.DATA_UNKNOWN_INSTRUMENT, symbol=market))
        decision = self._router.resolve(listing, timeframe, self._book, now)
        if decision.reason == UNMAPPED:
            self._observe_instrument(market, False, now)
            return self._refuse(market, timeframe, now, QualityStatus.INVALID, msg(K.DATA_UNMAPPED_INSTRUMENT, symbol=market))
        if decision.reason == UNSUPPORTED:
            return self._refuse(market, timeframe, now, QualityStatus.INVALID,
                                msg(K.DATA_UNSUPPORTED_TIMEFRAME, symbol=market, timeframe=timeframe.value))
        if decision.reason == BLOCKED:
            throttled = [(n, h) for n, h in decision.blocked if h.state == ProviderState.THROTTLED]
            if throttled:
                wait = min(retry_after_seconds(h, now) or 0.0 for _, h in throttled)
                raise ProviderRateLimitedError(f"provider throttled: {throttled[0][0]}", wait)
            name, h = decision.blocked[0]
            return self._refuse(market, timeframe, now, QualityStatus.DATA_UNAVAILABLE,
                                msg(K.DATA_PROVIDER_BLOCKED, provider=name, state=h.state), provider=name)
        route = decision.route
        pre_state = self._book.provider(route.provider, now).state

        throttle = self._throttles.setdefault(route.provider, Throttle(self._cfg.throttle))
        allowed, wait = throttle.try_acquire(now)
        if not allowed:
            emit(self._sink, DataEventKind.LOCAL_THROTTLED, now, route.provider, retry_after=wait)
            raise ProviderRateLimitedError(f"local throttle: {route.provider}", wait)
        if pre_state in (ProviderState.UNAVAILABLE, ProviderState.THROTTLED):
            emit(self._sink, DataEventKind.RECONNECT_ATTEMPT, now, route.provider, from_state=pre_state)

        request = BarRequest(route.provider_symbol, timeframe, limit)
        t0 = self._timer.now()
        outcome = self._retry.execute(lambda: route.feed.latest_bars(request), f"{route.provider}|{market}|{timeframe.value}", now)
        latency = max(0.0, self._timer.now() - t0)
        if outcome.error is not None:
            exc = outcome.error
            cls = FailureClass.PROVIDER_UNAVAILABLE if isinstance(exc, ProviderAuthError) else classify_fetch_exception(exc)
            self._provider_failure(route, exc, cls, market, timeframe, now)
            raise exc
        try:
            result = self._pipeline.ingest(outcome.value, request, listing, route.provider, route.feed.capabilities.declared_origin,
                                           pre_state, now)
        except Exception as exc:                              # structurally unusable payload = provider-scope fault
            self._provider_failure(route, exc, classify_fetch_exception(exc), market, timeframe, now)
            raise
        self._observe_provider(route.provider, ProviderObservation(ObsKind.SUCCESS), now)
        env, stream = result.envelope, result.stream
        self._book.record_stream(stream)
        emit(self._sink, DataEventKind.DATA_INGESTED, now, market, timeframe=timeframe, status=env.quality_status,
             provider=route.provider, bars=len(env.bars), latency_seconds=latency, freshness=stream.freshness)
        if env.quality_status == QualityStatus.OK:
            self._observe_instrument(market, True, now)
        elif env.quality_status == QualityStatus.STALE:
            emit(self._sink, DataEventKind.DATA_STALE, now, market, timeframe=timeframe, freshness=stream.freshness)
        else:
            first = next((i for i in stream.issues if i.fatal), None)
            emit(self._sink, DataEventKind.DATA_REJECTED, now, market, timeframe=timeframe, status=env.quality_status,
                 reason=first.message.key.value if first else "unknown")
            if env.quality_status == QualityStatus.INVALID and any(i.fatal and i.message.key != K.DATA_SESSION_GAP for i in stream.issues):
                self._observe_instrument(market, False, now)      # a scheduled session gap is a known limitation, not instrument damage
        return env
