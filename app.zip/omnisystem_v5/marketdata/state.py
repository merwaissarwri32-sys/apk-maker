"""Structured system state - the assistant-readiness boundary - MERWIS AI, Phase 11.

DataSystemSnapshot is a read-only, canonical, language-neutral picture of the data layer: provider
health, instrument health, stream (data) health, universe availability, metrics, adapter evidence
levels and derived roll-ups. Every reason is a MessageKey + params (never prose), so a future
assistant explains real evidence and localization is a presentation step. There is no assistant, no
LLM, and no free text here.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Protocol

from omnisystem_v5.marketdata.canonical import canonical_dict, canonical_json
from omnisystem_v5.marketdata.health import HealthBook, ProviderState, may_attempt
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.issues import FaultScope
from omnisystem_v5.marketdata.metrics import IngestionMetrics, MetricsSink
from omnisystem_v5.marketdata.router import ProviderRouter
from omnisystem_v5.marketdata.universe import InstrumentUniverse, UniverseSnapshot

SNAPSHOT_SCHEMA_VERSION = "1.0"


class RollupState(str, Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    UNAVAILABLE = "UNAVAILABLE"


@dataclass(frozen=True)
class HealthRollup:
    scope: FaultScope
    subject: str
    state: RollupState
    total: int = 0
    scannable: int = 0


@dataclass(frozen=True)
class DataSystemSnapshot:
    at: datetime
    providers: tuple
    instruments: tuple
    streams: tuple
    universe: UniverseSnapshot | None
    metrics: IngestionMetrics | None
    evidence: tuple                 # ((provider, EvidenceLevel), ...) - what has actually been demonstrated
    rollups: tuple
    schema_version: str = SNAPSHOT_SCHEMA_VERSION

    def to_dict(self) -> dict:
        return canonical_dict(self)

    def to_json(self) -> str:
        return canonical_json(self)


class StateReader(Protocol):
    def snapshot(self, now: datetime) -> DataSystemSnapshot: ...


_PROVIDER_REASONS = frozenset({K.INSTRUMENT_PROVIDER_UNAVAILABLE.value, K.INSTRUMENT_NO_PROVIDER.value})


def _rollups(now, book, router, universe: UniverseSnapshot | None) -> tuple:
    out = []
    if universe is not None:
        by_class: dict = {}
        for e in universe.entries:
            if e.asset_class is not None:
                by_class.setdefault(e.asset_class.value, []).append(e)
        for name in sorted(by_class):
            es = by_class[name]
            scannable = sum(1 for e in es if e.scannable)
            provider_blocked = sum(1 for e in es if not e.scannable and any(r.key.value in _PROVIDER_REASONS for r in e.reasons))
            if provider_blocked and scannable == 0:
                st = RollupState.UNAVAILABLE
            elif provider_blocked:
                st = RollupState.DEGRADED
            else:
                st = RollupState.HEALTHY
            out.append(HealthRollup(FaultScope.ASSET_CLASS, name, st, len(es), scannable))
    if router is not None and router.feeds:
        usable = sum(1 for f in router.feeds if may_attempt(book.provider(f.name, now), now))
        st = RollupState.UNAVAILABLE if usable == 0 else (
            RollupState.DEGRADED if any(book.provider(f.name, now).state != ProviderState.HEALTHY for f in router.feeds) else RollupState.HEALTHY)
        out.append(HealthRollup(FaultScope.SYSTEMIC, "providers", st, len(router.feeds), usable))
    return tuple(out)


def build_snapshot(now: datetime, book: HealthBook, router: ProviderRouter | None = None,
                   universe: InstrumentUniverse | None = None, metrics: MetricsSink | None = None) -> DataSystemSnapshot:
    if router is not None:
        for f in router.feeds:
            book.provider(f.name, now)                    # ensure every configured provider is represented
    usnap = universe.evaluate(now) if universe is not None else None
    evidence = tuple(sorted((f.name, f.capabilities.evidence) for f in router.feeds)) if router is not None else ()
    return DataSystemSnapshot(now, book.providers(), book.instruments(), book.streams(), usnap,
                              metrics.snapshot() if metrics is not None else None, evidence, _rollups(now, book, router, usnap))


class DataStateReader:
    """Read-only facade for a future assistant / admin UI."""

    def __init__(self, book: HealthBook, router: ProviderRouter | None = None, universe: InstrumentUniverse | None = None,
                 metrics: MetricsSink | None = None):
        self._args = (book, router, universe, metrics)

    def snapshot(self, now: datetime) -> DataSystemSnapshot:
        book, router, universe, metrics = self._args
        return build_snapshot(now, book, router, universe, metrics)
