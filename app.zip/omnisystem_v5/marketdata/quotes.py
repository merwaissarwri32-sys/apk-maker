"""Optional canonical quote record - MERWIS AI, Phase 11. Never enters MarketDataEnvelope or the scanner."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from omnisystem_v5.marketdata.config import QuotePolicy
from omnisystem_v5.marketdata.freshness import FreshnessState
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import msg
from omnisystem_v5.marketdata.normalize import parse_timestamp, to_float
from omnisystem_v5.marketdata.provider import RawQuote


class QuoteError(ValueError):
    def __init__(self, message):
        super().__init__(message.reason_str())
        self.message = message


@dataclass(frozen=True)
class Quote:
    symbol: str
    venue: str
    source: str
    timestamp: datetime
    bid: float | None = None
    ask: float | None = None
    last: float | None = None
    sequence: int | None = None

    def __post_init__(self):
        if not isinstance(self.timestamp, datetime) or self.timestamp.tzinfo is None:
            raise QuoteError(msg(K.QUOTE_INVALID, detail="timestamp must be timezone-aware"))
        for n in ("bid", "ask", "last"):
            v = getattr(self, n)
            if v is not None:
                f, err = to_float(v)
                if err or f <= 0:
                    raise QuoteError(msg(K.QUOTE_INVALID, detail=f"{n} must be a finite number > 0"))
        if self.bid is None and self.ask is None and self.last is None:
            raise QuoteError(msg(K.QUOTE_INVALID, detail="a quote needs at least one price"))
        if (self.bid is None) != (self.ask is None):
            raise QuoteError(msg(K.QUOTE_INVALID, detail="bid and ask must be given together"))
        if self.bid is not None and self.ask < self.bid:
            raise QuoteError(msg(K.QUOTE_CROSSED, bid=self.bid, ask=self.ask))


def normalize_quote(raw: RawQuote, symbol: str, venue: str, source: str) -> Quote:
    ts = parse_timestamp(raw.timestamp)
    if ts is None:
        raise QuoteError(msg(K.QUOTE_INVALID, detail="timestamp must be timezone-aware"))
    vals = {}
    for n in ("bid", "ask", "last"):
        v = getattr(raw, n)
        if v is None:
            vals[n] = None
            continue
        f, err = to_float(v)
        if err:
            raise QuoteError(msg(K.QUOTE_INVALID, detail=f"{n} is not a finite number"))
        vals[n] = f
    return Quote(symbol, venue, source, ts, sequence=raw.sequence, **vals)


def assess_quote(quote: Quote, now: datetime, policy: QuotePolicy) -> FreshnessState:
    age = (now - quote.timestamp).total_seconds()
    if age < 0:
        return FreshnessState.INVALID
    if age <= policy.max_age_seconds:
        return FreshnessState.FRESH
    if age <= policy.expired_age_seconds:
        return FreshnessState.STALE
    return FreshnessState.EXPIRED
