"""Canonical, deterministic serialization - MERWIS AI, Phase 11.

Sorted keys, UTC ISO timestamps, shortest-round-trip floats, NaN/inf refused. No wall-clock value
is added here; identity digests are computed only from the fields the caller passes in.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import math
from datetime import datetime, timezone
from enum import Enum


def canonical_dict(obj):
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: canonical_dict(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, Enum):
        return canonical_dict(obj.value)
    if isinstance(obj, datetime):
        if obj.tzinfo is None:
            raise ValueError("naive datetime cannot be serialized canonically")
        return obj.astimezone(timezone.utc).isoformat()
    if isinstance(obj, float):
        if not math.isfinite(obj):
            raise ValueError("non-finite float cannot be serialized canonically")
        return obj
    if isinstance(obj, (str, int, bool)) or obj is None:
        return obj
    if isinstance(obj, (tuple, list)):
        return [canonical_dict(x) for x in obj]
    if isinstance(obj, (set, frozenset)):
        return sorted((canonical_dict(x) for x in obj), key=lambda v: json.dumps(v, sort_keys=True))
    if isinstance(obj, dict):
        return {str(k): canonical_dict(v) for k, v in sorted(obj.items(), key=lambda kv: str(kv[0]))}
    raise TypeError(f"cannot serialize {type(obj).__name__} canonically")


def canonical_json(obj) -> str:
    return json.dumps(canonical_dict(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def digest(obj) -> str:
    return hashlib.sha256(canonical_json(obj).encode("ascii")).hexdigest()
