"""Phase 11 configuration - MERWIS AI.

SINGLE-SOURCE RULE: the analytical limits the scanner already enforces (staleness in bars,
minimum bars, fetch limit, its retry count) are NOT re-declared here. They are copied once, by
SharedLimits.from_scanner_config(), and every Phase 11 layer reads them from that one object.
verify_against() lets a caller prove the two layers still agree.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from omnisystem_v5.scanner.failures import RETRYABLE, FailureClass


class WiringMismatchError(ValueError):
    """Phase 11 and the scanner would apply different limits, or retries would multiply past the cap."""


class ConfigError(ValueError):
    pass


def _num(name, v, *, gt=None, ge=None, finite=True):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or (finite and not math.isfinite(v)):
        raise ConfigError(f"{name} must be a finite number")
    if gt is not None and not v > gt:
        raise ConfigError(f"{name} must be > {gt}")
    if ge is not None and not v >= ge:
        raise ConfigError(f"{name} must be >= {ge}")


@dataclass(frozen=True)
class SharedLimits:
    staleness_bars: float
    min_bars: int
    fetch_limit: int
    scanner_max_fetch_attempts: int

    def __post_init__(self):
        _num("staleness_bars", self.staleness_bars, gt=0)
        for n in ("min_bars", "fetch_limit", "scanner_max_fetch_attempts"):
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, int) or v < 1:
                raise ConfigError(f"{n} must be an int >= 1")
        if self.fetch_limit < self.min_bars:
            raise ConfigError("fetch_limit must be >= min_bars")

    @classmethod
    def from_scanner_config(cls, cfg) -> "SharedLimits":
        return cls(cfg.staleness_bars, cfg.min_bars, cfg.fetch_limit, cfg.max_fetch_attempts)

    def verify_against(self, cfg) -> None:
        theirs = SharedLimits.from_scanner_config(cfg)
        if theirs != self:
            raise WiringMismatchError(f"Phase 11 limits {self} disagree with the scanner's {theirs}")


@dataclass(frozen=True)
class FreshnessPolicy:
    """Only the EXPIRED horizon is Phase 11's own. The FRESH/STALE boundary is limits.staleness_bars."""
    expired_bars: float = 10.0

    def __post_init__(self):
        _num("expired_bars", self.expired_bars, gt=0)


@dataclass(frozen=True)
class ValidationPolicy:
    drop_forming_bar: bool = True          # the only bar that may be dropped by default, and it is recorded
    max_malformed_bars: int = 0            # malformed bars tolerated (dropped + recorded); 0 = reject the series
    truncate_at_session_gap: bool = False  # keep only the trailing contiguous segment after a session gap
    require_positive_prices: bool = True

    def __post_init__(self):
        if isinstance(self.max_malformed_bars, bool) or not isinstance(self.max_malformed_bars, int) or self.max_malformed_bars < 0:
            raise ConfigError("max_malformed_bars must be an int >= 0")


@dataclass(frozen=True)
class RetryPolicy:
    max_attempts: int = 1                  # 1 = no hidden retries
    base_delay_seconds: float = 0.5
    multiplier: float = 2.0
    max_delay_seconds: float = 30.0
    jitter_fraction: float = 0.1
    jitter_seed: int = 0
    rate_limit_max_wait_seconds: float = 0.0   # 0 = never wait on a rate limit; propagate it
    retry_on: frozenset = RETRYABLE

    def __post_init__(self):
        if isinstance(self.max_attempts, bool) or not isinstance(self.max_attempts, int) or self.max_attempts < 1:
            raise ConfigError("max_attempts must be an int >= 1")
        _num("base_delay_seconds", self.base_delay_seconds, ge=0)
        _num("multiplier", self.multiplier, ge=1)
        _num("max_delay_seconds", self.max_delay_seconds, ge=0)
        _num("jitter_fraction", self.jitter_fraction, ge=0)
        if self.jitter_fraction > 1:
            raise ConfigError("jitter_fraction must be <= 1")
        _num("rate_limit_max_wait_seconds", self.rate_limit_max_wait_seconds, ge=0)
        if not isinstance(self.jitter_seed, int) or isinstance(self.jitter_seed, bool):
            raise ConfigError("jitter_seed must be an int")
        if not all(isinstance(c, FailureClass) for c in self.retry_on):
            raise ConfigError("retry_on must contain FailureClass values")


@dataclass(frozen=True)
class ThrottlePolicy:
    max_requests: int | None = None        # None = client-side throttle disabled
    per_seconds: float = 1.0

    def __post_init__(self):
        if self.max_requests is not None and (isinstance(self.max_requests, bool) or not isinstance(self.max_requests, int) or self.max_requests < 1):
            raise ConfigError("max_requests must be an int >= 1 or None")
        _num("per_seconds", self.per_seconds, gt=0)


@dataclass(frozen=True)
class ProviderHealthPolicy:
    degrade_after: int = 2
    unavailable_after: int = 5
    recover_successes: int = 3
    cooldown_base_seconds: float = 30.0
    cooldown_multiplier: float = 2.0
    cooldown_max_seconds: float = 900.0
    throttle_default_seconds: float = 60.0

    def __post_init__(self):
        for n in ("degrade_after", "unavailable_after", "recover_successes"):
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, int) or v < 1:
                raise ConfigError(f"{n} must be an int >= 1")
        if self.degrade_after >= self.unavailable_after:
            raise ConfigError("degrade_after must be < unavailable_after")
        _num("cooldown_base_seconds", self.cooldown_base_seconds, gt=0)
        _num("cooldown_multiplier", self.cooldown_multiplier, ge=1)
        _num("cooldown_max_seconds", self.cooldown_max_seconds, gt=0)
        _num("throttle_default_seconds", self.throttle_default_seconds, gt=0)


@dataclass(frozen=True)
class InstrumentHealthPolicy:
    degrade_after: int = 1
    quarantine_after: int = 3
    quarantine_seconds: float = 900.0

    def __post_init__(self):
        for n in ("degrade_after", "quarantine_after"):
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, int) or v < 1:
                raise ConfigError(f"{n} must be an int >= 1")
        if self.degrade_after > self.quarantine_after:
            raise ConfigError("degrade_after must be <= quarantine_after")
        _num("quarantine_seconds", self.quarantine_seconds, gt=0)


@dataclass(frozen=True)
class QuotePolicy:
    max_age_seconds: float = 5.0
    expired_age_seconds: float = 60.0

    def __post_init__(self):
        _num("max_age_seconds", self.max_age_seconds, gt=0)
        if not self.expired_age_seconds > self.max_age_seconds:
            raise ConfigError("expired_age_seconds must be > max_age_seconds")


@dataclass(frozen=True)
class MarketDataConfig:
    limits: SharedLimits
    freshness: FreshnessPolicy = field(default_factory=FreshnessPolicy)
    validation: ValidationPolicy = field(default_factory=ValidationPolicy)
    retry: RetryPolicy = field(default_factory=RetryPolicy)
    throttle: ThrottlePolicy = field(default_factory=ThrottlePolicy)
    provider_health: ProviderHealthPolicy = field(default_factory=ProviderHealthPolicy)
    instrument_health: InstrumentHealthPolicy = field(default_factory=InstrumentHealthPolicy)
    quote: QuotePolicy = field(default_factory=QuotePolicy)
    max_total_attempts_per_request: int = 3

    def __post_init__(self):
        if self.freshness.expired_bars <= self.limits.staleness_bars:
            raise ConfigError("freshness.expired_bars must be > the shared staleness_bars")
        total = self.retry.max_attempts * self.limits.scanner_max_fetch_attempts
        if total > self.max_total_attempts_per_request:
            raise WiringMismatchError(
                f"retries would multiply: {self.retry.max_attempts} (Phase 11) x "
                f"{self.limits.scanner_max_fetch_attempts} (scanner) = {total} > cap {self.max_total_attempts_per_request}")

    @classmethod
    def for_scanner(cls, scanner_config, **overrides) -> "MarketDataConfig":
        return cls(limits=SharedLimits.from_scanner_config(scanner_config), **overrides)
