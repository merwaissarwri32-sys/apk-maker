"""Universe adapter - MERWIS AI, Phase 11. Implements scanner.universe.Universe (unchanged protocol).

symbols(now) yields a SymbolSpec ONLY for instruments that are enabled, mapped, in an OPEN session,
not quarantined, and served by at least one usable provider for every required timeframe. Everything
else is recorded with typed reasons in UniverseSnapshot.excluded (not yielded, so it never counts as a
scanner failure). Trade-off: the scanner's own `excluded` list will not show these; the precise reason
lives here. One broken listing can never break the others: each is evaluated in isolation.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from omnisystem_v5.marketdata.assets import AssetClass
from omnisystem_v5.marketdata.catalog import InstrumentCatalog
from omnisystem_v5.marketdata.health import HealthBook, InstrumentState, ProviderState, instrument_scannable
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import StructuredMessage, msg
from omnisystem_v5.marketdata.router import BLOCKED, OK, UNMAPPED, ProviderRouter
from omnisystem_v5.marketdata.sessions import MarketStatus
from omnisystem_v5.scanner.enums import TradingStatus
from omnisystem_v5.scanner.universe import SymbolSpec


@dataclass(frozen=True)
class InstrumentAvailability:
    symbol: str
    asset_class: AssetClass | None
    venue: str | None
    state: InstrumentState
    scannable: bool
    reasons: tuple = ()               # StructuredMessage
    next_open: datetime | None = None


@dataclass(frozen=True)
class UniverseSnapshot:
    at: datetime
    entries: tuple                    # InstrumentAvailability, sorted by symbol

    @property
    def excluded(self) -> tuple:
        return tuple(e for e in self.entries if not e.scannable)

    @property
    def scannable(self) -> tuple:
        return tuple(e for e in self.entries if e.scannable)


class InstrumentUniverse:
    def __init__(self, catalog: InstrumentCatalog, router: ProviderRouter, book: HealthBook, required_timeframes):
        self._catalog, self._router, self._book = catalog, router, book
        self._tfs = tuple(required_timeframes)
        if not self._tfs:
            raise ValueError("required_timeframes must not be empty")

    def evaluate(self, now: datetime) -> UniverseSnapshot:
        entries = []
        for symbol in self._catalog.symbols():
            try:
                entries.append(self._evaluate_one(symbol, now))
            except Exception as exc:                       # isolation: one listing never breaks the universe
                lst = self._catalog.any_listing(symbol)
                entries.append(InstrumentAvailability(
                    symbol, lst.instrument.asset_class if lst else None, lst.venue.code if lst else None,
                    InstrumentState.UNAVAILABLE, False, (msg(K.INSTRUMENT_INTERNAL_ERROR, detail=type(exc).__name__),)))
        return UniverseSnapshot(now, tuple(entries))

    def _evaluate_one(self, symbol: str, now: datetime) -> InstrumentAvailability:
        lst = self._catalog.primary(symbol)
        if lst is None:
            any_l = self._catalog.any_listing(symbol)
            return InstrumentAvailability(symbol, any_l.instrument.asset_class, any_l.venue.code, InstrumentState.DISABLED, False,
                                          (msg(K.INSTRUMENT_DISABLED),))
        ac, venue = lst.instrument.asset_class, lst.venue.code

        def out(state, scannable, *reasons, next_open=None):
            return InstrumentAvailability(symbol, ac, venue, state, scannable, tuple(reasons), next_open)

        status = lst.session.status(now)
        if status != MarketStatus.OPEN:
            return out(InstrumentState.UNAVAILABLE, False, msg(K.INSTRUMENT_SESSION_CLOSED, status=status),
                       next_open=lst.session.next_open(now))
        health = self._book.instrument(symbol)
        if not instrument_scannable(health, now):
            return out(InstrumentState.QUARANTINED, False, health.reason or msg(K.INSTRUMENT_QUARANTINED, until=health.quarantined_until))
        provider_states = []
        for tf in self._tfs:
            d = self._router.resolve(lst, tf, self._book, now)
            if d.reason == UNMAPPED:
                return out(InstrumentState.UNAVAILABLE, False, msg(K.DATA_UNMAPPED_INSTRUMENT, symbol=symbol))
            if d.reason == BLOCKED:
                return out(InstrumentState.UNAVAILABLE, False, msg(K.INSTRUMENT_PROVIDER_UNAVAILABLE, timeframe=tf.value))
            if d.reason != OK:
                return out(InstrumentState.UNAVAILABLE, False, msg(K.INSTRUMENT_NO_PROVIDER, timeframe=tf.value))
            provider_states.append(self._book.provider(d.route.provider, now).state)
        degraded = (health is not None and health.state == InstrumentState.DEGRADED) or \
                   any(s != ProviderState.HEALTHY for s in provider_states)
        reasons = (health.reason,) if health is not None and health.reason is not None and health.state == InstrumentState.DEGRADED else ()
        return out(InstrumentState.DEGRADED if degraded else InstrumentState.AVAILABLE, True, *reasons)

    def symbols(self, now: datetime) -> tuple:
        specs = []
        for e in self.evaluate(now).entries:
            if not e.scannable:
                continue
            lst = self._catalog.primary(e.symbol)
            specs.append(SymbolSpec(
                symbol=lst.symbol, market_type=lst.effective_market_type, quote_currency=lst.instrument.quote,
                status=TradingStatus.TRADING, quote_volume_24h=lst.quote_volume_24h,
                metadata=(("asset_class", lst.instrument.asset_class.value), ("venue", lst.venue.code))))
        return tuple(specs)
