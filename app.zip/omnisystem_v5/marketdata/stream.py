"""Streaming boundary - MERWIS AI, Phase 11.

BarStore receives updates from any push transport (a WebSocket client would live outside the core)
and keeps the latest rows per (provider_symbol, timeframe). Out-of-order / stale / malformed updates
are REJECTED with a typed reason, never applied. No stream is faked here: tests drive apply_update()
with a scripted event list.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from omnisystem_v5.data.providers.base import DataUnavailableError
from omnisystem_v5.marketdata.i18n import MessageKey as K
from omnisystem_v5.marketdata.i18n import StructuredMessage, msg
from omnisystem_v5.marketdata.normalize import parse_timestamp
from omnisystem_v5.marketdata.provider import BarRequest, ProviderCapabilities, RawBarRow, RawBars
from omnisystem_v5.schemas.enums import Timeframe


@dataclass(frozen=True)
class BarUpdate:
    provider_symbol: str
    timeframe: Timeframe
    row: RawBarRow
    sequence: int | None = None


@dataclass(frozen=True)
class UpdateResult:
    accepted: bool
    reason: StructuredMessage | None = None


class BarStore:
    def __init__(self, max_bars: int = 1000):
        if isinstance(max_bars, bool) or not isinstance(max_bars, int) or max_bars < 1:
            raise ValueError("max_bars must be an int >= 1")
        self._max = max_bars
        self._rows: dict = {}        # key -> {open_time: RawBarRow}
        self._last_seq: dict = {}
        self.rejected_count = 0

    def seed(self, provider_symbol: str, timeframe: Timeframe, rows) -> None:
        """Initial history (e.g. from a one-off bulk fetch). Bad rows are refused loudly."""
        store = self._rows.setdefault((provider_symbol, timeframe), {})
        for row in rows:
            ot = parse_timestamp(row.open_time)
            if ot is None:
                raise ValueError("cannot seed a row with an invalid open_time")
            store[ot] = row
        self._trim((provider_symbol, timeframe))

    def apply_update(self, update: BarUpdate) -> UpdateResult:
        key = (update.provider_symbol, update.timeframe)
        ot = parse_timestamp(getattr(update.row, "open_time", None))
        if ot is None:
            return self._reject(msg(K.STREAM_UPDATE_MALFORMED, detail="invalid open_time"))
        last_seq = self._last_seq.get(key)
        if update.sequence is not None and last_seq is not None and update.sequence <= last_seq:
            return self._reject(msg(K.STREAM_UPDATE_OUT_OF_ORDER, sequence=update.sequence, last=last_seq))
        store = self._rows.setdefault(key, {})
        if store and ot < max(store):
            return self._reject(msg(K.STREAM_UPDATE_OUT_OF_ORDER, sequence=update.sequence if update.sequence is not None else "none",
                                    last=last_seq if last_seq is not None else "none"))
        store[ot] = update.row                      # same open_time = update of the forming bar
        if update.sequence is not None:
            self._last_seq[key] = update.sequence
        self._trim(key)
        return UpdateResult(True)

    def _reject(self, reason) -> UpdateResult:
        self.rejected_count += 1
        return UpdateResult(False, reason)

    def _trim(self, key) -> None:
        store = self._rows[key]
        for ot in sorted(store)[:-self._max]:
            del store[ot]

    def snapshot(self, provider_symbol: str, timeframe: Timeframe, limit: int) -> tuple:
        store = self._rows.get((provider_symbol, timeframe), {})
        return tuple(store[ot] for ot in sorted(store)[-limit:])


class StreamingFeed:
    def __init__(self, name: str, capabilities: ProviderCapabilities, store: BarStore):
        self.name = name
        self._caps = capabilities
        self._store = store

    @property
    def capabilities(self) -> ProviderCapabilities:
        return self._caps

    def latest_bars(self, request: BarRequest) -> RawBars:
        rows = self._store.snapshot(request.provider_symbol, request.timeframe, request.limit)
        if not rows:
            raise DataUnavailableError(f"{self.name}: no streamed bars for {request.provider_symbol} {request.timeframe.value}")
        return RawBars(self.name, request.provider_symbol, rows, request.timeframe)
