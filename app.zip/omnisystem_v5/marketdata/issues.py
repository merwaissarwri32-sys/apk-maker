"""Typed data issues and fault scope - MERWIS AI, Phase 11.

FaultScope says WHERE a fault sits; scanner.failures.FailureClass (reused, not duplicated)
says WHAT it was. They are orthogonal axes, not two taxonomies of the same thing.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from omnisystem_v5.marketdata.i18n import StructuredMessage


class FaultScope(str, Enum):
    SYMBOL = "SYMBOL"            # one symbol at one timeframe (a stream)
    INSTRUMENT = "INSTRUMENT"    # the whole instrument (mapping, listing, repeated bad data)
    PROVIDER = "PROVIDER"
    ASSET_CLASS = "ASSET_CLASS"  # derived roll-up
    SYSTEMIC = "SYSTEMIC"        # derived roll-up


@dataclass(frozen=True)
class DataIssue:
    message: StructuredMessage
    scope: FaultScope = FaultScope.SYMBOL
    fatal: bool = True           # False = informational (e.g. a dropped forming bar), never blocks data
