"""
Risk Engine - MERWIS AI, Phase 5.

    TradeCandidateInput + AccountState + RiskPolicy -> RiskAssessmentResult

Pipeline (strict order, fail-closed, short-circuits on the first
blocking failure so a result never carries rejection codes from
multiple unrelated stages):

  1. Data integrity      -> DATA_INVALID
  2. Direction / SL shape -> REJECTED (wrong side / equals entry / too
                             tight / bad precision) or RISK_BLOCKED
                             (too wide - this is a risk-limit concern,
                             not a data-validity one)
  3. Take-profit shape    -> REJECTED
  4. Reward:Risk          -> REJECTED
  5. Position sizing      -> RISK_BLOCKED
  6. Account-level limits -> RISK_BLOCKED
  7. Otherwise            -> WARNING (if any non-blocking concern was
                             raised along the way) or VALID

This module performs NO market analysis of any kind - it has no
knowledge of structure, liquidity, FVGs, or scenario types, and never
imports from intelligence/, quant/, or context/.
"""

from __future__ import annotations

from datetime import datetime, timezone

from omnisystem_v5.risk.contracts import AccountState, RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.enums import RejectionReasonCode, RiskDecision, WarningCode
from omnisystem_v5.risk.position_sizing import calculate_position_size
from omnisystem_v5.risk.result import RiskAssessmentResult
from omnisystem_v5.risk.validators import (
    compute_reward_and_rr,
    validate_account_limits,
    validate_data_integrity,
    validate_direction_and_sl,
    validate_rr,
    validate_take_profits,
)

_SL_RISK_LIMIT_CODES = {RejectionReasonCode.SL_TOO_WIDE}


def _blocked(
    symbol, direction, decision, now, rejections, warnings=(), details=(),
    entry=None, stop_loss=None, take_profits=(),
) -> RiskAssessmentResult:
    return RiskAssessmentResult(
        symbol=symbol, direction=direction, decision=decision, evaluated_at=now,
        entry=entry, stop_loss=stop_loss, take_profits=take_profits,
        rejection_reasons=tuple(rejections), warnings=tuple(warnings), details=tuple(details),
    )


def assess_risk(
    candidate: TradeCandidateInput,
    account: AccountState,
    policy: RiskPolicy | None = None,
    now: datetime | None = None,
) -> RiskAssessmentResult:
    policy = policy or RiskPolicy()
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware (UTC) if provided")

    # --- Stage 1: data integrity (fail-closed, always first) ---
    data_check = validate_data_integrity(candidate, account)
    if not data_check.ok:
        return _blocked(candidate.symbol, candidate.direction, RiskDecision.DATA_INVALID, now,
                         data_check.rejections, details=data_check.details)

    all_warnings: list[WarningCode] = []
    all_details: list[str] = list(data_check.details)

    # --- Stage 2: direction / SL shape ---
    sl_check = validate_direction_and_sl(candidate, policy)
    all_details.extend(sl_check.details)
    if not sl_check.ok:
        decision = RiskDecision.RISK_BLOCKED if any(r in _SL_RISK_LIMIT_CODES for r in sl_check.rejections) else RiskDecision.REJECTED
        return _blocked(candidate.symbol, candidate.direction, decision, now, sl_check.rejections,
                         all_warnings, all_details, entry=candidate.entry, stop_loss=candidate.stop_loss,
                         take_profits=candidate.take_profits)
    all_warnings.extend(sl_check.warnings)

    # --- Stage 3: take-profit shape ---
    tp_check = validate_take_profits(candidate, policy)
    all_details.extend(tp_check.details)
    if not tp_check.ok:
        return _blocked(candidate.symbol, candidate.direction, RiskDecision.REJECTED, now, tp_check.rejections,
                         all_warnings, all_details, entry=candidate.entry, stop_loss=candidate.stop_loss,
                         take_profits=candidate.take_profits)
    all_warnings.extend(tp_check.warnings)

    # --- Stage 4: reward / R:R ---
    risk_per_unit = abs(candidate.entry - candidate.stop_loss)
    reward_distances, rr_ratios = compute_reward_and_rr(candidate, risk_per_unit)
    rr_check = validate_rr(rr_ratios, policy)
    all_details.extend(rr_check.details)
    if not rr_check.ok:
        return _blocked(candidate.symbol, candidate.direction, RiskDecision.REJECTED, now, rr_check.rejections,
                         all_warnings, all_details, entry=candidate.entry, stop_loss=candidate.stop_loss,
                         take_profits=candidate.take_profits)
    all_warnings.extend(rr_check.warnings)

    # --- Stage 5: position sizing (deterministic, never inflated for reward) ---
    risk_pct_requested = candidate.requested_risk_pct if candidate.requested_risk_pct is not None else policy.max_risk_per_trade_pct
    risk_pct_used = min(risk_pct_requested, policy.max_risk_per_trade_pct)
    size = calculate_position_size(account.equity, risk_pct_used, candidate.entry, candidate.stop_loss, candidate.instrument)
    all_details.extend(size.details)
    if not size.ok:
        return _blocked(candidate.symbol, candidate.direction, RiskDecision.RISK_BLOCKED, now, size.rejection_reasons,
                         all_warnings, all_details, entry=candidate.entry, stop_loss=candidate.stop_loss,
                         take_profits=candidate.take_profits)
    all_warnings.extend(size.warnings)

    # --- Stage 6: account-level limits ---
    account_check = validate_account_limits(size.actual_risk_amount, size.notional, policy, account)
    all_details.extend(account_check.details)
    if not account_check.ok:
        return _blocked(candidate.symbol, candidate.direction, RiskDecision.RISK_BLOCKED, now, account_check.rejections,
                         all_warnings, all_details, entry=candidate.entry, stop_loss=candidate.stop_loss,
                         take_profits=candidate.take_profits)
    all_warnings.extend(account_check.warnings)

    # --- Everything passed ---
    decision = RiskDecision.WARNING if all_warnings else RiskDecision.VALID
    risk_percentage = size.actual_risk_amount / account.equity * 100.0

    return RiskAssessmentResult(
        symbol=candidate.symbol, direction=candidate.direction, decision=decision, evaluated_at=now,
        entry=candidate.entry, stop_loss=candidate.stop_loss, take_profits=candidate.take_profits,
        risk_amount=size.actual_risk_amount, risk_percentage=risk_percentage,
        reward_amounts=reward_distances, reward_risk_ratios=rr_ratios, primary_reward_risk_ratio=rr_ratios[0],
        position_size=size.quantity, position_notional=size.notional,
        warnings=tuple(all_warnings), details=tuple(all_details),
    )
