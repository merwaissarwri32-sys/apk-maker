"""
Deterministic Position Sizing - MERWIS AI, Phase 5.

Formula (and ONLY this formula - there is no alternate path that
inflates size to chase a reward target):

    target_risk_amount = equity * (risk_pct / 100)
    per_unit_risk       = abs(entry - stop_loss) * contract_size
    raw_quantity        = target_risk_amount / per_unit_risk

If the instrument defines a position_step, the quantity is rounded
DOWN (floored) to the nearest step - never up, since rounding up would
silently increase risk beyond what was requested. If the resulting
quantity is below the instrument's min_position_size, or the raw
result is non-positive, sizing fails outright rather than substituting
a minimum size the caller didn't ask for.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from omnisystem_v5.risk.contracts import InstrumentSpec
from omnisystem_v5.risk.enums import RejectionReasonCode, WarningCode


@dataclass(frozen=True)
class PositionSizeResult:
    quantity: float | None
    actual_risk_amount: float | None    # recomputed from the (possibly rounded) quantity - the TRUE risk taken
    notional: float | None
    rejection_reasons: tuple[RejectionReasonCode, ...] = field(default_factory=tuple)
    warnings: tuple[WarningCode, ...] = field(default_factory=tuple)
    details: tuple[str, ...] = field(default_factory=tuple)

    @property
    def ok(self) -> bool:
        return self.quantity is not None and len(self.rejection_reasons) == 0


def calculate_position_size(
    equity: float,
    risk_pct: float,
    entry: float,
    stop_loss: float,
    instrument: InstrumentSpec | None = None,
) -> PositionSizeResult:
    per_unit_price_risk = abs(entry - stop_loss)
    contract_size = instrument.contract_size if instrument else 1.0
    per_unit_risk = per_unit_price_risk * contract_size

    if per_unit_risk <= 0:
        return PositionSizeResult(
            quantity=None, actual_risk_amount=None, notional=None,
            rejection_reasons=(RejectionReasonCode.POSITION_SIZE_IMPOSSIBLE,),
            details=("per-unit risk is zero or negative — cannot size a position",),
        )

    target_risk_amount = equity * (risk_pct / 100.0)
    raw_quantity = target_risk_amount / per_unit_risk

    if raw_quantity <= 0:
        return PositionSizeResult(
            quantity=None, actual_risk_amount=None, notional=None,
            rejection_reasons=(RejectionReasonCode.POSITION_SIZE_ZERO,),
            details=(f"computed raw quantity {raw_quantity} is non-positive",),
        )

    quantity = raw_quantity
    warnings: list[WarningCode] = []
    details: list[str] = []

    if instrument and instrument.position_step and instrument.position_step > 0:
        step = instrument.position_step
        floored = math.floor(quantity / step) * step
        if floored != quantity:
            warnings.append(WarningCode.POSITION_SIZE_ROUNDED_DOWN)
            details.append(f"quantity rounded down from {quantity} to nearest step {step} -> {floored}")
        quantity = floored

    if quantity <= 0:
        return PositionSizeResult(
            quantity=None, actual_risk_amount=None, notional=None,
            rejection_reasons=(RejectionReasonCode.POSITION_SIZE_ZERO,),
            details=tuple(details) + ("quantity rounded down to zero after applying position_step",),
        )

    if instrument and instrument.min_position_size and quantity < instrument.min_position_size:
        return PositionSizeResult(
            quantity=None, actual_risk_amount=None, notional=None,
            rejection_reasons=(RejectionReasonCode.POSITION_SIZE_IMPOSSIBLE,),
            details=tuple(details) + (
                f"sized quantity {quantity} is below instrument minimum {instrument.min_position_size} — "
                "never rounded UP to meet a minimum, since that would exceed the requested risk",
            ),
        )

    actual_risk_amount = quantity * per_unit_risk
    notional = quantity * entry * contract_size

    return PositionSizeResult(
        quantity=quantity, actual_risk_amount=actual_risk_amount, notional=notional,
        warnings=tuple(warnings), details=tuple(details),
    )
