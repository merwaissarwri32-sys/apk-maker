"""
Risk Result Contract - MERWIS AI, Phase 5.

The single object type Master Decision Engine (future) will consume.
Every rejection/warning is a structured code, never a bare string -
`details` carries human-readable text ALONGSIDE the codes, never
instead of them.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from omnisystem_v5.risk.contracts import Direction
from omnisystem_v5.risk.enums import RejectionReasonCode, RiskDecision, WarningCode

_ACTIONABLE_DECISIONS = {RiskDecision.VALID, RiskDecision.WARNING}


@dataclass(frozen=True)
class RiskAssessmentResult:
    symbol: str
    direction: Direction
    decision: RiskDecision
    evaluated_at: datetime

    entry: float | None = None
    stop_loss: float | None = None
    take_profits: tuple[float, ...] = field(default_factory=tuple)

    risk_amount: float | None = None           # $ at risk, given the sized position
    risk_percentage: float | None = None       # risk_amount / equity * 100
    reward_amounts: tuple[float, ...] = field(default_factory=tuple)   # one per TP, aligned by index
    reward_risk_ratios: tuple[float, ...] = field(default_factory=tuple)  # one per TP, aligned by index
    primary_reward_risk_ratio: float | None = None    # the TP1-based ratio actually validated against policy

    position_size: float | None = None
    position_notional: float | None = None

    rejection_reasons: tuple[RejectionReasonCode, ...] = field(default_factory=tuple)
    warnings: tuple[WarningCode, ...] = field(default_factory=tuple)
    details: tuple[str, ...] = field(default_factory=tuple)   # human-readable, ALWAYS paired with a code above

    def __post_init__(self):
        if self.evaluated_at.tzinfo is None:
            raise ValueError("evaluated_at must be timezone-aware (UTC)")
        if self.decision in (RiskDecision.REJECTED, RiskDecision.RISK_BLOCKED, RiskDecision.DATA_INVALID) and not self.rejection_reasons:
            raise ValueError(f"decision={self.decision.value} must carry at least one RejectionReasonCode")
        if self.decision == RiskDecision.VALID and self.rejection_reasons:
            raise ValueError("decision=VALID cannot carry rejection_reasons")

    @property
    def is_actionable(self) -> bool:
        """VALID or WARNING only. REJECTED/RISK_BLOCKED/DATA_INVALID are
        NEVER actionable, regardless of how close they came to passing -
        this is the fail-closed guarantee at the contract level, not just
        a convention callers have to remember."""
        return self.decision in _ACTIONABLE_DECISIONS
