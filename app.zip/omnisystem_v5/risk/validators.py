"""
Pure validation functions - MERWIS AI, Phase 5.

Every function here is a pure function: given the same input it always
returns the same output, with no side effects, no clock reads that
affect the verdict, no randomness. Each returns a list of
RejectionReasonCode / WarningCode plus paired human-readable details -
never a bare string alone.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from omnisystem_v5.risk.contracts import AccountState, InstrumentSpec, RiskPolicy, TradeCandidateInput
from omnisystem_v5.risk.enums import Direction, RejectionReasonCode, WarningCode


@dataclass(frozen=True)
class ValidationOutcome:
    rejections: tuple[RejectionReasonCode, ...] = field(default_factory=tuple)
    warnings: tuple[WarningCode, ...] = field(default_factory=tuple)
    details: tuple[str, ...] = field(default_factory=tuple)

    @property
    def ok(self) -> bool:
        return len(self.rejections) == 0


def _finite(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def validate_data_integrity(candidate: TradeCandidateInput, account: AccountState) -> ValidationOutcome:
    """MUST run first. Fail-closed: any non-finite/missing/nonsensical
    numeric input stops the pipeline before any arithmetic is attempted
    elsewhere (which could otherwise silently propagate NaN/inf)."""
    rejections: list[RejectionReasonCode] = []
    details: list[str] = []

    if candidate.direction not in (Direction.LONG, Direction.SHORT):
        rejections.append(RejectionReasonCode.DATA_INVALID_DIRECTION)
        details.append(f"direction={candidate.direction!r} is not a recognized Direction")

    for name, value in (("entry", candidate.entry), ("stop_loss", candidate.stop_loss), ("equity", account.equity)):
        if value is None:
            rejections.append(RejectionReasonCode.DATA_MISSING_FIELD)
            details.append(f"{name} is missing (None)")
        elif not _finite(value):
            rejections.append(RejectionReasonCode.DATA_NOT_FINITE)
            details.append(f"{name}={value!r} is NaN or infinite")

    for i, tp in enumerate(candidate.take_profits, start=1):
        if tp is None:
            rejections.append(RejectionReasonCode.DATA_MISSING_FIELD)
            details.append(f"take_profit[{i}] is missing (None)")
        elif not _finite(tp):
            rejections.append(RejectionReasonCode.DATA_NOT_FINITE)
            details.append(f"take_profit[{i}]={tp!r} is NaN or infinite")

    # Only check sign/positivity once we know the values are actually finite numbers.
    if _finite(account.equity) and account.equity <= 0:
        rejections.append(RejectionReasonCode.DATA_NONPOSITIVE_EQUITY)
        details.append(f"equity={account.equity} must be positive")
    if _finite(candidate.entry) and candidate.entry <= 0:
        rejections.append(RejectionReasonCode.DATA_NONPOSITIVE_ENTRY)
        details.append(f"entry={candidate.entry} must be positive")
    if _finite(candidate.stop_loss) and candidate.stop_loss <= 0:
        rejections.append(RejectionReasonCode.DATA_NONPOSITIVE_STOP_LOSS)
        details.append(f"stop_loss={candidate.stop_loss} must be positive")

    if len(candidate.take_profits) == 0:
        rejections.append(RejectionReasonCode.DATA_NO_TAKE_PROFIT)
        details.append("at least one take profit is required")
    elif len(set(candidate.take_profits)) != len(candidate.take_profits):
        rejections.append(RejectionReasonCode.DATA_DUPLICATE_TAKE_PROFIT)
        details.append(f"duplicate take profit values in {candidate.take_profits}")

    if candidate.instrument is not None:
        instr = candidate.instrument
        for name, value in (
            ("tick_size", instr.tick_size), ("min_position_size", instr.min_position_size),
            ("position_step", instr.position_step), ("contract_size", instr.contract_size),
        ):
            if value is not None and (not _finite(value) or value < 0):
                rejections.append(RejectionReasonCode.DATA_UNSUPPORTED_INSTRUMENT_SPEC)
                details.append(f"instrument.{name}={value!r} is invalid")

    return ValidationOutcome(rejections=tuple(rejections), details=tuple(details))


def validate_direction_and_sl(candidate: TradeCandidateInput, policy: RiskPolicy) -> ValidationOutcome:
    """Assumes validate_data_integrity already passed (all numbers finite
    and positive) - this checks structural/geometric validity."""
    entry, sl, direction = candidate.entry, candidate.stop_loss, candidate.direction
    rejections: list[RejectionReasonCode] = []
    warnings: list[WarningCode] = []
    details: list[str] = []

    if sl == entry:
        rejections.append(RejectionReasonCode.SL_EQUALS_ENTRY)
        details.append("stop_loss equals entry — zero risk distance")
        return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))

    if direction == Direction.LONG and sl >= entry:
        rejections.append(RejectionReasonCode.SL_WRONG_SIDE)
        details.append(f"LONG stop_loss={sl} must be below entry={entry}")
    elif direction == Direction.SHORT and sl <= entry:
        rejections.append(RejectionReasonCode.SL_WRONG_SIDE)
        details.append(f"SHORT stop_loss={sl} must be above entry={entry}")

    if rejections:
        return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))

    sl_distance_pct = abs(entry - sl) / entry * 100.0
    if sl_distance_pct < policy.min_sl_distance_pct:
        rejections.append(RejectionReasonCode.SL_TOO_TIGHT)
        details.append(f"SL distance {sl_distance_pct:.4f}% is below minimum {policy.min_sl_distance_pct}%")
    elif sl_distance_pct > policy.max_sl_distance_pct:
        rejections.append(RejectionReasonCode.SL_TOO_WIDE)
        details.append(f"SL distance {sl_distance_pct:.4f}% exceeds maximum {policy.max_sl_distance_pct}%")
    elif sl_distance_pct > policy.max_sl_distance_pct * 0.9:
        warnings.append(WarningCode.SL_NEAR_MAX_ALLOWED_DISTANCE)
        details.append(f"SL distance {sl_distance_pct:.4f}% is within 10% of the maximum allowed {policy.max_sl_distance_pct}%")

    if candidate.instrument and candidate.instrument.tick_size:
        tick = candidate.instrument.tick_size
        remainder = abs(sl / tick - round(sl / tick))
        if remainder > 1e-6:
            rejections.append(RejectionReasonCode.SL_PRECISION_INVALID)
            details.append(f"stop_loss={sl} is not aligned to tick_size={tick}")

    return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))


def validate_take_profits(candidate: TradeCandidateInput, policy: RiskPolicy) -> ValidationOutcome:
    entry, direction, tps = candidate.entry, candidate.direction, candidate.take_profits
    rejections: list[RejectionReasonCode] = []
    warnings: list[WarningCode] = []
    details: list[str] = []

    for i, tp in enumerate(tps, start=1):
        if tp == entry:
            rejections.append(RejectionReasonCode.TP_EQUALS_ENTRY)
            details.append(f"TP{i}={tp} equals entry")
            continue
        if direction == Direction.LONG and tp <= entry:
            rejections.append(RejectionReasonCode.TP_WRONG_SIDE)
            details.append(f"LONG TP{i}={tp} must be above entry={entry}")
        elif direction == Direction.SHORT and tp >= entry:
            rejections.append(RejectionReasonCode.TP_WRONG_SIDE)
            details.append(f"SHORT TP{i}={tp} must be below entry={entry}")
        else:
            distance_pct = abs(tp - entry) / entry * 100.0
            if distance_pct < policy.min_tp_distance_pct:
                rejections.append(RejectionReasonCode.TP_TOO_CLOSE)
                details.append(f"TP{i} distance {distance_pct:.4f}% is below minimum {policy.min_tp_distance_pct}%")

    if rejections:
        return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))

    if len(tps) > 1:
        if direction == Direction.LONG:
            ordered = all(tps[i] < tps[i + 1] for i in range(len(tps) - 1))
        else:
            ordered = all(tps[i] > tps[i + 1] for i in range(len(tps) - 1))
        if not ordered:
            rejections.append(RejectionReasonCode.TP_INVALID_ORDERING)
            expected = "TP1 < TP2 < TP3" if direction == Direction.LONG else "TP1 > TP2 > TP3"
            details.append(f"take profits {tps} are not strictly ordered correctly for {direction.value} (expected {expected})")

    if 0 < len(tps) < 3:
        warnings.append(WarningCode.ONLY_PARTIAL_TAKE_PROFITS_PROVIDED)
        details.append(f"only {len(tps)} take profit(s) provided")

    return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))


def compute_reward_and_rr(candidate: TradeCandidateInput, risk_amount_per_unit: float) -> tuple[tuple[float, ...], tuple[float, ...]]:
    """Pure arithmetic - no validation here (callers validate first).
    Returns (reward_distances, reward_risk_ratios), one pair per TP,
    aligned by index. Reward distance is in PRICE units (not $), same
    basis as risk_amount_per_unit (abs(entry - stop_loss))."""
    entry = candidate.entry
    rewards = tuple(abs(tp - entry) for tp in candidate.take_profits)
    ratios = tuple((r / risk_amount_per_unit) if risk_amount_per_unit > 0 else 0.0 for r in rewards)
    return rewards, ratios


def validate_rr(reward_risk_ratios: tuple[float, ...], policy: RiskPolicy) -> ValidationOutcome:
    """Validates the PRIMARY ratio (TP1, i.e. index 0) against policy -
    exactly one number decides pass/fail, always the nearest target,
    which is the conservative choice (further TPs only look better)."""
    if not reward_risk_ratios:
        return ValidationOutcome(rejections=(RejectionReasonCode.DATA_NO_TAKE_PROFIT,), details=("no reward:risk ratio could be computed",))

    primary = reward_risk_ratios[0]
    if primary < policy.min_reward_risk_ratio:
        return ValidationOutcome(
            rejections=(RejectionReasonCode.RR_BELOW_MINIMUM,),
            details=(f"primary R:R={primary:.4f} is below minimum {policy.min_reward_risk_ratio}",),
        )
    if primary < policy.min_reward_risk_ratio + policy.rr_marginal_buffer:
        return ValidationOutcome(
            warnings=(WarningCode.RR_MARGINAL,),
            details=(f"primary R:R={primary:.4f} passes but is within {policy.rr_marginal_buffer} of the minimum {policy.min_reward_risk_ratio}",),
        )
    return ValidationOutcome()


def validate_account_limits(
    risk_amount: float, notional: float, policy: RiskPolicy, account: AccountState
) -> ValidationOutcome:
    rejections: list[RejectionReasonCode] = []
    warnings: list[WarningCode] = []
    details: list[str] = []

    equity = account.equity

    per_trade_pct = risk_amount / equity * 100.0
    if per_trade_pct > policy.max_risk_per_trade_pct + 1e-9:
        rejections.append(RejectionReasonCode.MAX_RISK_PER_TRADE_EXCEEDED)
        details.append(f"trade risk {per_trade_pct:.4f}% exceeds max_risk_per_trade_pct={policy.max_risk_per_trade_pct}%")

    total_open_risk_pct = (account.existing_open_risk_amount + risk_amount) / equity * 100.0
    if total_open_risk_pct > policy.max_total_open_risk_pct + 1e-9:
        rejections.append(RejectionReasonCode.MAX_TOTAL_OPEN_RISK_EXCEEDED)
        details.append(f"total open risk {total_open_risk_pct:.4f}% would exceed max_total_open_risk_pct={policy.max_total_open_risk_pct}%")
    elif total_open_risk_pct > policy.max_total_open_risk_pct * 0.9:
        warnings.append(WarningCode.OPEN_RISK_NEAR_LIMIT)
        details.append(f"total open risk {total_open_risk_pct:.4f}% is within 10% of the limit {policy.max_total_open_risk_pct}%")

    total_exposure_pct = (account.existing_exposure_amount + notional) / equity * 100.0
    if total_exposure_pct > policy.max_exposure_pct + 1e-9:
        rejections.append(RejectionReasonCode.MAX_EXPOSURE_EXCEEDED)
        details.append(f"total exposure {total_exposure_pct:.4f}% would exceed max_exposure_pct={policy.max_exposure_pct}%")
    elif total_exposure_pct > policy.max_exposure_pct * 0.9:
        warnings.append(WarningCode.EXPOSURE_NEAR_LIMIT)
        details.append(f"total exposure {total_exposure_pct:.4f}% is within 10% of the limit {policy.max_exposure_pct}%")

    if policy.max_concurrent_risk_count is not None and account.existing_open_positions_count + 1 > policy.max_concurrent_risk_count:
        rejections.append(RejectionReasonCode.MAX_CONCURRENT_RISK_EXCEEDED)
        details.append(f"opening this position would result in {account.existing_open_positions_count + 1} concurrent positions, exceeding {policy.max_concurrent_risk_count}")

    if policy.daily_loss_limit_pct is not None:
        daily_loss_pct = account.daily_loss_amount / equity * 100.0
        if daily_loss_pct >= policy.daily_loss_limit_pct:
            rejections.append(RejectionReasonCode.DAILY_LOSS_LIMIT_EXCEEDED)
            details.append(f"daily loss {daily_loss_pct:.4f}% has reached/exceeded daily_loss_limit_pct={policy.daily_loss_limit_pct}%")

    if policy.consecutive_loss_guard is not None and account.consecutive_losses >= policy.consecutive_loss_guard:
        rejections.append(RejectionReasonCode.CONSECUTIVE_LOSS_GUARD_TRIGGERED)
        details.append(f"consecutive_losses={account.consecutive_losses} has reached the guard threshold {policy.consecutive_loss_guard}")

    return ValidationOutcome(tuple(rejections), tuple(warnings), tuple(details))
