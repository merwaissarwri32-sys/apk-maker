"""
Risk Contract - MERWIS AI, Phase 5.

All dataclasses here are plain data + self-validation only. No market
analysis, no direction guessing, no computation beyond input sanity
checks lives in this module - that belongs in validators.py/engine.py.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from omnisystem_v5.risk.enums import Direction


def _is_finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


@dataclass(frozen=True)
class InstrumentSpec:
    """Optional. When absent, the engine still functions but skips
    precision/tick-size and minimum-size checks (documented as reduced
    confidence, never silently assumed to be fine)."""

    symbol: str
    tick_size: float | None = None          # smallest price increment
    price_decimals: int | None = None       # decimal places for price rounding/precision checks
    min_position_size: float | None = None  # smallest tradeable quantity
    position_step: float | None = None      # quantity must be a multiple of this
    contract_size: float = 1.0              # price-move-to-value multiplier (e.g. lot size)


@dataclass(frozen=True)
class AccountState:
    """Snapshot of account risk state at evaluation time. All exposure/
    risk figures are plain currency amounts in `currency`, already
    aggregated by the caller - the Risk Engine does not track state
    across calls (determinism: no hidden state)."""

    equity: float
    currency: str = "USD"
    existing_open_risk_amount: float = 0.0     # sum of $ risk on all currently open positions
    existing_exposure_amount: float = 0.0      # sum of notional exposure on all currently open positions
    existing_open_positions_count: int = 0
    daily_loss_amount: float = 0.0             # realized loss so far today (positive number = loss)
    consecutive_losses: int = 0


@dataclass(frozen=True)
class RiskPolicy:
    """Every threshold is explicit and overridable - nothing here is a
    hard-coded magic number inside the engine itself. Defaults are
    reasonable, conservative starting points, not requirements."""

    max_risk_per_trade_pct: float = 1.0        # % of equity risked on a single trade
    max_total_open_risk_pct: float = 5.0       # % of equity allowed as SUM of all open risk
    max_exposure_pct: float = 20.0             # % of equity allowed as SUM of all notional exposure
    max_concurrent_risk_count: int | None = None
    daily_loss_limit_pct: float | None = None
    consecutive_loss_guard: int | None = None

    min_reward_risk_ratio: float = 2.0         # the "1:2" default from the spec - fully overridable
    min_sl_distance_pct: float = 0.05          # SL closer than this (% of entry) is REJECTED as unrealistic
    max_sl_distance_pct: float = 10.0          # SL farther than this (% of entry) is RISK_BLOCKED
    min_tp_distance_pct: float = 0.05          # TP closer than this to entry is REJECTED as unrealistic
    rr_marginal_buffer: float = 0.1            # RR within this much of the minimum triggers a WARNING, not silence


@dataclass(frozen=True)
class TradeCandidateInput:
    """The horizon-agnostic input contract. Any future Intelligence
    Engine (Scalp, Intraday, Short-Swing, or something not yet built)
    produces one of these via its own adapter - the Risk Engine itself
    never imports or knows about those engines' candidate types."""

    symbol: str
    direction: Direction
    entry: float
    stop_loss: float
    take_profits: tuple[float, ...] = field(default_factory=tuple)   # ordered TP1, TP2, TP3, ...
    horizon: str = "UNSPECIFIED"       # e.g. "SCALP", "INTRADAY", "SHORT_SWING" - free label only, not enforced
    source: str = "UNSPECIFIED"        # which engine/model produced this candidate
    instrument: InstrumentSpec | None = None
    requested_risk_pct: float | None = None   # if the caller wants a specific risk % for sizing; else policy default is used
