"""
Risk Engine enumerations - MERWIS AI, Phase 5.

This module has ZERO imports from intelligence/, quant/, or context/ -
the Risk Engine is a self-contained, independently testable authority.
It knows nothing about market structure, FVGs, liquidity, or scenario
types. It only knows numbers: entry, stop, targets, equity, policy.
"""

from enum import Enum


class Direction(str, Enum):
    """Risk-local direction vocabulary - deliberately NOT the same enum
    as intelligence.enums.DirectionBias, to keep this package import-free
    of the intelligence layer. See intelligence/risk_bridge.py for the
    one place that translates between the two."""

    LONG = "LONG"
    SHORT = "SHORT"


class RiskDecision(str, Enum):
    VALID = "VALID"
    WARNING = "WARNING"
    REJECTED = "REJECTED"
    RISK_BLOCKED = "RISK_BLOCKED"
    DATA_INVALID = "DATA_INVALID"


class RejectionReasonCode(str, Enum):
    """Structured, stable reason codes - never a free-form string alone.
    Grouped by validation stage for readability; the grouping is not
    load-bearing (all codes live in one flat enum for simple equality
    checks by callers)."""

    # --- Data integrity (checked first, fail-closed) ---
    DATA_MISSING_FIELD = "DATA_MISSING_FIELD"
    DATA_NOT_FINITE = "DATA_NOT_FINITE"          # NaN or +/-infinity anywhere numeric
    DATA_NONPOSITIVE_EQUITY = "DATA_NONPOSITIVE_EQUITY"
    DATA_NONPOSITIVE_ENTRY = "DATA_NONPOSITIVE_ENTRY"
    DATA_NONPOSITIVE_STOP_LOSS = "DATA_NONPOSITIVE_STOP_LOSS"
    DATA_INVALID_DIRECTION = "DATA_INVALID_DIRECTION"
    DATA_NO_TAKE_PROFIT = "DATA_NO_TAKE_PROFIT"
    DATA_DUPLICATE_TAKE_PROFIT = "DATA_DUPLICATE_TAKE_PROFIT"
    DATA_UNSUPPORTED_INSTRUMENT_SPEC = "DATA_UNSUPPORTED_INSTRUMENT_SPEC"

    # --- Structural SL/TP validity ---
    SL_EQUALS_ENTRY = "SL_EQUALS_ENTRY"
    SL_WRONG_SIDE = "SL_WRONG_SIDE"
    SL_TOO_TIGHT = "SL_TOO_TIGHT"
    SL_TOO_WIDE = "SL_TOO_WIDE"
    SL_PRECISION_INVALID = "SL_PRECISION_INVALID"
    TP_WRONG_SIDE = "TP_WRONG_SIDE"
    TP_EQUALS_ENTRY = "TP_EQUALS_ENTRY"
    TP_INVALID_ORDERING = "TP_INVALID_ORDERING"
    TP_TOO_CLOSE = "TP_TOO_CLOSE"

    # --- Reward / R:R ---
    RR_BELOW_MINIMUM = "RR_BELOW_MINIMUM"

    # --- Position sizing ---
    POSITION_SIZE_ZERO = "POSITION_SIZE_ZERO"
    POSITION_SIZE_IMPOSSIBLE = "POSITION_SIZE_IMPOSSIBLE"

    # --- Account-level risk limits ---
    MAX_RISK_PER_TRADE_EXCEEDED = "MAX_RISK_PER_TRADE_EXCEEDED"
    MAX_TOTAL_OPEN_RISK_EXCEEDED = "MAX_TOTAL_OPEN_RISK_EXCEEDED"
    MAX_EXPOSURE_EXCEEDED = "MAX_EXPOSURE_EXCEEDED"
    MAX_CONCURRENT_RISK_EXCEEDED = "MAX_CONCURRENT_RISK_EXCEEDED"
    DAILY_LOSS_LIMIT_EXCEEDED = "DAILY_LOSS_LIMIT_EXCEEDED"
    CONSECUTIVE_LOSS_GUARD_TRIGGERED = "CONSECUTIVE_LOSS_GUARD_TRIGGERED"


class WarningCode(str, Enum):
    """Non-blocking concerns - the candidate may still be actionable,
    but the caller should see these."""

    RR_MARGINAL = "RR_MARGINAL"                        # passes minimum but only barely
    TP_FAR_BEYOND_TYPICAL_RANGE = "TP_FAR_BEYOND_TYPICAL_RANGE"
    SL_NEAR_MAX_ALLOWED_DISTANCE = "SL_NEAR_MAX_ALLOWED_DISTANCE"
    EXPOSURE_NEAR_LIMIT = "EXPOSURE_NEAR_LIMIT"
    OPEN_RISK_NEAR_LIMIT = "OPEN_RISK_NEAR_LIMIT"
    POSITION_SIZE_ROUNDED_DOWN = "POSITION_SIZE_ROUNDED_DOWN"
    ONLY_PARTIAL_TAKE_PROFITS_PROVIDED = "ONLY_PARTIAL_TAKE_PROFITS_PROVIDED"
