# PHASE 12 — ALERT & NOTIFICATION INFRASTRUCTURE — FINAL REPORT

**Status: PHASE 12 COMPLETE — evidence level IMPLEMENTED + TESTED (synthetic / offline).**
Baseline: `MERWIS_AI_PHASE11.zip`. Phase 13 was **not** started.

| Evidence level | Applies to |
|---|---|
| IMPLEMENTED | every module in `omnisystem_v5/alerts/` |
| TESTED (synthetic, offline) | all of Phase 12 — 189 new tests, real Phase 10/11 objects, in-memory fake transports |
| LIVE_CONNECTED / OBSERVED / VALIDATED_IN_PRODUCTION | **none. Nothing in Phase 12 is, or claims to be, any of these.** No real notification transport exists. |

## 1. Exact results

| Item | Result |
|---|---|
| Phase 1–11 regression (unchanged tests) | **1038 / 1038** |
| Phase 12 new tests | **189** (domain 47 · dedup 22 · routing+envelope+transport+delivery 47 · pipeline/integration/reliability 36 · architecture 28 · determinism 9) |
| Full regression Phase 1–12 | **1227 / 1227 OK** (80 s) |
| Test methods lost from pre-existing test files | **0** (AST-compared against the original ZIP) |
| Assertion calls in the two edited guard files | `test_scanner_engine.py` 138 → 138; `test_marketdata_architecture.py` 41 → 41 (**none removed or weakened**) |
| Frozen Phase 1–11 implementation `.py` files modified | **0** |
| Files in original ZIP / removed / modified / added | 221 / **0** / **2 (guard tests only)** / 26 code+test files (+2 documents: this report, the checkpoint) |

## 2. Baseline verification (done before any change) and the manifest discrepancy

* ZIP integrity OK; uploaded `PHASE11_FINAL_REPORT.md` and `CHECKPOINT_STATUS_PHASE11.md` are byte-identical to the copies in the ZIP.
* Baseline run: 1038/1038.
* **Verified actual manifest baseline: `phase10_frozen_manifest.txt` has 174 entries; 173 are byte-identical and 1 (`tests/test_scanner_engine.py`) differs only by the authorized Phase 11 edit D1.**
* **Historical documentation discrepancy (not a contract violation, not corrected):** `PHASE11_FINAL_REPORT.md` states "176 recorded / 175 identical". The manifest file, its hash (`a81431ca…fff57`) and its own guard test establish 174 / 173(+D1). The Phase 11 report was deliberately **not** rewritten. Nothing in the implementation disagrees with the frozen contract; only that count in the prose is off by two.

## 3. Authorized guard extensions (the only edits to existing files)

Authorized by the project owner as the minimum needed to allow a new `omnisystem_v5/alerts/` package (the Phase 11 guards forbid any unknown package from importing `scanner`/`marketdata` or from adding files). Edits are allowlist extensions only; no assertion was removed or weakened; no implementation file changed.

| ID | File | Change |
|---|---|---|
| P12-G1 | `tests/test_scanner_engine.py` | exemption tuple `("scanner","tests","marketdata")` → `+ "alerts"` (one line) |
| P12-G2 | `tests/test_marketdata_architecture.py` | dependency-direction exemption `("marketdata","tests")` → `+ "alerts"` |
| P12-G3 | `tests/test_marketdata_architecture.py` | `TestFrozenManifest.D1_NEW` updated so the manifest hash check still reverses the (now longer) D1 line back to the recorded Phase 10 value |
| P12-G4 | `tests/test_marketdata_architecture.py` | file allowlist: `omnisystem_v5/alerts/`, `test_alerts_*.py` / `alerts_fixtures.py` / `phase12_guard_manifest.txt`, `PHASE1[12]_*.md` |

Exact pre-change hashes (recorded before editing) and post-change hashes (`tests/phase12_guard_manifest.txt`):

```
a81431ca9a9c4adb25317259b877d8f95fd1280982f9037e80dd39651f0fff57  phase10_frozen_manifest.txt
7aec87fe42ff34092ec30dc0dabf08c6fad74085b06a2823ce429548d802360d  test_marketdata_architecture.py
865ae12d62ab086fe2c2ec2b2596d78f8d976d4b74e499b6f87037cddc68ade0  test_scanner_engine.py

PRE  865ae12d62ab086fe2c2ec2b2596d78f8d976d4b74e499b6f87037cddc68ade0  omnisystem_v5/tests/test_scanner_engine.py
PRE  7aec87fe42ff34092ec30dc0dabf08c6fad74085b06a2823ce429548d802360d  omnisystem_v5/tests/test_marketdata_architecture.py
POST 9c311acd2d60800ea54db25b0c70f0e3cb6e609e90b8cd7b1e13cb9b6c899fb5  omnisystem_v5/tests/test_scanner_engine.py
POST 3c6ae51e5baa911c8b23627fd465f37f5b916c722ada8bfaa49f3865fbdd6568  omnisystem_v5/tests/test_marketdata_architecture.py
```

Exact diffs:

```diff
--- a/test_scanner_engine.py (Phase 11)
+++ b/test_scanner_engine.py (Phase 12)
@@ -525 +525 @@
-            if rel[0] in ("scanner", "tests", "marketdata"):
+            if rel[0] in ("scanner", "tests", "marketdata", "alerts"):
```

```diff
--- a/test_marketdata_architecture.py (Phase 11)
+++ b/test_marketdata_architecture.py (Phase 12)
@@ -50 +50 @@
-            if rel[0] in ("marketdata", "tests"):
+            if rel[0] in ("marketdata", "tests", "alerts"):
@@ -220 +220 @@
-    D1_NEW = 'if rel[0] in ("scanner", "tests", "marketdata"):'
+    D1_NEW = 'if rel[0] in ("scanner", "tests", "marketdata", "alerts"):'      # D1 + Phase 12 authorized edit P12-G1 (adds "alerts" only)
@@ -247 +247 @@
-        allowed = lambda rel: (rel.startswith("omnisystem_v5/marketdata/") or
+        allowed = lambda rel: (rel.startswith("omnisystem_v5/marketdata/") or rel.startswith("omnisystem_v5/alerts/") or
@@ -249 +249,2 @@
-                               re.match(r"omnisystem_v5/PHASE11_\w+\.md$", rel))
+                               re.match(r"omnisystem_v5/tests/(test_alerts_\w+\.py|alerts_fixtures\.py|phase12_guard_manifest\.txt)$", rel) or
+                               re.match(r"omnisystem_v5/PHASE1[12]_\w+\.md$", rel))
```

**Regression protection** (`test_alerts_architecture.py::TestAuthorizedGuardExtensions`): the four edits are recorded as reversible `(new, old)` pairs; reversing them must reproduce the exact Phase 11 hash, and the current files are pinned by hash — **any other edit to either guard file fails the suite**. An AST check proves the exemption tuples are exactly `("scanner","tests","marketdata","alerts")` and `("marketdata","tests","alerts")` — only `alerts/` is exempt. The Phase 10 manifest file itself is pinned (sha256 + 174 lines).

Guard diff result: baseline re-run after the guard edit and before any domain code: **1038/1038**.

## 4. Architecture

```
frozen Phase 10/11 layers                 (read-only)               alerts/  (Phase 12)
─────────────────────────                                          ──────────────────────────────────────────────
ScanReport / ScanSignal ───────────┐
DataSystemSnapshot ────────────────┼──►  sources ─► qualification ─► construction ─► dedup ─► routing ─► envelope
Phase 11 telemetry events ─────────┘     (map_*)    (severity)       (identity)      (verdict)  (decision)  (render)
                                                                                                              │
                          telemetry + audit  ◄──────────  delivery (bounded retry, state machine)  ◄──────────┘
                                                                          │
                                                       NotificationTransport Protocol  (injected; fakes only)
```

Dependency direction is **frozen layers → alerts**, never the reverse; alerts never imports decision / risk / intelligence / quant / data / context / validation / schemas, and never imports `tests`. `pipeline.py` is a thin composition of independent stage modules, not a manager holding their logic.

### Modules (`omnisystem_v5/alerts/`, 18 files)
`enums` · `errors` · `i18n` · `model` · `identity` · `construction` · `policy` · `qualification` · `dedup` · `sources` · `routing` · `envelope` · `transport` · `delivery` · `telemetry` · `audit` · `pipeline` · `__init__`.

### Reuse (verified by identity in tests, not duplicated)
`RetryPolicy`, `compute_delay`, `Throttle`, `ThrottlePolicy`, `emit`, `CompositeSink`, `StructuredMessage`, `InMemoryCatalog`, `Locale`, `canonical_json`, `digest`, the Phase 11 EN/FA tables, `FailureClass`, `classify_fetch_exception`, and the real `InstrumentCatalog` (via `CatalogContextResolver`). Exactly 22 named symbols are imported from frozen layers; the list is pinned by a test.

## 5. Alert domain model
`AlertSource` · `AlertContext` (symbol, instrument, asset class, venue, provider, horizon, direction, timeframe) · `AlertPriority` (the scanner's *computational* ordering, carried unchanged, labelled `COMPUTATIONAL_PRIORITY_NOT_PROBABILITY`) · `AlertCandidate` (source-normalised, no severity/identity/clock) · `AlertIdentity` · `Alert` · `AlertRecord`/`AlertDedupState` · `NotificationTarget` · `NotificationEnvelope` · `DeliveryAttempt`/`DeliveryResult` · `AlertAuditRecord`. All frozen dataclasses, validated in `__post_init__` (fail closed). Names from the brief that were **not** created because they would duplicate an existing concept: `AlertReason` (reasons are Phase 11 `StructuredMessage`s), `AlertLifecycle` (folded into `AlertState` + a transition table), `NotificationChannel` kept, `RetryPolicy` reused, `AlertPolicy` kept as a thin bundle.
Separate concepts, separate types: **source**, **type**, **severity** (policy table), **priority** (scanner ordinal, untouched), **urgency** (routing-derived), **channel**. No probability, confidence or score field exists anywhere (tested). Position size / risk amount are deliberately not carried into alerts.

## 6. Alert lifecycle and deduplication
Identity: `family = digest(version, type, family pairs)`, `fingerprint = digest(family, state pairs)` (20 hex each). Inputs are stable semantic fields only — no wall-clock, random id, pid, address or Python `hash()`. The **source is not part of identity**, so one provider outage seen via snapshot and via event is one condition (tested).

| Verdict | Condition | Notifies |
|---|---|---|
| NEW | no record for the family | yes |
| EXACT_DUPLICATE | observation key already seen (replay) | no |
| STILL_ACTIVE | same fingerprint, newer sighting, `now−last_seen ≤ expiry` | no |
| MATERIAL_CHANGE | same family, different fingerprint (bypasses cooldown, as Phase 10) | yes |
| COOLDOWN | expired alert re-appeared with `now−last_notified < cooldown` | no |
| RENOTIFY | expired alert re-appeared at/after cooldown | yes |
| REDELIVER | previous notification reached nobody; newer sighting; bounded by `max_redeliveries` (default 2) | yes |

`AlertState`: ACTIVE ⇄ EXPIRED (transition table enforced). Boundaries are strict and tested at ±1 s. Expired records are forgotten after `retention_seconds` (bounded state). Observation memory is bounded (documented trade-off: an evicted old key is treated as a newer sighting).
Notifications are not lost silently: if routes existed (or were only *transiently* suppressed by quiet hours / rate limit) and nobody was reached, the record is marked pending and a later sighting redelivers — bounded, visible as `REDELIVER`, never a hidden loop.

## 7. Severity, qualification and sources
Severity = explicit table lookup on a declared fact (`SeverityPolicy`): signal by risk verdict (VALID→NOTICE, WARNING→WARNING), provider by state (UNAVAILABLE→CRITICAL …), instrument by state, system/rollup/cycle by state, data event by kind. Unknown fact ⇒ **no severity ⇒ REJECTED_UNSUPPORTED** (never guessed). `QualificationPolicy.min_severity` default NOTICE.
Qualification outcomes: QUALIFIED · REJECTED_MALFORMED · REJECTED_UNSUPPORTED · REJECTED_UPSTREAM (scanner-suppressed/expired signals — audited, never alerted) · SUPPRESSED_BY_POLICY.
Sources (all read-only, real contracts): `map_signal`/`map_report` (EMITTED, risk-gated, actionable signals only; scanner cycle health), `map_snapshot` (provider / instrument / rollup health), `map_events` (provider & instrument state changes, stale/rejected data, provider errors/rate limits; strict or lenient). Healthy states are mapped only with `include_healthy=True` (recovery alerts are opt-in).

## 8. Routing model
Infrastructure-level only (no users, plans or permissions). `NotificationTarget(target_id, channel, locale, endpoint_ref, rate_limit)`; `endpoint_ref` must be a plain name — URLs/secrets are rejected. `RoutingRule` filters: min severity, sources, types, asset classes, symbols, providers; effect ALLOW/DENY; optional urgency; optional UTC quiet hours (wraps midnight, half-open window). Semantics: DENY overrides ALLOW regardless of order; conflicting ALLOWs take the highest urgency and name the winning rule; per-target rate limit uses the Phase 11 `Throttle` on the injected clock and suppressed routes do not consume budget; output ordered by `(channel, target_id)` — independent of declaration order. Unknown targets / duplicate ids / bad config fail closed at construction. Outcomes: ROUTED / NO_ELIGIBLE_TARGET; suppressions recorded with reason (DENIED_BY_RULE, QUIET_HOURS, RATE_LIMITED).

## 9. Transport boundary and delivery
`NotificationTransport` is a Protocol (`channel`, `send(envelope, timeout_seconds)`); failure = raise. Reference transports: `RecordingTransport`, `InMemoryTransport` (idempotent on `envelope_id`), `ScriptedTransport` (exhausted script fails loudly). `TransportRegistry` binds channel→transport; an unbound/mismatched channel fails closed (`FAILED/CONFIG`). Real channels (push/email/webhook/messaging/SMS) exist only as enum values.
`NotificationEnvelope` cannot be constructed invalid (id format, severity/urgency/verdict types, suppressed verdict refused, ≤12 lines, ≤1000 chars/line, ≤8000 total, no control characters, ≤16000-char canonical JSON payload that must parse as an alert). Payloads are untrusted: nothing is evaluated; hostile `{…}` text in a parameter renders literally (tested). Missing templates degrade to the neutral key string and set `degraded_localization`.

Delivery state machine (`DELIVERY_TRANSITIONS`, enforced at runtime, every path tested as a legal walk):
`PENDING → ATTEMPTING → {DELIVERED | RETRY_SCHEDULED → {ATTEMPTING | FAILED} | FAILED | EXHAUSTED}`, `PENDING → {FAILED | REJECTED}`. Terminal: DELIVERED, FAILED, EXHAUSTED, REJECTED.
Retry (reused Phase 11 `RetryPolicy`/`compute_delay`): attempts capped (default 3), deterministic jittered backoff keyed by `envelope_id`, optional total deadline, injected clock + sleep, **no `time` import**. Retried: timeout, unavailable (if in `retry_on`). Never retried: auth, config, rejected, internal, unknown exceptions. Rate limit: waited only inside `rate_limit_max_wait_seconds`, otherwise reported (`FAILED`, `retry_after_seconds`). A failing transport, sleep or sink affects only its own envelope; `KeyboardInterrupt` is not swallowed; exception **messages are never stored** (class name only).

## 10. Failure model
Reused: `FailureClass`, `classify_fetch_exception`, `TimeoutError`, `ConnectionError`, `ProviderRateLimitedError`. New, scoped, non-overlapping (pinned set of six, tested): `AlertValidationError` (qualification/construction), `AlertConfigError` (config, raised at build time), `PayloadValidationError`, `TransportRejectedError` / `TransportAuthError` / `TransportConfigError` (permanent delivery). `DeliveryFailureKind` exists because `FailureClass` has no AUTH/CONFIG/REJECTED; where they overlap the mapping to `FailureClass` is explicit and tested. Qualification, routing, payload, transport, exhaustion, configuration and permanent failures are distinct and recorded distinctly.

## 11. Localization
Alert core holds only `AlertMessageKey` + structured parameters. 21 keys, EN + FA tables, placeholder sets identical across EN, FA and the declared `REQUIRED_PARAMS` (tested); values disjoint from Phase 11 `MessageKey`. The merged catalog also renders existing Phase 11 reasons (e.g. provider health) so they are reused, not re-worded. Signal envelopes always carry a disclaimer line (informational, no guarantee of profit). Rendering happens only in the envelope builder, per target locale. **The Persian strings are not native-speaker reviewed** (same status as Phase 11). No RTL/UI work.
Note: Phase 11's `MessageKey` is frozen, so alert keys use their own enum; the catalog lookup is by enum member, which works because tables are keyed by both enums (nominal-typing convention already used by Phase 11 for event kinds).

## 12. Telemetry and audit
Reuses Phase 11's `TelemetryEvent`, sinks and the swallow-on-failure `emit`. Kinds: ALERT_CREATED, ALERT_REJECTED, ALERT_DEDUPLICATED, ALERT_SUPPRESSED, ALERT_EXPIRED, ROUTING_DECIDED, DELIVERY_STARTED, DELIVERY_SUCCEEDED, DELIVERY_FAILED, RETRY_SCHEDULED, RETRY_EXHAUSTED, PIPELINE_ERROR (every one exercised by a test). A failing sink/audit log/state store/router is contained, counted (`telemetry_errors`) and never stops the batch.
`AlertAuditRecord` per observation answers: why generated/rejected, source, identity, type, severity, headline key + params, verdict (deduplicated? suppressed?), routing decision (rules, routes, suppressions), every delivery with attempts, failure kind, retry delays and exhaustion, stage failures. Canonical JSON, language-neutral. The in-memory log is bounded (`dropped` counted).

## 13. Persistence boundary
`AlertStateStore` Protocol (`load`/`save`) + `AlertDedupState.to_dict/from_dict` (fail-closed on malformed input). Reference store is **in-memory and transient — not durable; nothing is faked.** A durable implementation must: restore the last state after restart (so EXACT_DUPLICATE/COOLDOWN survive), make `save` atomic, never invent state. Tested seam: state round-trips through plain JSON and a restored process stays idempotent; without restored state a restart re-notifies (documented). Transient: dedup records, rate-limit stamps, audit log. Delivery is **at-most-once at the dedup boundary** (no outbox).

## 14. Security checks (static, enforced by `test_alerts_architecture.py`)
Pinned import allowlist (22 frozen symbols + 8 stdlib modules); no import of network / process / thread / async / filesystem / random / uuid / time / os / sys modules; no wall-clock call, no `eval/exec/compile/open/print/hash/__import__` calls (AST), no dynamic `setattr`; `object.__setattr__` only in the validating model; no URLs, secrets, tokens or long opaque literals; no vendor names; no execution vocabulary or function names; no billing/identity/admin/UI/assistant/Phase-13+ vocabulary; no module-level mutable globals; the only retry loop is the single `while True` in `delivery.py`; endpoints cannot be URLs; no class shadows a frozen scanner/marketdata class (found and fixed during the work: `Route` → `NotificationRoute`); no probability/confidence field.

## 15. Determinism evidence
* In-process: 5 repeated runs byte-identical (mapping, canonical alerts, envelopes, audit JSON, dedup-state JSON, backoff schedule); alert identities identical under two different injected start times.
* Cross-interpreter: whole real-scanner + real-marketdata scenario hashed under `PYTHONHASHSEED` 0, 1, 42, 2026 (separate processes) — all equal, and equal to the in-process value:
  `5b00e42fe5c496e1c2c03706ca122d992f29f8ab074e48d2bb4102e9ae942cd6`
* Identity/canonical alert and dedup verdict sequences also verified under five seeds.

## 16. Performance measurements (CPython 3.12.3, single thread, measured ad hoc — not asserted in tests)
| Operation | Measured |
|---|---|
| identity compute | ≈ 29 µs |
| alert construction | ≈ 34 µs |
| end-to-end pipeline, 2 targets, delivered, audit + telemetry on | ≈ 1.1 ms / alert |
| dedup state, 100 / 1 000 / 3 000 active families | ≈ 90 / 280 / 800 µs per observation |

**Finding:** `observe()` rebuilds a sorted tuple, so cost is O(active families) per observation (O(n²) over a burst). Fine for the intended scale (tens to hundreds of concurrently active alert families, bounded by expiry/retention); not fixed, because changing the state representation is outside Phase 12 scope and would be speculative. See §17.

## 17. Known limitations (all accepted unless stated)
1. No real transport, no credentials, no network — by design; every delivery result is from fakes.
2. In-memory state is not durable; delivery is at-most-once at the dedup boundary (no outbox).
3. Dedup state lookup is O(n) per observation (see §16).
4. Bounded observation memory: an observation evicted from memory is treated as a newer sighting.
5. Quiet hours are UTC only (no time zones/DST) and *suppress* rather than queue; the pending/redeliver mechanism is what prevents loss.
6. Transport timeouts are passed down but enforced only by the transport (no threads in the core).
7. Persian alert strings are not native-speaker reviewed.
8. Alerts do not carry position size / risk amount by design; no probability/confidence exists because no frozen contract defines one.
9. Per-observation audit records for every scanner-suppressed signal grow with scanner volume (bounded by the audit log cap).
10. Inherited and untouched: forex 4h/1d SHORT_SWING scanner gate; `KlinesRestAdapter` IMPLEMENTED — NOT LIVE-VERIFIED; no live HTTP, no forex vendor adapter, no cross-provider failover, no health persistence, no holiday calendar, no real quote-serving path.
11. The historical Phase 11 manifest-count wording (§2) is left as written.

## 18. Deferred work
Real transports behind the Protocol; durable `AlertStateStore` + outbox; reminder cadence for long-active alerts; per-user/subscription routing (later identity/product phases); time-zone-aware quiet hours; native FA review; O(1) dedup index if scale demands; operator-facing alert console (UI, later phase).

## 19. Files
**Created (26 code/test files + 2 documents):** `alerts/` ×18 (above) · `tests/alerts_fixtures.py` · `tests/phase12_guard_manifest.txt` · `tests/test_alerts_{domain,dedup,routing_delivery,pipeline,architecture,determinism}.py` · this report · `CHECKPOINT_STATUS_PHASE12.md` (repo root).
**Modified (2, guard allowlists only — §3):** `tests/test_scanner_engine.py`, `tests/test_marketdata_architecture.py`.
**Not modified:** every other Phase 1–11 file (byte-compared against the original ZIP).

## 20. Exact next phase
**Phase 13 — Premium UX + MERWIS TRADER LAB (Trader Experience).** Not started. Phase 12 leaves it a stable, language-neutral alert/envelope/audit surface to present.
