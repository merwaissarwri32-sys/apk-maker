"""Kivy-free test runner for the MERWIS AI test APK."""
import importlib
import io
import os
import pkgutil
import sys
import time
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def quick_check():
    """Import every non-test module of omnisystem_v5."""
    import omnisystem_v5
    ok, bad = 0, []
    for m in pkgutil.walk_packages(omnisystem_v5.__path__, "omnisystem_v5."):
        if ".tests" in m.name:
            continue
        try:
            importlib.import_module(m.name)
            ok += 1
        except Exception as e:  # noqa
            bad.append("%s: %s: %s" % (m.name, type(e).__name__, e))
    head = "QUICK CHECK: %d modules imported OK, %d failed" % (ok, len(bad))
    return head + ("\n" + "\n".join(bad[:20]) if bad else "\nALL GOOD")


class _Live(unittest.TextTestResult):
    tick = None

    def startTest(self, test):
        super().startTest(test)
        if _Live.tick:
            _Live.tick(self.testsRun)


def run_tests(progress=None, pattern="test*.py"):
    start = os.path.join(ROOT, "omnisystem_v5", "tests")
    suite = unittest.defaultTestLoader.discover(start, pattern=pattern, top_level_dir=ROOT)
    total = suite.countTestCases()
    if progress:
        progress(0, total)
    _Live.tick = (lambda n: progress(n, total)) if progress else None
    buf = io.StringIO()
    t0 = time.time()
    res = unittest.TextTestRunner(stream=buf, verbosity=0, resultclass=_Live).run(suite)
    secs = time.time() - t0
    status = "PASS" if res.wasSuccessful() else "FAIL"
    out = "%s: ran %d/%d tests in %.0fs | failures=%d errors=%d skipped=%d" % (
        status, res.testsRun, total, secs, len(res.failures), len(res.errors), len(res.skipped))
    if not res.wasSuccessful():
        out += "\n\n" + buf.getvalue()[-6000:]
    return out
